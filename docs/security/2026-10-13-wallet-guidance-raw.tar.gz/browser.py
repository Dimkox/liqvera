import asyncio,json,pathlib,subprocess,urllib.request,time,base64
from websockets.asyncio.client import connect
out=pathlib.Path('/tmp/liqvera-wallet-guidance');opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
chrome=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--no-sandbox','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-address=127.0.0.1','--remote-debugging-port=19239','--user-data-dir='+str(out/'network-profile'),'about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
async def main():
 for _ in range(40):
  try:tabs=json.load(opener.open('http://127.0.0.1:19239/json'));break
  except OSError:await asyncio.sleep(.25)
 tab=next(x for x in tabs if x['type']=='page');errors=[];seq=0
 async with connect(tab['webSocketDebuggerUrl'],proxy=None) as ws:
  async def cmd(method,params={}):
   nonlocal seq
   seq+=1;ident=seq;await ws.send(json.dumps({'id':ident,'method':method,'params':params}))
   while True:
    item=json.loads(await ws.recv())
    if item.get('method')=='Runtime.exceptionThrown':errors.append(item['params'])
    if item.get('method')=='Fetch.requestPaused':
     event=item['params'];headers=event['request']['headers'];headers['Origin']='https://liqvera.site'
     await ws.send(json.dumps({'id':100000+seq,'method':'Fetch.continueRequest','params':{'requestId':event['requestId'],'headers':[{'name':k,'value':v} for k,v in headers.items()]}}))
    if item.get('id')==ident:
     if 'error' in item:raise RuntimeError(item['error'])
     return item.get('result',{})
  await cmd('Runtime.enable');await cmd('Page.enable')
  await cmd('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
  await cmd('Fetch.enable',{'patterns':[{'urlPattern':'http://127.0.0.1:18088/v1/*','requestStage':'Request'}]})
  await cmd('Page.addScriptToEvaluateOnNewDocument',{'source':"""
window.__chain='0x1';window.__known=false;window.__calls=[];
window.ethereum={request:async({method,params})=>{
 window.__calls.push(method);
 if(method==='eth_accounts'||method==='eth_requestAccounts')return ['0x1111111111111111111111111111111111111111'];
 if(method==='eth_chainId')return window.__chain;
 if(method==='wallet_switchEthereumChain'){
  if(!window.__known)throw {code:4902};
  window.__chain=params[0].chainId;return null;
 }
 if(method==='wallet_addEthereumChain'){window.__known=true;return null;}
 if(method==='eth_signTypedData_v4'){window.__signs=(window.__signs||0)+1;throw {code:4001};}
 throw new Error('No transaction allowed by this test');
},on(){},removeListener(){}};
"""})
  await cmd('Page.navigate',{'url':'http://127.0.0.1:18088/'})
  for _ in range(60):
   r=await cmd('Runtime.evaluate',{'expression':"document.querySelector('#capability-status')?.textContent.includes('Gateway payment ready')",'returnByValue':True})
   if r['result'].get('value'):break
   await asyncio.sleep(.1)
  r=await cmd('Runtime.evaluate',{'expression':"({disabled:document.querySelector('#create-button').disabled,note:document.querySelector('#create-note').textContent,wallet:document.querySelector('#wallet-label').textContent})",'returnByValue':True})
  print('before request:',json.dumps(r['result']['value']),flush=True)
  assert not r['result']['value']['disabled'],'Connected account on another chain cannot request report'
  await cmd('Runtime.evaluate',{'expression':"document.querySelector('#quantity').value='0.01';document.querySelector('#create-button').click()"})
  for _ in range(140):
   r=await cmd('Runtime.evaluate',{'expression':"Array.from(document.querySelectorAll('#result-content button')).some(b=>b.textContent.includes('payment in wallet'))",'returnByValue':True})
   if r['result'].get('value'):break
   await asyncio.sleep(.2)
  assert r['result'].get('value'),'Fresh report quote did not become ready'
  r=await cmd('Runtime.evaluate',{'expression':"({paymentDisabled:Array.from(document.querySelectorAll('#result-content button')).find(b=>b.textContent.includes('payment in wallet')).disabled,chain:window.__chain,signs:window.__signs||0})",'returnByValue':True})
  print('quote ready:',json.dumps(r['result']['value']),flush=True)
  assert r['result']['value']=={'paymentDisabled':True,'chain':'0x1','signs':0}
  await cmd('Runtime.evaluate',{'expression':"document.querySelector('#switch-button').click()"})
  for _ in range(60):
   r=await cmd('Runtime.evaluate',{'expression':"Array.from(document.querySelectorAll('#result-content button')).some(b=>b.textContent.includes('payment in wallet')&&!b.disabled)",'returnByValue':True})
   if r['result'].get('value'):break
   await asyncio.sleep(.1)
  diag=await cmd('Runtime.evaluate',{'expression':"({chain:window.__chain,calls:window.__calls,notice:document.querySelector('#announcement').textContent})",'returnByValue':True})
  print('network:',json.dumps(diag['result']['value']),flush=True)
  assert r['result'].get('value'),'Adding chain without selecting it did not recover payment readiness'
  await cmd('Runtime.evaluate',{'expression':"Array.from(document.querySelectorAll('#result-content button')).find(b=>b.textContent.includes('payment in wallet')).click()"})
  for _ in range(60):
   r=await cmd('Runtime.evaluate',{'expression':"({signs:window.__signs||0,notice:document.querySelector('#announcement').textContent})",'returnByValue':True})
   if 'canceled before submission' in r['result'].get('value',{}).get('notice',''):break
   await asyncio.sleep(.1)
  print('payment boundary:',json.dumps(r['result']['value']),flush=True)
  assert r['result']['value']['signs']==1 and 'canceled before submission' in r['result']['value']['notice']
  assert not errors,errors
try:asyncio.run(asyncio.wait_for(main(), timeout=55))
finally:chrome.terminate();chrome.wait(timeout=10)
