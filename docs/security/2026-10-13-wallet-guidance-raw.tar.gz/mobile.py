import asyncio,json,pathlib,subprocess,urllib.request,time,base64
from websockets.asyncio.client import connect
out=pathlib.Path('/tmp/liqvera-wallet-guidance');opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
chrome=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--no-sandbox','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-address=127.0.0.1','--remote-debugging-port=19239','--user-data-dir='+str(out/'mobile-deployed-profile'),'about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
async def main():
 for _ in range(40):
  try:tabs=json.load(opener.open('http://127.0.0.1:19239/json'));break
  except OSError:await asyncio.sleep(.25)
 tab=next(x for x in tabs if x['type']=='page');errors=[];seq=0
 async with connect(tab['webSocketDebuggerUrl'],proxy=None) as ws:
  async def cmd(method,params={}):
   nonlocal seq
   seq+=1;ident=seq;await ws.send(json.dumps({'id':ident,'method':method,'params':params}))
   while True:
    item=json.loads(await ws.recv())
    if item.get('method')=='Runtime.exceptionThrown':errors.append(item['params'])
    if item.get('method')=='Fetch.requestPaused':
     event=item['params'];headers=event['request']['headers'];headers['Origin']='https://liqvera.site'
     await ws.send(json.dumps({'id':100000+seq,'method':'Fetch.continueRequest','params':{'requestId':event['requestId'],'headers':[{'name':k,'value':v} for k,v in headers.items()]}}))
    if item.get('id')==ident:
     if 'error' in item:raise RuntimeError(item['error'])
     return item.get('result',{})
  await cmd('Runtime.enable');await cmd('Page.enable')
  await cmd('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
  await cmd('Fetch.enable',{'patterns':[{'urlPattern':'http://127.0.0.1:18088/v1/*','requestStage':'Request'}]})
  await cmd('Page.navigate',{'url':'http://127.0.0.1:18088/'})
  for _ in range(40):
   r=await cmd('Runtime.evaluate',{'expression':"!!document.querySelector('#historical-button')",'returnByValue':True})
   if r['result'].get('value'):break
   await asyncio.sleep(.2)
  network=await cmd('Runtime.evaluate',{'expression':"document.querySelector('.network-chip').innerText",'returnByValue':True});assert 'MEZO TESTNET' in network['result']['value']
  await cmd('Runtime.evaluate',{'expression':"document.querySelector('#connect-button').click()"})
  await asyncio.sleep(.3)
  r=await cmd('Runtime.evaluate',{'expression':"({notice:document.querySelector('#announcement').innerText,trustLink:document.querySelector('#trust-wallet-link')?.href||null,helpVisible:!!document.querySelector('#wallet-help')&&!document.querySelector('#wallet-help').classList.contains('hidden')})",'returnByValue':True})
  observed=r['result']['value'];print(json.dumps(observed));(out/'mobile-no-provider.json').write_text(json.dumps(observed,indent=2)+'\n')
  assert observed['trustLink'] and observed['helpVisible'],'No mobile connection route'
  assert 'your EVM wallet' in observed['notice'],'Mobile guidance still requires a specific brand'

try:asyncio.run(asyncio.wait_for(main(), timeout=55))
finally:chrome.terminate();chrome.wait(timeout=10)
