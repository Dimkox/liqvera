import asyncio,json,pathlib,subprocess,urllib.request,time,base64
from websockets.asyncio.client import connect
out=pathlib.Path('/tmp/liqvera-request-button');opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
chrome=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--no-sandbox','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-address=127.0.0.1','--remote-debugging-port=19239','--user-data-dir='+str(out/'race-profile'),'about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
async def main():
 for _ in range(40):
  try:tabs=json.load(opener.open('http://127.0.0.1:19239/json'));break
  except OSError:await asyncio.sleep(.25)
 tab=next(x for x in tabs if x['type']=='page');errors=[];seq=0
 async with connect(tab['webSocketDebuggerUrl'],proxy=None) as ws:
  async def cmd(method,params={}):
   nonlocal seq
   seq+=1;ident=seq;await ws.send(json.dumps({'id':ident,'method':method,'params':params}))
   while True:
    item=json.loads(await ws.recv())
    if item.get('method')=='Runtime.exceptionThrown':errors.append(item['params'])
    if item.get('method')=='Fetch.requestPaused':
     event=item['params'];headers=event['request']['headers'];headers['Origin']='https://liqvera.site'
     await ws.send(json.dumps({'id':100000+seq,'method':'Fetch.continueRequest','params':{'requestId':event['requestId'],'headers':[{'name':k,'value':v} for k,v in headers.items()]}}))
    if item.get('id')==ident:
     if 'error' in item:raise RuntimeError(item['error'])
     return item.get('result',{})
  await cmd('Runtime.enable');await cmd('Page.enable')
  await cmd('Fetch.enable',{'patterns':[{'urlPattern':'http://127.0.0.1:18088/v1/*','requestStage':'Request'}]})
  await cmd('Page.addScriptToEvaluateOnNewDocument',{'source':"""
const oldListeners = {};
window.ethereum = {request:async({method})=>{
 if(method==='eth_accounts')return window.__delayOld ? new Promise(resolve=>window.__releaseOld=()=>resolve([])) : [];
 if(method==='eth_chainId')return '0x7b7b';throw new Error(method);
},on:(event,listener)=>oldListeners[event]=listener,removeListener:(event)=>delete oldListeners[event]};
window.__startOld=()=>{window.__delayOld=true;oldListeners.accountsChanged([]);};
window.__announceTrust=()=>window.dispatchEvent(new CustomEvent('eip6963:announceProvider',{detail:{
 info:{uuid:'11111111-1111-4111-8111-111111111111',name:'Trust Wallet',rdns:'com.trustwallet.app',icon:'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg"/>'},
 provider:{request:async({method})=>{
  if(method==='eth_requestAccounts'||method==='eth_accounts')return ['0x1111111111111111111111111111111111111111'];
  if(method==='eth_chainId')return '0x7b7b';if(method==='wallet_switchEthereumChain')return null;throw new Error(method);
 },on(){},removeListener(){}}
}}));
"""})
  await cmd('Page.navigate',{'url':'http://127.0.0.1:18088/'})
  for _ in range(60):
   r=await cmd('Runtime.evaluate',{'expression':"document.querySelector('#create-note')?.textContent",'returnByValue':True})
   if r['result'].get('value')=='Connect an injected wallet to continue.':break
   await asyncio.sleep(.1)
  await cmd('Runtime.evaluate',{'expression':"window.__startOld()"})
  await asyncio.sleep(.1)
  await cmd('Runtime.evaluate',{'expression':"window.__announceTrust();document.querySelector('#connect-button').click()"})
  for _ in range(50):
   r=await cmd('Runtime.evaluate',{'expression':"!document.querySelector('#create-button').disabled",'returnByValue':True})
   if r['result'].get('value'):break
   await asyncio.sleep(.1)
  assert r['result'].get('value'),'Trust connection never became ready'
  await cmd('Runtime.evaluate',{'expression':"window.__releaseOld()"})
  await asyncio.sleep(.2)
  r=await cmd('Runtime.evaluate',{'expression':"({disabled:document.querySelector('#create-button').disabled,note:document.querySelector('#create-note').textContent,wallet:document.querySelector('#wallet-label').textContent})",'returnByValue':True})
  observed=r['result']['value'];print(json.dumps(observed))
  assert not observed['disabled'],'Old wallet response erased connected Trust account'
  assert not errors,errors
try:asyncio.run(asyncio.wait_for(main(), timeout=55))
finally:chrome.terminate();chrome.wait(timeout=10)
