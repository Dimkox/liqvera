import asyncio,json,pathlib,subprocess,urllib.request,base64
from websockets.asyncio.client import connect
out=pathlib.Path('/tmp/liqvera-appkit');opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
chrome=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--no-sandbox','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-address=127.0.0.1','--remote-debugging-port=19239','--user-data-dir='+str(out/'browser-profile'),'about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
async def main():
 for _ in range(40):
  try:tabs=json.load(opener.open('http://127.0.0.1:19239/json'));break
  except OSError:await asyncio.sleep(.25)
 tab=next(x for x in tabs if x['type']=='page');errors=[];seq=0
 async with connect(tab['webSocketDebuggerUrl'],proxy=None) as ws:
  async def cmd(method,params={}):
   nonlocal seq
   seq+=1;ident=seq;await ws.send(json.dumps({'id':ident,'method':method,'params':params}))
   while True:
    item=json.loads(await ws.recv())
    if item.get('method')=='Runtime.exceptionThrown':errors.append(item['params']['exceptionDetails'].get('text'))
    if item.get('id')==ident:
     if 'error' in item:raise RuntimeError(item['error'])
     return item.get('result',{})
  async def evaluate(expr):
   r=await cmd('Runtime.evaluate',{'expression':expr,'returnByValue':True,'awaitPromise':True})
   if 'exceptionDetails' in r:raise RuntimeError(r['exceptionDetails'])
   return r['result'].get('value')
  await cmd('Runtime.enable');await cmd('Page.enable')
  await cmd('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
  await cmd('Page.addScriptToEvaluateOnNewDocument',{'source':"window.csp=[];document.addEventListener('securitypolicyviolation',e=>window.csp.push({directive:e.effectiveDirective,blocked:e.blockedURI.split('?')[0]}));window.deep=(selector,root=document)=>[...root.querySelectorAll(selector),...[...root.querySelectorAll('*')].filter(e=>e.shadowRoot).flatMap(e=>window.deep(selector,e.shadowRoot))];"})
  await cmd('Page.navigate',{'url':'http://localhost:18089/'})
  for _ in range(40):
   if await evaluate("!!document.querySelector('#connect-button')"):break
   await asyncio.sleep(.25)
  await evaluate("document.querySelector('#connect-button').click()")
  await asyncio.sleep(12)
  result=await evaluate("({notice:document.querySelector('#announcement').innerText,csp:window.csp,modal:!!document.querySelector('w3m-modal'),texts:deep('button').map(e=>e.innerText),walletButtons:deep('w3m-wallet-button').map(e=>({name:e.name,tag:e.tagName})),body:deep('w3m-connect-view').map(e=>e.shadowRoot?.textContent.slice(-2000))})")
  assert result['modal'] and 'WalletConnect\nQR CODE' in result['texts']
  await evaluate("deep('button').find(e=>e.innerText.includes('WalletConnect')).click()")
  await asyncio.sleep(12)
  result['qr']=await evaluate("({qr:deep('wui-qr-code').map(e=>({hasUri:typeof e.uri==='string'&&e.uri.startsWith('wc:'),hasSvg:!!e.shadowRoot?.querySelector('svg')})),csp:window.csp,buttons:deep('button').map(e=>e.innerText)})")
  result['exceptions']=errors
  print(json.dumps(result,indent=2));(out/'qr.json').write_text(json.dumps(result,indent=2)+'\n')
  shot=await cmd('Page.captureScreenshot',{'format':'png'});(out/'qr.png').write_bytes(base64.b64decode(shot['data']))
try:asyncio.run(asyncio.wait_for(main(),timeout=55))
finally:chrome.terminate();chrome.wait(timeout=10)
