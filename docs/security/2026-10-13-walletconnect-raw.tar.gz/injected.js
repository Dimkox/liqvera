window.__chain='0x7b7b';window.__connected=sessionStorage.getItem('acceptance-wallet-connected')==='true';window.__calls=[];window.__signs=0;
const listeners=new Map();window.__emit=(event,...args)=>{for(const cb of listeners.get(event)||[])cb(...args)};
window.ethereum={request:async({method,params})=>{
 window.__calls.push(method);
 const accounts=['0x1111111111111111111111111111111111111111'];
 if(method==='eth_requestAccounts'){window.__connected=true;sessionStorage.setItem('acceptance-wallet-connected','true');return accounts;}
 if(method==='eth_accounts')return window.__connected?accounts:[];
 if(method==='eth_chainId')return window.__chain;
 if(method==='wallet_addEthereumChain'){window.__known=true;return null;}
 if(method==='wallet_switchEthereumChain'){if(window.__known===false)throw {code:4902};window.__chain=params[0].chainId;window.__emit('chainChanged',window.__chain);return null;}
 if(method==='wallet_getPermissions'||method==='wallet_requestPermissions')return [{parentCapability:'eth_accounts'}];
 if(method==='wallet_revokePermissions'){window.__connected=false;sessionStorage.removeItem('acceptance-wallet-connected');window.__emit('accountsChanged',[]);return null;}
 if(method==='eth_getBalance'||method==='eth_blockNumber')return '0x0';
 if(method==='eth_signTypedData_v4'){window.__signs++;throw {code:4001};}
 throw new Error('No transaction allowed by this test: '+method);
},on(event,cb){if(!listeners.has(event))listeners.set(event,new Set());listeners.get(event).add(cb);},removeListener(event,cb){listeners.get(event)?.delete(cb)}};
const announce=()=>window.dispatchEvent(new CustomEvent('eip6963:announceProvider',{detail:{info:{uuid:'00000000-0000-4000-8000-000000000001',name:'Acceptance wallet',icon:'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4=',rdns:'test.liqvera'},provider:window.ethereum}}));
window.addEventListener('eip6963:requestProvider',announce);announce();
