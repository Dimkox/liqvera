import asyncio,json,pathlib,subprocess,urllib.request,base64
from websockets.asyncio.client import connect
out=pathlib.Path('/tmp/liqvera-appkit');opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
chrome=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--no-sandbox','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-address=127.0.0.1','--remote-debugging-port=19239','--user-data-dir='+str(out/'injected-add-restore-profile'),'about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
async def main():
 for _ in range(40):
  try:tabs=json.load(opener.open('http://127.0.0.1:19239/json'));break
  except OSError:await asyncio.sleep(.25)
 tab=next(x for x in tabs if x['type']=='page');errors=[];seq=0
 async with connect(tab['webSocketDebuggerUrl'],proxy=None) as ws:
  async def cmd(method,params={}):
   nonlocal seq
   seq+=1;ident=seq;await ws.send(json.dumps({'id':ident,'method':method,'params':params}))
   while True:
    item=json.loads(await ws.recv())
    if item.get('method')=='Runtime.exceptionThrown':errors.append(item['params']['exceptionDetails'].get('text'))
    if item.get('id')==ident:
     if 'error' in item:raise RuntimeError(item['error'])
     return item.get('result',{})
  async def evaluate(expr):
   r=await cmd('Runtime.evaluate',{'expression':expr,'returnByValue':True,'awaitPromise':True})
   if 'exceptionDetails' in r:raise RuntimeError(r['exceptionDetails'])
   return r['result'].get('value')
  await cmd('Runtime.enable');await cmd('Page.enable')
  await cmd('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
  await cmd('Page.addScriptToEvaluateOnNewDocument',{'source':"window.csp=[];document.addEventListener('securitypolicyviolation',e=>window.csp.push({directive:e.effectiveDirective,blocked:e.blockedURI.split('?')[0]}));window.deep=(selector,root=document)=>[...root.querySelectorAll(selector),...[...root.querySelectorAll('*')].filter(e=>e.shadowRoot).flatMap(e=>window.deep(selector,e.shadowRoot))];"})
  await cmd('Page.addScriptToEvaluateOnNewDocument',{'source':(out/'injected.js').read_text()})
  await cmd('Page.navigate',{'url':'http://localhost:18089/'})
  for _ in range(40):
   if await evaluate("!!document.querySelector('#connect-button')"):break
   await asyncio.sleep(.25)
  await evaluate("document.querySelector('#connect-button').click()")
  await asyncio.sleep(12)
  print('bundle:',await evaluate("[...document.scripts].map(e=>e.src)"),flush=True)
  texts=await evaluate("deep('button').map(e=>e.innerText)")
  print('choices:',texts,flush=True)
  await evaluate("deep('button').find(e=>e.innerText.includes('Acceptance wallet')).click()")
  for _ in range(80):
   if await evaluate("!document.querySelector('#create-button').disabled"):break
   await asyncio.sleep(.2)
  state=await evaluate("({disabled:document.querySelector('#create-button').disabled,wallet:document.querySelector('#wallet-label').innerText,notice:document.querySelector('#announcement').innerText,signs:window.__signs})")
  print('connected:',state,flush=True)
  assert not state['disabled'] and state['signs']==0
  await evaluate("window.__chain='0x1';window.__emit('chainChanged','0x1')")
  await asyncio.sleep(.5)
  assert await evaluate("!document.querySelector('#create-button').disabled")
  await evaluate("document.querySelector('#quantity').value='0.01';document.querySelector('#create-button').click()")
  for _ in range(180):
   if await evaluate("!![...document.querySelectorAll('#result-content button')].find(e=>e.innerText.includes('payment in wallet'))"):break
   await asyncio.sleep(.2)
  state=await evaluate("({disabled:[...document.querySelectorAll('#result-content button')].find(e=>e.innerText.includes('payment in wallet'))?.disabled,signs:window.__signs,notice:document.querySelector('#announcement').innerText})")
  print('quote:',state,flush=True)
  assert state['disabled'] and state['signs']==0
  await evaluate("window.__known=false;document.querySelector('#switch-button').click()")
  for _ in range(40):
   if await evaluate("![...document.querySelectorAll('#result-content button')].find(e=>e.innerText.includes('payment in wallet')).disabled"):break
   await asyncio.sleep(.2)
  await evaluate("[...document.querySelectorAll('#result-content button')].find(e=>e.innerText.includes('payment in wallet')).click()")
  for _ in range(40):
   if await evaluate("document.querySelector('#announcement').innerText.includes('canceled before submission')"):break
   await asyncio.sleep(.2)
  state=await evaluate("({signs:window.__signs,notice:document.querySelector('#announcement').innerText,csp:window.csp})")
  print('payment:',state,flush=True)
  assert state['signs']==1 and 'canceled before submission' in state['notice']
  await evaluate("document.querySelector('#connect-button').click()")
  await asyncio.sleep(1)
  await evaluate("deep('[data-testid=disconnect-button]')[0].click()")
  for _ in range(40):
   if await evaluate("document.querySelector('#wallet-label').innerText==='No wallet connected'"):break
   await asyncio.sleep(.2)
  disconnected=await evaluate("({wallet:document.querySelector('#wallet-label').innerText,paymentDisabled:[...document.querySelectorAll('#result-content button')].find(e=>e.innerText.includes('payment in wallet')).disabled,hasQuote:!!document.querySelector('.quote-state')})")
  print('disconnect:',disconnected,flush=True)
  assert disconnected=={'wallet':'No wallet connected','paymentDisabled':True,'hasQuote':True}
  await evaluate("document.querySelector('#connect-button').click()")
  await asyncio.sleep(1)
  await evaluate("deep('button').find(e=>e.innerText.includes('Acceptance wallet')).click()")
  for _ in range(40):
   if await evaluate("document.querySelector('#wallet-label').innerText.includes('0x111111')"):break
   await asyncio.sleep(.2)
  reconnected=await evaluate("({wallet:document.querySelector('#wallet-label').innerText,paymentDisabled:[...document.querySelectorAll('#result-content button')].find(e=>e.innerText.includes('payment in wallet')).disabled,signs:window.__signs,csp:window.csp})")
  print('reconnect:',reconnected,flush=True)
  print('debug:',await evaluate("({calls:window.__calls,connected:window.__connected,chain:window.__chain,texts:deep('wui-text').map(e=>e.textContent)})"),flush=True)
  assert '0x111111' in reconnected['wallet'] and not reconnected['paymentDisabled'] and reconnected['signs']==1
  assert not reconnected['csp'] and not errors
  assert await evaluate("window.__calls.includes('wallet_addEthereumChain')")
  await cmd('Page.reload')
  for _ in range(80):
   if await evaluate("document.querySelector('#wallet-label')?.innerText.includes('0x111111')&&!!document.querySelector('.quote-state')"):break
   await asyncio.sleep(.2)
  restored=await evaluate("({wallet:document.querySelector('#wallet-label').innerText,hasQuote:!!document.querySelector('.quote-state'),signs:window.__signs,csp:window.csp})")
  print('restored:',restored,flush=True)
  assert '0x111111' in restored['wallet'] and restored['hasQuote'] and restored['signs']==0 and not restored['csp']
  (out/'injected-result.json').write_text(json.dumps({'payment':state,'disconnect':disconnected,'reconnect':reconnected,'restored':restored,'exceptions':errors},indent=2)+'\n')
try:asyncio.run(asyncio.wait_for(main(),timeout=110))
finally:chrome.terminate();chrome.wait(timeout=10)
