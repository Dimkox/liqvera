Wave 1 preserves Liqvera’s existing architecture. The audit should verify the browser funding extension and its interaction with existing payment guards, then run Liqvera’s own product checks alongside Getzilla. Getzilla’s optional architecture model is absent by design.

Source identity:

- Liqvera HEAD: `87b66c0d53cc276eae41b437f616346c33a28e98`; tree: `9b5ec7523543bb8591890db1b8ad885e1e16cf1e`.
- Application implementation: `9ca9ceda79fbce07b9b9bfb1dcc174d4c300b863`.
- Comparison base and observed `origin/main`: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`.
- Getzilla PR #115 merge: `2bb417431f1e4b9494e4af71ebf27adb1d04d898`; tree: `81076df2cd7db8713f7178ead66ebaa2728f861e`.
- Base is the merge-base and an ancestor of HEAD. All locally published tags `v0.0.1`–`v0.0.5` are ancestors. Worktrees were inventoried; none were changed.
- `reviewed-tree-modified: no`. Before/after HEAD and tree matched; working status was clean.

The 33-file delta contains four browser source/declaration files, three browser tests, and documentation/evidence. `git diff --quiet BASE..HEAD -- apps/mezo-gateway services packages schemas deploy acceptance` exited 0. No gateway, ledger, migration, report, capture, protocol, deployment configuration or existing API schema changed.

The architecture invariants and useful verification targets are:

| Invariant | Source authority | Audit check |
|---|---|---|
| One browser/API product; public capture remains read-only; sealed report inputs and outputs retain integrity. | `AGENTS.md:7–17`; `docs/architecture.md:3–27`; `docs/specification.md:5–30` | Preserve component inventory; run Python, artifact/package-boundary and offline verifier checks. Do not introduce a second app or delivery-framework runtime dependency. |
| Funding has no payment authority. Its permitted RPC methods are account/chain reads, block reads and `eth_call`. | `apps/mezo-web/src/mezo-finance.mjs:83–151`; `mezo-finance-panel.ts:119–150` | Assert the RPC allowlist and absence of signing, approval, transfer, loan submission and paid-report requests. Mounting, refresh, download and external-app return must not initiate payment. |
| Funding is bound to the current payer, selected provider, configured chain/token, unexpired READY quote and clear payment guard. | `mezo-finance.mjs:39–62`; `mezo-finance-panel.ts:79–137`; `main.ts:169–174` | Probe provider/account/network/quote changes, busy/polling state, uncertain payment, expiry, delayed results and disposal. Verify stale downloads are revoked and borrowing becomes unavailable. |
| Observations use exact integers and a bounded, block-specific read. | `mezo-finance.mjs:10–28,109–150` | Check explicit block-number `balanceOf`, block-hash recheck, final identity recheck, shared deadline, malformed metadata, one-wei shortfall, floor-divided purchase budget and both networks. |
| Observations remain advisory; wallet/RPC output cannot establish entitlement. | `docs/competition/wave1-musd-funding.md:60–64`; `mezo-finance-panel.ts:107–109` | Keep observation/export assertions separate from signed chain proof, reserved funds, borrowing, payment and report evidence. |
| Settlement remains durable and single-submit; unknown outcomes are confirm-only. | `apps/mezo-gateway/src/application/gateway.ts:82–143`; `src/adapters/postgres.ts:147–189`; `src/security/payment-policy.ts:73–85` | Preserve artifact readback before settlement, atomic SUBMITTING transition, cross-quote nonce uniqueness, exact payment terms, canonical receipt/finality checks and repeated delivery without resettlement. Run gateway tests including disposable PostgreSQL cases. |

Relevant browser coverage is in `mezo-finance.test.mjs`, `musd-observation.test.mjs`, `mezo-finance-panel.test.mjs`, and existing orchestration/wallet tests. The documented synthetic entrypoint check in `docs/competition/2026-10-21-funding/dom-smoke.mjs` additionally checks one quote, unchanged saved flow, no signing and no paid-report request. Its JSDOM result is not real wallet interoperability evidence.

Actual API and state contracts remain under `schemas/mezo-evidence/v1/`. Meaningful verification includes `tests/contracts/test_mezo_openapi.py`, `test_mezo_resources.py`, `test_mezo_requests.py`, `test_mezo_states.py` and `test_mezo_vectors.py`; gateway runtime validation and database tests complement those static contracts. Preserve migration bytes and use only the explicitly disposable database boundary documented at `docs/validation.md:14` and enforced by `apps/mezo-gateway/test/postgres.test.ts:20–54`.

Two external-tool coverage limitations were reproduced using read-only Python helper calls against the exact sources:

| Probe | Observed result | Interpretation |
|---|---|---|
| `_architecture_preflight_check(audit_root)` | `skip`: “architecture authority inputs are absent; not executed” | Expected. Liqvera has no `architecture/system.yaml`, `rules.yaml` or `adoption.json`. Getzilla explicitly supports absence: `.getzilla/getzilla/architecture.py:877–889`; `verification.py:203–224`. |
| `_node(audit_root, "pr")`, followed by the Node stack classifier | Zero Node checks; nested Node packages detected; metadata `builtin:["node"]`, `checked:[]`, `not_verified:[]` | **Material coverage gap.** The Node runner requires root `package.json`, while the stack classifier assumes builtin coverage. Sources: `verification.py:1770–1773`; `stacks.py:139–143`. Explicit web/gateway tests, typechecks, protocol compilation and both network builds are required separately. |
| `_contracts(audit_root, changed_paths)` | PASS, **“0 contracts checked”** | No schema delta was examined; this does not verify API compatibility or state semantics. Checker is primarily changed-file syntax validation: `verification.py:1368–1391`. |
| `_sql_safety(audit_root, changed_paths)` | PASS, “0 unsafe SQL findings” | No SQL changed. This is not migration, concurrency or existing-state preservation evidence. |

Residual risks and scope limits:

- Funding JSON introduces the version string `liqvera-musd-funding-observation/v1`, with `quote_id` added during export, but has no standalone JSON Schema. It is currently a local advisory format, not a report/receipt API contract. Any future importer should require an explicit validated contract.
- Network/token constants are duplicated in `mezo-finance.mjs:19–28` and `packages/mezo-protocol/src/index.ts:10–40`. They currently agree; both-network tests should guard drift.
- Canonical specification/architecture documents do not yet describe the new advisory funding export. The competition document supplies its current scope and limitations; a documentation follow-up would improve architectural ownership.
- The displayed balance is neither independently authenticated nor reserved, and its block need not be finalized. Real provider interoperability, external borrowing and a new paid delivery remain outside these observations.
- Getzilla skips must stay visible. Do not manufacture architecture adoption or reinterpret zero-check PASS results as full product verification.
- Audit evidence should be finalized before independent review and candidate freeze. No migration, deployment, publication, payment, grant renewal or secret access is necessary for this audit.

Only repository inspection and the bounded helper probes above were executed here; no application suite, heavy test, mutation probe or live action was run.

---

**2026-10-21 addendum — UI successor**

Reviewed successor `57660040b36300de62cd45cb663bd2124167fe45`, tree `7f70be70d1e53624ded7efcbba1c80eda5048437`, whose direct parent is the originally analyzed `87b66c0d53cc276eae41b437f616346c33a28e98`. The preceding analysis is retained verbatim and remains bound to its original source. This addendum covers the actual seven-file successor diff: `main.ts`, `mezo-finance-panel.ts`, `mezo-finance.mjs`, `style.css`, two funding test files and `handoff.md`.

The architectural conclusions do not change:

- The overlap fix replaces inline spacing with scoped grid rows and wrapping controls (`apps/mezo-web/src/style.css:3–13`; `mezo-finance-panel.ts:31–57`). It changes presentation and accessibility descriptions without adding a service, dependency, RPC method, persistent state, payment action or trust boundary. Browser geometry and keyboard/label behavior are the relevant validation boundaries; source inspection alone cannot prove the layout is repaired.
- The new initial-state branch in `mezo-finance.mjs:44–48` handles only `paymentGuard === 'unavailable'` with no quote and still returns `allowed: false`. It supplies wallet/report prerequisites instead of implying an existing payment. The subsequent requirement for a clear payment guard remains intact, so unknown/uncertain recovery is not relaxed.
- The checkbox help and `aria-describedby` explain the existing fresh-observation/shortfall prerequisite. The eligibility, freshness, acknowledgment and external-link guards remain authoritative and unchanged. Added tests cover initial blocked guidance, zero RPC calls and retention of recovery guidance; their results were not independently rerun for this addendum.
- The owner-requested Getzilla footer entry (`apps/mezo-web/src/main.ts:68`) is a fixed HTTPS hyperlink to the project repository, with `target="_blank"` and `rel="noopener noreferrer"`. It loads no external script, imports no framework and creates no application dependency or new runtime authority. Liqvera's standalone-product invariant is preserved.
- Gateway, services, packages, schemas, deployment configuration and acceptance files remain byte-identical across this successor. The optional architecture-model absence, nested Node verification gap, advisory export limitations and native contract-check requirements remain unchanged.

Read-only commands executed:

```sh
git show -s --format='%H%n%P%n%s' 57660040b36300de62cd45cb663bd2124167fe45
git diff --stat 87b66c0d53cc276eae41b437f616346c33a28e98..57660040b36300de62cd45cb663bd2124167fe45
git diff --name-only 87b66c0d53cc276eae41b437f616346c33a28e98..57660040b36300de62cd45cb663bd2124167fe45
git diff 87b66c0d53cc276eae41b437f616346c33a28e98..57660040b36300de62cd45cb663bd2124167fe45 -- apps/mezo-web/src/main.ts apps/mezo-web/src/mezo-finance-panel.ts apps/mezo-web/src/mezo-finance.mjs apps/mezo-web/src/style.css apps/mezo-web/test/mezo-finance-panel.test.mjs apps/mezo-web/test/mezo-finance.test.mjs handoff.md
git diff --quiet 87b66c0d53cc276eae41b437f616346c33a28e98..57660040b36300de62cd45cb663bd2124167fe45 -- apps/mezo-gateway services packages schemas deploy acceptance
```

All commands exited 0; the last command produced no output. No application code, candidate file, database or live system was modified by this analysis. The report is saved outside the candidate for coordinator incorporation before review freeze. Fresh final reviews and verification must identify the successor/frozen candidate; the earlier analysis does not qualify a changed tree automatically. No application tests, full verification, live actions or independent security reassessment were performed for this addendum.

The final read-only status check retained the same successor HEAD/tree and found no tracked product changes. It also reported the untracked directory `apps/mezo-web/test/.x402-wallet-iouNhO/`; this analysis did not create, inspect or remove that directory, and its contents are outside this source-diff analysis. The coordinator should account for concurrent test artifacts before freezing the final candidate.

