No Wave 1 database migration is needed. The audit should preserve the existing ledger and validate payment behavior only against a new, isolated PostgreSQL cluster.

Source identity:

- Liqvera: `87b66c0d53cc276eae41b437f616346c33a28e98`, tree `9b5ec7523543bb8591890db1b8ad885e1e16cf1e`.
- Comparison base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`; base and `v0.0.5` are ancestors.
- Getzilla: `2bb417431f1e4b9494e4af71ebf27adb1d04d898`; route `fc7402fc1070`, change `20261021-task-fc7402`.
- `reviewed-tree-modified: no`. No connections, test runs, application edits, or private recovery-file reads performed.

Required invariants, with paths relative to the Liqvera audit clone:

| Invariant | Exact source |
|---|---|
| Request idempotency is scoped; report, artifact, quote, receipt and entitlement identities remain bound by immutable hashes and composite foreign keys. | `apps/mezo-gateway/migrations/001_ledger.sql:6`, `:18`, `:29`, `:67`; `002_fix_immutable_ledger_identity.sql:3` |
| Authorization identity is globally unique; one non-rejected attempt per quote; merchant nonce remains reserved across quotes and states, including unknown/rejected attempts. | `001_ledger.sql:45`; `008_merchant_nonce.sql:1` |
| Durable `SUBMITTING` and authority consumption/reservation commit before the sole settlement call. Recovery confirms only and never resubmits. | `src/adapters/postgres.ts:147`; `src/application/gateway.ts:100`; `src/workers/reconciliation.ts:4` |
| Receipts, chain events, entitlement and confirmed state commit atomically. Delivery requires current finality, confirmed state, retention and artifact integrity. | `src/adapters/postgres.ts:220`; `src/application/gateway.ts:125`; `005_receipt_confirmation_count.sql:8` |
| One immutable network per ledger; Testnet/Mainnet chain, network and asset are paired. | `007_network_identity.sql:1`; `src/adapters/postgres.ts:31` |
| Unknown/manual-review records, consumed authority, dedup rows and paid evidence remain preserved. Unpaid cleanup excludes every non-rejected attempt and entitlement. | `src/workers/retention.ts:3`; `003_live_grant_consumption.sql:10`; `006_signed_live_grant_authority.sql:33`; `docs/migration.md:7` |
| Wave 1 funding exports are wallet observations, never receipts or payment authority. Non-clear payment guards block funding; amounts use integer strings; canonical block, account/network, quote and freshness checks bind observations. | `apps/mezo-web/src/mezo-finance.mjs:39`, `:109`; `mezo-finance-panel.ts:79`, `:94`, `:125` |

The comparison contains no gateway, migration, report-package, schema or historical-preview changes. All eight migration file hashes match the deployment record and pinned migration authority.

For disposable PostgreSQL validation:

1. **Create an entirely new cluster**, with task-owned storage under canonical `.getzilla/runtime`, no live volumes, private dumps or credentials. Isolate test networking to the disposable database and loopback fixtures; block public-service/payment egress. Restrict execution to one CPU while retaining the tests’ deliberate 20-client concurrency.
2. Use an allowlisted environment, explicit Testnet selection, task-owned temporary directory, a fresh `liqvera_f4_test_<suffix>` database and `TEST_DATABASE_DISPOSABLE=1`. Do not inherit `DATABASE_URL_FILE`, migration overrides, private grant settings, RPC/facilitator settings or application secrets.
3. Execute `npm run test:postgres --prefix apps/mezo-gateway` and require **13 executed cases, zero skips**. Preserve command, exact source, PostgreSQL/runtime versions, exit status and complete results.
4. Record schema/index definitions and migration receipts before/after. The suite deliberately creates `_upgrade` and `_network` databases, drops the nonce index and deletes/restores migration receipts. Its loopback/name checks alone do **not** establish disposal. See `test/postgres.test.ts:39`, `:46`, `:105`, `:390`, `:441`.
5. For broader data claims, use separate synthetic-only disposable probes for populated legacy migration rejection, receipt/entitlement transaction rollback, unknown/manual-review preservation through cleanup/restart, and synthetic dump/restore integrity. Keep these distinct from the existing 13-case coverage. The upgrade case explicitly starts with **zero receipts**; migrations 004 and 005 intentionally reject nonempty legacy receipts instead of fabricating provenance (`004_receipt_confirmation_provenance.sql:4`; `005_receipt_confirmation_count.sql:1`).

Historical evidence integrity was checked locally:

- Deployment JSON SHA-256: `f3e2f0bbaa48526d6c4a9254485ba1e30beb4d0f32f8089f31495c4ccf73ac45`.
- Raw archive SHA-256 matches `75cb10a985d99c3428273d6ed443bf6066e82c9c758ebf108add07695b8255d0`; **39/39 recorded member digests match**.
- Recorded before/after ledger summaries are identical: **3 CONFIRMED, 1 MANUAL_REVIEW, 4 receipts, 4 entitlements**. Four receipts despite three currently confirmed attempts is historical evidence to preserve, not a cleanup discrepancy.
- The prior 13 PostgreSQL passes and restored-backup comparison remain historical evidence, not fresh audit execution or live payment acceptance. Do not rerun production backup/rollback scripts or restore an older ledger over newer authorization records.

Addendum — 2026-10-21

The updated product source is `57660040b36300de62cd45cb663bd2124167fe45`, tree `7f70be70d1e53624ded7efcbba1c80eda5048437`. I inspected its full application/test diff against `87b66c0d53cc276eae41b437f616346c33a28e98` and the changed-file inventory: seven files, 56 insertions and three deletions. The changes are confined to the funding panel layout/accessibility, initial prerequisite guidance, a Getzilla footer link, two browser test files and `handoff.md`.

Data and payment invariants do not change. The new branch in `apps/mezo-web/src/mezo-finance.mjs:44` changes only the explanatory reason when `paymentGuard === 'unavailable'` and no quote exists; it still returns the same blocked result (`allowed: false`, `requiredAtomic: 0n`). Unknown payment guards retain the existing recovery guidance and remain blocked. Quote, payer, network, expiry, amount, observation freshness and canonical-block checks are unchanged. Panel layout, acknowledgement help/ARIA attributes and the footer link do not add requests, signatures, settlement calls or persistence.

The diff contains no gateway, SQL migration, schema, capture/report service, evidence-report package or historical-preview changes. The original disposable PostgreSQL validation requirements and historical-evidence limitations therefore remain applicable. The new browser tests express the initial-guidance and unknown-payment guard expectations; they were inspected but not executed by this analysis agent.

Read-only verification commands: `git status --short`, `git rev-parse HEAD HEAD^{tree}`, `git log -4 --oneline`, `git diff --stat 87b66c0d53cc276eae41b437f616346c33a28e98 57660040b36300de62cd45cb663bd2124167fe45`, the corresponding diff scoped to `apps/mezo-web/src` and `apps/mezo-web/test`, and a changed-file query scoped to gateway/migrations/schemas/report/capture/historical-preview paths. Initial candidate status was clean, and the latter query returned no paths. The final status check showed an untracked `apps/mezo-web/test/.x402-wallet-iouNhO/` directory; this agent did not create, read or remove it. HEAD and its committed tree remained unchanged. `reviewed-tree-modified: no` refers to this agent's actions, not a frozen clean working-tree receipt. This addendum is static analysis, not a fresh execution pass or a final review receipt. The only write was this coordinator-requested report outside the candidate; no app/live edits, private-material reads, payments or test runs occurred.
