# Independent code review — fc7402fc1070

Review status: COMPLETE, with two non-blocking observations. No blocking implementation defect was found in the reviewed Wave 1 funding, layout, or footer changes. This report does not claim a passing final Getzilla gate, complete product verification, security clearance, deployment acceptance, or live payment acceptance. The final qualifying gate has not been run by this reviewer.

Reviewer role: independently dispatched `code_reviewer`, no implementation ownership. Reviewed on 2026-10-21 under the pinned Getzilla delivery and code-review instructions, Liqvera `AGENTS.md`, and change package `engineering/changes/20261021-task-fc7402`. No fixes, commits, pushes, deployments, production database actions, live quote requests, payments, borrowing, or grant operations were performed. No secret files or values were read.

## Source and isolation

- Canonical project: `/home/pall/projects/liqvera`.
- Read-only candidate: `/home/pall/projects/liqvera/.getzilla/runtime/pr115-liqvera`.
- Reviewed HEAD, before and after: `84851abfddbc46ad3f097ba17ef9cfadc9c3296d`.
- Reviewed candidate tree, before and after: `034acc73fb4561763aba7b920417f722bd6c73c9`.
- Product commit: `57660040b36300de62cd45cb663bd2124167fe45`.
- Comparison base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`.
- Tool source: pinned PR115 merge `2bb417431f1e4b9494e4af71ebf27adb1d04d898`; instructions read from `/home/pall/projects/liqvera/.getzilla/runtime/pr115-tool/.agents/skills/getzilla-delivery/SKILL.md` and `.grok/agents/code_reviewer.md`. Also read the four workflow skills selected by the frozen route.
- Private scratch: `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-code`; snapshot: its `snapshot/` child.
- Scratch and canonical runtime parent were checked as real directories owned by the current UID, mode `0700`, with no sticky bit. Scratch did not previously exist. The snapshot is outside the reviewed candidate.
- Candidate `git status --porcelain=v1 --untracked-files=all` was empty both before and after. There were no staged, unstaged, or relevant untracked changes to add to the snapshot.
- Snapshot construction used `git archive --format=tar 84851abfddbc46ad3f097ba17ef9cfadc9c3296d`, extraction with Python's safe `data` filter, then `git init -q`, `git add -f .`, and `git write-tree` in scratch. Snapshot tree was exactly `034acc73fb4561763aba7b920417f722bd6c73c9` before and after the probes. All source mutants were restored in scratch. Final scratch `git diff --exit-code` passed and `git ls-files --others --exclude-standard` was empty.
- `reviewed-tree-modified: no`

Read-only operation was workflow discipline, not OS-enforced isolation. No test, build, mutation, browser profile, archive, or report was created inside the candidate. Probe subprocesses and Chrome were restricted to CPUs 0 and 1 with `taskset -c 0,1`; mutation runs were sequential. Node version was `v24.22.0`; Chrome was `156.0.8078.47`; the direct browser bundler was installed esbuild `0.28.2`, read without modifying candidate dependencies. This was not a fresh dependency installation or integrity audit.

The candidate clone has no local `main` branch: the initial `git merge-base --is-ancestor main HEAD` returned 128. `git rev-parse refs/remotes/origin/main` and `git merge-base f1d3bffc46fa1459908fdff865fcfbfc831b7f7f HEAD` both returned the supplied base. `git tag --merged HEAD` listed all locally available published tags `v0.0.1` through `v0.0.5`; worktrees were inventoried and none were cleaned. Remote refs were not refreshed. An initial active-route lookup in the tool checkout found no file; the candidate's frozen route with exact ID `fc7402fc1070` supplied the review contract. Coordinator lifecycle/status commands were not run inside the read-only candidate.

## Findings

1. **Low — committed tests do not detect removal of the observation freshness limit.** Location: `apps/mezo-web/src/mezo-finance-panel.ts:98`, coverage in `apps/mezo-web/test/mezo-finance-panel.test.mjs:54`. Changing only `Date.now() - lastBalance.at < 30000` to `< Infinity` leaves all 55 committed finance, observation, and panel tests passing. It would keep a previously acknowledged borrowing link and export usable after their intended freshness period. The current implementation correctly blocks those actions: an independent deterministic probe advances the clock exactly 30 seconds and clicks the links without calling `panel.update()` first; it passes on current source and kills the mutant. Preserve an equivalent boundary regression in the repository when tests are next changed. No current behavior failure is alleged, and no implementation was edited.

2. **Low — whitespace validation fails in a deployment evidence document.** Location: `docs/security/2026-10-21-wave1-deployment.md:51`. Exact command `GIT_OPTIONAL_LOCKS=0 git diff --check f1d3bffc46fa1459908fdff865fcfbfc831b7f7f HEAD` returned **2**, with `new blank line at EOF`. This is a documentation formatting observation, not a runtime defect. It remains present; do not report this command as passing.

## Executed scope and results

The actual 51-file base-to-candidate diff was inspected, with detailed source inspection of `main.ts`, `mezo-finance.mjs`, `mezo-finance.d.mts`, `mezo-finance-panel.ts`, the scoped CSS, and all three added test files. The specification, architecture, README, handoff, frozen change requirements, acceptance criteria, analysis reports, release limits, and rollback constraints were read.

Structural checks executed in the candidate:

```sh
git diff --stat f1d3bffc46fa1459908fdff865fcfbfc831b7f7f HEAD
git diff --name-status f1d3bffc46fa1459908fdff865fcfbfc831b7f7f HEAD
GIT_OPTIONAL_LOCKS=0 git diff --exit-code f1d3bffc46fa1459908fdff865fcfbfc831b7f7f HEAD -- apps/mezo-gateway services packages schemas deploy acceptance
GIT_OPTIONAL_LOCKS=0 git diff --exit-code 57660040b36300de62cd45cb663bd2124167fe45 HEAD -- . ':(exclude)engineering/changes/20261021-task-fc7402/**'
```

The first two reported 51 changed files, 2,393 insertions and four deletions. Both restricted `--exit-code` comparisons returned 0 with no output. Thus the compared gateway, services, packages, schemas, deployment configuration and acceptance source are byte-unchanged, and audit metadata introduces no product-source delta beyond the named product commit. These comparisons establish source preservation, not execution correctness of unchanged components.

All test commands below used scratch snapshot as cwd unless otherwise stated. Command F was:

```sh
taskset -c 0,1 node --test --test-concurrency=1 apps/mezo-web/test/mezo-finance.test.mjs apps/mezo-web/test/musd-observation.test.mjs apps/mezo-web/test/mezo-finance-panel.test.mjs
```

Fresh baseline: exit 0, **55 tests passed, 0 failed, 0 skipped**. Claims exercised include quote/payer/network/asset/expiry/payment eligibility, exact atomic arithmetic and formatting, RPC allowlists, malformed data rejection, block-tagged reads, canonical hash rechecks, final identity checks, shared deadline, Mainnet token selection, acknowledgement/shortfall gating, replacement-provider invalidation, and export revocation. These providers and DOM elements are synthetic; this is not live chain or real-wallet evidence.

Command R was:

```sh
taskset -c 0,1 node --test --test-concurrency=1 /home/pall/projects/liqvera/.getzilla/runtime/reviewer-code/reviewer-probes.test.mjs
```

Fresh baseline: exit 0, **4 tests passed, 0 failed, 0 skipped**. The probes execute: click-time rejection and Blob revocation at the 30-second boundary; elapsed quote expiry without object mutation; account/quote/busy/payment invalidation; and disposal of an existing export/panel. Disposal during an unresolved RPC was not separately exercised.

The mutation driver was executed as:

```sh
python3 /home/pall/projects/liqvera/.getzilla/runtime/reviewer-code/run-mutations.py
```

It returned 0 after storing complete per-run output and restoring the original source. Each row below is one isolated mutant; the test command and exact mutation are specified, with no mutation-score threshold applied.

| Mutant | Exact change in scratch | Command and observed result | Classification |
| --- | --- | --- | --- |
| M1 payment guard | Replace `if (context.paymentGuard !== 'clear')` with `if (false)` | F: exit 1; 53 pass, 2 fail, including pending-guard and unknown-outcome guidance checks | Killed |
| M2 block binding | Replace `params: [args.params[0], block.number]` with `params: [args.params[0], 'latest']` | F: exit 1; 54 pass, 1 fail; block pinning assertion fails | Killed |
| M3 canonical block | Remove ` || canonical.hash.toLowerCase() !== block.hash.toLowerCase()` | F: exit 1; 54 pass, 1 fail; changed-block-hash rejection fails | Killed |
| M4 shared deadline | Replace `const remaining = deadline - Date.now();` with `const remaining = timeoutMs;` | F: exit 1; 54 pass, 1 fail; shared-timeout-budget rejection fails | Killed |
| M5 result ownership | Replace the full `ownsResult` predicate with `const ownsResult = () => !disposed;` | F: exit 1; 54 pass, 1 fail; replaced-provider stale result test fails | Killed |
| M6 freshness | Replace `Date.now() - lastBalance.at < 30000` with `Date.now() - lastBalance.at < Infinity` | F: exit 0, 55 pass; R: exit 1, 3 pass and click-time stale-balance test fails | Survived committed tests; killed by independent probe; finding 1 |
| M7 sufficient balance | Replace `shortfall > 0n && ack.checked` with `shortfall >= 0n && ack.checked` | F: exit 1; 54 pass, 1 fail; sufficient-balance handoff prohibition fails | Killed |
| M8 revocation | Replace `if (downloadUrl) URL.revokeObjectURL(downloadUrl);` with `if (false && downloadUrl) URL.revokeObjectURL(downloadUrl);` | F: exit 1; 54 pass, 1 fail; fetch of revoked export unexpectedly succeeds | Killed |
| M9 layout | Remove compiled CSS beginning at `.funding-panel > summary`, preserving the preceding stylesheet | Browser command below: exit 1; label-to-button gap −28 px and button-to-terms gap −31 px; no runtime exception | Killed by independent browser probe |
| M10 footer | Replace bundled `https://github.com/Dimkox/Getzilla` with `https://example.invalid/incorrect` | Browser command below: exit 1; expected footer destination assertion false, layout still passes | Killed by independent browser probe |

M9/M10 mutate only a private, generated browser bundle; the snapshot source remains unchanged. They were not evaluated by F. No mutant remained unexplained or inconclusive after the stated probes; M6's committed-suite survivor is retained as a coverage finding.

Actual browser commands, each from scratch root:

```sh
taskset -c 0,1 node /home/pall/projects/liqvera/.getzilla/runtime/reviewer-code/browser-probe.mjs baseline
taskset -c 0,1 node /home/pall/projects/liqvera/.getzilla/runtime/reviewer-code/browser-probe.mjs M9-layout
taskset -c 0,1 node /home/pall/projects/liqvera/.getzilla/runtime/reviewer-code/browser-probe.mjs M10-footer
```

Baseline returned 0. The direct esbuild bundle uses the actual `main.ts`, stylesheet, and local protocol source from the exact snapshot, with Testnet and an empty WalletConnect project ID explicitly supplied. It does not invoke Vite environment loading. A loopback-only HTTP fixture supplies synthetic capabilities and one synthetic quote; the injected wallet permits only account, chain, block, and balance reads. The Chrome DevTools interceptor refuses any page request outside that loopback origin. No external request was observed.

At widths **320, 390, 768, 1024, 1280, 1440**, both control gaps were **14 px**, `innerWidth` matched the selected width, and no horizontal overflow was observed. Initial acknowledgement and borrowing were disabled with unpaid-report guidance. With a synthetic zero balance, the explicit acknowledgement enabled the correct official Testnet URL. After changing synthetic balance to `1000000000000000001`, refresh showed **100 report purchases**, disabled borrowing, and exported exact amount/quote identity with `payment_submitted: false`. Saved flow bytes did not change. The only POST was to the loopback synthetic quote endpoint; no paid-report request or signing method occurred. The Getzilla footer had its exact destination, `_blank`, and `noopener noreferrer`. Runtime exceptions: **0**.

## Static conclusions and unexecuted claims

Source inspection agrees with the exercised behavior: the finance code has no settlement authority; it publishes advisory, wallet-reported observations, while the existing payment path owns signing and delivery. Dynamic evidence here covers only the listed synthetic paths. Exhaustive absence of side effects, server-side payment idempotency, canonical settlement, durable ledger behavior, production state preservation, and all other component correctness remain **UNEXECUTED by this reviewer**; source preservation alone cannot establish them.

Also not executed here: the full web suite, TypeScript check, Vite production builds, Python suite, gateway/PostgreSQL suite, artifact/package verification, official borrowing-term revalidation, fresh dependency or container vulnerability scans, archived deployment evidence replay, real wallet pairing, live MUSD observation, loan/payment, physical-device or accessibility audit, published-site checks, and final Getzilla PR gate. The full audit coordinator and other selected reviewers own their assigned checks. Existing certifi findings in the analysis package were not researched or suppressed here. Historical test/deployment records were treated as historical claims, not fresh reviewer results.

## Retained reviewer evidence

All artifacts remain outside the candidate under `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-code/`: exact archive, snapshot, scripts, baseline and per-mutant logs, `mutation-results.json`, `browser-mutation-results.json`, `browser-baseline/result.json`, each browser mutant result, before/after identity records, and `artifact-sha256.json`.

Selected SHA-256 bindings:

- `candidate.tar`: `9014d5550f595319a98d64f10651852ba3981e0bfaf1e09ac51692c84007f216`
- `run-mutations.py`: `21719331950499b6f120a81bd0383ce69543e598a1ff07b24c2b682223f47e50`
- `reviewer-probes.test.mjs`: `8a7e3e41deacb67d35878144bba6441b720a8b846f78e608ddf4107160bd6153`
- `browser-probe.mjs`: `fc95716132ce0c2b7aba268e7d54a1de7e5f4cb38fac6505913d7d1099982fff`
- `mutation-results.json`: `16bcf5812c5d9dd84da442592c6ee4a01ffa2f569eef82cd3ecc5cf864453406`
- `browser-baseline/result.json`: `629b4a16523b1e4833898bbfadb9dd78fa7634cb6f725755563dc2698fb351f6`

The coordinator may persist this complete report under the selected change evidence directory. Any other candidate-source change requires a new review; this report does not pre-authorize a new source tree or final gate result.
