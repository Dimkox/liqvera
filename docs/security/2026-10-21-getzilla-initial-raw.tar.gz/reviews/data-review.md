# Independent data review — route fc7402fc1070

Review date: 2026-10-21. Role: `data_reviewer`. Change: `20261021-task-fc7402`.

**Result: PASS for the bounded data review. No blocking data finding identified in the actual diff.** This is not a final verification receipt, a deployment approval, or live-payment acceptance. The coordinator's final full gate remains pending.

## Source identity and read-only boundary

| Identity | Before review | After review |
| --- | --- | --- |
| Candidate HEAD | `84851abfddbc46ad3f097ba17ef9cfadc9c3296d` | `84851abfddbc46ad3f097ba17ef9cfadc9c3296d` |
| Candidate tree | `034acc73fb4561763aba7b920417f722bd6c73c9` | `034acc73fb4561763aba7b920417f722bd6c73c9` |
| Git status, including nonignored untracked paths | empty | empty |

reviewed-tree-modified: no

- Canonical root: `/home/pall/projects/liqvera`.
- Read-only candidate: `/home/pall/projects/liqvera/.getzilla/runtime/pr115-liqvera`.
- Comparison base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`.
- Product commit: `57660040b36300de62cd45cb663bd2124167fe45`, tree `7f70be70d1e53624ded7efcbba1c80eda5048437`.
- External tool commit: `2bb417431f1e4b9494e4af71ebf27adb1d04d898`.
- Reviewer scratch: `/home/pall/projects/liqvera/.getzilla/runtime/data-review-84851ab`; snapshot is its `source/` child.
- Both the scratch and its immediate canonical runtime parent are owner-only mode `0700`, with no sticky bit or symlink. Ancestor ownership/permissions were inspected. The initial, stricter preparation check refused group-writable owner-owned project ancestors before creating a scratch. Preparation then verified the private immediate parent and expected-owned, non-world-writable ancestors; the snapshot check passed. No unsafe or partial snapshot was used for testing.
- The clean committed candidate was exported with `git archive --format=tar 84851abfddbc46ad3f097ba17ef9cfadc9c3296d`. All **472 tracked blobs and executable modes** matched the Git snapshot before tests; all **472 candidate and scratch blobs** still matched after tests. Ignored runtime/dependency outputs were not copied into this product-source snapshot.

Read the pinned delivery and role instructions, all five named workflow skills, candidate AGENTS, README, architecture, specification, handoff, change package, and data architect analysis including its successor addendum. The analysis's original `87b66c0` identity was treated as historical; this review inspects `84851ab` directly. The candidate descends from the comparison base, local `origin/main`, and available tags v0.0.1 through v0.0.5 (`git merge-base --is-ancestor` returned 0 for each). Worktrees were inventoried; no cleanup occurred. No remote ref refresh or publication check was performed.

The candidate was never edited, built, migrated, or used as a database target by this reviewer. All new reviewer scripts, logs and this report are outside it. No live database, private dump, `.env`, private grant, wallet key or production credential was opened. No payment, quote, borrowing, deployment, push, or schema operation was executed.

## Scope and data impact

The base-to-candidate changed-file inventory has 51 paths. Runtime changes are confined to the existing web application's funding module/panel, their integration, CSS, and tests. The product-to-candidate delta has 17 paths, all in the active engineering change package. Executable comparison checks found **zero changed paths** in gateway, packages, services, schemas, historical migrations, or browser public assets.

Schema before and after is the same eight approved gateway migrations. No new table, index, query, backfill, database lock, database downtime requirement, or durable payment-state transition is introduced. There is no new production-volume assumption or query-plan claim to validate for this diff. The four historical receipt/entitlement aggregate counts are recovery observations, not representative load measurements.

The new export contains wallet/account, network/token, quote identifier, a provider-reported block identity, exact integer strings for balance/price/shortfall/budget, observation time, and `payment_submitted: false`. It is a local JSON Blob download; the new module does not upload it or use it as settlement authority. The same wallet provider reports the initial and repeated block hashes: this is a checked wallet observation, not independent chain authentication, finality proof, a loan receipt, or reserved funds.

## Executed checks and observed output

All commands below completed with exit 0 unless otherwise stated. Commands ran with the candidate read-only; the Node commands ran against the validated private snapshot with only PATH and LANG in their environment.

1. Source inventory and ancestry:

   ```text
   git status --short
   git log -6 --oneline
   git rev-parse HEAD HEAD^{tree}
   git worktree list --porcelain
   git for-each-ref --format='%(refname) %(objectname)' refs/heads refs/remotes refs/tags
   git diff --stat f1d3bffc46fa1459908fdff865fcfbfc831b7f7f 84851abfddbc46ad3f097ba17ef9cfadc9c3296d
   git diff --name-status f1d3bffc46fa1459908fdff865fcfbfc831b7f7f 84851abfddbc46ad3f097ba17ef9cfadc9c3296d
   ```

   Observed clean candidate, exact identities above, one worktree in this audit clone, and the stated inventory. A Python loop ran `git merge-base --is-ancestor <ref> HEAD` for base, origin/main, and all five tags: seven exit-0 results.

2. Funding tests; working directory `<scratch>/source`:

   ```text
   env -i PATH=/usr/local/bin:/usr/bin:/bin LANG=C.UTF-8 node --test apps/mezo-web/test/mezo-finance.test.mjs apps/mezo-web/test/musd-observation.test.mjs
   ```

   **46 tests, 46 pass, 0 fail, 0 skipped.** Executed claims include exact prices/formatting, wrong payer/network/asset rejection, expired/invalid quote rejection, uncertain-payment blocking, malformed balance/block rejection, read-only wallet methods, account/chain changes during reads, number-tagged balance lookup, changed block-hash rejection, shared timeout budget, one-wei shortfall, JSON serialization, and Mainnet token separation. These use simulated providers; no real RPC or wallet was contacted. Full output: `<scratch>/finance-tests.log`.

3. Independent arithmetic and state probes; working directory `<scratch>`:

   ```text
   env -i PATH=/usr/local/bin:/usr/bin:/bin LANG=C.UTF-8 node funding-boundary-probe.mjs
   ```

   Observed `arithmetic_boundary_cases_passed: 18`, `unresolved_or_paid_quote_states_blocked: 4`, `authority_bearing_RPC_calls: 0`, `network_calls: 0`. Prices 1, 10^16, and 2^256-1 were crossed with six balances including zero, a one-wei shortfall, and 2^256-1. Exported strings preserved values; budget satisfied `budget * price <= balance < (budget + 1) * price`; shortfall stayed exact. PAYMENT_PENDING, PAYMENT_UNCERTAIN, MANUAL_REVIEW and PAID were each denied funding eligibility even with a clear browser guard. The stub rejected any RPC method outside the four read methods. Script SHA-256: `2a13abfd6072121ec1f79a0a28eee2aa1af104d7d1355f2d5b29ac4101f6db25`. Output: `<scratch>/funding-boundary-probe.json`.

4. Read-only source/evidence assertions; working directory `<scratch>`:

   ```text
   python3 check-evidence.py
   ```

   Observed: 17 product-to-candidate paths all confined to the change package; zero protected subtree changes; **8/8 migration hashes match source authority and both rollout records**; **39/39 archived member hashes match**, including the internal SHA256SUMS manifest; all 12 restored aggregate/migration rows equal the original before-rollout record; both deployments preserve their before/after ledger summaries; the six non-web container records are identical between rollouts. Script SHA-256: `b9395b945ca19908b6485e86bb3e663ffdf93c70790095b69912ec22d44bb17d`. Full output: `<scratch>/evidence-check.json`.

   Original public archive SHA-256: `75cb10a985d99c3428273d6ed443bf6066e82c9c758ebf108add07695b8255d0`. Current safe layout deployment record SHA-256: `770fca6797a2a96c0da14c8b967289647462e5395427baaf312fe9f36f80b0ca`. These are integrity checks of retained records, not new observations of the live service.

5. Final identity check used `git ls-tree -rz HEAD` and recomputed each Git blob SHA-1 from both candidate and snapshot bytes, followed by `git rev-parse HEAD HEAD^{tree}` and `git status --porcelain=v1 --untracked-files=all`. **472/472 matched in each location; HEAD/tree unchanged; status empty.** Recorded at `<scratch>/final-identity.json`.

No mutation testing was performed by this data reviewer; none is required for this selected role. The executable probes above use the unchanged snapshot. No mutant killed/survived result is asserted.

## Coordinator test evidence inspected

The complete candidate-local `.getzilla/runtime/gateway-tests.log` reports **71 passed, 0 failed, 0 skipped**. Its SHA-256 is `813982376cc80016c5aac846b394a2ddae9627510c0786b4f2bc25666907145b`. The evidence checker matched all **13** test names declared by `apps/mezo-gateway/test/postgres.test.ts` to passing log entries. These cover fresh/checksummed migrations, an empty-receipt legacy upgrade, twenty-client request/grant concurrency, restart and rollback boundaries, signed-v2 budget durability, artifact recovery/cleanup, grantless startup, network isolation, repeated merchant purchases, cross-quote nonce replay, expired/mixed payment modes, and missing nonce-index/migration-receipt rejection.

The adjacent `gateway-control.json` records exit 0 at product `5766004`, disposable tmpfs storage without live volumes, an internal Docker network with loopback proxy, and an allowlisted environment. Product gateway/test/migration bytes are identical to this reviewed candidate. These are current coordinator-produced bounded observations that I inspected and hash-checked; **I did not independently rerun PostgreSQL tests or inspect that database/container**. The control record's isolation description is not a separate OS-level isolation attestation by this reviewer.

## Static invariant and recovery review

The following code paths were inspected. Their unchanged behavior is supported by the named coordinator tests where covered; static inspection alone is not represented as fresh execution:

- `apps/mezo-gateway/migrations/001_ledger.sql` and `002_fix_immutable_ledger_identity.sql`: scoped request idempotency, immutable quote/artifact/authorization identity, digest-bound receipt/entitlement relationships, append-only receipts/audit/chain events, and one non-rejected attempt per quote.
- `008_merchant_nonce.sql` and `src/adapters/postgres.ts:131`: a unique merchant network/payer/nonce key spans quotes and does not release reservations based on uncertain/rejected state. `markSubmitting` at line 147 commits durable SUBMITTING and authority consumption/reservation before the sole external settlement call at `src/application/gateway.ts:109`.
- `src/workers/reconciliation.ts:4`: recovery leases SUBMITTING/UNKNOWN attempts for confirmation only. `recoverUnsubmitted` only rejects stale RECEIVED/VERIFIED attempts. The new funding code does not reset these states or browser payment guards.
- `src/adapters/postgres.ts:220`: chain event, receipt, entitlement, confirmed attempt, paid quote and audit record share one transaction. `src/application/gateway.ts:125` and `recordDelivery` at line 255 require confirmed entitlement, retention, current receipt validation and artifact integrity.
- `007_network_identity.sql` and `src/adapters/postgres.ts:31`: immutable per-ledger network identity, paired chain/token constraints, and startup mismatch refusal remain intact.
- `src/workers/retention.ts:3`: cleanup excludes every non-rejected payment attempt and every entitlement; it does not delete payment/dedup rows. Grant consumptions/reservations remain append-only under migrations 003/006. Scope-bound request/quote/delivery lookups remain unchanged.
- `apps/mezo-web/src/mezo-finance-panel.ts:79`: quote/account/provider/guard/busy changes discard observations; eligibility and 30-second freshness are reevaluated before links/downloads. These panel lifecycle paths were read, not executed by this reviewer; the other selected reviewers own full panel/browser execution.
- Published `ops.py` inside the hash-checked original archive was read, never executed. Its backup path drains the gateway, pauses report/capture writers, archives their volumes as their owners, and resumes writers in `finally` with lost-response reconciliation. Rollback is documented to replace browser/manifest without restoring the live ledger or applying migrations. This is static/historical recovery evidence, not a fresh recovery rehearsal.

Original and subsequent safe rollout summaries retain **3 CONFIRMED attempts, 1 MANUAL_REVIEW attempt, 4 receipts and 4 entitlements**. `backup-restore.json` records a disposable restore with exactly those aggregate rows and migration digests; the archive also retains five passing fault tests and the disposable browser rollback rehearsal. Four receipts alongside three currently confirmed attempts is historical state to preserve, not sufficient reason to delete records or infer a duplicate. Source rollback must preserve subsequent payment/nonce/consumed-authority rows and sealed artifacts.

## Findings and unexecuted claims

**Blocking findings: none. Nonblocking code/data findings: none.** The following are explicit coverage limits rather than new defects introduced by this web-only diff:

1. No live balance read, loan, payment, quote, entitlement delivery, production query, schema change, or production restore was attempted. There is no new live-acceptance claim.
2. The existing PostgreSQL upgrade case starts with zero receipts. Populated legacy receipt refusal by migrations 004/005 was inspected statically, not executed here. Never describe that case as a populated-ledger migration proof.
3. No fresh database fault injection after each confirmation insert, mixed UNKNOWN/MANUAL_REVIEW/paid cleanup-and-restart test, or synthetic dump/restore was run by this reviewer. The unchanged transaction/retention code and bounded coordinator cases support review, not exhaustive database failure coverage.
4. Private recovery bytes were not read. The historical restore comparison covers aggregate states and migration hashes; it does not establish complete row-by-row equivalence or a fresh end-to-end restoration of every database/artifact/capture binding. Production restore must remain a separately authorized operation.
5. Query plans, realistic-volume contention, database growth, alert operation and production performance were not exercised. There is no schema/query/backfill delta in scope to justify such a claim.
6. Canonical-block checks are against the selected provider's responses. A dishonest provider, a later reorganization, or subsequent spending can invalidate the observation; the product labels the export accordingly and still requires separate server-verified payment.
7. Full Python/artifact/build/security verification and the final Getzilla PR gate were not run by this reviewer. The coordinator must preserve this complete report and all selected reports before qualifying the frozen final candidate. This PASS must not be generalized to those pending gates.

The reviewed source remains unchanged. Report and supporting reviewer artifacts are retained outside the candidate under the canonical runtime root.
