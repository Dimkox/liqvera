# Independent release review — route fc7402fc1070

**Result: FAIL / NO-GO for a clean release or security certification.** The known certifi exposure remains in the candidate. Final verification and selected parallel reviews are incomplete at this review boundary. Publishing this audit's honest failure/limitation evidence is appropriate; this report does not authorize deployment, publication of a release, payment, borrowing, grant renewal or database changes.

**Reviewed source identity**

- Canonical project: `/home/pall/projects/liqvera`.
- Read-only candidate: `/home/pall/projects/liqvera/.getzilla/runtime/pr115-liqvera`.
- HEAD before and after: `84851abfddbc46ad3f097ba17ef9cfadc9c3296d`.
- Committed tree before and after: `034acc73fb4561763aba7b920417f722bd6c73c9`.
- Working-tree status before and after: clean; `git diff --exit-code` and `git diff --cached --exit-code` return zero.
- Product commit: `57660040b36300de62cd45cb663bd2124167fe45`, tree `7f70be70d1e53624ded7efcbba1c80eda5048437`.
- Comparison base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`; this is the merge base with local `origin/main`, which is 0 commits ahead / 4 behind the reviewed candidate. All local published tags `v0.0.1` through `v0.0.5` are ancestors.
- Pinned Getzilla: `2bb417431f1e4b9494e4af71ebf27adb1d04d898`, tree `81076df2cd7db8713f7178ead66ebaa2728f861e`.
- Route `fc7402fc1070`; change `engineering/changes/20261021-task-fc7402`; tracked lifecycle state `reviewing`; no write agent.
- Scratch: `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-release`, mode `0700`, beneath a checked non-sticky, non-world-writable runtime parent.
- **reviewed-tree-modified: no**

The scratch contains exact public operational scripts and their fault tests, plus a reviewer harness. It is not a copy of the application candidate. No application mutation tests were run by this release reviewer; those are assigned to the independent code/test reviewers. I did not read private manifests, configuration files, dumps, grants, wallet keys or browser pairing material. No production action was executed. Only public advisory pages were opened over the network.

## Findings and release conditions

### R1 — Blocking: affected certifi remains in the Python release closure

`requirements.lock:3` and `requirements-dev.lock:6` both pin `certifi==2026.7.22`. These files are unchanged from the comparison base; this is an existing exposure discovered during the requested audit, not a regression caused by the funding UI.

Fresh retrieval of the [maintainer advisory](https://github.com/certifi/python-certifi/security/advisories/GHSA-6q48-6c7w-9gw2) confirms the compromised intermediate-CA issue and Critical classification. The [PyPA advisory](https://raw.githubusercontent.com/pypa/advisory-database/main/vulns/certifi/PYSEC-2026-4320.yaml) explicitly lists 2026.7.22, aliases the same GHSA, and recommends 2026.10.19 or later and rebuilding vendored images. These identifiers represent one issue.

The checked-in `analysis-docs_researcher.md` reports an independently executed failing online supplement, explains that native Getzilla discovery omits these `.lock` filenames, and identifies affected certifi in historical capture/report image records matching the deployment inventory. I independently confirmed the source pins and current advisories; I did not rescan or inspect the running Python images.

Do not convert a narrower passing Getzilla dependency result, zero browser-image Trivy matches, or configuration-bound nginx/curl dispositions into an overall security PASS. A separately owned fix must update the affected dependency closure, validate the source/builds, and rebuild/rescan affected images before claiming remediation. Publishing source and rolling out replacement images remain separately scoped operations.

### R2 — Important operational documentation gap at the frozen snapshot: rollback instructions describe the earlier browser

`docs/deployment.md:23-31`, `docs/security/2026-10-21-wave1-deployment.md`, and the audit package's `rollback.md` point to the 9ca9ced browser and its recovery command. The separately authorized successor rollout record identifies:

- Current product: `57660040b36300de62cd45cb663bd2124167fe45`.
- Current web image: `sha256:e824dfe58616166fcabbe973b140be27857d7dbb3113fa501296488610527e0f`; entry `index-Cnfn94HM.js`.
- Immediate previous image: `sha256:de0e5216443ac6a51c5e0c63e5ee45b416f57ced9590943161f8addcbc7ecbcd`.
- Immediate previous container: `liqvera-live-web-live-1-before-layout-5766004`.
- Current recovery directory: `/home/pall/.local/state/liqvera/recovery/2026-10-21-layout-5766004`.

The old script checks its expected current image before recovery. Fresh synthetic execution confirms an unexpected image is rejected before recovery is invoked. Therefore the old command will refuse the successor image; this finding is a stale operational instruction, not evidence of database restoration or unsafe image substitution.

The public successor script preserves the same current-image and retained-container identity guards and uses the successor recovery directory. Its documented invocation, only when separately authorized rollback is intended, is `python3 /home/pall/.local/state/liqvera/recovery/2026-10-21-layout-5766004/rollout.py rollback`. It restores the immediate previous browser and manifest; it does not restore a database or apply migrations. I inspected the safe public script only, not the private recovery directory or private retained copy.

The coordinator reports that current deployment documentation will be published separately on the source branch. That post-freeze change is not in the reviewed tree and is not certified here. Preserve the original deployment evidence; add the successor record and current recovery pointer rather than rewriting historical results.

### R3 — Pending release qualification, not a completed PASS

The frozen package correctly says that the final full PR gate has not yet run and that historical Python verification is not fresh candidate evidence. Its selected code, test, security, data and release reports must be persisted before the report-only freeze and final qualifying gate.

The actual route identifies the repository as Python despite nested Node applications. The checked-in repository analysis identifies omitted Node checks, narrower default pytest discovery, omitted Python lockfiles, incomplete Python static-analysis paths and missing nested deployment triggers. Native supplement results must remain separately visible. In particular, full `make verify`, both application test/build paths, both browser networks, real disposable PostgreSQL execution, artifact verification and fresh locked-dependency scans cannot be inferred from a generic Getzilla PASS.

The full gate, supplemental commands, final fingerprints and remaining parallel reports were not executed or available to this reviewer at the review boundary. Preserve every failure and skipped check. An honest completed audit may report FAIL; it must not invent a passing release receipt.

## What the actual diff preserves

I read AGENTS, README, architecture, specification, handoff, the complete change package and analysis reports, the application/test diff, validation and migration guidance, both deployment records and the public recovery implementation.

The base-to-candidate product diff adds a browser funding panel, exact block-bound wallet balance observations, shortfall/budget export, guarded external borrowing guidance, responsive layout and tests. The panel labels exported observations as wallet-reported and separate from payment/loan proof. Its source uses read methods and a separately acknowledged link; no signing or settlement call is added. Unknown-payment recovery remains authoritative. These statements are source inspection, not new live interoperability acceptance.

The eight changed application/test files are under `apps/mezo-web`. A scoped `git diff --name-only` returned no changes under gateway, packages, services, schemas, migrations, deployment definitions, CI, the Python lockfiles, the browser lockfile or historical browser preview. Product-to-audit-HEAD contains exactly 17 paths, all in the active change package. The complete web/API, public capture, report/verifier and payment-guard product remains present. No SQL migration, backfill, new runtime dependency or external delivery-framework runtime dependency is introduced by this diff.

The funding flow's new unit tests cover blocked/unknown states, exact amounts, account/network changes, canonical-block changes, shared timeout, stale results and export invalidation. These application tests were inspected, not rerun by this reviewer. Recorded 104 web tests and 71 gateway tests including 13 PostgreSQL cases are coordinator observations; the 951 Python tests plus 85 subtests in the deployment archive belong to 9ca9ced.

## Freshly executed release probes

Commands ran from the candidate unless a scratch directory is shown. No test contacted Docker, a database, a wallet, an RPC service or the public application.

| Claim and command | Observed result | Scope |
| --- | --- | --- |
| `git rev-parse HEAD 'HEAD^{tree}'`; `git status --short`; `git diff --exit-code`; `git diff --cached --exit-code` | Exact identities above; clean before/after; zero diff exit codes | Frozen source identity |
| `git merge-base HEAD origin/main`; `git rev-list --left-right --count origin/main...HEAD`; `git worktree list --porcelain`; `git merge-base --is-ancestor <tag> HEAD` for every local tag | Expected base; 0 / 4; one candidate worktree; all five tags ancestors | Local ancestry, no remote fetch |
| `git diff --name-only f1d3bffc46fa1459908fdff865fcfbfc831b7f7f HEAD -- apps/mezo-gateway packages services schemas migrations deploy .github requirements.lock requirements-dev.lock apps/mezo-web/package-lock.json apps/mezo-web/public/demo` | Empty | Unchanged protected product surfaces |
| `git diff --name-only 57660040b36300de62cd45cb663bd2124167fe45 HEAD` | 17 active change-package paths only | Audit metadata separation |
| Python SHA-256 validation of `docs/security/2026-10-21-wave1-deployment-raw.tar.gz`, every named `archive.members` entry and `SHA256SUMS.json` | Archive digest matches; 39/39 member digests match; inner manifest equals summary | Historical evidence integrity, not reexecution |
| Python comparison of historical/current sanitized deployment JSON, migration file SHA-256 values and preview file SHA-256 values | Both before/after ledgers equal; successor equals historical; six non-web container records unchanged; all seven recorded health values healthy with zero restarts; 8/8 migrations and both preview hashes match | Recorded observations, not fresh production inspection |
| `TMPDIR=/home/pall/projects/liqvera/.getzilla/runtime/reviewer-release/tmp python3 -B /home/pall/projects/liqvera/.getzilla/runtime/reviewer-release/run_recovery.py /home/pall/projects/liqvera/.getzilla/runtime/reviewer-release/wave1` | Exit 0; 8 tests passed | Exact archived public recovery script, mocked external I/O |
| Same command with final argument `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-release/layout` | Exit 0; 8 tests passed | Exact safe public successor script, mocked external I/O |

Each script run includes the five archived recovery fault cases and three fresh rollback-entry guards. The five cases exercise lost create/delete replies, lost pause replies, a removal failure, retaining a candidate whose first stop failed, and retrying failed inspection. The three new cases reject an unexpected current image, reject the wrong retained-container ID, and delegate matching identities to recovery. The harness disables socket construction and subprocess execution around the tests. Synthetic baseline JSON is created only in private reviewer scratch.

**Mutants:** none created; killed/survived/inconclusive is not applicable. Injected transport/state faults above are ordinary recovery probes, not application mutation testing. There is no claimed mutation score.

The recorded ledger remains three CONFIRMED attempts, one MANUAL_REVIEW attempt, four receipts and four entitlements. Four receipts alongside three currently confirmed attempts is preserved historical state, not authorization to delete or reconcile rows. Existing databases, unknown payment outcomes, sealed bundles and prior release assets must remain intact.

## Evidence identity and boundaries

The historical archive SHA-256 is `75cb10a985d99c3428273d6ed443bf6066e82c9c758ebf108add07695b8255d0`. Its verified log records `951 passed, 85 subtests passed in 421.78s`; earlier timeout/interrupted logs remain present. Its historical replacement rehearsal is bound to the previous e4a2aeb5 image and Wave 1 de0e5216 image. Its backup-restore record explicitly uses a disposable database. Neither is a new rehearsal or backup restoration of the layout successor.

Safe successor evidence read outside the candidate:

| Runtime-relative file | SHA-256 |
| --- | --- |
| `layout/deployment.json` | `770fca6797a2a96c0da14c8b967289647462e5395427baaf312fe9f36f80b0ca` |
| `layout/security-summary.json` | `698d2a969b849b916d30812b298644729374a0076b945c57002e424b6f7d96f8` |
| `layout/rollout.py` | `fb3bcb5d8811b197ed86d00b27f2a8939bfaec026fa39157b4a571037a5b2106` |
| `layout/runtime-comparison.txt` | `d3d1495fd6c263c5fb37d5a578cbb557a01734e134414f5222653b74507f1778` |
| `reviewer-release/run_recovery.py` | `82fc678256d3b3c4bfa3ea815316d0b84ebd339cb6279325fefb1a51fe528092` |

The successor runtime-comparison digest agrees with its security summary. The archived original operational script digest is `e6c12dc4cb9539ede19eb492e0aa35d6d62fdeadbb4bb86e2a65d0d87ed850b4`; archived fault tests are `b49848a10a39fa3f29a115621bf8c12f89f033eb4360733e219c3afe662090ca`. These copied bytes were checked before execution.

The successor security summary records zero Trivy matches, nine raw Grype matches and no untriaged findings for the exact browser. It explicitly limits nginx/curl conclusions to configuration applicability and retains unchanged-service historical audits. I inspected and hash-bound that summary; I did not independently rerun image scanners, applicability exploits, runtime binary comparisons or BusyBox regressions.

**Unexecuted claims and missing checks**

- Final Getzilla full PR gate, full fresh native product matrix, passing receipts and exact-head external PR checks: pending coordinator work; no release certification here.
- Fresh whole-stack runtime scan and certifi remediation: not performed; known exposure is open.
- Live browser UI successor verification: coordinator reported it ongoing; no completion assumed here.
- Physical mobile wallet pairing, live wallet funding observation, external borrowing and a new signed paid delivery: not executed; historical or synthetic evidence cannot establish these.
- Actual successor-image rollback rehearsal and production rollback: not executed; only isolated script probes ran.
- Current private backup completeness, restore contents, retained private script identity, private manifest or current database contents: not inspected; only sanitized historical records and public scripts reviewed.
- Production metrics, alert delivery and long-running operational observation: not exercised. Health/readiness/capabilities and exact preview checks are recorded point-in-time evidence, not continuous observability proof.

Keep audit evidence, source commits and production operations separate. The final report must retain this NO-GO decision unless the blocking dependency and evidence gaps are resolved on a freshly qualified source and runtime; passing browser or recovery checks alone do not resolve them.

