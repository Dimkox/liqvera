# Independent security review — Liqvera PR115 audit

**Verdict: FAIL for a clean whole-product security conclusion.** The reviewed browser change has no confirmed new authorization, payment, secret-disclosure or unknown-state regression in this review. Inherited TLS trust-store exposures remain actionable in Python, gateway Node, edge Go and development/build tooling. These are distinct affected consumers of the same CA incident, not four unrelated attacks. A passing web test or nginx configuration check does not resolve them. The final qualifying gate is pending and this report is not a PASS receipt.

## Source identity and boundaries

- Route: `fc7402fc1070`; change: `20261021-task-fc7402`; role: selected independent `security_reviewer`.
- Candidate: `/home/pall/projects/liqvera/.getzilla/runtime/pr115-liqvera`.
- HEAD before and after: `84851abfddbc46ad3f097ba17ef9cfadc9c3296d`.
- Committed tree before and after: `034acc73fb4561763aba7b920417f722bd6c73c9`.
- Working-tree status before and after: clean; no staged, unstaged or visible untracked source changes.
- Product commit: `57660040b36300de62cd45cb663bd2124167fe45`; comparison base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`.
- `git merge-base HEAD origin/main` equals the comparison base. All locally published tags `v0.0.1` through `v0.0.5` are ancestors; `git describe` reports `v0.0.5-44-g84851ab`. This is local-ref ancestry, not a fresh remote publication assertion. Worktree inventory showed only the audit worktree; no cleanup occurred.
- Pinned external Getzilla: commit `2bb417431f1e4b9494e4af71ebf27adb1d04d898`, tree `81076df2cd7db8713f7178ead66ebaa2728f861e`.
- Private reviewer scratch: `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-security`, mode `0700`, below the non-sticky mode-`0700` canonical runtime parent. `git archive` reproduced the exact clean committed candidate before tests; archive SHA-256 `9014d5550f595319a98d64f10651852ba3981e0bfaf1e09ac51692c84007f216` (564 members). Only scratch received generated protocol build files and test output.
- **reviewed-tree-modified: no**.

Read repository policy, README, architecture, specification, handoff, the change package and analysis, and the pinned delivery/security-review instructions. Reviewed the actual base-to-candidate browser diff and adjacent security boundaries. Gateway, SQL migrations, capture/report code, protocol/schema files, dependencies and deployment sources are unchanged over this comparison. Those inherited components were inspected for interaction and current dependency risk; the web-only change must not be blamed for introducing the findings below.

## Findings

### SR-01 — Critical advisory: affected certifi is pinned and used for live capture TLS

Locations: `requirements.lock:3`, `requirements-dev.lock:6`, `deploy/mezo-evidence/Dockerfile.capture:10`, `deploy/mezo-evidence/Dockerfile.report:10`, and `packages/public-capture/src/liqvera_public_capture/evidence_capture.py:108`.

Both locks contain `certifi==2026.7.22`. The runtime Docker builds consume that constraint. Live capture creates HTTPX 0.28.1 with `trust_env=False` and default verification; [HTTPX's pinned implementation](https://raw.githubusercontent.com/encode/httpx/0.28.1/httpx/_config.py) loads certifi in this configuration. Therefore replacing an unrelated system CA file is not an evidenced fix for capture.

[The certifi maintainer advisory](https://github.com/certifi/python-certifi/security/advisories/GHSA-6q48-6c7w-9gw2) rates the compromised-intermediate trust issue Critical. [The PyPA record](https://raw.githubusercontent.com/pypa/advisory-database/main/vulns/certifi/PYSEC-2026-4320.yaml) explicitly includes this pinned version and recommends `2026.10.19` or later. GHSA and PYSEC are aliases for one issue. An attacker possessing a compromised intermediate key and an on-path position could impersonate a TLS origin. Application inference: upstream market bytes could be changed before Liqvera seals and hashes them; downstream digest correctness would not authenticate the exchange. No interception or forged-certificate test was executed.

Evidence:

- Existing fresh OSV supplement `reviewer-docs-researcher/lock-scan.json` is `fail`, source `OSV API`, SHA-256 `6b995bcfab5b54173a338a0ab9462c8a06e3135cd60cd69dc10cd88a87ccae61`. Its four rows are the two advisory identifiers repeated for two lockfiles. They are not four unique vulnerabilities.
- Rechecked source-lock SHA-256 values match the scan inputs: runtime `5129c1a955aa2cca603d2ef7d297f6e3951e869b081ff93ff0a366116a917e3a`; development `8fadc7f93b6656ac16bbaf2b02825e87d731ba9f24aa22425c3f71b4e9ccee05`.
- Fresh coordinator-provided Trivy and Grype results now also identify affected certifi in capture `sha256:0eeaac0d5071cdd628d8aa0ac8bce1e4c3bdff95231932ccad1566c482c3f6a5` and report `sha256:317b8c5ae4f14a2ca9bc4ea529eb80a4e9ded790efd2863afeffa80b17e18d15`. Raw files are under canonical `runtime/stack-scans/`. Trivy reports Critical and fix `2026.10.19`. Report-image package presence alone does not prove an external TLS call from the isolated report service; capture has the concrete outbound path.

Remediation direction: update both locks to a reviewed fixed certifi version, rebuild and verify the Python images, and treat deployment as a separate operation. The old clean scans predate this advisory and remain historical evidence.

### SR-02 — High contextual risk: gateway default Node trust still includes the compromised root

Locations: `deploy/mezo-evidence/Dockerfile.gateway:24`, `apps/mezo-gateway/src/adapters/http.ts:5`, `apps/mezo-gateway/src/adapters/x402.ts:46`, and `apps/mezo-gateway/src/adapters/mezo-rpc.ts:22`.

A benign, network-disabled probe of the exact retained gateway image `sha256:226733a2ee759d28fb610768bccfba6b3f49cb6b76edad9cc29d3aac92d62b6c` reports Node `v24.18.1`. Both `tls.rootCertificates` and `tls.getCACertificates('default')` contain **emSign ECC Root CA - G3**, fingerprint `86:A1:EC:BA:08:9C:4A:8D:3B:BE:27:34:C6:12:BA:34:1D:81:3E:04:3C:F9:E8:A8:62:CD:5C:57:A3:6B:BE:6B`. This is the affected trust anchor identified by the CA incident above. Evidence: `reviewer-security/gateway-public-ca-roots.json`, SHA-256 `766034440a390fe11f0f4748db345045d2d8d2a22459a01f876964bf21feac31`.

The application uses default `fetch` in `boundedJson` for facilitator verify/settle/supported requests and HTTPS Mezo RPC calls. It supplies no custom CA, pinned certificate or independent TLS trust policy in that helper. Thus this is relevant to security decisions about payment and receipt observations, beyond an unused CA package. An eligible on-path attacker could threaten the integrity/confidentiality of those upstream exchanges. This is a reasoned applicability finding, not a demonstrated signature bypass, a forged paid entitlement or proof of exploitation. Default image trust was measured; private live environment overrides and live traffic were deliberately not inspected.

Fresh gateway npm/Trivy zero findings do not cover this trust-anchor condition. No separate Node CVE number or fixed Node release is asserted here. Remediation must remove the compromised trust from the **effective Node default trust set**, through a reviewed runtime/trust-store update, then rerun the same introspection and payment-boundary tests. Updating only certifi or assuming a system OpenSSL package update replaces Node's bundled roots is insufficient evidence.

### SR-03 — High advisory: edge Go verifier lacks the compromised-intermediate denylist

Location: `deploy/mezo-evidence/Dockerfile.edge:7`.

The exact retained edge image `sha256:2758b18f013b58b60356355affe505e7b4e29182873cfa710dbbf6d03f720233` is freshly matched to `CVE-2026-111943` / `GO-2026-6809`, Go stdlib `1.27.2`. [The Go security team's record](https://raw.githubusercontent.com/golang/vulndb/master/data/reports/GO-2026-6809.yaml) identifies `crypto/x509.Certificate.Verify`, fixed in `1.27.3` on this release line. [The upstream issue](https://github.com/golang/go/issues/82345) describes the intermediate distrust mitigation.

This reviewer copied only the public CA bundle and Caddy binary from an unstarted, network-disabled disposable container of that exact image, then removed the container. The bundle contains emSign ECC Root CA - G3. Native `nm` succeeded, enumerating 81,633 symbols including `crypto/x509.(*Certificate).Verify`. Caddy SHA-256 is `46cc40c5d4efcf16c21f62156f9b912f21576ec66d778f90e6ec35f337b6d1db`; CA-bundle SHA-256 is `028fca5150ee1915c4474489985d55c54fceaa680c754cc8d1301734f01b2232`. The fresh scan also records `ca-certificates` and bundle `20260909-r0`. No mitigating trust-store update has been demonstrated for this image.

Applicability is peer-certificate verification, such as Caddy outbound HTTPS/certificate automation. The configured application reverse proxies use internal HTTP. Root presence and a compiled symbol do not establish that a particular hostile chain was accepted, nor that inbound server TLS or client authentication is bypassed. No exploit or live ACME request was attempted. Preserve this as an unresolved inherited High finding; rebuild with the fixed Go line and reviewed current roots, then rescan/review the exact edge image.

The separate `GO-2026-5932` match concerns [unmaintained OpenPGP packages](https://pkg.go.dev/vuln/GO-2026-5932). There are zero `golang.org/x/crypto/openpgp` symbols in this unstripped binary, consistent with the earlier exact-binary govulncheck evidence. Its existing absent-code disposition remains distinct from the new x509 finding. A fresh govulncheck run was not performed; the local Go CLI is absent.

### SR-04 — High build-tool exposure: pinned pip has its own affected certifi copy

Locations: `pyproject.toml:14` and `requirements-dev.lock:28`.

Pip is pinned to `26.2.1`. [Its official vendor inventory](https://raw.githubusercontent.com/pypa/pip/26.2.1/src/pip/_vendor/vendor.txt) contains certifi `2026.6.17`; [pip 26.2.2 release notes](https://raw.githubusercontent.com/pypa/pip/26.2.2/NEWS.rst) update that vendored copy to `2026.10.19`. A separately installed certifi upgrade does not update pip's vendor tree. This is conditional development/build TLS risk under the CA incident's on-path prerequisite. The installed development pip instance, custom index policy and effective live build environment were not probed.

Production capture/report Dockerfiles uninstall pip and remove ensurepip (`Dockerfile.capture:22`, `Dockerfile.report:25`), so this is not reported as an active production pip endpoint. Update the pip development pins and independently verify effective tooling trust when addressing SR-01. The supplemental OSV scan's lack of a pip finding does not resolve a vendored trust bundle.

## Security boundaries reviewed

| Asset and boundary | Inspection and result | Executable coverage in this review |
| --- | --- | --- |
| Funding data versus payment authority | New finance module permits only `eth_chainId`, `eth_accounts`, `eth_getBlockByNumber` and `eth_call`; exact paired network/token, uint256 amounts, quote payer/expiry/READY state and clear payment guard are checked. No approval, transfer, signing or paid-report call is introduced. `mezo-finance.mjs:39`, `:114`. | Funding tests exercise allowlists, malformed inputs, identity changes, block-hash change, one-wei precision and shared timeout. |
| Current wallet/quote versus delayed observations | Provider and context identity plus a sequence token discard stale results. Busy/polling, non-clear guards, expiry and 30-second freshness invalidate balances/downloads. `mezo-finance-panel.ts:79`, `:94`, `:125`; `main.ts:169`. | Funding tests include provider replacement, uncertain state, wrong chain, failed reads and blob revocation. Additional hypothetical interleavings were not exhaustively explored. |
| Browser navigation and exported information | All dynamic new text uses `textContent`; Borrow URLs are fixed network-specific HTTPS constants; external links use `noopener noreferrer`. Export includes public account/quote/observation data, no bearer capability or authorization signature. Link/download handlers recheck eligibility. | Unit tests inspect emitted JSON and guarded links; real browser/physical wallet behavior was not re-executed by this reviewer. |
| Saved unknown payment state | Funding does not modify session/ledger state. Existing browser orchestration persists `started` before paid request and keeps ambiguous results `uncertain`; disconnect preserves the report identity. `browser-orchestration.ts:88`, `main.ts:528`, `:623`. | Existing orchestration, wallet-event and modal tests passed in scratch; these use mocks and do not constitute live settlement acceptance. |
| WalletConnect | Existing connection-only `AppKit` configuration, canonical origin metadata and disabled authentication/swaps/onramp remain unchanged; selected-provider events do not initiate payment. `wallet-appkit.ts:14`, `wallet-modal.ts:12`. CSP still permits same-origin scripts only. | Modal and wallet-provider/event unit tests passed. SDK pairing/relay/physical wallet tests are NOT_RUN here. |
| Server resource authorization and isolation | Scoped bearer digest reaches ledger predicates for request/quote/report resources; gateway receipt/finality/retention and artifact checks remain at the delivery boundary. `security/input.ts:4`, `routes/app.ts:28`, `adapters/postgres.ts:85`, `application/gateway.ts:82`. | Static inspection only in this review; independent server/database execution is NOT_RUN here. Coordinator's earlier 71 gateway passes, including 13 disposable-PostgreSQL cases, are separate bounded observations. |
| Irreversible settlement and recovery | `markSubmitting` durably commits before the sole settle call; replay/unknown/manual states are closed; recovery confirms only; retention excludes non-rejected attempts and entitlements. Merchant nonce index/migrations are unchanged. `application/gateway.ts:100`, `adapters/postgres.ts:147`, `workers/reconciliation.ts:4`, `workers/retention.ts:3`. | Static inspection only here. No live payment, replay/exploit, grant renewal, SQL mutation or recovery operation was executed. |
| Input/output, origin and logging | Existing bounded body/signature parsing, duplicate-header rejection, Origin allowlist, scoped/global/IP budgets, query parameters, no-store responses and bounded log fields remain unchanged. New funding data is not sent to an arbitrary URL. | Static inspection only; exhaustive injection/CSRF/SSRF/rate-limit/tenant probes NOT_RUN here. |

## Runtime and scanner evidence

The new browser image is bound to product commit `5766004`. Fresh `layout/web-trivy.json` contains zero vulnerability rows. Fresh `layout/web-grype.json` contains nine raw matches: five nginx, one curl and three BusyBox. Grype records the image's OCI config/manifest identifiers separately; its `repoDigests` includes the same `e824dfe5…` image reference as Trivy and the runtime summary. No matches were suppressed.

The retained configuration/backport dispositions remain narrowly supported. A fresh benign `nginx -T` execution on the exact browser image passed with `/tmp` mounted as disposable tmpfs. The full effective configuration output hashes to `c22f48101f88d774fa9d3ed7ff065181e379e94f71220d63e0237c021873e679`, exactly the recorded security-summary hash. It has constant root/log paths, no alias/rewrite/map capture configuration, no SSI/AIO, and no nginx TLS/HTTP3/proxy listener. The earlier `layout/runtime-comparison.txt` command failed to write `/tmp/nginx.pid`; that failure is not treated as a pass, and the new bounded check resolves that specific configuration-test limitation. The [nginx advisory index](https://nginx.org/en/security_advisories.html) confirms affected versions; F5 detail pages returned loading/CSS errors during this review. Nginx/curl packages are not claimed patched. [Curl's advisory](https://curl.se/docs/CVE-2026-92392.html) concerns HTTP/2 uploads; the retained configuration/linkage evidence does not place that path in the static browser service. BusyBox's recorded binary hash matches the reviewed backport. Exploit/regression backport tests were not rerun here.

All six additional service scans were inspected at the finding/inventory level. Fresh counts (Trivy/Grype) are gateway `0/4`, gateway-net `0/4`, PostgreSQL `0/3`, capture `1/6`, report `1/6`, edge `2/3`. Old BusyBox/CPython backport and unrelated Ada.cx/ada-url matches retain their previous image-bound dispositions; this review does not convert them to newly executed regression passes. New certifi/x509 findings remain open. Raw scan success and zero package-advisory rows do not certify trust-anchor correctness, as SR-02 demonstrates.

The normal Getzilla inventory omits the two `.lock` files and does not resolve all vendored/runtime components. The byte-identical `.txt` supplement, with `GETZILLA_OSV_DB=''` and online mode, is therefore mandatory evidence. That supplement was already executed by the docs researcher; this reviewer verified its hashes, current-input applicability and findings rather than rerunning the network scan.

Supplemental Bandit output has 27 rows: 25 Low and two Medium `B104` bindings (`evidence-report/service.py:265`, `public-capture/evidence_service.py:96`). The service bindings are expected inside Compose networks; the repository exposes the edge, not those service ports. This static configuration disposition is not a live network isolation test. Nested Docker scanning reports six Low missing-Dockerfile-HEALTHCHECK findings; the supplied Compose service definitions carry healthchecks. Neither tool result is represented as an unqualified zero-finding scan.

## Executed probes and exact commands

All paths below are under canonical `/home/pall/projects/liqvera/.getzilla/runtime`. The candidate was never used as a test output directory.

1. Identity/inventory: `git status --short`, `git log -8 --oneline`, `git worktree list`, `git rev-parse HEAD HEAD^{tree}`, `git diff --name-status f1d3bffc46fa1459908fdff865fcfbfc831b7f7f HEAD`, `git merge-base HEAD origin/main`, `git tag --merged HEAD`. One initial comparison mistyped the base with a trailing `7` and exited 128; the corrected exact base command succeeded. No failing source check was relabeled as a pass.
2. Snapshot: `git archive --format=tar 84851abfddbc46ad3f097ba17ef9cfadc9c3296d`, extracted only regular files/directories into private `reviewer-security/candidate`; no staged/unstaged source existed to supplement.
3. Funding, from scratch: `node --test --test-concurrency=1 apps/mezo-web/test/mezo-finance.test.mjs apps/mezo-web/test/musd-observation.test.mjs apps/mezo-web/test/mezo-finance-panel.test.mjs`. **55 passed, zero failed/skipped**, Node `v24.22.0`.
4. Compiled the scratch protocol using `/home/pall/projects/liqvera/.getzilla/runtime/pr115-liqvera/apps/mezo-web/node_modules/.bin/tsc -p packages/mezo-protocol/tsconfig.json`, with cwd in scratch. Linked only the scratch protocol package into the scratch web `node_modules`.
5. Wallet/recovery: `node --test --test-concurrency=1 apps/mezo-web/test/browser-flow.test.mjs apps/mezo-web/test/browser-orchestration.test.mjs apps/mezo-web/test/wallet-events.test.mjs apps/mezo-web/test/wallet-modal.test.mjs apps/mezo-web/test/wallet-provider.test.mjs`. **26 passed, zero failed/skipped**.
6. Edge image: `docker image inspect --format '{{.Id}}' sha256:2758b18f013b58b60356355affe505e7b4e29182873cfa710dbbf6d03f720233`; `docker create --pull=never --network none --read-only --cap-drop ALL --security-opt no-new-privileges --entrypoint /bin/true <same-image>`. Only `/usr/bin/caddy` and `/etc/ssl/certs/ca-certificates.crt` were copied to scratch with `docker cp`. Removed only returned disposable container `de312eac26c9d5ee7b0abe9ab7f602818e9e82ad5b8f92ffc631eb86584463c9` with `docker rm`; it was never started. Public CA subjects were obtained using `openssl crl2pkcs7 -nocrl -certfile <copied-bundle>` piped in memory to `openssl pkcs7 -print_certs -noout`; symbol inventory used `nm <copied-caddy>` (exit 0).
7. Browser image: `docker run --rm --pull=never --network none --read-only --tmpfs /tmp --cap-drop ALL --security-opt no-new-privileges --entrypoint nginx sha256:e824dfe58616166fcabbe973b140be27857d7dbb3113fa501296488610527e0f -T` (exit 0, successful test).
8. Gateway roots: the following exact probe exited 0. It does not load the application, request a network resource or read environment values.

```sh
docker run --rm --pull=never --network none --read-only --cap-drop ALL --security-opt no-new-privileges --entrypoint node sha256:226733a2ee759d28fb610768bccfba6b3f49cb6b76edad9cc29d3aac92d62b6c -e 'const tls = require("node:tls"); const {X509Certificate} = require("node:crypto"); const roots = tls.rootCertificates.map(pem => new X509Certificate(pem)); console.log(JSON.stringify({node:process.version, roots:roots.length, affectedRoots:roots.filter(cert => cert.subject.includes("emSign ECC Root CA - G3")).map(cert => ({subject:cert.subject, fingerprint256:cert.fingerprint256})), defaultRootCheckAvailable:typeof tls.getCACertificates === "function", defaultAffectedRoots:typeof tls.getCACertificates === "function" ? tls.getCACertificates("default").map(pem => new X509Certificate(pem)).filter(cert => cert.subject.includes("emSign ECC Root CA - G3")).map(cert => ({subject:cert.subject, fingerprint256:cert.fingerprint256})) : []}, null, 2));'
```

Full unit output and probe metadata are retained in `reviewer-security/`. `probe-hashes.json` binds `snapshot.json`, `source-after.json`, `funding-tests.log`, `wallet-guards-tests.log`, `edge-image-evidence.json`, `gateway-public-ca-roots.json` and `web-nginx-T.txt`. Final identity check at `2026-10-21T11:34:27Z` retains the exact clean candidate HEAD/tree above. Code/test mutation probes belong to the separately selected reviewers; **no application mutant was generated or scored by this security reviewer**.

## Explicit limits and disposition

No secret/private `.env` values, wallet keys, passwords, tokens, private grants, private dumps or browser profiles were inspected. No candidate edit, application fix, live quote, signature, payment, loan, deployment, publication, live database read/write, or live container mutation occurred. Public CA certificates and disposable image configurations are public audit material, not private credentials.

No exploitability claim is based only on a root subject or scanner severity: image trust presence and default code-path relevance are proven/inferred separately, while hostile-chain acceptance and end-to-end exploitation remain unexecuted. Full Python/Node builds, final gate, exhaustive server authorization/concurrency probes, physical WalletConnect interoperability, loan execution, and fresh paid delivery are NOT_RUN by this reviewer. Parent/coordinator evidence and the final qualifying gate must keep their own identities and outcomes.

The browser change can be assessed independently of these inherited issues, but the requested whole-product security audit must retain a negative verdict. A separate coherent remediation should update certifi and pip, remove compromised gateway trust, rebuild the edge with the x509 fix and current roots, and re-audit the resulting exact images. Existing ledger states, migrations, grants, sealed evidence and deployment recovery assets must remain preserved. No security exception or production authority is created by this report.
