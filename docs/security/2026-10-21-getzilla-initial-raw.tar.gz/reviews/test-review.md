# Independent test review — route fc7402fc1070

**Review result: PASS with two non-blocking regression-coverage findings.** The reviewed implementation passed the bounded probes below. No current checkbox, payment-guard, protocol-binding or layout defect was reproduced. The two native-test survivors are reported explicitly; reviewer-only supplemental probes killed both. This is an independent test-adequacy review, not a full-product verification receipt, security clearance or live acceptance result. The final qualifying gate has not run as of this report.

## Identity and read-only boundary

- Canonical project root: `/home/pall/projects/liqvera`.
- Reviewed candidate: `/home/pall/projects/liqvera/.getzilla/runtime/pr115-liqvera`.
- Before and after HEAD: `84851abfddbc46ad3f097ba17ef9cfadc9c3296d`.
- Before and after committed tree: `034acc73fb4561763aba7b920417f722bd6c73c9`.
- Before and after working status: empty, including ordinary untracked files. No relevant staged, unstaged or untracked source changes needed copying.
- Product source commit: `57660040b36300de62cd45cb663bd2124167fe45`, tree `7f70be70d1e53624ded7efcbba1c80eda5048437`. The candidate delta from that product commit contains only the recorded change package.
- Comparison base, observed `origin/main` and merge-base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`. There is no local `main` in this audit clone; the initial query against that absent name failed and was replaced with the actual `origin/main` reference. All locally published tags `v0.0.1` through `v0.0.5` are ancestors. `git worktree list --porcelain` showed only this audit-clone worktree; no cleanup was performed.
- Reviewer-owned scratch: `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-test`, outside the candidate, mode `0700`, under the trusted non-sticky canonical runtime parent, also mode `0700`.
- **reviewed-tree-modified: no**

Read the repository AGENTS, README, architecture, specification, handoff, actual source/test diff, active route, change brief/requirements/test plan, all four analysis reports and bounded-control evidence. Followed the pinned Getzilla delivery and test-reviewer instructions without installing its framework into Liqvera or running controller mutations in the candidate.

The private snapshot was created using:

```sh
git archive --format=tar --output=/home/pall/projects/liqvera/.getzilla/runtime/reviewer-test/source.tar 84851abfddbc46ad3f097ba17ef9cfadc9c3296d
git ls-tree -rz 84851abfddbc46ad3f097ba17ef9cfadc9c3296d
```

A Python verifier checked all 472 archive files/symlinks against their exact Git blob IDs and executable modes. It uses Git's blob hash input, `b'blob ' + decimal_length + b'\0' + bytes`. After the probes, it rechecked all 472 candidate files and all 472 scratch source files against the same manifest: **472/472 matched in both locations**. All scratch mutations were restored. The before/after `git status --porcelain=v1 --untracked-files=all` and `git rev-parse HEAD HEAD^{tree}` values above matched.

- Source manifest canonical JSON digest: `5791671bd7cbdc01146881bc389121103547b8ad74b288319fb0d61af5780516`.
- Source archive SHA-256: `9014d5550f595319a98d64f10651852ba3981e0bfaf1e09ac51692c84007f216`.
- Snapshot verification records: `reviewer-test/before.json`, `after.json`, `source-manifest.json`.

Only scratch dependencies were copied with `cp -a --reflink=auto` from the prepared audit installation. The copied local protocol symlink resolves to `reviewer-test/snapshot/packages/mezo-protocol`, not to the candidate. Protocol compilation, temporary modules, browser profiles, logs and mutation artifacts were generated only under reviewer scratch. Browser and test subprocesses inherited `taskset -c 0,1`; Node test concurrency was one. No full suite ran here.

## Non-blocking findings

1. **The committed panel tests do not exercise the 30-second observation freshness boundary.** In `apps/mezo-web/src/mezo-finance-panel.ts:95`, changing the upper freshness check from `Date.now() - lastBalance.at < 30000` to `true` survived all 55 funding tests. A reviewer-only deterministic clock probe passes on the actual candidate and fails on that mutant: at exactly 30 seconds, the candidate disables acknowledgement, removes the borrowing/download URLs and revokes the old blob. Add this boundary to the durable panel tests, including the still-valid quote case. This is a coverage gap, not an observed source defect; the current source enforces freshness and the observation has no payment authority.

2. **The committed Node funding tests do not detect loss of the CSS grid separation.** Replacing the section's `display:grid;gap:14px` with `display:block` in `apps/mezo-web/src/style.css:5` survived all 55 funding tests. The reviewer Chrome probe kills that mutant at all six widths: label/button gap becomes 0 px, and the borrowing-terms overlap is 33 px at desktop/tablet widths. The actual candidate has 14 px gaps throughout. Preserve a repeatable actual-browser geometry check as a separate validation step; the hand-written Element test double and historical JSDOM smoke do not lay out CSS. The existing external geometry evidence and the fresh reviewer browser probe verify the current change, so this does not block this test review.

Neither finding is converted into a hidden mutation-score threshold. Both concern durability of regression detection; both have passing executable evidence for the current source and a demonstrated failing mutant.

## Executed claims and commands

Commands below use `S=/home/pall/projects/liqvera/.getzilla/runtime/reviewer-test/snapshot` and `R=/home/pall/projects/liqvera/.getzilla/runtime/reviewer-test` only as path abbreviations in this report.

### Funding behavior and bounded RPC protocol

From `S`:

```sh
taskset -c 0,1 node --test --test-concurrency=1 apps/mezo-web/test/mezo-finance.test.mjs apps/mezo-web/test/musd-observation.test.mjs apps/mezo-web/test/mezo-finance-panel.test.mjs
```

Observed **55 tests, 55 passed, 0 failed, 0 skipped**, about 0.49 seconds. Full baseline output is `R/snapshot/baseline.log`.

This executes the initial no-quote guidance, fresh unpaid-shortfall acknowledgement, sufficient-funds suppression, quote/payer/network/expiry checks, unknown payment blocking, provider replacement, malformed RPC values, exact atomic amounts/budget, one-wei shortfall, block-specific reads, canonical-block recheck, final identity recheck, timeout/shared deadline, download invalidation and both Mezo networks. It is deterministic synthetic-wallet coverage, not a live network observation.

### Existing payment recovery and wallet orchestration

After compiling the scratch-local protocol package, from `S`:

```sh
taskset -c 0,1 apps/mezo-web/node_modules/.bin/tsc -p packages/mezo-protocol/tsconfig.json
taskset -c 0,1 node --test --test-concurrency=1 apps/mezo-web/test/browser-flow.test.mjs apps/mezo-web/test/browser-orchestration.test.mjs
```

Protocol compilation exited 0. The two test files produced **15 tests, 15 passed, 0 failed, 0 skipped**, about 0.32 seconds. Coverage includes GET-only recovery, saved request identity, ambiguous-result persistence, cancellation only after authoritative READY refresh, one guarded invocation, state-only wallet callbacks and replacement-provider ownership. No gateway/database mutation was performed by this reviewer.

From `R`:

```sh
taskset -c 0,1 node protocol-probe.mjs
```

The reviewer probe imports the freshly compiled real `mezoNetwork()` exports and supplies their chain/token/decimals values to `fundingEligibility` and `readFundingObservation`. **Testnet 31611 and Mainnet 31612 both PASS**; each observation retains its actual protocol network and token. Output: `R/protocol-probe.log`. This verifies consistency with the package metadata rather than merely repeating the finance module's constants. No external RPC was contacted.

### Actual browser, CSS and unknown-payment preservation

Built the actual entrypoint from `S`:

```sh
taskset -c 0,1 apps/mezo-web/node_modules/.bin/esbuild apps/mezo-web/src/main.ts --bundle --format=iife --platform=browser --target=es2022 --loader:.css=empty '--define:__LIQVERA_NETWORK__="testnet"' '--define:__LIQVERA_WALLETCONNECT_PROJECT_ID__=""' --outfile=../browser-main.js
```

Build exited 0; the scratch bundle was 9.2 MB. This is an esbuild browser probe bundle, not the production Vite/typecheck build. The browser separately loads exact candidate `style.css`.

From `R`:

```sh
taskset -c 0,1 timeout 45s node browser-probe.mjs control
```

**PASS** with actual Chrome `156.0.8078.47`, Node `24.22.0`. The loopback-only harness serves the candidate bundle and CSS, uses synthetic capability/quote responses and a synthetic EIP-1193 wallet, and records zero outbound application network requests and zero runtime exceptions.

Observed behavior:

- Initial no-wallet/no-quote acknowledgement is disabled. Calling the actual DOM checkbox `.click()` does not check it; borrowing has no `href`, balance read is disabled, and prerequisite guidance is present.
- After synthetic connection and one synthetic unpaid READY quote, acknowledgement remains disabled until the balance observation completes.
- Zero balance produces an exact 0.01 MUSD shortfall. The checkbox becomes enabled; the external link appears only after its actual DOM click. Funding calls only `eth_chainId`, `eth_accounts`, `eth_getBlockByNumber` and `eth_call`. The separate connect action uses `eth_requestAccounts`/`wallet_switchEthereumChain`; it is not counted as funding authority.
- Sufficient synthetic MUSD disables acknowledgement and borrowing and preserves the saved checkout flow.
- Reload with the existing flow's `paymentGuard: uncertain` preserves that guard even when the synthetic quote endpoint reports READY. Acknowledgement, balance read, borrowing and observation download remain disabled. Recovery performs only GET capabilities/quote requests and account/chain reads; no additional quote POST, signature or paid-report call occurs.
- At **320, 390, 768, 1024, 1280 and 1440 px**, both label-to-borrow and borrow-to-terms gaps are **14 px**, with no horizontal overflow. The canonical Getzilla footer link is present.

Complete results: `R/browser-control.json`, `browser-control.log`; harness: `browser-probe.mjs`. The first harness invocation incorrectly included the existing connection-time switch request in its funding-only RPC assertion. It was a harness failure, retained as `browser-control-harness-error.{json,log}`. Source inspection confirmed the existing `connectWallet` switch; the corrected probe models that request and independently checks only the funding call segment. No application change was made to obtain the passing result.

### Reviewer-only freshness boundary

From `R`:

```sh
taskset -c 0,1 node --test --test-concurrency=1 freshness.test.mjs
```

Actual source: **1 passed, 0 failed**. The same command against only M4: **0 passed, 1 failed**, assertion `false !== true` at the expected disabled checkbox. The test also asserts cleared borrowing/download URLs and revoked blob on the unchanged candidate. Full mutant result: `R/freshness-mutant.log`.

## Mutation results

Executed `python3 /home/pall/projects/liqvera/.getzilla/runtime/reviewer-test/mutations.py`. Each mutant changed exactly one scratch-source expression, ran the same 55-test funding command above, preserved the complete output, and restored original bytes in `finally`. Exact old/new expressions, argv, cwd, exit status and failing test names are in `R/mutations.json`.

| ID | Claim weakened | Native funding result | Outcome |
|---|---|---|---|
| M1 | Force `ack.disabled = false` | Exit 1; 54 pass / 1 fail, initial preview assertion | **killed** |
| M2 | Force `ack.disabled = true` | Exit 1; 54 / 1, fresh-shortfall acknowledgement assertion | **killed** |
| M3 | Delete non-clear payment-guard rejection | Exit 1; 53 / 2, unknown guidance and pending guard | **killed** |
| M4 | Remove the 30-second upper freshness bound | Exit 0; 55 / 0 | **survived native tests**; **killed** by reviewer freshness probe |
| M5 | Ignore canonical block-hash mismatch | Exit 1; 54 / 1, changed-block rejection | **killed** |
| M6 | Remove positive-shortfall requirement from borrowing link | Exit 1; 54 / 1, sufficient-funds suppression | **killed** |
| M7 | Replace grid/gap with block layout | Exit 0; 55 / 0 | **survived native tests**; **killed** by actual Chrome geometry |

For the browser M7 probe, from `R`:

```sh
taskset -c 0,1 timeout 45s node browser-probe.mjs css-mutant
```

The harness applies the same single CSS replacement only to its scratch-served asset. Captured Node exit **1**; geometry assertions fail at all widths. Results: `browser-css-mutant.json`, `browser-css-mutant-run.json`, `browser-css-mutant.log`. No timeouts, setup errors or inconclusive mutation classifications occurred. There is no invented blanket score threshold, and the native survivors remain findings despite supplemental kills.

## Existing evidence and unexecuted claims

Inspected current audit-clone raw logs, without rerunning or writing to that clone:

- `.getzilla/runtime/web-control-retry.log`: **104 passed, 0 failed, 0 skipped**. The original `.getzilla/runtime/web-control.log` contains real `ERR_MODULE_NOT_FOUND` failures for the unbuilt local protocol `dist/index.js`; that failed invocation remains visible. The successful retry follows the documented protocol compilation. These are coordinator bounded controls, not this reviewer's complete-suite execution or the final gate.
- `.getzilla/runtime/gateway-tests.log`: **71 passed, 0 failed, 0 skipped**, consistent with the bounded-control record including 13 disposable-PostgreSQL cases. This reviewer did not recreate the database or independently rerun those 71 cases; no live ledger guarantee is inferred.
- `.getzilla/runtime/artifacts-control.log`: native artifact guard reports no Go inputs; `.getzilla/runtime/docs-control.log`: 58-document link check passes. These are existing control observations, not fresh reviewer artifact executions.
- The recorded **951 Python tests plus 85 subtests** are historical at `9ca9ced`; they do not qualify this reviewed tree. The earlier JSDOM funding smoke is likewise historical synthetic evidence, not actual browser layout or new payment acceptance.
- The earlier layout record under canonical runtime shows 14 px gaps at the same six widths. The actual current-source Chrome probe above provides separate fresh confirmation.

**Not executed here:** the final Getzilla qualifying PR gate; full native Python suite; complete web/gateway production build matrix; dependency/security scans; Docker/image/backport checks; independent PostgreSQL concurrency, retention or restart mutation probes; fresh artifact/offline-bundle acceptance; physical wallet or WalletConnect pairing; real chain balance observation; external borrowing; signed payment, paid delivery, grant renewal, deployment, publication or production database access. Static source observations concerning those paths are **unexecuted claims**, not passes. The coordinator's stated final plan is the unmodified pinned PR verifier with full scope/keep-going and `PYTEST_ADDOPTS=tests` to include the canonical all-tests Python target once, plus the artifact guard and explicit Node/security supplements; none is pre-certified by this report.

The optional external verifier's documented nested-Node, Python discovery, lockfile and deployment-config omissions require the native supplements. Its zero-contract/zero-SQL checks cannot demonstrate state or API semantics. Existing certifi/security findings are outside this test-review decision and prevent interpreting a green test result as a clean security audit.

## Evidence preservation

All complete reviewer outputs stay outside the candidate in `R`. `evidence-manifest.json` binds 25 probe/identity/log files; SHA-256 of that manifest is `786756f61df25ff0c3aecdc436d81263a741e6644ba705569bceeacea43f1ec3`. The browser harness SHA-256 is `bad8568b20d86a4f7579884e0b3ab393f38c91697608bf6ee7cdf9eae5b1655e`; mutation-results SHA-256 is `57cdaac2cec841bb6f0853b0d8b5f66a28b368663f093e123aa3391dea8a3e3b`.

The coordinator may persist this complete report after all selected reviewers finish, then freeze the report-only successor and run the qualifying gate. No application fixes, candidate edits, secret/private-grant reads or external mutations were performed by this reviewer.
