from __future__ import annotations

import unittest

from tests.test_architecture_fitness import FIT, GitArchitectureRepo
from tests.test_architecture_model import _rules, _system


class QueueAdapterDemandTests(unittest.TestCase):
    def repo(self):
        repo = GitArchitectureRepo(self)
        system = _system()
        system['nodes'][0]['type'] = 'worker'
        system['nodes'][0]['repository_paths'] = ['adapters', 'src']
        rules = _rules()
        rules['background_job_policies'] = [{
            'id': 'FIT-JOBS', 'node_types': ['worker'], 'max_retries': 3,
            'require_idempotency': True, 'require_correlation_id': True,
            'terminal_actions': ['dead_letter'], 'severity': 'error',
        }]
        repo.model(system, rules)
        repo.write_text('adapters/__init__.py', '')
        return repo

    def evaluate(self, repo, source, *, before='', path='src/consumer.py'):
        repo.write_text(path, before)
        base = repo.commit('base')
        repo.write_text(path, source)
        head = repo.commit('changed operation')
        diff = FIT.diff_architecture(repo.root, base_sha=base, head_sha=head)
        report = FIT.evaluate_fitness(repo.root, FIT.load_architecture(repo.root), diff,
                                      diff.changed_paths, pre_risk='yellow')
        result = next(item for item in report.results if item.category == 'background_job')
        return result, report

    def chain(self, repo, kind):
        if kind == 'depth':
            for index in range(FIT.MAX_QUEUE_ADAPTER_DEPTH + 1):
                body = ('return 1' if index == FIT.MAX_QUEUE_ADAPTER_DEPTH else
                        f'from adapters.m{index + 1} import run\n    return run()')
                repo.write_text(f'adapters/m{index}.py', f'def run():\n    {body}\n')
            return 'from adapters.m0 import run\n    return run()'
        imports = []
        for index in range(FIT.MAX_QUEUE_ADAPTER_MODULES + 1):
            repo.write_text(f'adapters/m{index}.py', 'def run():\n    return 1\n')
            imports.append(f'from adapters.m{index} import run as run{index}')
        return '\n    '.join((*imports, *(f'run{index}()' for index in range(len(imports)))))

    def test_unused_function_imports_do_not_spend_demanded_module_budget(self):
        for kind in ('depth', 'width'):
            for imported, call in (('from adapters.facade import selected\n', 'selected()'),
                                   ('import adapters.facade as facade\n', 'facade.selected()')):
                with self.subTest(kind=kind, imported=imported):
                    repo = self.repo()
                    unused = self.chain(repo, kind)
                    repo.write_text('adapters/facade.py',
                                    f'def unused():\n    {unused}\ndef selected():\n    return 1\n')
                    result, report = self.evaluate(repo, imported + call + '\n', before=imported)
                    self.assertEqual(result.status, 'not_applicable', result.findings)
                    self.assertNotIn('new_queue', report.triggers)

    def test_demanded_function_chain_still_enforces_original_bounds(self):
        self.assertEqual((FIT.MAX_QUEUE_ADAPTER_MODULES, FIT.MAX_QUEUE_ADAPTER_DEPTH), (32, 8))
        for kind in ('depth', 'width'):
            with self.subTest(kind=kind):
                repo = self.repo()
                body = self.chain(repo, kind)
                repo.write_text('adapters/facade.py', f'def selected():\n    {body}\n')
                imported = 'from adapters.facade import selected\n'
                result, report = self.evaluate(repo, imported + 'selected()\n', before=imported)
                self.assertEqual(result.status, 'unsupported')
                self.assertIn('new_queue', report.triggers)

    def test_demanded_return_alias_wrapper_and_closure_keep_queue_provenance(self):
        for body in (
            'def selected():\n    from rq import Queue\n    return Queue()\n',
            'from rq import Queue\ndef private():\n    return Queue()\nselected = private\n',
            'from rq import Queue\ndef private():\n    return Queue()\n'
            'def selected():\n    return private()\n',
            'from rq import Queue\ndef selected():\n'
            '    def nested():\n        return Queue()\n    return nested\n',
        ):
            with self.subTest(body=body.splitlines()[0]):
                repo = self.repo()
                repo.write_text('adapters/facade.py', body)
                imported = 'from adapters.facade import selected\n'
                result, report = self.evaluate(repo, imported + 'selected().enqueue(job)\n', before=imported)
                self.assertEqual(result.status, 'unsupported')
                self.assertIn('new_queue', report.triggers)

    def test_top_level_calls_defaults_and_decorators_are_not_sliced_away(self):
        for side_effect in ('run()\n', '@run()\ndef unused():\n    pass\n',
                            'def unused(value=run()):\n    pass\n'):
            with self.subTest(side_effect=side_effect.splitlines()[0]):
                repo = self.repo()
                self.chain(repo, 'depth')
                repo.write_text('adapters/facade.py', 'from adapters.m0 import run\n'
                                + side_effect + 'def selected():\n    return 1\n')
                imported = 'from adapters.facade import selected\n'
                result, report = self.evaluate(repo, imported + 'selected()\n', before=imported)
                self.assertEqual(result.status, 'unsupported')
                self.assertIn('new_queue', report.triggers)

    def test_unused_module_import_retains_executed_queue_side_effects(self):
        for imported in ('import adapters.side_effect\n',
                         'from adapters.side_effect import value\n'):
            with self.subTest(imported=imported):
                repo = self.repo()
                repo.write_text('adapters/side_effect.py', 'from rq import Queue\n'
                                'active = Queue()\nactive.enqueue("job")\nvalue = 1\n')
                repo.write_text('adapters/facade.py', imported + 'def selected():\n    return 1\n')
                result, report = self.evaluate(repo, 'from adapters.facade import selected\nselected()\n')
                self.assertEqual(result.status, 'unsupported')
                self.assertIn('new_queue', report.triggers)

    def test_narrow_cache_cannot_hide_later_private_queue_export(self):
        for first, second in (('selected', '_hidden'), ('_hidden', 'selected')):
            with self.subTest(first=first):
                repo = self.repo()
                repo.write_text('adapters/facade.py', 'def selected():\n    return 1\n'
                                'def _hidden():\n    from rq import Queue\n    return Queue()\n')
                repo.write_text('src/first.py', f'from adapters.facade import {first}\n')
                imported = f'from adapters.facade import {second}\n'
                repo.write_text('src/second.py', imported)
                base = repo.commit('base')
                repo.write_text('src/first.py', f'from adapters.facade import {first}\n{first}()\n')
                repo.write_text('src/second.py', imported + f'{second}()\n')
                head = repo.commit('two demands')
                diff = FIT.diff_architecture(repo.root, base_sha=base, head_sha=head)
                report = FIT.evaluate_fitness(repo.root, FIT.load_architecture(repo.root), diff,
                                              diff.changed_paths, pre_risk='yellow')
                result = next(item for item in report.results if item.category == 'background_job')
                self.assertEqual(result.status, 'unsupported')
                self.assertIn('new_queue', report.triggers)


if __name__ == '__main__':
    unittest.main()
