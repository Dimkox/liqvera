# Factory pin consistency repair

Commit: `0350dcc781640c896092566ecd4dc05801f16851`. The isolated gate-repair worktree is clean. This is bounded component evidence, not a qualifying full gate receipt.

The runtime wheel inventory is derived from the existing lockfile; only its lock hash and the certifi wheel version, filename and digest changed. The isolated PDF worker and parser metadata now require the declared pypdf 6.19.0. The test probe reads that declaration, and a non-skipped assertion binds the production metadata to it. The eight existing exact profile enum objects retain their order, membership and all fields except the parser version and worker digest. Isolation, resource limits, database behavior and the 720-second gate timeout are unchanged.

RED evidence: the PDF module ran nine tests with five failures, one error and one skip before production edits; all five real parser cases executed. The existing inventory derivation test failed with inventory drift. The existing exact profile test then failed all eight profile subtests before regeneration.

GREEN evidence: PDF and media controls ran 11 tests, 10 passed and one was skipped; all five parser-present tests passed. The sole skip is the parser-absent branch because the actual supported child interpreter has pypdf 6.19.0. The complete offline builder module passed seven tests. The exact profile test and semantic contract module passed ten tests. Ruff, Bandit and Git whitespace checks passed.

Validation used CPUs 16-23 and trusted non-Git temporary directory `/home/pall/gzgr`; factory interpreter `/home/pall/gzgr/fenv/bin/python` is Python 3.12.3 with the locked dependencies. Detailed logs and hashes are bound in `getzilla-gate-pin-handoff.json`.

The bounded worktree architecture check against `e158ddc7263a55f5308944c5a426eb1e9f1a4327` remains FAIL only for contract compatibility: the backend capability v1 enum is narrowed and producer output is widened; the referencing landing failover OpenAPI v1 output is also widened. This is a real change in accepted exact profiles, not an unsupported-comparison error. Compatibility/versioning needs coordinator and architecture review before a full-gate success can be claimed. This commit makes no compatibility exemption or comparator change.
