# Hook package ownership repair

Commit `378c70f180af7e1d1ceab54e87e8446df0df33a9` is a direct child of frozen R4 `b1ff3de3eb952521cacaa1119c88d2d6990c0545`. The isolated `getzilla-hook-ownership-repair` worktree is clean. The diff changes only `.grok/hooks/_lib.py` and `tests/test_hook_degraded.py`: 13 production lines and 54 test lines.

The helper requires its own regular package initializer before importing Getzilla. It then checks the imported package's actual file and package search path before loading policy helpers. This also rejects an already cached foreign package. Import failures enter the existing standard-library degraded path: ordinary reads remain allowed, protected classifications are denied, and `HOOK_DEGRADED` records the failure. Competing healthy paths remain present in the tests. Missing-package tests also check that no foreign package initialized before rejection.

RED: the two new real-subprocess tests produced six assertion failures and zero errors on the R4 source. GREEN: all 74 distinct tests in the complete degradation, degraded-fail-closed, enforcement, hook and harness-payload modules passed with zero skips. The initial focused two-test run also passed. Removing the initializer precondition from disposable fixture hooks produced four assertion failures; removing the package ownership check produced two. Both mutation controls had zero errors. No classified command was executed.

Ruff, Bandit and Git whitespace checks passed. Runs used CPUs 16-23 with at most four parallel test workers, the gate Python 3.12 environment and trusted non-Git TMPDIR `/home/pall/gzgr`. The source diff is `getzilla-hook-ownership-source.patch`; exact hashes and all RED/GREEN/mutation logs are bound by `getzilla-hook-ownership-handoff.json`.

This is bounded implementation evidence. The coordinator owns new independent review and the qualifying full gate. Existing R4 reports/probes, compatibility limits, API/PDF behavior, budgets, timeout and runner configuration were not changed by this repair.
