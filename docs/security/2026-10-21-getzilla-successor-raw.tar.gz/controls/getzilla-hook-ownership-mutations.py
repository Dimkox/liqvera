"""Run hook ownership mutants only in disposable test fixtures."""
from contextlib import contextmanager
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

root = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(root), str(root / '.getzilla')]
from tests import test_hook_degraded as tests

original_copy = tests.project_copy
mutants = {
    'missing_initializer_guard': (
        "if not PACKAGE_INIT.is_file() or PACKAGE_INIT.resolve() != PACKAGE_INIT:\n"
        "    raise ImportError('Hook requires its own regular Getzilla package initializer')\n",
        'test_missing_own_package_never_falls_back_to_foreign_pythonpath',
    ),
    'package_ownership_guard': (
        "if (Path(getattr(getzilla, '__file__', '')).resolve() != PACKAGE_INIT\n"
        "        or tuple(Path(path).resolve() for path in getattr(getzilla, '__path__', ())) != (PACKAGE,)):\n"
        "    raise ImportError('Hook imported a Getzilla package outside its installation')\n",
        'test_cached_foreign_package_cannot_supply_hook_policy',
    ),
}
results = []
for name, (removed, method) in mutants.items():
    @contextmanager
    def mutant_copy(**kwargs):
        with original_copy(**kwargs) as fixture:
            target = fixture / '.grok/hooks/_lib.py'
            source = target.read_text()
            assert source.count(removed) == 1
            target.write_text(source.replace(removed, ''))
            yield fixture

    print(f'MUTANT {name}', flush=True)
    suite = unittest.TestSuite([tests.HookDegradedTests(method)])
    with patch.object(tests, 'project_copy', mutant_copy):
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    observation = {'mutant': name, 'tests': result.testsRun, 'failures': len(result.failures),
                   'errors': len(result.errors), 'killed': bool(result.failures) and not result.errors}
    results.append(observation)
print(json.dumps(results, indent=2))
raise SystemExit(0 if all(result['killed'] for result in results) else 1)
