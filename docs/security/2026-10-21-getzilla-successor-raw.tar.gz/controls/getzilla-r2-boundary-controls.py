from __future__ import annotations

import importlib
import inspect
import json
import subprocess
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

REPO = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions-repair')
OUTPUT = Path('/home/pall/projects/liqvera/.getzilla/runtime/completion')
sys.path[:0] = [str(REPO / '.getzilla'), str(REPO / 'tests')]

from getzilla import verification_dispositions
from getzilla.verification import _secret_scan

tests = importlib.import_module('test_verification_dispositions')
original = verification_dispositions._standalone_context
source = inspect.getsource(original)
whitespace_line = "whitespace = ' \\t\\r\\n\\f\\v'"
assert source.count(whitespace_line) == 1
namespace = dict(verification_dispositions.__dict__)
exec(compile(source.replace(whitespace_line, "whitespace = ' \\t\\r\\n'"),
             '<remove-form-feed-and-vertical-tab>', 'exec'), namespace)
mutants = (
    ('remove-context-gate', lambda text, end: True, (
        'test_address_shape_does_not_admit_credential_names_or_opaque_values',
        'test_real_scanner_suffix_never_disposes_unicode_or_escaped_credentials',
        'test_non_ascii_prefix_cannot_erase_member_context',
        'test_non_ascii_comment_and_string_prefixes_are_conservatively_refused',
        'test_ascii_whitespace_preserves_declarations_and_member_rejection',
        'test_unsupported_ascii_constructs_cannot_manufacture_standalone_context',
    )),
    ('remove-ascii-ff-vt', namespace['_standalone_context'], (
        'test_ascii_whitespace_preserves_declarations_and_member_rejection',
    )),
)
summary = []
for label, replacement, methods in mutants:
    suite = unittest.TestSuite(tests.DispositionTests(method) for method in methods)
    log = OUTPUT / f'getzilla-r2-boundary-mutation-{label}.log'
    with log.open('w') as stream, patch.object(
            verification_dispositions, '_standalone_context', replacement):
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    record = {'mutation': label, 'tests_run': result.testsRun,
              'assertion_failures': len(result.failures), 'errors': len(result.errors),
              'status': 'KILLED' if result.failures and not result.errors else 'SURVIVED_OR_ERROR',
              'log': str(log)}
    summary.append(record)
    print(json.dumps(record))
(OUTPUT / 'getzilla-r2-boundary-mutation-results.json').write_text(
    json.dumps(summary, indent=2) + '\n')
assert all(item['status'] == 'KILLED' for item in summary)
assert verification_dispositions._standalone_context is original

target = Path('/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit')
policy = verification_dispositions.Dispositions(target)
paths = sorted({entry['path'] for entry in policy.entries if entry['check'] == 'secret-scan'})
result = _secret_scan(target, paths)
observation = {
    'evidence_kind': 'bounded observation; no receipt',
    'target_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=target, text=True).strip(),
    'checked_paths': paths,
    'result': result.to_dict(),
}
(OUTPUT / 'getzilla-r2-boundary-liqvera-native.json').write_text(
    json.dumps(observation, indent=2) + '\n')
counts = next(item for item in result.details if item['code'] == 'disposition-summary')
print(json.dumps({'native_status': result.status, 'counts': counts, 'checked_paths': paths}))
assert result.status == 'pass'
assert counts['observed'] == 2 and counts['disposed'] == 2 and counts['unresolved'] == 0
