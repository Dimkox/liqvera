"""Archive a passing Liqvera audit and the explicitly failed tool self-check."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--tool-commit', required=True)
parser.add_argument('--audit-commit', required=True)
parser.add_argument('--getzilla-attempt', type=int, default=2)
parser.add_argument('--liqvera-attempt', type=int, default=2)
args = parser.parse_args()
runtime = Path('/home/pall/projects/liqvera/.getzilla/runtime')
completion = runtime / 'completion'
tool = runtime / 'getzilla-audit-final'
audit = runtime / 'liqvera-final-audit'
output = completion / 'liqvera-audit-archive'
output.mkdir(mode=0o700, exist_ok=False)
payload = output / 'payload'
payload.mkdir(mode=0o700)
public_evidence_extensions = {'.json', '.jsonl', '.md', '.log', '.txt', '.py', '.mjs', '.js', '.sh', '.diff', '.patch', '.stdout', '.stderr', '.xml'}


def git(root, *parts):
    return subprocess.check_output(['git', *parts], cwd=root, text=True).strip()


def copy(source, relative):
    assert source.is_file() and not source.is_symlink(), source
    assert not any(part in {'.env', 'approvals', 'grants', 'credentials'} for part in source.parts)
    target = payload / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists(), target
    target.write_bytes(source.read_bytes())


identities = {}
for kind, root, expected, change, base in [
    ('getzilla', tool, args.tool_commit, 'd83415', 'e158ddc7263a55f5308944c5a426eb1e9f1a4327'),
    ('liqvera', audit, args.audit_commit, 'ec1239', '3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd'),
]:
    assert git(root, 'rev-parse', 'HEAD') == expected
    assert not git(root, 'status', '--porcelain')
    attempt = args.getzilla_attempt if kind == 'getzilla' else args.liqvera_attempt
    final = root / '.getzilla/runtime' / f'final-{attempt}'
    invocation = json.loads((final / 'invocation.json').read_text())
    gate = json.loads((final / 'getzilla-pr.json').read_text())
    status = json.loads((final / 'evidence-status.json').read_text())
    if kind == 'liqvera':
        assert invocation['returncode'] == 0 and gate['status'] == 'pass'
        assert not status['evidence_gaps'] and not status['package_incomplete']
    else:
        assert invocation['returncode'] == 1 and gate['status'] == 'fail'
        assert 'verification: status=fail' in status['evidence_gaps']
    assert invocation['head'] == invocation['head_after'] == expected
    assert invocation['tree'] == invocation['tree_after'] == git(root, 'rev-parse', 'HEAD^{tree}')
    assert invocation['git_status_after'] == ''
    for name in ['invocation.json', 'getzilla-pr.json', 'getzilla-pr.stderr', 'evidence-status.json']:
        copy(final / name, f'{kind}/final/{name}')
    package = root / f'engineering/changes/20261021-task-{change}'
    for name in git(root, 'ls-files', '--', str(package.relative_to(root))).splitlines():
        copy(root / name, f'{kind}/change/' + str(Path(name).relative_to(package.relative_to(root))))
    route_id = {'getzilla': 'd834158878e0', 'liqvera': 'ec1239ea42dd'}[kind]
    receipt_directory = root / '.getzilla/runtime/receipts' / route_id
    assert receipt_directory.is_dir() and not receipt_directory.is_symlink()
    required_receipts = set()
    if kind == 'liqvera':
        required_receipts = {'verification.json', 'code_review.json', 'test_review.json', 'security_review.json', 'release_review.json', 'data_review.json'}
    assert required_receipts <= {source.name for source in receipt_directory.glob('*.json')}
    for source in sorted(receipt_directory.glob('*.json')):
        copy(source, f'{kind}/receipts/{route_id}/{source.name}')
    for name in ['active-route.json', 'active-change.json']:
        copy(root / '.getzilla/runtime' / name, f'{kind}/runtime-selection/{name}')
    bundle = payload / f'{kind}/frozen-audit.bundle'
    subprocess.run(['git', 'bundle', 'create', str(bundle), f'{base}..HEAD'], cwd=root, check=True)
    verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], cwd=root, capture_output=True, text=True, check=True)
    (payload / f'{kind}/bundle-verification.txt').write_text(verified.stdout + verified.stderr)
    identities[kind] = {'commit': expected, 'tree': invocation['tree'], 'reviewed_commit': invocation['reviewed_head'],
                        'comparison_base': invocation['comparison_base'], 'bundle_prerequisite': base,
                        'duration_seconds': invocation['duration_seconds'], 'returncode': invocation['returncode'],
                        'attempt': attempt, 'status': gate['status'], 'evidence_gaps': status['evidence_gaps'],
                        'package_incomplete': status['package_incomplete'],
                        'receipt_files': sorted(source.name for source in receipt_directory.glob('*.json')),
                        'checks': [{'name': check['name'], 'status': check['status'], 'summary': check['summary']} for check in gate['checks']]}

for relative in ['engineering/verification-dispositions.json', 'docs/security/2026-10-21-verification-dispositions.md']:
    copy(audit / relative, f'liqvera/product/{relative}')
binding = json.loads((audit / 'engineering/changes/20261021-task-ec1239/evidence/tool-binding.json').read_text())
for relative, expected_hash in binding['overlay'].items():
    source = audit / relative
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected_hash
    copy(source, f'liqvera/tool-overlay/{relative}')
for name in ['run-qualifying-gate.py', 'prepare-liqvera-review.py', 'archive-successor.py', 'save-final-reviews.py', 'record-final-reviews.py', 'refresh-public-readback.py',
             'getzilla-gate-requirements.txt', 'getzilla-gate-environment.json', 'prepare-liqvera-review-first.py', 'check-gate-repair.py', 'check-gate-repair-first-all-tracked.py', 'check-liqvera-second.py', 'preserve-getzilla-r4.py', 'prepare-getzilla-r5.py', 'write-successor-report.py',
             'archive-liqvera-audit.py', 'write-liqvera-audit-report.py', 'preserve-getzilla-second-gate.py']:
    copy(completion / name, f'coordinator/{name}')
copy(completion / 'liqvera-pip-red.log', 'controls/liqvera-pip-red.log')
for name in ['public-readback-final.json', 'public-readback-before-final.json', 'getzilla-publication-status.json']:
    copy(completion / name, f'external-observations/{name}')
for kind, attempt in [('getzilla', 1), ('getzilla', 2), ('liqvera', 1)]:
    for source in sorted((completion / f'{kind}-failed-gate-{attempt}').iterdir()):
        if source.is_file():
            copy(source, f'failed-gates/{kind}-{attempt}/{source.name}')
copy(completion / 'liqvera-final-scope-review.md', 'scope/liqvera-final-scope-review.md')
for source in sorted(completion.glob('getzilla-gate-*-diagnosis*')):
    if source.is_file() and source.suffix in public_evidence_extensions:
        copy(source, f'gate-diagnosis/{source.name}')
directory = completion / 'getzilla-gate-environment-diagnosis'
for source in sorted(directory.iterdir()):
    if source.is_file() and source.suffix in public_evidence_extensions:
        copy(source, f'gate-diagnosis/environment/{source.name}')
patterns = ['getzilla-dispositions-red.log', 'getzilla-dispositions-packaging-red.log',
            'getzilla-dispositions-green.log', 'getzilla-dispositions-controls.log',
            'getzilla-dispositions-bounded.log', 'getzilla-dispositions-packaging-green.log',
            'getzilla-committed-controls.json', 'getzilla-boundary-*', 'getzilla-r2-boundary-*',
            'getzilla-repaired-controls.*', 'getzilla-r3-committed-controls*',
            'getzilla-gate-capacity-*', 'getzilla-gate-architecture-capacity*',
            'getzilla-gate-import-effects-*', 'getzilla-gate-hook-*',
            'getzilla-gate-slicer-*', 'getzilla-gate-demand-*', 'getzilla-gate-repair-*', 'getzilla-r4-committed-controls*', 'getzilla-r5-committed-controls*', 'getzilla-hook-ownership-*',
            'getzilla-gate-profile-*', 'getzilla-gate-pdf-*', 'getzilla-gate-pin-*', 'getzilla-gate-inventory-*', 'getzilla-inventory-only-*',
            'getzilla-r5-saved-report-bindings.json', 'liqvera-second-saved-report-bindings.json', 'liqvera-second-committed-controls.json']
copied = set()
for pattern in patterns:
    for source in sorted(completion.glob(pattern)):
        if source.is_file() and source.name not in copied:
            copy(source, f'controls/{source.name}')
            copied.add(source.name)
review_directories = []
for role in ['code', 'test', 'security', 'release']:
    review_directories.extend([f'getzilla-{role}-review', f'getzilla-r2-{role}-review', f'getzilla-r3-{role}-review', f'getzilla-r4-{role}-review', f'getzilla-r5-{role}-review'])
for wave in ['final', 'second']:
    review_directories.extend(f'liqvera-{wave}-{role}-review' for role in ['code', 'test', 'security', 'data', 'release'])
for name in review_directories:
    directory = completion / name
    if not directory.is_dir():
        continue
    report = completion / f'{name}.md'
    if report.is_file():
        copy(report, f'reviewer-probes/{name}.md')
    sources = list(directory.glob('*')) + list((directory / 'logs').glob('*'))
    for source in sorted(sources):
        if source.is_file() and not source.is_symlink() and source.suffix in public_evidence_extensions:
            copy(source, f'reviewer-probes/{name}/' + str(source.relative_to(directory)))
record = {'schema': 'liqvera-getzilla-successor-archive-v2',
          'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Liqvera full native audit passes. Getzilla self-qualification fails and its candidate is not delivered as a qualified tool release.',
          'identities': identities,
          'original_pr115_commit': '2bb417431f1e4b9494e4af71ebf27adb1d04d898',
          'preservation': 'Original negative audits and production TLS/image/database evidence remain unchanged. No new production acceptance or payment operation.',
          'exclusions': ['private configuration', 'database dumps', 'wallet material', 'delegated grants', 'browser profiles', 'scanner databases', 'test environments']}
(payload / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
members = {str(path.relative_to(payload)): {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}
           for path in sorted(payload.rglob('*')) if path.is_file()}
(payload / 'manifest.json').write_text(json.dumps({'schema': 'sha256-manifest-v1', 'payloads': members}, indent=2) + '\n')
archive = output / '2026-10-21-getzilla-successor-raw.tar.gz'
with tarfile.open(archive, 'w:gz') as stream:
    for path in sorted(payload.rglob('*')):
        if path.is_file():
            stream.add(path, arcname=str(path.relative_to(payload)), recursive=False)
with tarfile.open(archive, 'r:gz') as stream:
    assert set(stream.getnames()) == set(members) | {'manifest.json'}
    for name, expected in members.items():
        member = stream.getmember(name)
        assert member.isfile() and not member.issym()
        data = stream.extractfile(member).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
result = {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
          'bytes': archive.stat().st_size, 'verified_payloads': len(members), 'record': record}
(output / 'archive-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['archive', 'sha256', 'bytes', 'verified_payloads']}, indent=2))
