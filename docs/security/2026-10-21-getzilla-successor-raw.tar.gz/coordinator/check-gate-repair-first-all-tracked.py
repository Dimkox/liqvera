"""Bounded native specification, range, secret and architecture controls; no receipt."""
import dataclasses
import json
import os
from pathlib import Path
import subprocess
import sys
import time
root = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions')
sys.path.insert(0, str(root / '.getzilla'))
from getzilla.state import get_active_route
from getzilla.verification import _architecture_preflight_check, _architecture_check, _governance_check, _secret_scan, _git_range_selection, _git_diff_check, _change_specs

def git(*parts):
    return subprocess.check_output(['git', *parts], cwd=root, text=True).strip()

os.sched_setaffinity(0, [0,1,2,3])
assert git('status','--porcelain') == ''
head = git('rev-parse','HEAD')
route=get_active_route(root)
assert route['base_commit']=='e158ddc7263a55f5308944c5a426eb1e9f1a4327'
started=time.monotonic()
selection=_git_range_selection(root,route,'pr')
assert not selection.findings
files=git('ls-files').splitlines()
checks=[_architecture_preflight_check(root),_secret_scan(root,files),_git_diff_check(root,'pr',selection)]
spec, spec_payload=_change_specs(root,git('diff','--name-only',route['base_commit'],'HEAD').splitlines(),route,'pr')
checks.append(spec)
architecture, arch_payload = _architecture_check(root,route)
checks.append(architecture)
governance, gov_payload = _governance_check(root,route,arch_payload)
checks.append(governance)
record={'kind':'bounded native controls; not a qualifying gate or receipt','head':head,'tree':git('rev-parse','HEAD^{tree}'),'base':route['base_commit'],'secondary_main':git('rev-parse','origin/main'),'checks':[dataclasses.asdict(item) for item in checks],'spec':spec_payload,'architecture':arch_payload,'governance':gov_payload,'duration_seconds':time.monotonic()-started,'head_after':git('rev-parse','HEAD'),'status_after':git('status','--porcelain')}
output=Path(sys.argv[1])
output.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['head','tree','duration_seconds','head_after','status_after']}))
for item in checks: print(item.name,item.status,item.summary)
assert record['head_after']==head and record['status_after']==''
assert all(item.status=='pass' for item in checks)
