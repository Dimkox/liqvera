"""Bounded exact-consumer controls before the second independent review freeze."""
import dataclasses
import json
import os
from pathlib import Path
import subprocess
import sys

runtime = Path('/home/pall/projects/liqvera/.getzilla/runtime')
root = runtime / 'liqvera-final-audit'
tool = runtime / 'getzilla-audit-final'
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
os.sched_setaffinity(0, [16, 17])
sys.dont_write_bytecode = True
sys.path.insert(0, str(tool / '.getzilla'))
from getzilla.state import get_active_route
from getzilla.verification import _secret_scan, _git_diff_check, _git_range_selection, _change_specs, _architecture_preflight_check, _architecture_check, _governance_check

def git(path, *args):
    return subprocess.check_output(['git', *args], cwd=path, text=True).strip()

head = git(root, 'rev-parse', 'HEAD')
assert head == '1b90f54c7ab26a7689cb892687175ac12cb7e3a4'
assert git(tool, 'rev-parse', 'HEAD') == '45be42f74b5a8ee6f079f8ac55206e475936fdc6'
assert not git(root, 'status', '--porcelain') and not git(tool, 'status', '--porcelain')
assert not git(root, 'diff', '17a70595e98aa183afac115e5b99488830fba712', 'HEAD', '--', '.', ':!engineering/changes')
route = get_active_route(root)
selection = _git_range_selection(root, route, 'pr')
assert route['base_commit'] == 'f1d3bffc46fa1459908fdff865fcfbfc831b7f7f'
assert not selection.findings
files = git(root, 'ls-files').splitlines()
checks = [_architecture_preflight_check(root), _secret_scan(root, files), _git_diff_check(root, 'pr', selection)]
spec, spec_payload = _change_specs(root, files, route, 'pr')
checks.append(spec)
architecture, arch_payload = _architecture_check(root, route)
checks.append(architecture)
governance, gov_payload = _governance_check(root, route, arch_payload)
checks.append(governance)
record = {'kind': 'bounded native observation, not a final gate or receipt', 'head': head, 'tree': git(root, 'rev-parse', 'HEAD^{tree}'), 'tool_commit': git(tool, 'rev-parse', 'HEAD'), 'original_base': route['base_commit'], 'secondary_main': git(root, 'rev-parse', 'origin/main'), 'secret_scope': 'all tracked Liqvera files', 'checks': [dataclasses.asdict(c) for c in checks], 'spec': spec_payload, 'architecture': arch_payload, 'governance': gov_payload, 'head_after': git(root, 'rev-parse', 'HEAD'), 'status_after': git(root, 'status', '--porcelain')}
output = runtime / 'completion/liqvera-second-committed-controls.json'
assert not output.exists()
output.write_text(json.dumps(record, indent=2) + '\n')
for check in checks:
    print(check.name, check.status, check.summary)
assert record['head_after'] == head and record['status_after'] == ''
assert all(c.status in {'pass', 'skip'} for c in checks)
assert spec.status == 'pass'
assert [(next(d for d in c.details if d.get('code') == 'disposition-summary')['unresolved']) for c in checks[1:3]] == [0, 0]
