"""Bind the isolated ownership repair and clarify source-only rollback."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

runtime = Path('/home/pall/projects/liqvera/.getzilla/runtime')
root = runtime / 'getzilla-audit-final'
package = root / 'engineering/changes/20261021-task-d83415'
evidence = package / 'evidence'
completion = runtime / 'completion'
handoff = json.loads((completion / 'getzilla-hook-ownership-handoff.json').read_text())
for name, digest in handoff['evidence_sha256'].items():
    assert hashlib.sha256((completion / name).read_bytes()).hexdigest() == digest, name
for name, digest in handoff['source_sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
for extension in ('md', 'json'):
    name = f'getzilla-hook-ownership-handoff.{extension}'
    assert not (evidence / name).exists()
    shutil.copyfile(completion / name, evidence / name)

def revision(value):
    return subprocess.check_output(['git', 'rev-parse', value], cwd=root, text=True).strip()

source_commit = revision('HEAD')
(evidence / 'fourth-review-repair.md').write_text(f'''# Owning hook package repair

The complete fourth review wave is preserved in `fourth-*-review.md` with exact bindings in `fourth-review-binding.json`. Its SR-GZ-R4-01 blocker is not relabelled: the reviewed source allowed foreign policy when its own package or initializer was absent.

The same sole writer repaired two files in isolated source commit `{handoff['commit']}`, based on the reviewed `b1ff3de3eb952521cacaa1119c88d2d6990c0545`. Integrated source commit: `{source_commit}`. The hook now requires its own regular initializer and verifies the imported package origin and search path before loading helpers. The existing standard-library fallback records degradation, preserves reads and denies protected classifications. Tests cover absent initializer, absent package and an already cached foreign package, alongside the previous broken-policy/filesystem controls.

Writer evidence: two new regressions first failed with six assertions and no execution errors. The repaired source passed 74 distinct degradation, enforcement, hook and harness tests with no skips. Removing each new guard was detected separately; Ruff, Bandit and whitespace checks passed. Complete raw logs and the exact patch are SHA-bound by `getzilla-hook-ownership-handoff.json` and retained in the final successor archive. These are bounded writer observations, not independent review, the final gate, external CI or live acceptance.

The full original comparison, finite queue limits, wheel-inventory repair, first failed gate, prior review reports and disclosed unrelated limitations are retained. No PDF, contract, timeout, scanner-selection or production Liqvera source change accompanies this repair. Fresh committed controls, all four selected reviews and a frozen full native gate remain required.
''')
(package / 'rollback.md').write_text(f'''# Rollback

This is source/tool-pin rollback only. The disposition implementation was delivered by PR #124, merge `a103b373031f477efad0e7bd9ffab24a96e6c63f`. Its pre-change tool pin is `e158ddc7263a55f5308944c5a426eb1e9f1a4327`; omit the consumer-owned disposition file when selecting that pin, restoring the prior strict findings. Preserve all historical evidence and reports.

The follow-up source changes are queue capacities `{revision('c517a2a')}`, hook precedence `{revision('013ff3b')}`, wheel inventory `{revision('9da43eb')}` and package ownership `{source_commit}`. A source revert must target these implementation commits through a separately verified PR, newest first, rather than reverting a report or metadata freeze. The final audit binds the delivered tool commit explicitly; changing that pin invalidates its acceptance evidence and requires fresh verification.

No database migration, payment-state change, live service rollback or historical evidence rewrite is part of this tooling rollback. Liqvera's already retained production rollback remains separate.
''')
print(json.dumps({'integrated_source_commit': source_commit, 'bound_writer_commit': handoff['commit'], 'evidence_files': len(handoff['evidence_sha256'])}))
