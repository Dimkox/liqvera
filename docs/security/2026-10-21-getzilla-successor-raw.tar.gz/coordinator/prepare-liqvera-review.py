"""Bind the reviewed external verifier before freezing the Liqvera audit."""
import argparse
import dataclasses
import hashlib
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--tool-commit', required=True)
parser.add_argument('--audit-commit', required=True)
args = parser.parse_args()
runtime = Path('/home/pall/projects/liqvera/.getzilla/runtime')
tool = runtime / 'getzilla-audit-final'
root = runtime / 'liqvera-final-audit'
evidence = root / 'engineering/changes/20261021-task-ec1239/evidence'


def git(path, *parts):
    return subprocess.check_output(['git', *parts], cwd=path, text=True).strip()


def digest(data):
    return hashlib.sha256(data).hexdigest()


assert git(tool, 'rev-parse', 'HEAD') == args.tool_commit
assert not git(tool, 'status', '--porcelain')
assert git(root, 'rev-parse', 'HEAD') == args.audit_commit
assert not git(root, 'diff', '17a70595e98aa183afac115e5b99488830fba712', 'HEAD', '--', '.', ':!engineering/changes')
assert not git(root, 'status', '--porcelain')
for name in ['tool-binding.json', 'committed-tool-controls.json']:
    previous = evidence / name
    saved = evidence / ('first-' + name)
    assert previous.is_file() and not saved.exists()
    saved.write_bytes(previous.read_bytes())
overlay = {}
for parent in ['.getzilla/config', '.getzilla/sast', '.getzilla/templates']:
    for relative in git(tool, 'ls-files', '--', parent).splitlines():
        source = tool / relative
        assert source.is_file() and not source.is_symlink()
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        data = source.read_bytes()
        target.write_bytes(data)
        overlay[relative] = digest(data)
sys.path.insert(0, str(tool / '.getzilla'))
from getzilla.state import get_active_route
from getzilla.verification import _git_diff_check, _secret_scan, _git_range_selection

route = get_active_route(root)
assert route['base_commit'] == 'f1d3bffc46fa1459908fdff865fcfbfc831b7f7f'
ranges = _git_range_selection(root, route, 'pr')
assert not ranges.findings
results = [_secret_scan(root, git(root, 'ls-files').splitlines()), _git_diff_check(root, 'pr', ranges)]
assert all(result.status == 'pass' for result in results)
summaries = [next(item for item in result.details if item.get('code') == 'disposition-summary') for result in results]
assert [(item['observed'], item['disposed'], item['unresolved']) for item in summaries] == [(2, 2, 0), (1, 1, 0)]
observation = {
    'kind': 'bounded_observation_not_receipt',
    'product_commit': '17a70595e98aa183afac115e5b99488830fba712',
    'audit_commit_before_binding': git(root, 'rev-parse', 'HEAD'),
    'tool_commit': args.tool_commit,
    'tool_tree': git(tool, 'rev-parse', 'HEAD^{tree}'),
    'command': 'Native _secret_scan on every tracked Liqvera file and _git_diff_check on worktree, index, original route and current-main ranges.',
    'results': [dataclasses.asdict(result) for result in results],
}
(evidence / 'committed-tool-controls.json').write_text(json.dumps(observation, indent=2) + '\n')
binding = {
    'tool_repository': 'https://github.com/Dimkox/Getzilla',
    'tool_commit': args.tool_commit,
    'tool_tree': git(tool, 'rev-parse', 'HEAD^{tree}'),
    'original_pr115_commit': '2bb417431f1e4b9494e4af71ebf27adb1d04d898',
    'tool_comparison_base': 'e158ddc7263a55f5308944c5a426eb1e9f1a4327',
    'observed_tool_origin_main': git(tool, 'rev-parse', 'origin/main'),
    'tool_review_reports': {name: digest((tool / 'engineering/changes/20261021-task-d83415/evidence' / f'{name}-review.md').read_bytes()) for name in ['code', 'test', 'security', 'release']},
    'overlay': overlay,
    'policy_sha256': digest((root / 'engineering/verification-dispositions.json').read_bytes()),
    'isolation': 'External source plus ignored local configuration overlay only; no Getzilla runtime, package, policy authority or build requirement is installed into Liqvera.',
    'final_gates': 'Results and receipts are archived separately with exact candidate identities. This source binding is not a passing verification receipt.',
}
(evidence / 'tool-binding.json').write_text(json.dumps(binding, indent=2) + '\n')
print(json.dumps({'tool_commit': args.tool_commit, 'overlay_files': len(overlay), 'bounded_results': [result.summary for result in results]}, indent=2))
