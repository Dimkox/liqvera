"""Preserve complete failed independent reports before the ownership repair."""
from pathlib import Path
import hashlib
import json
import subprocess

runtime = Path('/home/pall/projects/liqvera/.getzilla/runtime')
root = runtime / 'getzilla-audit-final'
package = root / 'engineering/changes/20261021-task-d83415'
evidence = package / 'evidence'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == 'b1ff3de3eb952521cacaa1119c88d2d6990c0545'
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=root) == b''
expected = {
    'code': '6d2ba5ac2963492144621d850619d88d0b487a202b2e85015d33d86a937ff0fa',
    'test': '5671e487ab568b590652660b67eb005e8c3ef40a8d209ab6e54f29223bfecb12',
    'security': 'a74396021287dd50b41b84a9172ba384723dd301a3a77872a08ea77c7e9e4e49',
    'release': '3d732fea06bf40e1b31c1077a08883800954bc87485a915edad95d8082de1794',
}
records = []
for role, digest in expected.items():
    source = runtime / 'completion' / f'getzilla-r4-{role}-review.md'
    data = source.read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest, role
    target = evidence / f'fourth-{role}-review.md'
    assert not target.exists()
    target.write_bytes(data)
    (evidence / f'{role}-review.md').write_bytes(data)
    records.append({'role': role, 'report': target.name, 'sha256': digest, 'bytes': len(data)})
binding = {
    'reviewed_commit': head,
    'reviewed_tree': '88a830f5a18631cdfef4cf35b4866f466b06264c',
    'original_base': 'e158ddc7263a55f5308944c5a426eb1e9f1a4327',
    'secondary_main': 'f9f02dd53ba9f6e69d51ae5322df0c96e3d41b02',
    'verdict': 'REQUEST_CHANGES',
    'blocking_finding': 'SR-GZ-R4-01: absent owning package permits foreign-policy fallback without degradation',
    'reports': records,
    'qualifying_gate': 'NOT_RUN',
}
(evidence / 'fourth-review-binding.json').write_text(json.dumps(binding, indent=2) + '\n')
print(json.dumps(binding, indent=2))
