"""Keep the complete second native failure without changing the frozen source."""
from pathlib import Path
import hashlib
import json
import shutil

runtime = Path('/home/pall/projects/liqvera/.getzilla/runtime')
completion = runtime / 'completion'
source = runtime / 'getzilla-audit-final/.getzilla/runtime/final-2'
target = completion / 'getzilla-failed-gate-2'
target.mkdir(mode=0o700, exist_ok=False)
record = json.loads((source / 'invocation.json').read_text())
gate = json.loads((source / 'getzilla-pr.json').read_text())
assert record['returncode'] == 1 and gate['status'] == 'fail'
assert record['head'] == record['head_after'] == '45be42f74b5a8ee6f079f8ac55206e475936fdc6'
assert record['git_status_after'] == ''
for name in ['invocation.json', 'getzilla-pr.json', 'getzilla-pr.stderr']:
    shutil.copyfile(source / name, target / name)
shutil.copyfile(completion / 'run-qualifying-gate.py', target / 'run-qualifying-gate.py')
result = {'status': gate['status'], 'head': record['head'], 'tree': record['tree'], 'duration_seconds': record['duration_seconds'], 'failed_checks': [check['name'] for check in gate['checks'] if check['status'] == 'fail'], 'hashes': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in target.iterdir() if p.is_file()}, 'note': 'Core records one failing huge-argv policy test. The saved bounded tail omits the assertion traceback; timing versus decision cause is not inferred. Coverage threshold was reached, but coverage correctly refuses to qualify unsuccessful tests. Factory-unit and actual disposable PostgreSQL exit both pass. No receipt or PASS is claimed for this run.'}
(target / 'retention.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
