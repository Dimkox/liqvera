"""Record native selected review receipts only after an actual passing full gate."""
import argparse
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('kind', choices=['getzilla', 'liqvera'])
args = parser.parse_args()
runtime = Path('/home/pall/projects/liqvera/.getzilla/runtime')
root = runtime / ('getzilla-audit-final' if args.kind == 'getzilla' else 'liqvera-final-audit')
tool = runtime / 'getzilla-audit-final'
final = root / '.getzilla/runtime/final-2'
gate = json.loads((final / 'getzilla-pr.json').read_text())
invocation = json.loads((final / 'invocation.json').read_text())
assert gate['status'] == 'pass' and invocation['returncode'] == 0
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == invocation['head'] == invocation['head_after']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tool, text=True).strip() == invocation['tool_commit']
roles = ['code', 'test', 'security', 'release'] + ([] if args.kind == 'getzilla' else ['data'])
change = 'd83415' if args.kind == 'getzilla' else 'ec1239'
python = runtime / 'completion/getzilla-gate-venv/bin/python'
for role in roles:
    report = f'engineering/changes/20261021-task-{change}/evidence/{role}-review.md'
    result = subprocess.run([str(python), '-B', str(tool / 'scripts/getzilla_review.py'), role + '_review', '--status', 'pass', '--report', report, '--reviewed-commit', invocation['reviewed_head']], cwd=root, capture_output=True, text=True)
    (final / f'{role}-review-receipt.stdout').write_text(result.stdout)
    (final / f'{role}-review-receipt.stderr').write_text(result.stderr)
    print(role, result.returncode, result.stdout.strip())
    assert result.returncode == 0, result.stderr
result = subprocess.run([str(python), '-B', str(tool / 'scripts/getzilla_status.py')], cwd=root, capture_output=True, text=True)
assert result.returncode == 0, result.stderr
status = json.loads(result.stdout)
(final / 'evidence-status.json').write_text(json.dumps(status, indent=2) + '\n')
print(json.dumps({'evidence_gaps': status['evidence_gaps'], 'package_incomplete': status['package_incomplete']}))
assert not status['evidence_gaps'] and not status['package_incomplete']
