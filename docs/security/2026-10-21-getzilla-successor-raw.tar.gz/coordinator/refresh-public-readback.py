"""Observe the existing public product with HTTPS GET; preserve prior observation."""
import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import ssl
import urllib.request

runtime = Path('/home/pall/projects/liqvera/.getzilla/runtime')
completion = runtime / 'completion'
old = completion / 'public-readback-final.json'
previous = completion / 'public-readback-before-final.json'
assert old.exists() and not previous.exists()
previous.write_bytes(old.read_bytes())
prior = json.loads(old.read_text())
ca = runtime.parent.parent / '.worktrees/wave1-deploy/.venv/lib/python3.12/site-packages/pip/_vendor/certifi/cacert.pem'
context = ssl.create_default_context(cafile=str(ca), capath=str(runtime / 'tls-fix/empty-ca'))
agent = 'Liqvera-ReadOnly-Verification/1.0'
expected = {
    '/demo/latest-live/report.json': '0ebf36b89bda183b99767cd7fedc3c956405ef4a3f195d9d73b911d2c146ccf2',
    '/demo/latest-live/evidence.zip': '3255a42c210c6fe6ad0020c34113988da3f1659c566a73b7729606ad65d083b0',
}

def check(path):
    request = urllib.request.Request('https://liqvera.site' + path, headers={'User-Agent': agent}, method='GET')
    with urllib.request.urlopen(request, context=context, timeout=30) as response:
        data = response.read(2_000_001)
        assert len(data) <= 2_000_000
        result = {'status': response.status, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'final_url': response.url}
    assert result['status'] == 200 and result['final_url'] == request.full_url
    if path in {'/healthz', '/readyz', '/v1/capabilities'}:
        result['public_response'] = json.loads(data)
    if path in expected:
        result['historical_bytes_match'] = result['sha256'] == expected[path]
        assert result['historical_bytes_match']
    return path, result

paths = ['/', '/healthz', '/readyz', '/v1/capabilities', *expected]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
    checks = dict(executor.map(check, paths))
assert checks['/readyz']['public_response']['ready'] is True
assert checks['/readyz']['public_response']['blockers'] == []
capabilities = checks['/v1/capabilities']['public_response']
assert capabilities['network'] == 'eip155:31611' and capabilities['price_musd'] == '0.01'
assert capabilities['payment_ready'] is True and capabilities['blockers'] == []
result = {'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': prior['scope'], 'tls_verification': True, 'user_agent': agent, 'previous_observation': {'file': previous.name, 'sha256': hashlib.sha256(previous.read_bytes()).hexdigest()}, 'checks': checks}
old.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'observed_at': result['observed_at'], 'statuses': {path: check['status'] for path, check in checks.items()}, 'historical_bytes_match': True}, indent=2))
