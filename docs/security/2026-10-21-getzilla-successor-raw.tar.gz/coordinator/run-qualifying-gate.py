"""Record one complete, exact-source local gate after independent review freeze."""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('kind', choices=['getzilla', 'liqvera'])
parser.add_argument('--reviewed', required=True)
parser.add_argument('--tool-commit', required=True)
parser.add_argument('--attempt', type=int, default=2)
args = parser.parse_args()
base = Path('/home/pall/projects/liqvera/.getzilla/runtime')
root = base / ('getzilla-audit-final' if args.kind == 'getzilla' else 'liqvera-final-audit')
tool = base / 'getzilla-audit-final'
change = 'd83415' if args.kind == 'getzilla' else 'ec1239'
reviewers = ['code', 'test', 'security', 'release'] + ([] if args.kind == 'getzilla' else ['data'])
allowed = {f'engineering/changes/20261021-task-{change}/evidence/{name}-review.md' for name in reviewers}

def git(path, *arguments):
    return subprocess.check_output(['git', *arguments], cwd=path, text=True).strip()

assert git(root, 'status', '--porcelain') == '', 'candidate must be clean'
assert git(tool, 'status', '--porcelain') == '', 'tool must be clean'
assert git(tool, 'rev-parse', 'HEAD') == args.tool_commit, 'wrong tool commit'
assert set(git(root, 'diff', '--name-only', args.reviewed, 'HEAD').splitlines()) == allowed, 'only complete review reports may differ after review'
if args.kind == 'liqvera':
    assert not git(root, 'diff', '17a70595e98aa183afac115e5b99488830fba712', 'HEAD', '--', '.', ':!engineering/changes'), 'product changed after its source binding'
assert args.attempt >= 2, 'initial runs are immutable; use a new attempt number'
output = root / '.getzilla/runtime' / f'final-{args.attempt}'
output.mkdir(mode=0o700, exist_ok=False)
temporary_parent = Path('/home/pall/.gz-gates-20261021')
temporary_parent.mkdir(mode=0o700, exist_ok=True)
for ancestor in [temporary_parent, *temporary_parent.parents]:
    info = ancestor.lstat()
    assert not ancestor.is_symlink() and ancestor.is_dir()
    assert info.st_uid in {0, os.getuid()} and info.st_mode & 0o022 == 0, str(ancestor)
probe = subprocess.run(['git', 'rev-parse', '--show-toplevel'], cwd=temporary_parent, capture_output=True, text=True)
assert probe.returncode == 128, 'test scratch must be outside every Git repository'
temporary = temporary_parent / f'{args.kind}-{args.attempt}'
temporary.mkdir(mode=0o700, exist_ok=False)
cpus = list(range(0, 16)) if args.kind == 'getzilla' else list(range(18, 22))
os.sched_setaffinity(0, cpus)
keep = ['HOME', 'USER', 'LANG', 'LC_ALL', 'PATH', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY',
        'http_proxy', 'https_proxy', 'all_proxy', 'no_proxy', 'DOCKER_HOST', 'DOCKER_CONTEXT', 'SSH_AUTH_SOCK']
env = {name: os.environ[name] for name in keep if name in os.environ}
corrected = base.parent.parent / '.worktrees/wave1-deploy/.venv'
env.update(SSL_CERT_FILE=str(corrected / 'lib/python3.12/site-packages/pip/_vendor/certifi/cacert.pem'),
           SSL_CERT_DIR=str(base / 'tls-fix/empty-ca'), NODE_OPTIONS='--use-openssl-ca', PYTHONHTTPSVERIFY='1',
           GETZILLA_NO_VENV='1', GETZILLA_OSV_DB='', GETZILLA_OSV_ONLINE='1', PYTHONDONTWRITEBYTECODE='1',
           RUFF_CACHE_DIR=str(output / 'ruff-cache'), TMPDIR=str(temporary))
if args.kind == 'liqvera':
    interpreter = str(root / '.venv/bin/python')
    env['PATH'] = str(root / '.venv/bin') + os.pathsep + env['PATH']
    env.update(PYTEST_ADDOPTS='tests', GETZILLA_SERIAL='1')
else:
    interpreter = str(base / 'completion/getzilla-gate-venv/bin/python')
    env['PATH'] = str(Path(interpreter).parent) + os.pathsep + env['PATH']
    env['GETZILLA_TEST_WORKERS'] = '16'
    env['UV_PYTHON'] = interpreter
    env['UV_PYTHON_DOWNLOADS'] = 'never'
command = [interpreter, str(tool / 'scripts/getzilla_verify.py'), '--mode', 'pr', '--full-scope', '--keep-going', '--json']
versions = json.loads(subprocess.check_output([interpreter, '-c', "import importlib.metadata,json; print(json.dumps({n:importlib.metadata.version(n) for n in ['pytest','ruff','bandit','coverage','certifi','pip']}))"], text=True))
explicit = ['GETZILLA_NO_VENV', 'GETZILLA_OSV_DB', 'GETZILLA_OSV_ONLINE', 'GETZILLA_TEST_WORKERS', 'PYTEST_ADDOPTS', 'GETZILLA_SERIAL', 'UV_PYTHON', 'UV_PYTHON_DOWNLOADS']
record = {'command': command, 'cwd': str(root), 'head': git(root, 'rev-parse', 'HEAD'),
          'attempt': args.attempt, 'temporary_directory': str(temporary),
          'temporary_directory_git_exit': probe.returncode,
          'tree': git(root, 'rev-parse', 'HEAD^{tree}'), 'reviewed_head': args.reviewed,
          'tool_commit': args.tool_commit, 'tool_tree': git(tool, 'rev-parse', 'HEAD^{tree}'),
          'comparison_base': 'e158ddc7263a55f5308944c5a426eb1e9f1a4327' if args.kind == 'getzilla' else 'f1d3bffc46fa1459908fdff865fcfbfc831b7f7f',
          'environment_names': sorted(env), 'explicit_nonsecret_environment': {name: env[name] for name in explicit if name in env},
          'cpu_affinity': cpus, 'versions': versions,
          'scope': 'Full PR gate. Liqvera uses all tests/ and serial execution to avoid shared artifact-build races; Getzilla uses 16 coverage workers.',
          'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(output / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
with (output / 'getzilla-pr.json').open('w') as stdout, (output / 'getzilla-pr.stderr').open('w') as stderr:
    result = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr)
record.update(returncode=result.returncode, duration_seconds=time.monotonic() - started,
              head_after=git(root, 'rev-parse', 'HEAD'), tree_after=git(root, 'rev-parse', 'HEAD^{tree}'),
              git_status_after=git(root, 'status', '--porcelain'), tool_head_after=git(tool, 'rev-parse', 'HEAD'),
              finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(output / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key:record[key] for key in ['returncode','duration_seconds','head','tree','git_status_after']}), flush=True)
raise SystemExit(result.returncode)
