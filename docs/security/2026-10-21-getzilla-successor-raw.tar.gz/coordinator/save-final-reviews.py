"""Save only complete independently returned reports after a source freeze."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('kind', choices=['getzilla', 'liqvera'])
parser.add_argument('--reviewed', required=True)
args = parser.parse_args()
runtime = Path('/home/pall/projects/liqvera/.getzilla/runtime')
root = runtime / ('getzilla-audit-final' if args.kind == 'getzilla' else 'liqvera-final-audit')
package = root / 'engineering/changes' / ('20261021-task-d83415' if args.kind == 'getzilla' else '20261021-task-ec1239')
roles = ['code', 'test', 'security', 'release'] + ([] if args.kind == 'getzilla' else ['data'])
prefix = 'getzilla-r5' if args.kind == 'getzilla' else 'liqvera-second'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == args.reviewed
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
reports = []
for role in roles:
    source = runtime / 'completion' / f'{prefix}-{role}-review.md'
    data = source.read_bytes()
    text = data.decode()
    assert args.reviewed in text, role
    assert 'reviewed-tree-modified: no' in text, role
    assert 'PASS' in text[:1200], role
    target = package / 'evidence' / f'{role}-review.md'
    target.write_bytes(data)
    reports.append({'role': role, 'source': str(source), 'target': str(target.relative_to(root)), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
expected = {item['target'] for item in reports}
changed = set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines())
assert changed == expected
assert subprocess.run(['git', 'diff', '--check'], cwd=root).returncode == 0
output = runtime / 'completion' / f'{prefix}-saved-report-bindings.json'
assert not output.exists()
output.write_text(json.dumps({'reviewed_commit': args.reviewed, 'reports': reports}, indent=2) + '\n')
print(output)
