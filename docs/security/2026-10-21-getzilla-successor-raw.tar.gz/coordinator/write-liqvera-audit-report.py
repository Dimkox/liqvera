"""Publish Liqvera results while retaining the failed tool self-qualification."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess

runtime = Path('/home/pall/projects/liqvera/.getzilla/runtime')
completion = runtime / 'completion'
root = runtime / 'liqvera-completion-docs'
archive_record = json.loads((completion / 'liqvera-audit-archive/archive-verification.json').read_text())
archive = Path(archive_record['archive'])
assert hashlib.sha256(archive.read_bytes()).hexdigest() == archive_record['sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == '17a70595e98aa183afac115e5b99488830fba712'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
identities = archive_record['record']['identities']
external = json.loads((completion / 'getzilla-publication-status.json').read_text())
public = json.loads((completion / 'public-readback-final.json').read_text())
gates = {}
for kind, directory in [('getzilla', 'getzilla-audit-final'), ('liqvera', 'liqvera-final-audit')]:
    final = runtime / directory / '.getzilla/runtime/final-2'
    gate = json.loads((final / 'getzilla-pr.json').read_text())
    invocation = json.loads((final / 'invocation.json').read_text())
    status = json.loads((final / 'evidence-status.json').read_text())
    if kind == 'liqvera':
        assert gate['status'] == 'pass' and invocation['returncode'] == 0
        assert not status['evidence_gaps'] and not status['package_incomplete']
        assert all(check['status'] in {'pass', 'skip'} for check in gate['checks'])
    else:
        assert gate['status'] == 'fail' and invocation['returncode'] == 1
        assert 'verification: status=fail' in status['evidence_gaps']
    assert invocation['head'] == identities[kind]['commit']
    assert invocation['head'] == invocation['head_after'] and invocation['git_status_after'] == ''
    tests = []
    for check in gate['checks']:
        if check['name'] in {'pytest', 'python-unittest', 'factory-unit', 'factory-postgres-exit'}:
            lines = [line.strip() for line in check.get('stdout', '').splitlines()
                     if re.search(r'\d+ passed|Ran \d+ tests|^OK(?:\s|$)|^FAILED|^SKIPPED', line)]
            tests.append({'check': check['name'], 'status': check['status'], 'summary': check['summary'], 'observed_summary_lines': lines})
    gates[kind] = {
        **identities[kind],
        'started_at': invocation['started_at'],
        'finished_at': invocation['finished_at'],
        'attempt': invocation['attempt'],
        'tests': tests,
        'skipped_checks': [{'name': check['name'], 'reason': check['summary']} for check in gate['checks'] if check['status'] == 'skip'],
        'invocation_sha256': hashlib.sha256((final / 'invocation.json').read_bytes()).hexdigest(),
        'native_result_sha256': hashlib.sha256((final / 'getzilla-pr.json').read_bytes()).hexdigest(),
    }

record = {
    'schema': 'liqvera-getzilla-successor-v2',
    'status': 'pass',
    'status_scope': 'Liqvera full native audit and its five selected independent reviews only; not Getzilla tool qualification or a new live payment acceptance.',
    'tool_self_qualification': 'fail',
    'date': '2026-10-21',
    'product_commit': '17a70595e98aa183afac115e5b99488830fba712',
    'deployed_application_commit': '1c020995adaa1a80fc8a97888aa838041d8e01d5',
    'original_pr115_commit': '2bb417431f1e4b9494e4af71ebf27adb1d04d898',
    'gates': gates,
    'getzilla_publication_status': external,
    'tool_source_rollback_commits': {
        'queue_capacity_integrated': '4c47e7ca5cf40ed6bc3f91aa24532ad457e19cdd',
        'hook_precedence_integrated': 'de0ed1d9f98b21d2636deb977f0eef403529d23a',
        'wheel_inventory_integrated': '9da43eb1e808aeafa3dbba18104ce1cfe9ba6440',
        'hook_ownership_integrated': '9e8b444400066a82fe252da48c46237292f5c811',
        'note': 'R5 release review verifies patch equivalence to isolated queue/hook predecessor commits; use these integrated ancestors in delivered clones. Source rollback requires a separately verified PR and fresh consumer audit.'
    },
    'public_readback': public,
    'archive': {'file': archive.name, 'sha256': archive_record['sha256'], 'bytes': archive_record['bytes'], 'verified_payloads': archive_record['verified_payloads']},
    'dispositions': {'raw_findings': 3, 'disposed': 3, 'unresolved': 0, 'policy_sha256': 'e0395a8b681958936fa97f552f517d77cecb49744eb33b902a3ee5c6569ef141'},
    'preservation': {
        'historical_reports_unchanged': True,
        'new_deployment': False,
        'new_quote_payment_loan_or_grant': False,
        'production_rollback': '/home/pall/.local/state/liqvera/recovery/2026-10-21-tls-1c02099/rollout.py rollback',
        'historical_report_sha256': '0ebf36b89bda183b99767cd7fedc3c956405ef4a3f195d9d73b911d2c146ccf2',
        'historical_zip_sha256': '3255a42c210c6fe6ad0020c34113988da3f1659c566a73b7729606ad65d083b0',
    },
    'limits': [
        'The locally modified Getzilla tool is not fully qualified: its second full self-check exits 1. Its failed gate and five evidence gaps are retained; the candidate has not been published or merged as a qualified tool release.',
        'The original huge-argv failure traceback was truncated. Two exact-source isolated coverage replays reproduce only its 8-second elapsed assertion at 8.487197 and 8.3206 seconds, while the protected command is correctly denied. No timeout/assertion was relaxed or failure relabelled.',
        'This is exact-source verification at the recorded time, not a promise that future dependencies or changes remain safe.',
        'Historical deployment, Docker/PostgreSQL, browser and supplemental lock-scan evidence keeps its original source and scope; it is not a new live acceptance run.',
        'Native optional or unconfigured check skips are listed exactly and are not passes.',
        'Getzilla retains disclosed pre-existing PDF parser skips, an import-effect analysis gap and seven supplementary all-tracked baseline heuristic matches; its native changed-file scan has a different scope.',
        'The incompatible PDF-profile prototype is excluded and its failed compatibility result is preserved.',
        'The first Liqvera test review retains a nonblocking request for a committed 29,999/30,000 ms funding-age boundary regression; its independent oracle verifies the unchanged correct behavior, without claiming that native test coverage.',
        'Physical wallet pairing, borrowing and a new signed paid delivery were not exercised.',
    ],
}
policy = root / 'engineering/verification-dispositions.json'
assert hashlib.sha256(policy.read_bytes()).hexdigest() == record['dispositions']['policy_sha256']
security = root / 'docs/security'
for name in ['2026-10-21-getzilla-successor.md', '2026-10-21-getzilla-successor.json', archive.name]:
    assert not (security / name).exists(), name
shutil.copyfile(archive, security / archive.name)
(security / '2026-10-21-getzilla-successor.json').write_text(json.dumps(record, indent=2) + '\n')
rows = []
for kind in ['liqvera', 'getzilla']:
    item = gates[kind]
    rows.append(f"| {kind.title()} | `{item['commit']}` | {item['status'].upper()} / {item['returncode']} | {item['duration_seconds']:.2f} s | {len(item['evidence_gaps'])} |")
test_rows = []
for kind in ['liqvera', 'getzilla']:
    for item in gates[kind]['tests']:
        summary = '; '.join(item['observed_summary_lines']) or item['summary']
        test_rows.append(f"| {kind.title()} / `{item['check']}` | {item['status']} | {summary.replace('|', '/')} |")
skips = []
for kind in ['liqvera', 'getzilla']:
    skips.extend(f"- {kind.title()} `{item['name']}`: {item['reason']}" for item in gates[kind]['skipped_checks'])
report = f'''# Current Liqvera verification result — 2026-10-21

Liqvera's complete native Getzilla audit passes with exit 0 and zero evidence gaps. Its five selected independent reviews pass against the exact frozen source. The four inherited TLS blockers were corrected and deployed. The optional audit tool's own full self-check fails; this report does not claim that Getzilla is fully qualified or that all results are green.

The distinction is material: Liqvera was checked with an exact locally modified Getzilla candidate whose independent reviews pass but whose self-test exceeds a time limit. Its source bundle, failed self-check and limitations are preserved below. The candidate is not published or merged as a qualified Getzilla release. Liqvera remains buildable and verifiable without an external delivery framework.

The live application remains `1c020995adaa1a80fc8a97888aa838041d8e01d5` on claw. Its funding-layout repair, checkbox prerequisite guidance and Getzilla footer are already deployed. This audit adds no rollout, quote, payment, loan or grant. The delivery source `17a70595e98aa183afac115e5b99488830fba712` also preserves corrected `pip==26.2.2` after the PR #14 dependency merge.

## Exact native results

| Candidate | Frozen report-containing commit | Result / exit | Duration | Evidence gaps |
| --- | --- | --- | --- | --- |
{chr(10).join(rows)}

The Liqvera reviewed source is `{gates['liqvera']['reviewed_commit']}`; the Getzilla reviewed source is `{gates['getzilla']['reviewed_commit']}`. Only the selected complete review report files were added after each review freeze. Both invocations use `--mode pr --full-scope --keep-going --json`, preserve clean unchanged candidates and retain their original comparison bases. The raw invocation, trees, scope selection and every check are archived. Liqvera has six fingerprint-bound passing receipts: verification and five reviews. Getzilla has a failed verification receipt and four missing review receipts; its review reports do not override the failed gate. This is a successor to the unmodified [PR #115](https://github.com/Dimkox/Getzilla/pull/115) tool, not a claim that its original failed result passed.

| Native test runner | Result | Observed summary |
| --- | --- | --- |
{chr(10).join(test_rows)}

The selected executable checks include source stability, architecture/governance, specification, Git ranges, secret scanning, online dependency vulnerability scanning, OpenGrep, Ruff and Bandit. Optional or unconfigured checks retain their actual skips:

{chr(10).join(skips) or '- None.'}

Complete Getzilla code/test/security/release reviews and Liqvera code/test/security/data/release reviews are preserved with source identities and raw probes. Getzilla has no passing external acceptance recorded for this candidate; its publication status is explicit in the [JSON record](2026-10-21-getzilla-successor.json). Local receipts do not establish external acceptance.

The release review's nonblocking tool-rollback clarification is resolved in the JSON delivery mapping: integrated queue and hook-precedence commits are `4c47e7ca5cf40ed6bc3f91aa24532ad457e19cdd` and `de0ed1d9f98b21d2636deb977f0eef403529d23a`. Their patch identities equal the isolated predecessors named by the frozen package. Use delivered ancestors for a separately verified source rollback; this does not affect production recovery.

## Why the audit outcome changed

Exactly three reviewed raw findings remain visible: two public Testnet MUSD contract-address occurrences and the final blank line in immutable Wave 1 evidence. [The disposition explanation](2026-10-21-verification-dispositions.md) identifies their meaning and exact hashes. Each entry binds target bytes, the individual finding and independent review evidence. Stale or altered entries, other occurrences and genuine credential classes remain failures. The policy hash is `e0395a8b681958936fa97f552f517d77cecb49744eb33b902a3ee5c6569ef141`. Raw severity and command exits are retained separately from the effective result; no entire file or Git comparison range is suppressed.

The first successor gates also failed and remain archived. Liqvera's first run passed 956 Python tests and 85 subtests but failed required approval-scope metadata. Getzilla's first run exposed execution-environment problems, insufficient finite analyzer capacity, hook import ownership and a stale wheel inventory. Short non-Git test scratch and explicit supported Python corrected the environment. Source repairs retain finite queue limits, bind hooks to their owning package and derive the inventory from existing pins. Independent reviews found and then verified the narrow hook repair. No final-gate timeout, assertion, scanner scope or compatibility rule was weakened.

Getzilla's second full self-check remains **FAIL**: Core reports 2,277 passed, one failed and 17 skipped; Factory unit tests pass 63, and the real disposable-PostgreSQL exit suite passes 1,040 with six documented skips. Coverage reaches 81.72%, above the unchanged 74% threshold, but the coverage gate correctly fails because the tests did not all succeed. The failing Core test is `Review2PosixTests.test_secret_scan_is_bounded_and_fails_closed_on_a_huge_argv`. The native output truncation lost its original traceback, so its original assertion cannot be proven from that log alone. Two exact-source isolated replays with unchanged coverage reproduce only the elapsed-time assertion at 8.487197 and 8.3206 seconds against the 8-second limit; the protected command is denied in both. The named unittest runner and matched pytest without coverage pass. These controls do not turn the full failure into a pass. No further Getzilla repair, full rerun, qualification receipt or merge is claimed by this Liqvera delivery.

The unrelated PDF-profile prototype remains excluded after its actual compatibility failure. Existing Getzilla PDF skips, the pre-existing import-effect analyzer gap and seven supplementary all-tracked baseline heuristic observations remain disclosed in the full reports. A passing native changed-file scan does not clear those different-scope observations. These tooling limits are not new Liqvera runtime vulnerabilities and are not represented as repaired here.

## Deployed behavior and preservation

[TLS deployment evidence](2026-10-21-tls-deployment.md) retains the exact images, scanner dispositions, Docker builds, complete web/gateway checks and all 13 real disposable-PostgreSQL cases. Those results retain their original time and source. The public browser was checked at six widths from 320 to 1440 pixels, with correct funding spacing and no overflow. The checkbox requires a fresh unpaid quote with a confirmed MUSD shortfall; that prerequisite is explained in the interface.

WalletConnect configuration, the existing PostgreSQL container, databases, three confirmed and one manual-review payment attempts, four receipts/entitlements, SQL migrations and sealed evidence were preserved by the earlier rollout. This audit makes no live payment-state change. Fresh read-only public observations are bound in the JSON record. The historical report and ZIP retain SHA-256 `0ebf36b89bda183b99767cd7fedc3c956405ef4a3f195d9d73b911d2c146ccf2` and `3255a42c210c6fe6ad0020c34113988da3f1659c566a73b7729606ad65d083b0`.

The existing production recovery command remains:

```bash
python3 /home/pall/.local/state/liqvera/recovery/2026-10-21-tls-1c02099/rollout.py rollback
```

It restores retained application containers without restoring a database or running migrations. Old images retain their previous TLS exposure. Physical wallet pairing, borrowing and a new signed paid delivery were not exercised. A passing dated audit is not a guarantee against future dependency advisories or source changes.

## Evidence

[Machine-readable record](2026-10-21-getzilla-successor.json) and [complete raw archive]({archive.name}) bind the passing Liqvera run, failed Getzilla self-check, every review wave, earlier failed gates, bounded controls, diagnoses, exact frozen Git bundles and public observations. Archive SHA-256: `{archive_record['sha256']}`. All {archive_record['verified_payloads']} payload hashes were verified after reopening the archive. Private configuration, database dumps, wallet material, delegated grants and browser profiles are excluded.

Native JSON retains the tool's bounded subprocess-output excerpts. Separate diagnostic and reviewer logs retain their own recorded scope; the archive does not claim an unsliced log for every subprocess in the full gate.

The [initial negative audit](2026-10-21-getzilla-initial.md), [Wave 1 evidence](2026-10-21-wave1-deployment.md), [layout evidence](2026-10-21-layout-deployment.md) and [TLS deployment record](2026-10-21-tls-deployment.md) remain byte-for-byte unchanged. Their negative results remain historical facts; this document is the current successor result.
'''
(security / '2026-10-21-getzilla-successor.md').write_text(report)
readme = root / 'README.md'
old = '- **[Validation evidence](docs/security/2026-10-21-wave1-deployment.md)** — deployed version, security checks and the scope of functional verification.'
new = '- **[Current validation evidence](docs/security/2026-10-21-getzilla-successor.md)** — passing Liqvera audit, failed tool self-check, exact deployment evidence and verification limits.'
text = readme.read_text()
assert text.count(old) == 1
readme.write_text(text.replace(old, new))
index = root / 'docs/README.md'
text = index.read_text()
needle = '- [Security audit and remediation]'
assert text.count(needle) == 1
text = text.replace(needle, '- [Current Liqvera verification](security/2026-10-21-getzilla-successor.md): passing product audit, failed tool self-check, independent reviews and preserved historical evidence.\n' + needle)
index.write_text(text)
deployment = root / 'docs/deployment.md'
text = deployment.read_text()
needle = 'The current application source is '
assert text.count(needle) == 1
text = text.replace(needle, 'The [current Liqvera audit](security/2026-10-21-getzilla-successor.md) passes with zero evidence gaps. The optional tool self-check remains failed and is disclosed separately; earlier negative reports retain their historical results. This audit did not redeploy services or change payment state.\n\n' + needle)
deployment.write_text(text)
handoff = root / 'handoff.md'
text = handoff.read_text()
first, rest = text.split('\n', 1)
entry = f'''\n\n## 2026-10-21 — Liqvera audit passes; tool self-check remains failed

Liqvera's full frozen native gate at `{gates['liqvera']['commit']}` passes with exit 0 and zero evidence gaps. All five selected independent reviews and six passing receipts are retained in the [current successor evidence](docs/security/2026-10-21-getzilla-successor.md). Exactly three hash-bound public/historical findings retain raw severity and are dispositioned; new or stale findings remain failures. Earlier negative reports, failed review waves and full gates remain unchanged.

The locally modified Getzilla tool `{gates['getzilla']['commit']}` is not fully qualified or delivered as a Getzilla release. Its second self-check exits 1 for a huge-command timing test, with five evidence gaps retained. Isolated unchanged-coverage replays exceed eight seconds while correctly denying the protected command. Do not call this self-check passing or reuse Liqvera's receipts for the tool. Further tool repair is outside this Liqvera completion scope; the complete source bundle and failure evidence remain available.

The application stays on deployed TLS source `1c020995adaa1a80fc8a97888aa838041d8e01d5`; layout, checkbox guidance and the Getzilla footer are live. This step changes audit/dependency metadata and evidence only. WalletConnect, databases, payment outcomes and historical bundles remain preserved; no quote, payment, loan or grant was created. Existing rollback remains `/home/pall/.local/state/liqvera/recovery/2026-10-21-tls-1c02099/rollout.py rollback`. Read the current report for exact native skips, unrelated tool limitations and the distinction between fresh audit checks and historical deployment acceptance.
'''
handoff.write_text(first + entry + rest)
print(json.dumps({'report': str(security / '2026-10-21-getzilla-successor.md'), 'archive_sha256': archive_record['sha256'], 'payloads': archive_record['verified_payloads']}, indent=2))
