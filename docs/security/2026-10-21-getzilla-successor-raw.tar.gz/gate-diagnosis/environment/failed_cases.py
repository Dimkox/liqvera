#!/usr/bin/env python3
"""Re-run only parents named by the retained 42 FAILED/SUBFAILED records."""
from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import signal
import subprocess
import sys
import time

from run import CANDIDATE, EVIDENCE, TEMPS, identity, save

sys.path.insert(0, str(CANDIDATE / '.getzilla'))
from getzilla import python_test_runner


def main():
    gate_path = CANDIDATE / '.getzilla/runtime/final/getzilla-pr.json'
    gate_bytes = gate_path.read_bytes()
    gate = json.loads(gate_bytes)
    core = next(c for c in gate['checks'] if c['name'] == 'python-unittest')
    lines = (core['stdout'] + '\n' + core['stderr']).splitlines()
    failed = [line for line in lines if line.startswith(('FAILED ', 'SUBFAILED('))]
    assert len(failed) == 42
    targets = []
    for line in failed:
        found = re.search(r'(?<!\S)(tests/[^\s:]+\.py::[^\s:]+::[^\s:]+)', line)
        assert found is not None, line
        node = found.group(1)
        if node not in targets:
            targets.append(node)
    assert len(targets) == 38
    selection = {
        'gate_path': str(gate_path), 'gate_sha256': hashlib.sha256(gate_bytes).hexdigest(),
        'failure_record_count': len(failed), 'failed_records': failed,
        'unique_parent_count': len(targets), 'targets': targets,
        'source_sha256': {p: hashlib.sha256((CANDIDATE / p).read_bytes()).hexdigest()
                          for p in sorted({t.split('::')[0] for t in targets})},
    }
    save('failed-selection.json', selection)
    before = identity()
    save('failed-before.json', before)
    env = python_test_runner._environment(CANDIDATE, EVIDENCE / '.coverage-unused')
    env['TMPDIR'] = str(TEMPS['short'])
    cmd = ['taskset', '-c', '0-3', *python_test_runner._pytest_command(4, 'worksteal'),
           f'--junitxml={EVIDENCE / "failed-tests.junit.xml"}', *targets]
    metadata = {
        'command': cmd, 'shell_command': shlex.join(cmd), 'cwd': str(CANDIDATE),
        'environment_builder': '.getzilla/getzilla/python_test_runner.py::_environment',
        'environment_overrides': {k: env[k] for k in (
            'TMPDIR', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD', 'PYTHONDONTWRITEBYTECODE',
            '_GETZILLA_TEST_CHILD', 'COVERAGE_FILE', 'PYTHONPATH')},
        'runner_changes_vs_full_gate': '38 selected parent nodes, four workers, no coverage plugin/threshold; external JUnit report',
        'timeout_seconds': 600,
    }
    save('failed-tests-command.json', metadata)
    print(f'Running {len(targets)} unique parents covering all {len(failed)} failure records', flush=True)
    t0 = time.monotonic()
    with (EVIDENCE / 'failed-tests.stdout').open('wb') as out, (EVIDENCE / 'failed-tests.stderr').open('wb') as err:
        process = subprocess.Popen(cmd, cwd=CANDIDATE, env=env, stdout=out, stderr=err, start_new_session=True)
        try:
            returncode = process.wait(timeout=600)
            timed_out = False
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            returncode = process.returncode
            timed_out = True
    after = identity()
    save('failed-after.json', after)
    assert before == after
    source_after = {p: hashlib.sha256((CANDIDATE / p).read_bytes()).hexdigest() for p in selection['source_sha256']}
    assert source_after == selection['source_sha256']
    output = {name: (EVIDENCE / f'failed-tests.{name}').read_bytes() for name in ('stdout', 'stderr')}
    result = {'returncode': returncode, 'timed_out': timed_out,
              'seconds': round(time.monotonic() - t0, 3), 'reviewed-tree-modified': 'no',
              'stdout_bytes': len(output['stdout']), 'stderr_bytes': len(output['stderr']),
              'stdout_sha256': hashlib.sha256(output['stdout']).hexdigest(),
              'stderr_sha256': hashlib.sha256(output['stderr']).hexdigest()}
    save('failed-tests-result.json', result)
    print(json.dumps(result), flush=True)
    print(output['stdout'].decode('utf-8', 'replace'), flush=True)
    print(output['stderr'].decode('utf-8', 'replace'), flush=True)


if __name__ == '__main__':
    main()
