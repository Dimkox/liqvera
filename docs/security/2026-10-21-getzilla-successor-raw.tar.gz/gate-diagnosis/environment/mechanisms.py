#!/usr/bin/env python3
"""Read-only source probes using disposable, synthetic local fixtures."""
from __future__ import annotations

import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from run import CANDIDATE, EVIDENCE, TEMPS, save

sys.path.insert(0, str(CANDIDATE / '.getzilla'))
from getzilla import stacks, util


def git_probe():
    results = {}
    for label, parent in TEMPS.items():
        with tempfile.TemporaryDirectory(prefix='plain-probe-', dir=parent) as temp:
            root = Path(temp)
            (root / 'Cargo.toml').write_text('[package]\nname="synthetic"\n')
            commands = []
            for args in (
                ('rev-parse', '--show-toplevel'),
                ('ls-files', '-co', '--exclude-standard', '-z'),
                ('check-ignore', '-v', 'Cargo.toml'),
            ):
                argv = ['git', '--no-optional-locks', *args]
                proc = subprocess.run(argv, cwd=root, capture_output=True, text=True)
                commands.append({'command': argv, 'cwd': str(root), 'returncode': proc.returncode,
                                 'stdout': proc.stdout, 'stderr': proc.stderr})
            before = util.tree_fingerprint(root)
            scratch = root / '.qwen/tmp/probe'
            scratch.parent.mkdir(parents=True)
            scratch.write_text('synthetic scratch edit\n')
            results[label] = {
                'commands': commands,
                'tree_files': stacks.tree_files(root),
                'detected_stacks': [s.id for s in stacks.detect_stacks(root)],
                'git_head': util.git_head(root),
                'changed_files': util.changed_files(root),
                'fingerprint_before': before,
                'fingerprint_after': util.tree_fingerprint(root),
            }
    save('git-mechanism.json', results)
    print(json.dumps(results, indent=2), flush=True)


def chrome_probe():
    chrome = shutil.which('google-chrome') or shutil.which('chromium') or shutil.which('chromium-browser')
    assert chrome, 'Chrome executable is required for the startup diagnostic'
    results = {}
    for label, parent in TEMPS.items():
        profile = parent / ('seo-landing-browser-contract-' + os.urandom(3).hex())
        profile.mkdir(mode=0o700)
        with socket.socket() as local:
            local.bind(('127.0.0.1', 0))
            port = local.getsockname()[1]
        argv = [chrome, '--headless=new', '--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu',
                f'--remote-debugging-port={port}', f'--user-data-dir={profile}', 'about:blank']
        env = {**os.environ, 'TMPDIR': str(parent), 'PYTHONDONTWRITEBYTECODE': '1'}
        stdout_path = EVIDENCE / f'{label}-chrome-startup.stdout'
        stderr_path = EVIDENCE / f'{label}-chrome-startup.stderr'
        t0 = time.monotonic()
        proc = None
        ready = False
        try:
            with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
                proc = subprocess.Popen(argv, cwd=CANDIDATE, env=env, stdout=stdout, stderr=stderr,
                                        start_new_session=True)
                while time.monotonic() - t0 < 12:
                    ready = b'DevTools listening on' in stderr_path.read_bytes()
                    if ready or proc.poll() is not None:
                        break
                    time.sleep(0.1)
                exit_before_cleanup = proc.poll()
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait(timeout=3)
                results[label] = {'command': argv, 'cwd': str(CANDIDATE), 'TMPDIR': str(parent),
                                  'profile_path_bytes': len(os.fsencode(profile)),
                                  'seconds': round(time.monotonic() - t0, 3), 'devtools_ready': ready,
                                  'exit_before_cleanup': exit_before_cleanup,
                                  'exit_after_cleanup': proc.returncode}
        finally:
            if proc is not None and proc.poll() is None:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=3)
            shutil.rmtree(profile)
        print(label, json.dumps(results[label]), flush=True)
        print(stderr_path.read_text(errors='replace'), flush=True)
    save('chrome-startup.json', results)


if __name__ == '__main__':
    if sys.argv[1] == 'git':
        git_probe()
    elif sys.argv[1] == 'chrome':
        chrome_probe()
    else:
        raise SystemExit('unknown diagnostic')
