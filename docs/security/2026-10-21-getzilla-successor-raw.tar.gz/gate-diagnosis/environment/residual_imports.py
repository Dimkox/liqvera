#!/usr/bin/env python3
"""Five unchanged residual parents; isolate the inherited import-path entry."""
from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import time

from run import CANDIDATE, EVIDENCE, TEMPS, identity, save

sys.path[:0] = [str(CANDIDATE), str(CANDIDATE / '.getzilla')]
from getzilla import python_test_runner
from tests._support import project_copy


def env_for(label):
    env = python_test_runner._environment(CANDIDATE, EVIDENCE / '.coverage-unused')
    env['TMPDIR'] = str(TEMPS['short'])
    if label == 'without-stack-entry':
        env['PYTHONPATH'] = os.pathsep.join(p for p in env['PYTHONPATH'].split(os.pathsep)
                                          if p != str(CANDIDATE / '.getzilla'))
    return env


def residual_tests():
    previous = (EVIDENCE / 'failed-tests.stdout').read_bytes()
    records = [line for line in previous.decode().splitlines() if line.startswith(('FAILED ', 'SUBFAILED('))]
    targets = list(dict.fromkeys(re.search(r'(?<!\S)(tests/[^\s:]+\.py::[^\s:]+::[^\s:]+)', line).group(1)
                                for line in records))
    assert len(records) == 7 and len(targets) == 5
    before = identity()
    save('residual-before.json', before)
    outcomes = {}
    for label in ('native', 'without-stack-entry'):
        env = env_for(label)
        cmd = ['taskset', '-c', '0-3', *python_test_runner._pytest_command(4, 'worksteal'), *targets]
        t0 = time.monotonic()
        result = subprocess.run(cmd, cwd=CANDIDATE, env=env, capture_output=True, timeout=180)
        for name in ('stdout', 'stderr'):
            (EVIDENCE / f'residual-{label}.{name}').write_bytes(getattr(result, name))
        outcomes[label] = {'command': cmd, 'shell_command': shlex.join(cmd), 'cwd': str(CANDIDATE),
                           'TMPDIR': env['TMPDIR'], 'PYTHONPATH': env['PYTHONPATH'],
                           'returncode': result.returncode, 'seconds': round(time.monotonic() - t0, 3),
                           'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                           'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
        save('residual-results.json', outcomes)
        print(label, json.dumps(outcomes[label]), flush=True)
        print(result.stdout.decode()[-2600:], flush=True)
    after = identity()
    assert after == before
    save('residual-after.json', after)


def provenance():
    os.environ['TMPDIR'] = str(TEMPS['short'])
    import tempfile
    tempfile.tempdir = None
    results = {}
    with project_copy() as root:
        policy = root / '.getzilla/getzilla/policy.py'
        policy.write_text('raise ImportError("diagnostic broken fixture policy")\n')
        payload = {'cwd': str(root), 'tool_name': 'Bash', 'tool_input': {'command': 'rm -rf build'}}
        for label in ('native', 'without-stack-entry'):
            env = env_for(label)
            cmd = [sys.executable, '-B', '-v', str(root / '.grok/hooks/pre_tool_use.py')]
            result = subprocess.run(cmd, cwd=root, env=env, input=json.dumps(payload).encode(),
                                    capture_output=True, timeout=30)
            for name in ('stdout', 'stderr'):
                (EVIDENCE / f'provenance-{label}.{name}').write_bytes(getattr(result, name))
            source_lines = [line for line in result.stderr.decode().splitlines()
                            if ('code object from' in line and '/getzilla/' in line)
                            and any('/' + name + '.py' in line for name in ('__init__', 'policy', 'fsx'))]
            events = root / '.getzilla/runtime/hook-events.jsonl'
            results[label] = {'command': cmd, 'cwd': str(root), 'TMPDIR': env['TMPDIR'],
                              'PYTHONPATH': env['PYTHONPATH'], 'payload': payload,
                              'returncode': result.returncode, 'stdout': result.stdout.decode(),
                              'selected_import_trace': source_lines,
                              'fixture_degraded_event_exists': events.exists()}
            print(label, json.dumps(results[label]), flush=True)
    save('provenance.json', results)


if __name__ == '__main__':
    if sys.argv[1] == 'tests':
        residual_tests()
    elif sys.argv[1] == 'provenance':
        provenance()
    else:
        raise SystemExit('unknown action')
