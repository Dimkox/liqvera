#!/usr/bin/env python3
"""Bounded, unchanged native tests; vary only TMPDIR between fresh processes."""
from __future__ import annotations

import hashlib
import json
import os
import shlex
import stat
import subprocess
import sys
import time
from pathlib import Path

CANDIDATE = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions')
EVIDENCE = Path(__file__).parent
PYTHON = Path('/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python')
TEMPS = {
    'original': Path('/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-tmp'),
    'short': Path('/home/pall/.cache/gz-gate-env'),
}
EXPECTED_HEAD = '4cf2abf21753e61383e3d89be593e0fb815afc7f'
EXPECTED_TREE = '947e9f362d4f0bc862e8bf12455c8e4b1862e850'
SOURCES = (
    'tests/test_stacks_registry.py', 'tests/test_adopt_existing_cli.py',
    'tests/test_util_fingerprint.py', 'tests/zero_git_support.py',
    'tests/test_seo_landing_side_project.py',
    'side-projects/seo-landing-showcase/browser-contract.mjs',
    '.getzilla/getzilla/stacks.py', '.getzilla/getzilla/util.py',
    'scripts/adopt_existing.py', '.getzilla/getzilla/project_ingestion.py',
)
TESTS = [
    'tests.test_stacks_registry.DetectionTests.test_detects_by_marker_and_ignores_fixtures_and_dependencies',
    'tests.test_stacks_registry.DetectionTests.test_git_tree_skips_ignored_files',
    'tests.test_stacks_registry.NotVerifiedTests.test_pr_with_changed_files_of_an_unchecked_stack_fails',
    'tests.test_stacks_registry.NotVerifiedTests.test_untouched_stack_is_reported_but_does_not_refuse',
    'tests.test_stacks_registry.NotVerifiedTests.test_fast_mode_warns_instead_of_refusing',
    'tests.test_stacks_registry.NotVerifiedTests.test_registered_runner_replaces_the_not_verified_line',
    'tests.test_adopt_existing_cli.CliTests.test_cli_plan_has_no_source_side_effect',
    'tests.test_util_fingerprint.FingerprintTests.test_non_git_and_unborn_repositories_conservatively_bind_scratch',
]
BROWSER_TESTS = [
    'tests.test_seo_landing_side_project.SeoLandingShowcaseContractTests.test_local_chrome_runner_exits_cleanly_after_contract_passes',
]


def save(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n')


def git(*args):
    p = subprocess.run(['git', '--no-optional-locks', *args], cwd=CANDIDATE,
                       capture_output=True, text=True, check=True)
    return p.stdout.strip()


def identity():
    value = {
        'candidate': str(CANDIDATE), 'head': git('rev-parse', 'HEAD'),
        'tree': git('rev-parse', 'HEAD^{tree}'),
        'status': git('status', '--porcelain=v1', '--untracked-files=all'),
        'source_sha256': {p: hashlib.sha256((CANDIDATE / p).read_bytes()).hexdigest() for p in SOURCES},
    }
    assert value['head'] == EXPECTED_HEAD and value['tree'] == EXPECTED_TREE
    assert value['status'] == ''
    return value


def inspect_path(path):
    result = []
    for item in [*reversed(path.parents), path]:
        info = item.lstat()
        row = {'path': str(item), 'mode': oct(stat.S_IMODE(info.st_mode)),
               'uid': info.st_uid, 'gid': info.st_gid,
               'symlink': stat.S_ISLNK(info.st_mode),
               'sticky': bool(info.st_mode & stat.S_ISVTX),
               'group_or_other_writable': bool(info.st_mode & 0o022)}
        assert stat.S_ISDIR(info.st_mode) and not row['symlink']
        assert info.st_uid in (0, os.getuid()) and not row['group_or_other_writable']
        assert not row['sticky']
        result.append(row)
    info = path.lstat()
    assert info.st_uid == os.getuid() and stat.S_IMODE(info.st_mode) == 0o700
    cmd = ['git', '--no-optional-locks', 'rev-parse', '--show-toplevel']
    proc = subprocess.run(cmd, cwd=path, capture_output=True, text=True)
    return {'path': str(path), 'path_bytes': len(os.fsencode(path)), 'ancestors': result,
            'command': cmd, 'returncode': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr}


def run_tests(label, group, tests):
    env_delta = {'TMPDIR': str(TEMPS[label]), 'PYTHONDONTWRITEBYTECODE': '1'}
    env = os.environ.copy()
    env.update(env_delta)
    cmd = ['taskset', '-c', '0-3', str(PYTHON), '-B', '-m', 'unittest', '-v', *tests]
    t0 = time.monotonic()
    proc = subprocess.run(cmd, cwd=CANDIDATE, env=env, capture_output=True, timeout=180)
    (EVIDENCE / f'{label}-{group}.stdout').write_bytes(proc.stdout)
    (EVIDENCE / f'{label}-{group}.stderr').write_bytes(proc.stderr)
    result = {'label': label, 'group': group, 'cwd': str(CANDIDATE), 'command': cmd,
              'shell_command': 'env ' + ' '.join(f'{k}={shlex.quote(v)}' for k, v in env_delta.items()) + ' ' + shlex.join(cmd),
              'env_delta': env_delta, 'returncode': proc.returncode,
              'seconds': round(time.monotonic() - t0, 3),
              'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(),
              'stderr_sha256': hashlib.sha256(proc.stderr).hexdigest(),
              'stdout_bytes': len(proc.stdout), 'stderr_bytes': len(proc.stderr)}
    save(f'{label}-{group}.json', result)
    print(json.dumps(result), flush=True)
    print(proc.stderr.decode('utf-8', 'replace')[-2400:], flush=True)
    return result


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare':
        save('identity-before.json', identity())
        safety = {label: inspect_path(path) for label, path in TEMPS.items()}
        assert safety['short']['returncode'] == 128
        assert safety['original']['stdout'].strip() == '/home/pall/projects/liqvera'
        save('path-safety.json', safety)
        save('process-binding.json', {
            'uid': os.getuid(), 'python': str(PYTHON), 'python_version': subprocess.check_output([str(PYTHON), '--version'], text=True).strip(),
            'git_environment_names_present': sorted(k for k in os.environ if k.startswith('GIT_')),
            'reviewer_affinity': sorted(os.sched_getaffinity(0)),
        })
        print('prepared identity and path safety evidence')
    elif action in ('core', 'browser'):
        group_tests = TESTS if action == 'core' else BROWSER_TESTS
        label = sys.argv[2]
        run_tests(label, action, group_tests)
    elif action == 'finish':
        after = identity()
        before = json.loads((EVIDENCE / 'identity-before.json').read_text())
        save('identity-after.json', after)
        assert after == before
        print('reviewed-tree-modified: no; exact identities, source hashes, clean status unchanged')
    else:
        raise SystemExit('unknown action')
