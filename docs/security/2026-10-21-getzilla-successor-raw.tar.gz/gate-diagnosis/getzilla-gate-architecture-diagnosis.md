# Getzilla gate diagnosis — architecture and spec

The gate has two independent causes: missing required-scope metadata and queue-provenance analysis that reaches its bounds. Governance then fails because architecture did not pass. Keep risk red. Repair the metadata and bounded resolver; do not add a model exception, raise limits or weaken the gate.

Source: `4cf2abf21753e61383e3d89be593e0fb815afc7f`, tree `947e9f362d4f0bc862e8bf12455c8e4b1862e850`, route `d834158878e0`, comparison base `e158ddc7263a55f5308944c5a426eb1e9f1a4327`. Candidate `/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions` remained clean and unchanged. `reviewed-tree-modified: no`.

Raw gate `.getzilla/runtime/final/getzilla-pr.json` SHA-256: `db7509a86319038f3f699259fc71957f9d649ff9c0a3048ba656e3d9d5a82de5`. A bounded reproduction returned exit 1 and the exact same fitness evidence digest as that gate: `3dccf2420af0bf356fe79341310fe74f4062fb693197c4da81cdacf7efa0b949`.

## Required-scope metadata

`.getzilla/getzilla/spec.py:792–796` requires red-risk gate specs to contain forbidden outcomes and a nonempty `approvals.required_scopes`. The active Getzilla spec declares red risk and an empty list. The Liqvera route `ec1239ea42dd` spec has the same omission.

For both, the minimal legitimate correction is:

```json
"approvals": {"required_scopes": ["scope_and_design_approval"]}
```

This names an existing route gate. It matches the established red-risk example at `engineering/changes/20261012-task-43786c/change-spec.yaml:154–158`. Keep the current risk, forbidden outcomes, reviews and exact-source verification requirements. Reference the already-authorized bounded design and its recorded owner decision; do not create a new decision, grant, actor identity or signed security approval. A required-scope declaration is not evidence that approval was granted. `human_gates.py` explicitly distinguishes local workflow evidence from delegated grants, Trust CI signatures and merge authority.

Architecture's generated `required_scopes: ["architecture"]` is a separate fitness result, currently caused by unresolved provenance. Do not forge an approval to satisfy it. Recompute it after the resolver repair and handle any remaining real requirement through the existing workflow.

## Exact fitness failure

Preflight, repository drift and generated diagrams pass. The only non-passing fitness category is `background_job`, rule `FIT-BOUNDED-WORKER-JOBS` (`architecture/rules.yaml:3–22`), status `unsupported`, reason `queue_provenance_unresolved`. Its findings name:

- `.getzilla/getzilla/verification.py`.
- `tests/test_verification_dispositions.py`.

`_new_queue_sources` catches the analysis limit as unsupported changed-source provenance (`architecture_fitness.py:2416–2487`). That generates `new_queue`, red risk and revoked exemption. This is a conservative unresolved signal, not proof that this change added a runtime queue. `evaluate_fitness` treats unsupported as failure (`2848–2934`). Governance's message, “requires a complete successful architecture check,” is therefore derivative; no governance-registry edit is justified by this result.

The detailed trace identifies the cause:

1. `_queue_adapter_names` expands every `ImportFrom` binding during recursive resolution, beyond the caller's actual demanded export (`2244–2286`). `_local_queue_resolution` analyzes the complete imported module before selecting the needed export (`2164–2239`). Broad verifier imports pull in unrelated callable dependencies.
2. The verifier exceeds the 32-module bound in both base and head. In the head trace, `diff_risk -> code_graph.builder` reaches 31 visited modules, then attempts to prefetch several `code_graph` modules with only one slot left.
3. The new test's broad verifier dependency exceeds depth 8 through `verification -> receipts -> review_source -> state -> agent_lifecycle -> policy -> _policy_legacy -> cost_guard -> risk_terms`.
4. Model-derived ownership prefixes also include `.getzilla/getzilla`. Longest-prefix package selection consequently treats `verification.py` as package `""`; bare `state` becomes ambiguous. The imported `architecture_diff` module contains an existing standard-library queue used by bounded Git I/O.

A read-only hypothesis probe removed only `.getzilla/getzilla` from the derived import-root set in memory. This correctly produced package `getzilla`, but both affected files still exceeded depth 8. Therefore correcting that interpretation alone is insufficient. Adding a declared queue edge or a model waiver cannot resolve unsupported analysis. The existing model's job envelope rules are not an exemption from provenance proof.

## Smallest sound repair boundary

The sole implementation owner should repair demand-driven local-symbol resolution, with focused regression coverage:

- Derive demanded symbols from direct callable imports, static module attributes, decorators, aliases, returns and other operations that can carry queue provenance. Direct private imports such as `_git_diff_check` are valid demands.
- Resolve definitions and assignments feeding those demands, instead of recursively expanding every imported definition. Preserve executed top-level initializers, decorators and relevant side effects; an unused function body is different from an import that executes code.
- Carry the demand set into local-module resolution and caching. Bind cached results to side, source identity, module and demand, or expand/recompute the demand. A narrow negative proof must not cover later wider use.
- Resolve package identity from actual package boundaries. An architecture ownership directory is not automatically a Python import root. Preserve ambiguity failures when identity cannot be established.
- Keep current 32-module/depth-8 and AST/value/dependency-work limits for demanded analysis. Keep unknown dynamic attributes, wildcard/re-export escapes, cycles, unresolved aliases and unsupported semantics fail-closed. Do not special-case these files or treat unchanged base failure as permission to ignore head analysis.

The falsifying regression must include a safe demanded export whose unrelated function/export bodies lead beyond module/depth limits. That irrelevant branch must not poison the narrow proof. Then connect the same demanded export to that branch: bounded analysis must return unsupported. Also connect it through an alias, wrapper return, closure or container to a real queue constructor/submission: detection or a conservative failure must remain. Test direct and module-attribute imports, private names, demand-cache widening and package-name collisions. Existing hidden/dynamic queue controls must continue to fail closed. Unexamined top-level effects must never be labeled safe merely to make this test pass.

This proposal was sent to the coordinator and `general_implementer`. No source or model repair was performed here. The repaired whole diff needs fresh independent reviews and a new frozen full gate. The old failed gate remains immutable.

## Saved evidence and limits

All files are beside this report under canonical `completion/`:

| Artifact | SHA-256 |
|---|---|
| `getzilla-gate-architecture-diagnosis.fitness.json` — complete actual fitness output | `2b2a4b9bb4b2a57eeff0c3b6be39e25cb5f0b4ed5612980fe1d74a54e1ddee5b` |
| `getzilla-gate-architecture-diagnosis.provenance.json` — base/head bound failures | `03e7a796d69b67a65244eca52ea2f2519941e2c187ad6b471c6caddc327bb64a` |
| `getzilla-gate-architecture-diagnosis.trace.json` — exact import chains and unsuccessful root-only hypothesis | `1e2f35ead7247bd2202c117fafa74157e954acbdf425ff6e140d24a1168536a2` |
| `getzilla-gate-architecture-diagnosis.gate-extract.json` — selected original gate records and binding | `5a80dd473e3ab592bdb7de0c46207bb470c573c4ae1a7b91845d58efc1f39f9c` |

The actual fitness command was `taskset -c 4,5 python3 -B scripts/getzilla_architecture.py --root /home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions fitness --base e158ddc7263a55f5308944c5a426eb1e9f1a4327 --worktree --pre-risk red --json`, with `PYTHONDONTWRITEBYTECODE=1` and `TMPDIR=/tmp/gz-arch-DLpzab`. That private mode-0700, non-Git parent held only temporary architecture materialization. Output was redirected outside the candidate. Further read-only helper probes observed the resolver and its unchanged limits.

One trace attempt stopped with `Git worktree binding changed`; HEAD/tree and working status remained unchanged, and the single retry completed. The first fitness reproduction already matched the original gate digest. The transient interruption is retained here and is not asserted to explain unrelated suite failures. No full suite, application edit, live action, receipt or private authorization access occurred.
