"""Non-qualifying bounded factory diagnostic; no repository source writes."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import tempfile
import threading
import time

ROOT = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions')
OUTPUT = Path('/home/pall/projects/liqvera/.getzilla/runtime/completion')
EXPECTED = '4cf2abf21753e61383e3d89be593e0fb815afc7f'
PREFIX = OUTPUT / 'getzilla-gate-factory-diagnosis-full'
INTERPRETER = OUTPUT / 'getzilla-gate-venv/bin/python'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

assert git('rev-parse', 'HEAD') == EXPECTED
assert git('status', '--porcelain') == ''
os.sched_setaffinity(0, list(range(8, 16)))
scratch = Path(tempfile.mkdtemp(prefix='.gz-fdiag-', dir='/home/pall'))
scratch.chmod(0o700)
ancestry = []
for path in reversed((scratch, *scratch.parents)):
    metadata = path.lstat()
    assert stat.S_ISDIR(metadata.st_mode) and not stat.S_ISLNK(metadata.st_mode)
    assert metadata.st_uid in (0, os.geteuid()) and not metadata.st_mode & 0o022
    ancestry.append({'path': str(path), 'uid': metadata.st_uid, 'mode': oct(stat.S_IMODE(metadata.st_mode))})
assert subprocess.run(['git', 'rev-parse', '--show-toplevel'], cwd=scratch, capture_output=True).returncode == 128
source = ROOT / 'factory/tests/run_disposable_exit.py'
original = source.read_bytes()
assert original == subprocess.check_output(['git', 'show', f'{EXPECTED}:factory/tests/run_disposable_exit.py'], cwd=ROOT)
before = b'_FULL_SUITE_TIMEOUT_SECONDS = 720\n'
after = b'_FULL_SUITE_TIMEOUT_SECONDS = 1200\n'
assert original.count(before) == 1
modified = original.replace(before, after)
copy = scratch / 'run_disposable_exit.py'
copy.write_bytes(modified)
copy.chmod(0o600)
diff = ''.join(difflib.unified_diff(original.decode().splitlines(keepends=True), modified.decode().splitlines(keepends=True), fromfile='candidate/factory/tests/run_disposable_exit.py', tofile='private-diagnostic/run_disposable_exit.py'))
Path(str(PREFIX) + '.copy.diff').write_text(diff)
keep = ['HOME', 'USER', 'LANG', 'LC_ALL', 'PATH', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY',
        'http_proxy', 'https_proxy', 'all_proxy', 'no_proxy', 'DOCKER_HOST', 'DOCKER_CONTEXT', 'SSH_AUTH_SOCK']
env = {name: os.environ[name] for name in keep if name in os.environ}
base = ROOT.parent
corrected = Path('/home/pall/projects/liqvera/.worktrees/wave1-deploy/.venv')
cert = corrected / 'lib/python3.12/site-packages/pip/_vendor/certifi/cacert.pem'
assert cert.is_file()
ca_dir = base / 'tls-fix/empty-ca'
assert ca_dir.is_dir()
env.update(SSL_CERT_FILE=str(cert), SSL_CERT_DIR=str(ca_dir), NODE_OPTIONS='--use-openssl-ca',
           PYTHONHTTPSVERIFY='1', GETZILLA_NO_VENV='1', GETZILLA_OSV_DB='', GETZILLA_OSV_ONLINE='1',
           PYTHONDONTWRITEBYTECODE='1', GETZILLA_TEST_WORKERS='8', TMPDIR=str(scratch))
env['PATH'] = str(INTERPRETER.parent) + os.pathsep + env['PATH']
command = [str(INTERPRETER), str(copy)]
start = time.monotonic()
record = {
    'purpose': 'DIAGNOSTIC ONLY; NON-QUALIFYING; no receipt', 'head': EXPECTED,
    'tree': git('rev-parse', 'HEAD^{tree}'), 'cwd': str(ROOT), 'command': command,
    'source_sha256': hashlib.sha256(original).hexdigest(), 'copy_sha256': hashlib.sha256(modified).hexdigest(),
    'only_source_override': '_FULL_SUITE_TIMEOUT_SECONDS: 720 -> 1200 in private copy',
    'test_selection': 'unchanged full unittest discovery plus original preflight and restart probes',
    'cpu_affinity': sorted(os.sched_getaffinity(0)), 'scratch': str(scratch), 'ancestry': ancestry,
    'environment_names': sorted(env), 'environment_nonsecret': {name: env[name] for name in ('TMPDIR', 'SSL_CERT_FILE', 'SSL_CERT_DIR', 'GETZILLA_TEST_WORKERS', 'GETZILLA_NO_VENV', 'PYTHONDONTWRITEBYTECODE')},
    'started_at': datetime.now(timezone.utc).isoformat(), 'start_monotonic': start,
    'inner_suite_timeout_seconds': 1200, 'outer_diagnostic_timeout_seconds': 1900,
}
provenance = Path(str(PREFIX) + '.json')
provenance.write_text(json.dumps(record, indent=2) + '\n')
for suffix in ('.json', '.copy.diff'):
    Path(str(PREFIX) + suffix).chmod(0o600)
process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
record['pid'] = process.pid
provenance.write_text(json.dumps(record, indent=2) + '\n')
lock = threading.Lock()
progress = Path(str(PREFIX) + '.progress.jsonl')
status = Path(str(PREFIX) + '.progress.json')
state = {'completed_test_lines': 0, 'last_test': None, 'last_test_elapsed_seconds': None}
pattern = re.compile(r'^(test_\S+) \(([^\r\n)]+)\) \.\.\. (.*)$')

def drain(stream, suffix):
    destination = Path(str(PREFIX) + suffix)
    with destination.open('xb') as log:
        destination.chmod(0o600)
        for raw in iter(stream.readline, b''):
            log.write(raw)
            log.flush()
            text = raw.decode('utf-8', 'replace').rstrip('\r\n')
            match = pattern.match(text)
            if match:
                elapsed = round(time.monotonic() - start, 6)
                result = match.group(3)
                safe_result = result if result in ('ok', 'FAIL', 'ERROR', 'expected failure', 'unexpected success') else ('skipped' if result.startswith('skipped') else 'other')
                with lock:
                    previous = state['last_test_elapsed_seconds']
                    event = {'test': match.group(2), 'result': safe_result, 'elapsed_seconds': elapsed,
                             'delta_since_prior_test_seconds': round(elapsed - previous, 6) if previous is not None else None}
                    with progress.open('a') as handle:
                        handle.write(json.dumps(event) + '\n')
                    progress.chmod(0o600)
                    state.update(completed_test_lines=state['completed_test_lines'] + 1,
                                 last_test=match.group(2), last_result=safe_result, last_test_elapsed_seconds=elapsed)
                    status.write_text(json.dumps(state, indent=2) + '\n')
                    status.chmod(0o600)
    stream.close()

with ThreadPoolExecutor(max_workers=2) as readers:
    futures = [readers.submit(drain, process.stdout, '.stdout'), readers.submit(drain, process.stderr, '.stderr')]
    try:
        returncode = process.wait(timeout=1900)
    except subprocess.TimeoutExpired:
        record['outer_timeout'] = True
        os.killpg(process.pid, signal.SIGINT)
        try:
            returncode = process.wait(timeout=45)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            returncode = process.wait()
            record['outer_kill'] = True
    for future in futures:
        future.result(timeout=10)
end = time.monotonic()
record.update(returncode=returncode, end_monotonic=end, duration_seconds=end-start,
              finished_at=datetime.now(timezone.utc).isoformat(), head_after=git('rev-parse', 'HEAD'),
              tree_after=git('rev-parse', 'HEAD^{tree}'), git_status_after=git('status', '--porcelain'),
              progress=state)
for suffix in ('.stdout', '.stderr', '.progress.jsonl'):
    path = Path(str(PREFIX) + suffix)
    if path.is_file():
        record[suffix.lstrip('.') + '_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
provenance.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('returncode', 'duration_seconds', 'head_after', 'git_status_after', 'scratch', 'progress')}), flush=True)
raise SystemExit(returncode)
