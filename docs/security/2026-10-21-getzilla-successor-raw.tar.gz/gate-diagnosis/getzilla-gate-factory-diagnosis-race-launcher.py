from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import tempfile
import time

root=Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions')
out=Path('/home/pall/projects/liqvera/.getzilla/runtime/completion')
prefix=out/'getzilla-gate-factory-diagnosis-race'
python=out/'getzilla-gate-venv/bin/python'
os.sched_setaffinity(0,[8,9])
scratch=Path(tempfile.mkdtemp(prefix='.gz-race-',dir='/home/pall'))
scratch.chmod(0o700)
for p in (scratch,*scratch.parents):
 s=p.lstat()
 assert stat.S_ISDIR(s.st_mode) and not stat.S_ISLNK(s.st_mode) and s.st_uid in (0,os.geteuid()) and not s.st_mode & 0o022
assert subprocess.run(['git','rev-parse','--show-toplevel'],cwd=scratch,capture_output=True).returncode==128
wrapper=scratch/'selected_runner.py'
wrapper.write_text('''from pathlib import Path
import importlib.util
import json
import sys
root=Path.cwd()
spec=importlib.util.spec_from_file_location("factory_disposable_original",root/"factory/tests/run_disposable_exit.py")
runner=importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
original=runner._run
target="factory.tests.test_execution_persistence_postgres.ExecutionPersistencePostgresTests.test_cancel_and_fresh_recovery_race_is_bounded_and_single_terminal"
def selected(command,*,environment=None,timeout=runner._DEFAULT_COMMAND_TIMEOUT_SECONDS):
 if "unittest" in command:
  assert command==["uv","run","--project","factory","python","-m","unittest","discover","-s","factory/tests","-t",".","-v"]
  probe="import os,sys; from pathlib import Path; assert sys.version_info[:2]==(3,12); assert Path(sys._base_executable).resolve()==Path(sys.argv[1]).resolve(); fd=os.pidfd_open(os.getpid()); os.close(fd); print('SUPPORTED_INTERPRETER',sys.version.split()[0],sys._base_executable)"
  original(["uv","run","--project","factory","python","-c",probe,environment["UV_PYTHON"]],environment=environment,timeout=30)
  command=["uv","run","--project","factory","python","-m","unittest","-v",*[target]*5]
  print("DIAGNOSTIC_SELECTED_REPETITIONS",json.dumps({"target":target,"count":5,"retries":False,"assertions_changed":False}),flush=True)
 return original(command,environment=environment,timeout=timeout)
runner._run=selected
raise SystemExit(runner.main())
''')
keep=['HOME','USER','LANG','LC_ALL','PATH','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy','DOCKER_HOST','DOCKER_CONTEXT','SSH_AUTH_SOCK']
env={name:os.environ[name] for name in keep if name in os.environ}
env.update(SSL_CERT_FILE='/home/pall/projects/liqvera/.worktrees/wave1-deploy/.venv/lib/python3.12/site-packages/pip/_vendor/certifi/cacert.pem',SSL_CERT_DIR='/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/empty-ca',PYTHONHTTPSVERIFY='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(scratch),UV_PYTHON=str(python))
env['PATH']=str(python.parent)+os.pathsep+env['PATH']
record={'purpose':'NON-QUALIFYING five independent observations, no retry-until-pass','scratch':str(scratch),'command':[str(python),str(wrapper)],'cpu_affinity':[8,9],'UV_PYTHON':str(python),'source_sha256':hashlib.sha256((root/'factory/tests/run_disposable_exit.py').read_bytes()).hexdigest(),'wrapper_sha256':hashlib.sha256(wrapper.read_bytes()).hexdigest(),'head_before':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'test_source_sha256':hashlib.sha256((root/'factory/tests/test_execution_persistence_postgres.py').read_bytes()).hexdigest(),'store_source_sha256':hashlib.sha256((root/'factory/src/getzilla_factory/store.py').read_bytes()).hexdigest(),'started_at':datetime.now(timezone.utc).isoformat(),'outer_timeout_seconds':150}
start=time.monotonic()
record['start_monotonic']=start
Path(str(prefix)+'.json').write_text(json.dumps(record,indent=2)+'\n')
with Path(str(prefix)+'.stdout').open('w') as stdout,Path(str(prefix)+'.stderr').open('w') as stderr:
 process=subprocess.Popen(record['command'],cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try:returncode=process.wait(timeout=150)
 except subprocess.TimeoutExpired:
  record['outer_timeout']=True
  os.killpg(process.pid,signal.SIGINT)
  try:returncode=process.wait(timeout=30)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL)
   returncode=process.wait()
   record['forced_kill']=True
record.update(returncode=returncode,duration_seconds=time.monotonic()-start,finished_at=datetime.now(timezone.utc).isoformat(),head_after=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),git_status_after=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip())
Path(str(prefix)+'.json').write_text(json.dumps(record,indent=2)+'\n')
for suffix in ('.json','.stdout','.stderr'):Path(str(prefix)+suffix).chmod(0o600)
print(json.dumps({k:record[k] for k in ('returncode','duration_seconds','head_after','git_status_after','scratch')}))
raise SystemExit(returncode)
