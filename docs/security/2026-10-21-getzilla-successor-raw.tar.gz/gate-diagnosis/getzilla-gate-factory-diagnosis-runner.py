import faulthandler,hashlib,json,os,subprocess,sys,tempfile,time,unittest
from pathlib import Path
faulthandler.enable()
faulthandler.dump_traceback_later(10,repeat=True)
print("python",sys.executable,flush=True)
print("affinity",sorted(os.sched_getaffinity(0)),flush=True)
print("tempdir",tempfile.gettempdir(),flush=True)
with tempfile.TemporaryDirectory() as probe:
 path=Path(probe)/"model.sock"
 print("socket_path_bytes",len(os.fsencode(path)),flush=True)
 result=subprocess.run(["git","rev-parse","--show-toplevel"],cwd=probe,capture_output=True,text=True,timeout=5)
 print("temp_git_exit",result.returncode,"temp_git_root",result.stdout.strip(),flush=True)
name="factory.tests.test_result_dispatch.UdsResultHandoffClientTests.test_delivered_response_requires_exact_observation_digest"
suite=unittest.defaultTestLoader.loadTestsFromName(name)
source=Path("factory/tests/test_result_dispatch.py")
print("test_source_sha256",hashlib.sha256(source.read_bytes()).hexdigest(),flush=True)
start=time.monotonic()
result=unittest.TextTestRunner(verbosity=2).run(suite)
print("elapsed_seconds",round(time.monotonic()-start,3),flush=True)
faulthandler.cancel_dump_traceback_later()
sys.exit(0 if result.wasSuccessful() else 1)
