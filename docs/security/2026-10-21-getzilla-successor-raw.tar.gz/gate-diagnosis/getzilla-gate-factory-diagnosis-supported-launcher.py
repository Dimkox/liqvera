from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import tempfile
import time

root=Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions')
out=Path('/home/pall/projects/liqvera/.getzilla/runtime/completion')
prefix=out/'getzilla-gate-factory-diagnosis-supported'
python=out/'getzilla-gate-venv/bin/python'
os.sched_setaffinity(0,list(range(8,16)))
scratch=Path(tempfile.mkdtemp(prefix='.gz-fenv-',dir='/home/pall'))
scratch.chmod(0o700)
for p in (scratch,*scratch.parents):
 s=p.lstat()
 assert stat.S_ISDIR(s.st_mode) and not stat.S_ISLNK(s.st_mode)
 assert s.st_uid in (0,os.geteuid()) and not s.st_mode & 0o022
assert subprocess.run(['git','rev-parse','--show-toplevel'],cwd=scratch,capture_output=True).returncode==128
keep=['HOME','USER','LANG','LC_ALL','PATH','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy','DOCKER_HOST','DOCKER_CONTEXT','SSH_AUTH_SOCK']
env={name:os.environ[name] for name in keep if name in os.environ}
env.update(SSL_CERT_FILE='/home/pall/projects/liqvera/.worktrees/wave1-deploy/.venv/lib/python3.12/site-packages/pip/_vendor/certifi/cacert.pem',SSL_CERT_DIR='/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/empty-ca',PYTHONHTTPSVERIFY='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(scratch),UV_PROJECT_ENVIRONMENT=str(scratch/'venv'),UV_PYTHON=str(python))
env['PATH']=str(python.parent)+os.pathsep+env['PATH']
probe='''import json,os,sys
from pathlib import Path
expected=Path(sys.argv[1]).resolve()
assert sys.version_info[:2]==(3,12)
assert Path(sys._base_executable).resolve()==expected
assert callable(getattr(os,"pidfd_open",None))
fd=os.pidfd_open(os.getpid())
os.close(fd)
print(json.dumps({"python":sys.executable,"base_python":sys._base_executable,"version":sys.version.split()[0],"expected_base":str(expected),"pidfd_open_available":True,"pidfd_open_self_succeeded":True}))
'''
precommand=['uv','run','--project','factory','python','-c',probe,str(python)]
record={'purpose':'NON-QUALIFYING selected interpreter control','scratch':str(scratch),'UV_PYTHON':str(python),'UV_PROJECT_ENVIRONMENT':str(scratch/'venv'),'cpu_affinity':sorted(os.sched_getaffinity(0)),'started_at':datetime.now(timezone.utc).isoformat(),'head_before':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'test_source_sha256':hashlib.sha256((root/'factory/tests/test_linux_process_adapter.py').read_bytes()).hexdigest()}
start=time.monotonic()
pre=subprocess.run(precommand,cwd=root,env=env,capture_output=True,timeout=90)
Path(str(prefix)+'.preflight.stdout').write_bytes(pre.stdout)
Path(str(prefix)+'.preflight.stderr').write_bytes(pre.stderr)
record['preflight_exit']=pre.returncode
if pre.returncode!=0:
 Path(str(prefix)+'.json').write_text(json.dumps(record,indent=2)+'\n')
 raise SystemExit(pre.returncode)
record['interpreter']=json.loads(pre.stdout)
base='factory.tests.test_linux_process_adapter.LinuxProcessAdapterTests.'
names=['test_concurrent_managers_leave_one_child_and_coherent_journal','test_real_child_has_fixed_identity_health_logs_and_bounded_shutdown','test_setup_manager_real_process_install_failed_update_reconcile_remove_and_purge','test_stale_boot_record_never_signals_live_group','test_stop_kills_child_forked_by_term_handler_before_deleting_state','test_stop_kills_resistant_descendant_and_never_signals_own_group']
command=['uv','run','--project','factory','python','-m','unittest','-v',*[base+name for name in names]]
record['command']=command
with Path(str(prefix)+'.stdout').open('w') as stdout,Path(str(prefix)+'.stderr').open('w') as stderr:
 result=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=120)
record.update(returncode=result.returncode,duration_seconds=time.monotonic()-start,finished_at=datetime.now(timezone.utc).isoformat(),head_after=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),git_status_after=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip())
Path(str(prefix)+'.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record['interpreter']))
print(json.dumps({key:record[key] for key in ('returncode','duration_seconds','head_after','git_status_after','scratch')}))
print(Path(str(prefix)+'.stderr').read_text())
raise SystemExit(result.returncode)
