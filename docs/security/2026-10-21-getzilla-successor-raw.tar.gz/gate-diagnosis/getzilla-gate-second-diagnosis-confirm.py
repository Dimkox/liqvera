"""Two matched exact-test controls, retaining every outcome."""
from pathlib import Path
import dataclasses, datetime, hashlib, json, os, resource, subprocess, sys, tempfile, time
prefix=Path('/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-second-diagnosis')
meta=json.loads(prefix.with_suffix('.json').read_text())
source=Path(meta['source']); scratch=Path(meta['scratch'])
assert sys.version_info[:2] == (3,12) and sys._base_executable == '/usr/bin/python3.12'
os.sched_setaffinity(0,set(range(8)))
keep=['HOME','USER','LANG','LC_ALL','PATH','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy','DOCKER_HOST','DOCKER_CONTEXT','SSH_AUTH_SOCK']
env={k:os.environ[k] for k in keep if k in os.environ}
env.update(SSL_CERT_FILE='/home/pall/projects/liqvera/.worktrees/wave1-deploy/.venv/lib/python3.12/site-packages/pip/_vendor/certifi/cacert.pem',SSL_CERT_DIR='/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/empty-ca',NODE_OPTIONS='--use-openssl-ca',PYTHONHTTPSVERIFY='1',GETZILLA_NO_VENV='1',GETZILLA_OSV_DB='',GETZILLA_OSV_ONLINE='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=meta['temporary_directory'],UV_PYTHON=sys.executable,UV_PYTHON_DOWNLOADS='never')
env['PATH']=str(Path(sys.executable).parent)+os.pathsep+env['PATH']
os.environ.clear();os.environ.update(env);tempfile.tempdir=None;sys.dont_write_bytecode=True
sys.path.insert(0,str(source/'.getzilla'))
from getzilla import python_test_runner as runner
node='tests/test_policy_hardening.py::Review2PosixTests::test_secret_scan_is_bounded_and_fails_closed_on_a_huge_argv'
for label, measured in [('pytest-one-unmeasured',False),('coverage-confirm',True)]:
    data=scratch/label;data.mkdir(mode=0o700)
    command=runner._pytest_command(1,'worksteal')
    if measured:command+=['-p','pytest_cov.plugin','--cov',f'--cov-config={source / ".coveragerc"}','--cov-report=term']
    command += [node]
    start=time.monotonic();usage=resource.getrusage(resource.RUSAGE_CHILDREN)
    before={'loadavg':Path('/proc/loadavg').read_text().strip(),'cpu_pressure':Path('/proc/pressure/cpu').read_text().strip()}
    result=runner.execute(command,source,runner._environment(source,data/'.coverage'),timeout=90)
    final_usage=resource.getrusage(resource.RUSAGE_CHILDREN)
    item=dataclasses.asdict(result)
    for stream in ('stdout','stderr'):
        content=item.pop(stream);path=Path(str(prefix)+'-'+label+'.'+stream);path.write_text(content);os.chmod(path,0o600)
        item[stream+'_sha256']=hashlib.sha256(content.encode()).hexdigest()
    item.update(label=label,start_monotonic=start,end_monotonic=time.monotonic(),host_observation_before=before,child_user_cpu_seconds=final_usage.ru_utime-usage.ru_utime,child_system_cpu_seconds=final_usage.ru_stime-usage.ru_stime)
    meta['controls'].append(item)
    prefix.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps({k:item[k] for k in ('label','returncode','seconds','child_user_cpu_seconds','child_system_cpu_seconds')}),flush=True)
candidate=Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final')
meta['candidate_status_after']=subprocess.check_output(['git','status','--porcelain'],cwd=candidate,text=True).strip()
meta['candidate_head_after']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=candidate,text=True).strip()
meta['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
prefix.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
