"""Bounded NON-QUALIFYING exact-source diagnostic; never writes the candidate."""
from pathlib import Path
import dataclasses
import datetime
import hashlib
import importlib.metadata
import json
import os
import stat
import subprocess
import sys
import tarfile
import tempfile
import time

completion = Path('/home/pall/projects/liqvera/.getzilla/runtime/completion')
candidate = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final')
expected = '45be42f74b5a8ee6f079f8ac55206e475936fdc6'
prefix = completion / 'getzilla-gate-second-diagnosis'
assert completion.stat().st_uid == os.getuid() and stat.S_IMODE(completion.stat().st_mode) == 0o700
for ancestor in [Path('/home/pall'), *Path('/home/pall').parents]:
    mode = ancestor.lstat()
    assert not ancestor.is_symlink() and ancestor.is_dir() and mode.st_uid in {0,os.getuid()} and mode.st_mode & 0o022 == 0

def git(*args):
    return subprocess.check_output(['git',*args],cwd=candidate,text=True).strip()
assert git('rev-parse','HEAD') == expected
assert git('status','--porcelain') == ''
assert sys.version_info[:2] == (3,12)
assert Path(sys._base_executable).resolve() == Path('/usr/bin/python3.12').resolve()
fd = os.pidfd_open(os.getpid()); os.close(fd)
os.sched_setaffinity(0, set(range(8)))
scratch = Path(tempfile.mkdtemp(prefix='.gz-core-',dir='/home/pall'))
os.chmod(scratch,0o700)
source = scratch/'source'; source.mkdir(mode=0o700)
archive = scratch/'source.tar'
with archive.open('wb') as out:
    subprocess.run(['git','archive','--format=tar',expected],cwd=candidate,stdout=out,check=True,timeout=60)
with tarfile.open(archive) as contents:
    contents.extractall(source,filter='data')
archive_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.unlink()
tmp = scratch/'tmp'; tmp.mkdir(mode=0o700)
probe = subprocess.run(['git','rev-parse','--show-toplevel'],cwd=tmp,text=True,capture_output=True,timeout=10)
assert probe.returncode == 128
keep = ['HOME','USER','LANG','LC_ALL','PATH','HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','NO_PROXY','http_proxy','https_proxy','all_proxy','no_proxy','DOCKER_HOST','DOCKER_CONTEXT','SSH_AUTH_SOCK']
env = {key:os.environ[key] for key in keep if key in os.environ}
base = completion.parent
corrected = Path('/home/pall/projects/liqvera/.worktrees/wave1-deploy/.venv')
env.update(SSL_CERT_FILE=str(corrected/'lib/python3.12/site-packages/pip/_vendor/certifi/cacert.pem'),SSL_CERT_DIR=str(base/'tls-fix/empty-ca'),NODE_OPTIONS='--use-openssl-ca',PYTHONHTTPSVERIFY='1',GETZILLA_NO_VENV='1',GETZILLA_OSV_DB='',GETZILLA_OSV_ONLINE='1',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmp),UV_PYTHON=sys.executable,UV_PYTHON_DOWNLOADS='never')
env['PATH']=str(Path(sys.executable).parent)+os.pathsep+env['PATH']
os.environ.clear();os.environ.update(env)
tempfile.tempdir = None
sys.dont_write_bytecode = True
sys.path.insert(0,str(source/'.getzilla'))
from getzilla import python_test_runner as runner
files = ['tests/test_policy_hardening.py','tests/_support.py','.getzilla/getzilla/_policy_legacy.py','.getzilla/getzilla/policy.py','.getzilla/getzilla/shell_targets.py','.getzilla/getzilla/python_test_runner.py','.coveragerc']
meta = {'purpose':'NON-QUALIFYING bounded read-only diagnosis','candidate':expected,'tree':git('rev-parse','HEAD^{tree}'),'candidate_status_before':git('status','--porcelain'),'scratch':str(scratch),'source':str(source),'source_archive_sha256':archive_sha,'cpu_affinity':sorted(os.sched_getaffinity(0)),'temporary_directory':str(tmp),'temporary_directory_git_exit':probe.returncode,'interpreter':sys.executable,'python':sys.version.split()[0],'base_executable':sys._base_executable,'versions':{key:importlib.metadata.version(key) for key in runner.PINS},'environment_names':sorted(env),'source_sha256':{file:hashlib.sha256((source/file).read_bytes()).hexdigest() for file in files},'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controls':[]}

def save():
    prefix.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')
    os.chmod(prefix.with_suffix('.json'),0o600)

def retain(label, result, start):
    for stream in ('stdout','stderr'):
        path=Path(str(prefix)+'-'+label+'.'+stream)
        path.write_text(getattr(result,stream));os.chmod(path,0o600)
    item=dataclasses.asdict(result)
    item.pop('stdout');item.pop('stderr')
    item.update(label=label,start_monotonic=start,end_monotonic=time.monotonic(),stdout_sha256=hashlib.sha256(result.stdout.encode()).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr.encode()).hexdigest())
    meta['controls'].append(item);save()
    print(json.dumps({k:item[k] for k in ('label','returncode','seconds','terminal_state','cleanup_error')}),flush=True)

save()
name='tests.test_policy_hardening.Review2PosixTests.test_secret_scan_is_bounded_and_fails_closed_on_a_huge_argv'
start=time.monotonic()
retain('named',runner.run_named_tests(source,[name],budget=60),start)
coverage_dir=scratch/'coverage';coverage_dir.mkdir(mode=0o700)
command=runner._pytest_command(1,'worksteal')+['-p','pytest_cov.plugin','--cov',f'--cov-config={source / ".coveragerc"}','--cov-report=term','tests/test_policy_hardening.py::Review2PosixTests::test_secret_scan_is_bounded_and_fails_closed_on_a_huge_argv']
start=time.monotonic()
retain('coverage-one',runner.execute(command,source,runner._environment(source,coverage_dir/'.coverage'),timeout=90),start)
meta.update(candidate_status_after=git('status','--porcelain'),candidate_head_after=git('rev-parse','HEAD'),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
save()
print('DIAGNOSTIC_COMPLETE',str(prefix.with_suffix('.json')),flush=True)
