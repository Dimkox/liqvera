# Getzilla final-2: bounded Core timing diagnosis

Candidate `45be42f74b5a8ee6f079f8ac55206e475936fdc6`, tree `bcdd090531e657ee1d3cd20c340205df86fc8900`, route `d834158878e0`. Read-only, non-qualifying diagnosis. No source, assertion, timeout, coverage threshold, receipt, ref or production change.

Getzilla final-2 remains **FAIL**. Isolated reproduction identifies a covered wall-clock failure; the guard correctly denies access. Do not claim full Getzilla qualification or publication. Liqvera's own final-2 PASS is a separate result.

## Original evidence

The full Getzilla invocation exited 1 after 1225.840 seconds. Core took 529.683 seconds: one failed parent, 2,277 passed, 17 skipped, 3,961 passed subtests. The failed parent is `tests.test_policy_hardening.Review2PosixTests.test_secret_scan_is_bounded_and_fails_closed_on_a_huge_argv`. Coverage reached 81.72%, above the unchanged 74% minimum, but correctly failed because the test run failed. Architecture, specification, static checks, OSV, Factory unit and disposable PostgreSQL exit checks passed.

The original traceback is unavailable. The runner captures output in `TemporaryFile`, closes it on return, and returns text in memory; the verifier stores only the last 12,000 characters. The long coverage table displaced the traceback. Gate stderr is empty. No retained raw Core trace was found in the invocation directory or temporary-root top level. New traces supplement the original FAIL; they do not replace it.

## Four unchanged controls

Exact tracked 45be source was archived into private, trusted, non-Git scratch `/home/pall/.gz-core-2knnvjlm`. Controls use the dedicated gate Python 3.12.3, base `/usr/bin/python3.12`, original runner helpers, CPU affinity 0–7 and one pytest worker. The synthetic command is only policy input; it is never executed. No real secret or private grant was read.

| Control | Result | Raw-log suffix |
| --- | --- | --- |
| Original named unittest runner, no coverage | PASS; test 4.389s | `-named.stdout/.stderr` |
| Original pytest builder with unchanged branch coverage | Denial passes; elapsed 8.487197s fails the 8.0s assertion | `-coverage-one.stdout/.stderr` |
| Matched pytest without coverage | PASS; test call 4.06s | `-pytest-one-unmeasured.stdout/.stderr` |
| Matched covered confirmation | Denial passes; elapsed 8.320582s fails the same assertion | `-coverage-confirm.stdout/.stderr` |

All filenames start with `getzilla-gate-second-diagnosis`. Both covered selections separately fail the unchanged aggregate coverage minimum at 4.58%, as expected when running only one test. The full assertion traces independently show the timing failure. These selected runs are not qualifying coverage. Tool pins match the original: pytest 9.1.1, xdist 3.8.0, pytest-cov 7.1.0, coverage 7.15.4.

The failure reproduces without the original 16-worker suite. Original host load was not recorded; no retrospective claim is made. Simply lowering workers or declaring a host-load flake is unsupported.

## Cause

The test times the entire `evaluate_pre_tool` call. Its 20,000 ordinary operands and final sensitive path fit below the existing 131,072-character cap. Control-plane, hardlink and destructive-command parsing happen before `shell_secret_reference` starts its three-second scan budget. That budget does not include the earlier parsing.

One separate timing observation had already started before the coordinator's stop instruction and completed when it arrived. Private function wrappers recorded timings; the test, assertions, coverage and candidate remained unchanged. Preserve it separately from the four unchanged controls:

| Phase | Wall seconds | CPU seconds |
| --- | ---: | ---: |
| Control-plane parsing | 2.625 | 2.623 |
| Hardlink parsing | 1.120 | 1.119 |
| Destructive-command parsing | 1.463 | 1.462 |
| Secret scan | 3.002 | 2.999 |
| Whole evaluation | 8.211 | 8.204 |

The guard returned false with its existing scan-budget marker. The assertion failed at 8.210629s. Near-equal CPU and wall time shows computation, rather than scheduler starvation, in this isolated observation. Three nested `_simple_commands` calls took about 1.11–1.14s each; do not add those again to the phase totals. The scan respects its own limit; covered parsing before it consumes about 5.21s.

The target test, policy, shell parser, runner, coverage configuration and pinned test tools are unchanged from original base `e158ddc7263a55f5308944c5a426eb1e9f1a4327`. Fixture support only adds path resolution before fixture creation, outside the measured call; that exact diff is retained. The evidence shows an existing covered timing limitation, not a secret-read allowance introduced by Liqvera dispositions.

## Liqvera reporting boundary

Stop here. Preserve Getzilla final-2 as FAIL. No new repair or full tool run belongs to this Liqvera diagnosis. Report Liqvera's exact-source native final-2 PASS separately; its six receipts, as recorded by the coordinator, were not changed or reissued here. Disclose the tool self-test limitation when discussing tool qualification. Make no claim of full Getzilla qualification, publication, or new production/deployment acceptance.

All controls completed with original runner cleanup and no cleanup error. No process remains in the owned scratch. Candidate HEAD/tree and clean status remain unchanged, as do the controlled snapshot source hashes. The JSON companion retains complete commands, monotonic timings, hashes, original failure binding, phase-plugin binding and the separate Liqvera native report binding. All failures and raw logs remain preserved.
