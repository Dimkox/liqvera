# Design

Use target-owned engineering/verification-dispositions.json, outside installer-managed directories. A small shared validator/matcher serves secret-scan and git-diff-check. Bind exact check/rule/path, whole-file SHA-256, occurrence or diagnostic position, reason and review-evidence path/hash. Enumerate every secret match. Public-token eligibility requires the exact token assignment and 0x plus 40 hex digits; private-key, AWS, API-key/password/secret assignments never qualify. Hash the actual target Git layer for whitespace. Validate every entry, even when untouched; invalid input fails closed. Keep raw findings and command exits, expose disposition metadata and unresolved totals. Never waive arbitrary Git errors.

## Full-gate repairs

Retain eager queue inspection and all finite budgets; size only dependency module/depth budgets to measured source closure. Resolve hook libraries from the invoking installation first. Align generated inventory with existing dependency pins. Execution uses a trusted non-Git temporary root and an explicit supported uv interpreter. No runtime database, payment, timeout or external-authority change. See evidence/first-gate-repair.md and the full independent diagnosis records.
