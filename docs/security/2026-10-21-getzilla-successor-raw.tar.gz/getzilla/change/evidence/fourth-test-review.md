REQUEST_CHANGES. The repaired queue and inventory controls pass, and the original five hook failures are closed. The hook regression still omits loss of the owning package or its initializer; the independent security review confirms that these cases silently accept foreign policy. Final qualifying gate: NOT_RUN.

Route `d834158878e0`. Candidate `/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final`. Original comparison base `e158ddc7263a55f5308944c5a426eb1e9f1a4327`; secondary integrated main `f9f02dd53ba9f6e69d51ae5322df0c96e3d41b02`. Both remain ancestors. Reviewed both complete changed-path inventories and the source/test deltas, including upstream integration, disposition integration, queue limits, hook bootstrap, installation/packaging and the wheel inventory. Published tags v2.2.0, v2.2.1 and v2.3.0 remain ancestors. The isolated candidate has one worktree; no cleanup occurred.

Before and after identities are identical:

- HEAD: `b1ff3de3eb952521cacaa1119c88d2d6990c0545`.
- Git tree: `88a830f5a18631cdfef4cf35b4866f466b06264c`.
- Actual tracked-byte/mode manifest SHA-256: `75be0e6132dc1bc83f020eb058f9b96831e350c5beff1546d9cc0bb0fe717fb6`.
- Git status, including untracked files: empty.
- reviewed-tree-modified: no

Private scratch `/home/pall/.cache/gzr4tr`, mode 0700, contains the exact snapshot at `src` and short non-Git TMPDIR at `t`. All ancestors were checked for trusted ownership, symlinks, sticky bits and group/other write access. This location follows the coordinator's explicit non-Git isolation instruction after the earlier nested-repository failures. Durable probes and outputs remain under canonical `completion/getzilla-r4-test-review/`. The snapshot reproduces all 5,512 tracked entries, 53,620,038 checkout bytes, symlinks and modes, including checkout line endings. Every candidate and snapshot byte/mode binding was rechecked after restoring all mutations; no extra snapshot files remain. See `before.json`, `source-manifest.json`, `scratch-safety.json`, `after.json` and `restoration.json`.

Finding:

- **Medium, blocking; same issue as SR-GZ-R4-01.** `tests/test_hook_degraded.py:31` checks broken local `policy.py` and `fsx.py`, but does not cover missing local `getzilla/__init__.py` or the entire local package. The matching R4 security report independently reproduces foreign-library fallback, protected-action allowance and absent degradation events for those cases. I read that report; I did not duplicate its probes. Extend the competing-installation regression to both package-loss cases and require local ownership or degraded refusal. Preserve ordinary read access and the existing assertions. Source repair belongs to the sole implementation owner.

Fresh reviewer execution used Python 3.12.3 at `/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python`, CPUs 4–7, four native pytest/xdist workers, disabled bytecode/cache writes, and the frozen runner's `_environment` and `_pytest_command`. Coverage was omitted for this explicit subset; no test assertion, source timeout or gate selection was changed.

| Baseline scope | Observed result |
| --- | --- |
| Six queue cases: measured closure, exact/overflow boundaries, cycle at depth limit, possible-operation exhaustion, dependency chains and cached-module charging | Included in 12 passed, 47 passing subtests, 18.63 s |
| New competing-installation hook regression and all five previously failing hook/enforcement parents | Included in the same 12 passed, 47 passing subtests |
| Exact committed wheel inventory derived from `factory/uv.lock` | 1 passed, 1.69 s; zero skips |

Exact entry commands, from `/home/pall/projects/liqvera`:

```sh
env PYTHONDONTWRITEBYTECODE=1 taskset -c 4-7 .getzilla/runtime/completion/getzilla-gate-venv/bin/python -B .getzilla/runtime/completion/getzilla-r4-test-review/run_probes.py baseline
env PYTHONDONTWRITEBYTECODE=1 taskset -c 4-7 .getzilla/runtime/completion/getzilla-gate-venv/bin/python -B .getzilla/runtime/completion/getzilla-r4-test-review/run_probes.py mutants
```

The driver, each expanded native argv/environment/cwd, source edits and hashes, and full unsliced stdout/stderr are retained in the probe directory. Baseline and mutation result JSON files contain native exits and durations. Mutation probes ran sequentially and changed only private snapshot bytes.

| Mutant | Selected native oracle | Outcome |
| --- | --- | --- |
| M1: replace `_local_queue_resolution`'s `len(visited) >= MAX_QUEUE_ADAPTER_MODULES` guard with `False` | Exact-boundary test | Survived: 1 parent and 3 subtests passed |
| M2: remove `len(resolving) >= MAX_QUEUE_ADAPTER_DEPTH` guard | Exact-boundary and cycle-at-limit tests | Killed: two expected assertion failures; no test errors |
| M3: change the M1 guard from `>=` to `>` | Exact-boundary test | Survived: 1 parent and 3 subtests passed |
| M4: restore the old conditional own-stack insertion | New competing-installation regression | Killed: four failed subtests; protected decisions/events expose the regression |
| M5: restore only the old certifi wheel row | Exact inventory derivation | Killed: `WHEEL_INVENTORY_DRIFT` |
| M6: restore only the old lock SHA-256 binding | Exact inventory derivation | Killed: `WHEEL_INVENTORY_DRIFT` |

The two survivors do **not** establish missing module-boundary coverage or a production bypass. They change only the per-module guard at `architecture_fitness.py:2185`. The separate `_prime_local_module_sources` guard at line 2145 remains: it rejects `len(pending) > remaining`, and callers supply `MAX_QUEUE_ADAPTER_MODULES - len(seen)`. It therefore retains enforcement of the same capacity, including negative remaining capacity, and can mask either single-guard mutation in the 65-module fixture. The exact throwing guard was not instrumented. The writer's retained broader `MAX_QUEUE_ADAPTER_MODULES` mutation does fail that fixture; its byte-exact log is separately bound in `historical-budget-mutation-binding.json`. These observations are consistent. Guard-specific sensitivity remains unadjudicated; no blanket mutation-score threshold or additional queue blocker is inferred. Four mutants were killed, two survived, and none had an inconclusive execution.

Historical evidence remains historical. `third-test-review.md` binds R3's 29 native tests, 26 independent cases and seven killed mutants to its earlier source. The disposition implementation, verifier integration, disposition tests and reference documentation are blob-identical between `4cf2abf` and R4, as recorded in `historical-bindings.json`; I did not rerun those suites here. The coordinator's six passing exact-R4 controls are separately SHA-bound in `coordinator-controls-binding.json`, not counted as this reviewer's execution. Earlier failed gates and reviews remain retained.

Limits: after the coordinator confirmed the package-ownership blocker, further selection stopped. The prepared eight-case `queue_probe.py` was not executed; its claims are NOT_RUN. No combined module-guard removal, broader mutation campaign, full suite, qualifying gate, receipts, cross-platform installation, physical wheel download/hash verification, PostgreSQL run or PDF test run occurred here. The five existing PDF skips and excluded incompatible prototype `0350dcc781640c896092566ecd4dc05801f16851` remain disclosed. The pre-existing import-effect analysis gap is not repaired or certified by capacity tuning. The supplemental all-tracked scan's seven baseline heuristic findings remain unresolved; the passing native changed-file scan does not clear them. No private grants, live payments, deployments, publication or external mutation were accessed or performed.
