# R5 independent release review

Verdict: PASS for release scope, with one low documentation clarification. No new blocker. Fresh focused tests pass for the reported R4 missing-package defect and cached foreign packages. Security reviewers own their independent reassessment of SR-GZ-R4-01. This report is not aggregate readiness, a qualifying gate or external CI acceptance.

Candidate: `/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final`; route `d834158878e0`; package `20261021-task-d83415`. Before and after HEAD `3968ae4445836eda9cf377035b1d1f64fe9659b0`, tree `5e0c8153899219b238a3ff63f064665eb28f41ca`, complete Git status empty. Original base stays `e158ddc7263a55f5308944c5a426eb1e9f1a4327`; independent `origin/main` and merge-base stay `f9f02dd53ba9f6e69d51ae5322df0c96e3d41b02`. No refs were fetched or changed.

reviewed-tree-modified: no

## Finding

Low: `rollback.md` correctly distinguishes source implementation from metadata freezes, but names isolated predecessor commits for queue capacity and hook precedence. `c517a2aa5e20d024405a72c00fd1138815760bba` and `013ff3b8c7dd035132e68c888c5e0c43dbd73a3b` are not candidate ancestors. The integrated equivalents are `4c47e7ca5cf40ed6bc3f91aa24532ad457e19cdd` and `de0ed1d9f98b21d2636deb977f0eef403529d23a`. Stable patch IDs match for each pair. Document these integrated pins so a clone containing the delivered branch can resolve rollback inputs without isolated-worktree objects. Nonblocking follow-up under the repository's low-severity rule; no candidate edit was made.

## Reviewed scope and preservation

- Inspected the actual R4-to-R5 diff. Only `.grok/hooks/_lib.py` and `tests/test_hook_degraded.py` change executable behavior; other changes retain reports/repair evidence, state and rollback guidance. The hook requires its own non-symlink initializer before import, then checks package origin and search path before loading helpers. Existing fallback behavior records degradation, permits reads and denies protected classifications. No classified fixture command is executed and no duplicate external write is introduced.
- Fresh in-memory installer payload construction includes the repaired hook with exact bytes and the local package initializer. Fresh manifest selection includes the hook. Payload: 698 entries; manifest: 5,515 files. Neither includes an active consumer disposition policy. No installation or archive publication occurred.
- All four `fourth-*-review.md` files match binding hashes and byte counts. The release copy also equals this reviewer's original R4 report. REQUEST_CHANGES and SR-GZ-R4-01 remain preserved. All ten writer evidence payload hashes and both source hashes match `getzilla-hook-ownership-handoff.json`. This verifies integrity, not fresh execution of the writer's 74-test or mutation observations.
- First failed full-gate evidence, third-wave reports, disposition/report-consumer code, Factory/API/PDF bytes, published packages and CI remain unchanged from R4. Prior whole-diff, wheel-inventory and capacity observations in `fourth-release-review.md` are historical evidence bound to R4 `b1ff3de3eb952521cacaa1119c88d2d6990c0545` / `88a830f5a18631cdfef4cf35b4866f466b06264c`. No inventory/download/API/PDF checks were repeated. Five inherited PDF skips, the baseline import-effect gap and seven supplementary heuristic matches remain disclosed and unresolved.

## Fresh bounded checks

Private scratch: `/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-r5-release-review`, mode 0700. Exact `git archive HEAD` SHA-256: `83bfe36bcfe79aafd1926b5a7b6a79d296cab9f8e8c8ffdfdad6a422c9b3c83f`. Requested short temporary root `/home/pall/.cache/gz-r5-rel` is 0700; ancestry is free of symlinks, sticky or group/other-writable directories. Git discovery there exits 128.

From `scratch/snapshot`, interpreter `/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python`, CPUs 12–15, three workers:

```text
python -B -m pytest -c /dev/null -p xdist.plugin -p no:cacheprovider --import-mode=prepend --rootdir=. -o python_files=test*.py -q -n 3 --dist=worksteal --max-worker-restart=0 --durations=20 -ra <three nodes>
```

Nodes in `tests/test_hook_degraded.py::HookDegradedTests`:

- `test_missing_own_package_never_falls_back_to_foreign_pythonpath`
- `test_cached_foreign_package_cannot_supply_hook_policy`
- `test_own_stack_precedes_foreign_pythonpath_when_local_imports_break`

Observed exit 0: three tests and fourteen subtests passed in 11.34 seconds. Competing foreign paths remained present. Bytecode writes, interpreter downloads and pytest plugin autoload were disabled; UV_PYTHON was explicit. `bounded.json` records expanded argv, cwd and environment; complete output is in `bounded.stdout`/`bounded.stderr`. `preservation-packaging.json` retains hash checks and results from `getzilla.manifest.included_files` and `install_into.build_payload`. Identity, path-safety and `delivery-bindings.json` records retain the remaining probes, including the ancestry exit 1 that identified the low finding.

## Delivery boundary

Rollback remains a separately verified source/tool-pin PR, omission of consumer dispositions for the pre-change tool and a fresh consumer acceptance binding. Database/payment state, live services and immutable evidence remain separate. The updated note correctly binds PR #124 separately from the follow-up repairs.

The coordinator's exact-head six native bounded controls all record PASS; they are not verification receipts. After all selected reviews complete, persist reports, freeze the report-only successor, run the full native gate and observe required external checks on the exact PR head. Current CI includes Linux, Windows and macOS. Full gate and exact-head external CI remain NOT_RUN.

No full suite, coverage run, mutation probe, cross-platform execution, download, live action, private-state read, grant, receipt, push or release was performed. Historical evidence is reused only with its original source identity and limits.
