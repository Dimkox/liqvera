# Rollback

This is source/tool-pin rollback only. The disposition implementation was delivered by PR #124, merge `a103b373031f477efad0e7bd9ffab24a96e6c63f`. Its pre-change tool pin is `e158ddc7263a55f5308944c5a426eb1e9f1a4327`; omit the consumer-owned disposition file when selecting that pin, restoring the prior strict findings. Preserve all historical evidence and reports.

The follow-up source changes are queue capacities `c517a2aa5e20d024405a72c00fd1138815760bba`, hook precedence `013ff3b8c7dd035132e68c888c5e0c43dbd73a3b`, wheel inventory `9da43eb1e808aeafa3dbba18104ce1cfe9ba6440` and package ownership `9e8b444400066a82fe252da48c46237292f5c811`. A source revert must target these implementation commits through a separately verified PR, newest first, rather than reverting a report or metadata freeze. The final audit binds the delivered tool commit explicitly; changing that pin invalidates its acceptance evidence and requires fresh verification.

No database migration, payment-state change, live service rollback or historical evidence rewrite is part of this tooling rollback. Liqvera's already retained production rollback remains separate.
