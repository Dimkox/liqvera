# Architecture and authority

The web, gateway, capture and report/verifier remain one Liqvera product. The only new executable delta after merged main is a regression test that binds the development pip pin to the audited lock. Optional engineering/verification-dispositions.json does not participate in application execution.

Getzilla reads exact normalized paths, whole-file and occurrence hashes plus an evidence-file hash. It must preserve raw severity and findings and expose separately the effective classification. No whole-file secret waiver or generic command-error override is allowed. The target policy is versioned outside installer-managed .getzilla state. The reviewed successor tool commit will be bound before freeze.

The original Wave 1 report stays immutable. Payment guards, PostgreSQL identities, SQL migrations, WalletConnect configuration and sealed report/ZIP evidence retain their existing contracts. No data migration or external-write plan exists for this read-only task.
