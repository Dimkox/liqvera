# Liqvera successor architecture analysis — 2026-10-21

The committed changes preserve Liqvera's application architecture. The dispositions are narrow optional audit policy; the pip correction repairs development-install metadata. Neither changes payment authority, service topology or historical evidence. No architectural blocker is identified in these committed changes. This is a static analysis, not a passing security review or final gate.

## Source boundary

Product commit: `17a70595e98aa183afac115e5b99488830fba712`; tree: `b4a0a202b2002245113fd48db3f9fc73f67ebc49`. Repository: `/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit`. Active route: `ec1239ea42dd`; change: `20261021-task-ec1239`.

Observed main and merge-base with `origin/main`: `3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd`. Original Wave 1 comparison base remains `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`; it is an ancestor. Tags `v0.0.1` through `v0.0.5` are ancestors. The full comparison contains 59 changed files, including funding UI, TLS recipes, dependency changes and evidence. Do not replace that scope with the five-file post-merge correction.

The coordinator is preparing an untracked `engineering/changes/` package concurrently. Before/after inspection retained the same product HEAD/tree and that untracked package. This analysis binds to the committed product, not the unfinished package or a future report-containing freeze. No candidate files were edited. `reviewed-tree-modified: no`.

## Exact dispositions

`engineering/verification-dispositions.json` has schema version 1 and exactly three entries. Its SHA-256 is `e0395a8b681958936fa97f552f517d77cecb49744eb33b902a3ee5c6569ef141`. All target-file and explanatory-evidence hashes matched the inspected files.

| Entry | Exact scope |
|---|---|
| `liqvera-public-testnet-musd-1` | `apps/mezo-web/test/mezo-finance.test.mjs`, line 10, column 7; one generic-secret token assignment; file hash `61c64095503eaca71d387d610c118d25f3ea2c8f7a8dd1c11f045d5fde34e3e2`; exact-match hash also recorded. |
| `liqvera-public-testnet-musd-2` | `docs/competition/2026-10-21-funding/dom-smoke.mjs`, line 9, column 73; one generic-secret token assignment; file hash `4a99ffe47e5620a97fb1ef567b43918ea4d79b89d33208c4ff1b961a69d55325`; exact-match hash also recorded. |
| `liqvera-immutable-wave1-blank-eof` | `docs/security/2026-10-21-wave1-deployment.md`, line 51; only `new-blank-line-at-eof`; file hash `2fc820a62bd6c8d453256d856f923ee2bdf812875c24fab684265883022335ba`. |

All entries bind `docs/security/2026-10-21-verification-dispositions.md`, SHA-256 `d2a11a5029a4fe3b8a05201ba3ed9cc58e55ee32dc79a4e95d442bc5885b15c1`. The two visible literals equal the public Testnet MUSD identifier in `packages/mezo-protocol/src/index.ts`; its recorded hash `28a5c0a9143a803bbd836ab59b3aad31cd225bb6459eb97778a256aada88489b` also matches. They identify a token contract in tests, with no signing material or grant authority. This source comparison is not a new on-chain observation.

The policy does not exempt either whole JavaScript file, other token occurrences, password/API-key assignments, private keys or AWS findings. The whitespace entry does not normalize or rewrite historical Markdown, ignore other diagnostics or shorten Git ranges. The explanation expressly preserves the original negative audit.

These hashes prove byte identity, not benign intent or an independent approval. The manifest changes verification behavior and must receive independent security/code review as policy, despite being optional to the product. Its decoder and classifier belong to the separately reviewed external Getzilla successor. Pin that tool's final committed identity in the fresh gate; an uncommitted implementation or old PR #115 result cannot qualify it.

Required classifier guarantees remain: strict schema/path/type/duplicate validation; stale and missing entries fail; per-match classification; target-layer hashes for index/worktree/range checks; preservation of original rule/severity and Git command/output/exit status; visible informational disposition evidence; and hard failure for every unrelated secret, Git execution error, incomplete diagnostic or source change. The explanation alone demonstrates none of those executable guarantees.

## Pip correction and runtime boundary

Commit `db29710` changes `pyproject.toml`'s development extra from pip 26.2.1 to 26.2.2, preserving the incoming Ruff 0.17.1 update. It adds `test_development_install_preserves_the_audited_pip_bootstrap` in `tests/test_tls_trust_guard.py`. The current development lock, CI checksum-bound bootstrap and both Python wheel-building recipes already specify pip 26.2.2. This closes the metadata path that could otherwise reinstall the older pip after bootstrap.

The new test checks agreement between the extra and audited lock. It does not independently prove that the lock's chosen version is secure or exercise an actual pip install. Effective trust probes and fresh dependency evidence remain separate requirements. The handoff reports five passing trust/metadata checks; this analyst did not rerun them.

Compared with merged main, only `pyproject.toml`, that regression, the disposition manifest/explanation and handoff changed. Browser/gateway logic, Python services/packages, protocol, schemas, SQL migrations, Dockerfiles, Compose, entrypoints and artifacts have no post-merge delta. No deployment is required by the audit manifest. Production image/TLS acceptance remains bound to its prior exact images and rollout records, not automatically to this new source SHA.

## Preserved architecture and fresh evidence

`docs/architecture.md` and `docs/specification.md` remain the product authority: one TypeScript browser/gateway, Python capture/exact calculation/report/verifier, durable PostgreSQL payment state and immutable capture/artifact volumes. Funding observations remain advisory reads tied to provider, payer, network/token, quote freshness and a clear payment guard. Connecting or refreshing a wallet cannot authorize payment. Preserve exact arithmetic, artifact hashes and offline verification.

Merchant payment still requires fresh wallet signatures and durable nonce uniqueness. The gateway must enter SUBMITTING atomically before settlement; unknown outcomes remain confirm-only. Delivery requires canonical receipts and at least twelve confirmations. Existing MANUAL_REVIEW states, grants, migration bytes, published bundles and historical acceptance limits remain intact. An external audit framework acquires no runtime or operational authority.

The fresh gate must cover the original full comparison and identify the product, final frozen candidate, tool commit, disposition digest, comparison base and raw outputs. Native nested Node builds/tests, both browser networks, Python/artifact/contract checks, disposable-PostgreSQL cases and effective TLS/dependency evidence remain necessary. The historic Getzilla root-package discovery gap and zero-contract checks must not be mistaken for native application coverage. Optional architecture-model absence is a disclosed non-applicable check, not a fabricated PASS.

Persist the route-selected independent reports before freeze, then run the qualifying successor gate and record fresh receipts with zero gaps. Retain the three raw findings with their original severities and precise dispositions. Preserve every old failure, archive and review under its original source identity. A fresh exit-zero result can qualify only the successor; it cannot override the earlier negative outcome or establish new live wallet, borrowing or paid-delivery acceptance.

This task performed source reads, Git metadata/diff inspection and SHA-256 inspection only. No application tests, external verifier, image builds, live requests, database operations, private-state reads or deployments were performed. The report is saved outside the candidate for coordinator incorporation before independent review and freeze.
