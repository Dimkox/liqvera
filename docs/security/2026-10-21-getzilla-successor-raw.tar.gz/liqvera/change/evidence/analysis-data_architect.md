# Liqvera data analysis — completion audit, 2026-10-21

No payment, SQL or sealed-evidence invariant changes are introduced by the current pip metadata guard and optional exact dispositions. No migration, backfill, production database test, new payment, redeployment or rewrite of historical evidence is needed to assess this change.

## Identity and observed scope

- Product SHA: `17a70595e98aa183afac115e5b99488830fba712`.
- Product tree: `b4a0a202b2002245113fd48db3f9fc73f67ebc49`.
- Full original Wave 1 base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`.
- Route: `ec1239ea42dd`.
- Examined clone: `/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit`.
- `reviewed-tree-modified: no`.

Read AGENTS, README, architecture and handoff; inspected Git status/history, ancestry, worktrees, the full comparison inventory and the postmerge diff. The full comparison contains 59 changed paths. There are no changes under gateway application code, packages, services, schemas, migrations, browser historical-preview assets or Compose configuration. The base, origin/main and v0.0.5 are ancestors of the product. The coordinator's untracked `engineering/changes/` package was present during analysis; this report binds the committed product SHA rather than claiming a frozen clean working tree.

Relative to merged PR #14 at `3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd`, the executable correction restores the development extra to pip 26.2.2 and adds a test requiring equality with the audited lock. The Ruff update remains. The other additions are exact audit dispositions and explanatory/handoff documentation. No Docker recipe, runtime lock, calculation, payment adapter or database interface changes after deployed source `1c020995adaa1a80fc8a97888aa838041d8e01d5` were found.

## Preserved invariants

All source references below are relative to the product SHA above.

| Invariant | Source |
| --- | --- |
| Scoped request idempotency, immutable quote/artifact identities, and digest-bound receipt/entitlement foreign keys. | `apps/mezo-gateway/migrations/001_ledger.sql:6`, `:18`, `:29`, `:67`; `002_fix_immutable_ledger_identity.sql:3` |
| Unique authorization identity, at most one non-rejected attempt per quote, and merchant nonce reservation across quotes and unknown outcomes. | `apps/mezo-gateway/migrations/001_ledger.sql:45`; `008_merchant_nonce.sql:1` |
| Durable SUBMITTING/authority reservation before the sole settlement call; recovery confirms existing attempts without resubmission. | `apps/mezo-gateway/src/adapters/postgres.ts:147`; `src/application/gateway.ts:100`; `src/workers/reconciliation.ts:4` |
| Atomic chain event, receipt, entitlement and confirmed state; current finality and artifact integrity required for delivery. | `apps/mezo-gateway/src/adapters/postgres.ts:220`; `src/application/gateway.ts:125`; `migrations/005_receipt_confirmation_count.sql:8` |
| Immutable network identity and paired chain/network/asset; preservation of unknown/manual-review outcomes, deduplication and consumed authority. | `apps/mezo-gateway/migrations/007_network_identity.sql:1`; `src/workers/retention.ts:3`; `docs/migration.md:7` |
| Funding observations remain read-only, use exact integer-string amounts and are bound to account/network/quote/canonical block/freshness. Non-clear payment guards remain blocked. | `apps/mezo-web/src/mezo-finance.mjs`; `mezo-finance-panel.ts` |

Fresh local SHA-256 comparisons found all eight SQL migrations identical to their hashes in `docs/security/2026-10-21-tls-deployment.json`. No migration or index work follows from this audit. Existing nonempty legacy receipts must still cause migrations 004/005 to stop rather than fabricate provenance. The real PostgreSQL suite's empty-receipt upgrade case does not establish compatibility with populated older receipt schemas.

Report provenance remains version-bound: `packages/evidence-report/src/liqvera_evidence_report/service.py:87` loads LIQVERA_ENGINE_COMMIT for new reports, while existing report IDs use read_published at line 189. `evidence_bundle.py:162` reconstructs with the bundle's own embedded commit. Production's recorded engine identity remains 1c02099; this metadata-only correction does not relabel it to 17a7059. Preserve old bundle bytes, report/ZIP digests, receipt bindings, runtime calculation manifests and matching verifier evidence. Do not treat engine provenance as grant renewal or alter source-bound authority settings.

## Historical results that may be cited

The strongest existing record is `docs/security/2026-10-21-tls-deployment.md`, with its JSON and raw archive, explicitly bound to application source 1c02099. It can be referenced without repeating unchanged live actions, provided the report says "recorded on 2026-10-21 for source 1c02099" and retains these limits:

| Recorded result | Accurate scope and limit |
| --- | --- |
| 71 gateway tests, including 13 real PostgreSQL cases, zero skips. | Disposable isolated database validation, not production-ledger testing or fresh execution at 17a7059. Source: deployment record lines 27–30 and JSON verification. |
| 955 Python tests plus 85 subtests, 104 web tests, both network builds and six image builds. | Historical complete validation. The new metadata regression and current final gate need their own result; these counts must not be relabelled as the current run. |
| Exact report image reproduced the historical evidence ZIP with execution authority NONE. | Report image `sha256:f938d4f3483af7453944ad98de648f9b7a1f6ac4ad3399434069194245d58901`; historical-byte compatibility, not live payment or exchange authentication. |
| Gateway/image trust checks and exact-image scans: 30 retained, reviewed scanner occurrences and zero untriaged findings. | Bound to recorded image IDs and advisory data; no claim of a fresh vulnerability scan or patched nginx/curl versions. Gateway/carrier image: `sha256:a341fae9c0c8a1feade5b11493b58dbeb1a4f22cad5e5b79ef4602dd5b7db901`. |
| Same live PostgreSQL container, no migrations, three CONFIRMED/one MANUAL_REVIEW attempts, four receipts and four entitlements before/after rollout. | A historical comparison, not today's observed ledger. Retained live image `sha256:ac94c2b07e35f5f12172a07ba198a7bcd221a90d149122bc9900771d467733ec` is distinct from the corrected test-only image `sha256:98e5cab850b96ff1acfaca92834c8590274e62ba9f64b6d882d27ec7f6e090d8`. |
| Coherent backup restored into a disposable internal-network database and reproduced ledger summaries/migration hashes. | Historical recovery evidence with owned container/network removed; do not reread private dumps or restore them over newer payment state for this audit. |
| Public GET-only browser/layout, QR/relay and immutable preview checks. | Historical public behavior only; no physical wallet pairing, new funding observation, loan or paid delivery. |

Sources for preservation and recovery are deployment-record lines 45–61. Earlier Wave 1 and layout records remain valid evidence for their own browser/source generations; they must not be presented as the current deployed image. Normal gateway startup and workers may write legitimate state, so "no payment or migration" does not mean "no database statement ever ran."

The old Getzilla PR #115 gate remains negative: JSON records raw_exit_code 1, zero_gap_complete false and no passing final receipt. Neither the passing TLS security review nor these new dispositions retroactively changes that result. Successor review/gate evidence must be generated and bound independently.

## Exact dispositions and immutable evidence

The optional `engineering/verification-dispositions.json` classifies only two public Testnet MUSD contract occurrences and one final blank line in historical Markdown. These are audit classifications, not payment credentials or runtime configuration. The canonical protocol file hash matches `28a5c0a9143a803bbd836ab59b3aad31cd225bb6459eb97778a256aada88489b`. All three complete target-file hashes and their explanatory-document hashes match the policy. Exact detector occurrence handling and rejection of stale/unsupported entries remain the successor security review/final gate's responsibility; this static analysis does not assert that the external tool passed.

The historical Wave 1 Markdown remains byte-identical with SHA-256 `2fc820a62bd6c8d453256d856f923ee2bdf812875c24fab684265883022335ba`, including its final blank line. The Wave 1, layout, initial-negative-audit and TLS archives, plus examined deployment JSON/Markdown, are unchanged since merged PR #14. The TLS archive hash still equals `625cd5f517b19b80073530f9ffdba2bfab71f0461050d68d0051be57d0dc8b89`; its record reports 354 previously verified payloads. This analysis rechecked archive identity, not every payload or historical test execution.

No tests, SQL, network/live calls, private-material reads or candidate edits were performed. Only Git/file inspection, local hashing and this requested external report write were used. No data blocker was found. Keep any future database probes isolated and synthetic; the current audit metadata grants no authority for payments, live test mutations, grant renewal, migration, deployment or restoring old state.
