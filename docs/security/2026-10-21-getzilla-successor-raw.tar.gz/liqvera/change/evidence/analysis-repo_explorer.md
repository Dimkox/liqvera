Read-only repository analysis — 2026-10-21 — route ec1239ea42dd.

Identity and scope

Product commit: 17a70595e98aa183afac115e5b99488830fba712. Product tree: b4a0a202b2002245113fd48db3f9fc73f67ebc49. Inspected checkout: /home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit. The exact original Wave 1 base remains f1d3bffc46fa1459908fdff865fcfbfc831b7f7f; it is an ancestor. Current origin/main is 3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd. Published tags v0.0.1 through v0.0.5 remain ancestors. The route selects four analyses, five independent reviews and no write agent. Workflow metadata was untracked and being prepared concurrently; observations below bind to committed product bytes, not that mutable package.

The full product remains one web/API system: two Node applications, shared protocol metadata, four Python packages, public capture, report builder/offline verifier, PostgreSQL ledger and payment guards, six image recipes and their security probes. No source cleanup, application edits, tests, network calls or live operations were performed by this analysis.

Delta from production source

The deployment record identifies production source 1c020995adaa1a80fc8a97888aa838041d8e01d5. Compared with that source, committed HEAD changes ten files: deployment/remediation documentation, a new TLS deployment record and archive, handoff, the disposition explanation/policy, pyproject.toml and tests/test_tls_trust_guard.py. There is no delta in apps/, packages/, services/, schemas/, deploy/, either Python lock, Makefile or .github/workflows/verify.yml. This is a documentation, audit-policy, development-metadata and regression-test delta; it does not alter application/payment code or runtime build inputs.

Commit db297105b1fb58735ad275115ede0777abe9dad6 (tree 6db50941b5c37e36bc6f0bd8b94d992245550725) repairs a post-merge development-extra regression: main had restored pip==26.2.1 while the audited lock and CI bootstrap still required 26.2.2. The correction restores pip==26.2.2 and retains the incoming Ruff 0.17.1 declaration. Relative to production 1c020995, the final development-extra difference is Ruff 0.17.0 to 0.17.1; pip is again identical. The added test_development_install_preserves_the_audited_pip_bootstrap compares the dev-extra pip declaration with requirements-dev.lock. It complements the four existing effective-trust cases; it does not perform a real dependency installation.

Versioned dispositions

engineering/verification-dispositions.json contains exactly three entries. Static inspection of Git blobs at committed HEAD confirmed every complete-file hash and evidence hash. Both generic matches have the recorded decoded line/column and match digest, with one generic occurrence in each target file.

| ID | Exact target and finding | Target SHA-256 |
|---|---|---|
| liqvera-public-testnet-musd-1 | apps/mezo-web/test/mezo-finance.test.mjs, secret-scan/generic-secret, line 10 column 7 | 61c64095503eaca71d387d610c118d25f3ea2c8f7a8dd1c11f045d5fde34e3e2 |
| liqvera-public-testnet-musd-2 | docs/competition/2026-10-21-funding/dom-smoke.mjs, secret-scan/generic-secret, line 9 column 73 | 4a99ffe47e5620a97fb1ef567b43918ea4d79b89d33208c4ff1b961a69d55325 |
| liqvera-immutable-wave1-blank-eof | docs/security/2026-10-21-wave1-deployment.md, git-diff-check/new-blank-line-at-eof, line 51 | 2fc820a62bd6c8d453256d856f923ee2bdf812875c24fab684265883022335ba |

The two match digests are respectively 05e2960a431f5166660c9f4399d2920dd2fa3635e77e23a75b2a918647aaaf19 and 0ccf1a411cfbb57f5794fcc989b1f4ece9fda101e3e23e06240745e2a1caa5ab. Both are public Testnet MUSD contract references, with provenance in packages/mezo-protocol/src/index.ts (confirmed SHA-256 28a5c0a9143a803bbd836ab59b3aad31cd225bb6459eb97778a256aada88489b). They confer no signing or payment authority.

All entries bind docs/security/2026-10-21-verification-dispositions.md at SHA-256 d2a11a5029a4fe3b8a05201ba3ed9cc58e55ee32dc79a4e95d442bc5885b15c1. The historical Markdown still has 51 lines and its final blank line. These are exact reviewed classifications, not path-wide ignores. The policy expressly preserves raw detector findings and original severity, forbids private-key/AWS/generic-credential exemptions, and requires changed bytes to receive renewed review. Static hash correspondence is not independent approval or proof that the successor verifier applies the policy safely.

Reuse versus fresh evidence

- Reuse the deployment record and its exact image/source bindings as historical runtime evidence. Its documented 955 Python tests plus 85 subtests, 104 browser tests, 71 gateway tests including disposable PostgreSQL, image probes/scans and published browser checks belong to source 1c020995 and their recorded execution times. They do not become fresh tests of HEAD.
- Preserve the initial negative audit and the TLS-era exit-1 gate. Git comparison confirms the initial negative audit/archive and original Wave 1/layout records are unchanged from 1c020995. The newly added TLS record retains its own failing gate and full reports. The original PR #115 tool result must not be relabelled as passing.
- Fresh focused evidence is needed for .venv/bin/python -B -m pytest tests/test_tls_trust_guard.py -q, including the new pip-metadata case. A real installation claim requires separate execution; the metadata assertion alone does not prove it.
- Fresh successor review must validate the three exact dispositions against the revised external verifier, including raw-finding retention and rejection of stale/unsafe entries. Five selected independent reports must bind the same frozen source. The policy explanation alone is not a passing review receipt.
- The final qualifying gate must retain f1d3bffc46fa1459908fdff865fcfbfc831b7f7f and full scope. The recent narrow delta does not justify replacing the full Wave 1/TLS comparison with a documentation-only range. Run the newly pinned external getzilla_verify.py --mode pr --full-scope --keep-going --json from the frozen audit checkout, then record fresh passing review receipts only if it succeeds and confirm zero gaps with getzilla_status.py.
- Keep native coverage explicit: make verify PYTHON=.venv/bin/python supplies the full tests/ target and artifact guard; default pytest testpaths omit the root TLS regression, acceptance and operations directories. Record both Node builds/tests, both browser network builds, disposable-PostgreSQL coverage and supplemental Python-lock/image security scope separately from generic external detection. Historical unchanged-component evidence can support the audit but must retain its original source/date and limitations.

Production identity and boundaries

docs/security/2026-10-21-tls-deployment.md records source 1c020995, six replaced application containers and retained production PostgreSQL. Its exact image table remains the production reference; HEAD is an audit/development-metadata successor, not a new deployment. Existing databases, unknown payment outcomes, migrations, sealed bundles, WalletConnect configuration and retained rollback images remain outside this task. No current service health, new payment, borrowing, physical pairing or fresh image-scan result was observed here.

Repository-scope conclusion: the committed changes fit the stated final-audit contour. Static disposition identities match, and the original comparison range and negative evidence are preserved. Completion still requires the newly pinned verifier, independent exact-source reviews, its final successful gate and zero current status gaps. This analysis claims none of those executions.
