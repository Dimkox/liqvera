# Bounded observations before review

These controls are observations, not a qualifying Getzilla receipt. Product source: `17a70595e98aa183afac115e5b99488830fba712`.

- `GETZILLA_SERIAL=1 taskset -c 8-9 .venv/bin/python -B -m pytest tests/test_tls_trust_guard.py -q`: 5 passed in 0.45 s. Serialization prevents artifact-build races; this bounded module does not perform an installation.
- `taskset -c 10-11 npm test` in `apps/mezo-web`: 104 passed, 0 failed/skipped. Test sources and dependencies are unchanged from the deployed source.
- `python3 scripts/check-docs.py`: links pass for 63 documents.
- `python3 -B scripts/check-python-artifacts.py --forbid-path 'cmd/**' 'internal/**' 'go.mod' 'go.sum' --forbid-binary engine`: no forbidden inputs.
- The pip metadata regression failed on merged main and passed after the source correction; complete red/green logs are included.
- A separate preliminary external-tool probe observed 2 raw generic-secret findings, both exactly classified; Git checked the original route and current-main ranges and classified only the immutable EOF finding. This used the implementation worktree and creates no final claim. The frozen reviewed tool must repeat these controls and the complete gate.

`product-preservation.json` records exact old archive/document hashes and proves unchanged runtime input roots against source `1c020995`. Prior 71-test gateway/disposable-PostgreSQL, both browser-network builds, image scans and production checks are reused only as historical evidence from the linked TLS record. No production, quote, payment, loan, grant or database write occurred in these observations.

The failing pip regression output is stored byte-exact as `liqvera-pip-red.log.gz`; `red-log-binding.json` binds both compressed and decompressed bytes. Compression retains pytest diagnostic whitespace without presenting generated log formatting as source-code whitespace. The original raw log remains in the final evidence archive.
