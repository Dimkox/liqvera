Independent second data review: PASS. No blocking data finding in the current audit-metadata/tool-binding delta. The Liqvera qualifying rerun remains NOT_RUN; this review is not a verification receipt or authority for a live operation.

- Route/package: `ec1239ea42dd` / `engineering/changes/20261021-task-ec1239`.
- Candidate: `/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit`.
- Before/after HEAD: `1b90f54c7ab26a7689cb892687175ac12cb7e3a4`.
- Before/after tree: `23d2befc1bcf354fe5ca9c920ed6d54b62fe37dd`; status clean, including untracked files.
- Before/after tracked inventory: 514 blobs with executable modes; digest `afaf08bf11a3f12d78d9406cea81f304c32acd66a5eff4119fc041dafa5b2ae1`.
- Original base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`; secondary main: `3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd`.
- Unchanged product: `17a70595e98aa183afac115e5b99488830fba712`, tree `b4a0a202b2002245113fd48db3f9fc73f67ebc49`.
- External tool: `45be42f74b5a8ee6f079f8ac55206e475936fdc6`, tree `bcdd090531e657ee1d3cd20c340205df86fc8900`.
- Private scratch: `/home/pall/projects/liqvera/.getzilla/runtime/completion/liqvera-second-data-review`; scratch and trusted non-sticky parent mode `0700`. A committed snapshot reproduces all 514 tracked blobs and executable modes.
- Final identity check recorded at `2026-10-21T16:03:10.704257+00:00`.
- reviewed-tree-modified: no

Read the repository instructions, README, architecture, handoff, current route/package, second preparation, first-gate failure record and invocation, corrected scope metadata, preserved data review, current bounded controls, preservation record and exact tool binding. Read the current pinned controller and data-reviewer role; the four other workflow skills are unchanged from those already read. Inspected history/worktrees and confirmed the original base, secondary main, product and `v0.0.5` ancestry; published tags through `v0.0.5` are merged. All Git commands used `GIT_OPTIONAL_LOCKS=0`; no ref updates, fetches, cleanup or candidate changes were performed.

The actual delta from first-reviewed `ca65575dd2283a47b7671b356847ed8fb9f5a125` / tree `53e1e0688f123d35a948bd8946eae7a33c71da88` is 22 paths, all in the active audit package. The full original range is 103 paths: 59 product/history paths and 44 package paths. Product-to-current differences are confined to those 44 package paths. The change-spec correction only adds `scope_and_design_approval` to required scopes; risk remains red, and its criteria, invariants and forbidden outcomes are unchanged. Added decision records preserve the earlier entries and explicitly describe read-only scope with no live-write authority. The `migration-plan` record is not a migration authorization or signed security approval.

Fresh preservation checks found all nine declared runtime roots identical to deployed source `1c020995adaa1a80fc8a97888aa838041d8e01d5`; all eight SQL migrations match the original base, migration policy and historical ledger hashes. Gateway/payment code, schemas, public preview assets and report/verifier packages retain the previously reviewed bytes. Consequently this delta introduces no schema/index/query/backfill requirement, database startup behavior or new payment mutation.

The preserved implementations retain scoped idempotency; immutable quote/artifact/authorization and receipt/entitlement bindings; durable SUBMITTING and authority/nonce reservation before settlement; atomic confirmation; confirm-only reconciliation; and preservation of unknown/manual-review and deduplication state. Existing migrations 004/005 still reject populated legacy receipt schemas rather than fabricate provenance. Report service provenance remains source-bound for new reports, while existing reports and offline reproduction preserve their embedded historical engine identity. The audit commits do not relabel deployed engine `1c020995`, renew a grant or rewrite sealed output. These conclusions rely on fresh byte preservation checks plus the complete first source review, not fresh SQL execution.

Five complete first reviews match their original files at `3cadcb7fca99b9d8929a91103735a87cbafeecb0`, both under `first-*-review.md` and the existing role filenames. The retained first data report also matches the external original, SHA-256 `b75ecc165629891d3b1fa003716de6f3343665015967834b2257d0908f8ec72e`. First tool/control bindings match their original committed bytes. The first gate JSON, empty stderr and invocation remain unchanged since their preservation commit `2475407c22701538487f932e492fd25c4ef93ca4`.

| Evidence generation | Exact attribution and result |
| --- | --- |
| Historical TLS deployment | Source `1c020995adaa1a80fc8a97888aa838041d8e01d5`, recorded `2026-10-21T12:49:15.145720+00:00`: 71 gateway tests including 13 disposable PostgreSQL cases, zero skips; 955 Python tests plus 85 subtests; 104 web tests; isolated restore and deployed-image observations. These were not rerun. |
| First successor Liqvera full gate | Source `3cadcb7fca99b9d8929a91103735a87cbafeecb0`, tree `b023e497f6d7b4b5cad4f2778e06b95b7efc42cf`, tool `4cf2abf21753e61383e3d89be593e0fb815afc7f`; started `2026-10-21T14:36:16.904097+00:00`. Raw exit 1 and status fail remain; missing required scope is the failed check. Its 956 tests and 85 subtests passed, but evidence is `not_recorded` with explicit receipt refusal. These passing components do not qualify the new source. |
| Current review and supplied bounded controls | Current source/tool identities above. Fresh preservation and attribution probes pass. Supplied native controls explicitly identify themselves as bounded observations, retain raw findings and report corrected spec validity. They are not the new full gate. |

All nine historical files in `product-preservation.json` match their pinned hashes and merged-main bytes, including the initial negative audit and all named deployment archives. The old PR #115 failure remains negative. The historical TLS ledger/restore aggregates still report three CONFIRMED/one MANUAL_REVIEW attempt, four receipts/entitlements and eight migration hashes. These are recorded aggregates, not a current production observation or proof of every row. Historical retained-live PostgreSQL and disposable-test image identities remain distinct. The report JSON and evidence ZIP match their recorded hashes; no private recovery material was opened. Archive identity was checked; individual archived payloads and restores were not rerun.

Fresh commands ran from the private scratch above on CPUs 22–23, sequentially with one worker:

```sh
env GIT_OPTIONAL_LOCKS=0 taskset -c 22,23 python3 check.py
env GIT_OPTIONAL_LOCKS=0 taskset -c 22,23 python3 check_delta.py
```

Both exited 0. `check.py` verifies the committed snapshot/source identities, ancestry, full-range inventory, unchanged runtime/data/historical bytes, all three exact dispositions and two preview assets. `check_delta.py` verifies the 22-path package-only delta, retained reviews and failed-gate records, scope-only correction, four exact external review hashes, the tool's report-only delta from `3968ae4445836eda9cf377035b1d1f64fe9659b0`, all 48 allowlisted ignored overlay hashes, supplied control identities and final source stability. Results are retained as `checks.json`, `delta-checks.json`, `source-before.json` and `source-after.json`.

The raw original-range `git diff --check f1d3bffc46fa1459908fdff865fcfbfc831b7f7f 1b90f54c7ab26a7689cb892687175ac12cb7e3a4` still exits 2 with only `docs/security/2026-10-21-wave1-deployment.md:51: new blank line at EOF.`. The exact historical bytes, line and diagnostic remain preserved. Both public MUSD occurrences match their full-file, line/column and match hashes; the explanatory document and canonical protocol hashes match. Supplied controls retain two raw error-severity token findings and one raw EOF finding, with exact dispositions and zero unresolved findings. This data review verifies those bindings and attribution, not the external detector implementation or a new scan execution.

Evidence hashes: first gate JSON `fd05b33275af9b5e1d593b53b212bf7c0752ebd032294f7df41ba9d13b97f04d`; first gate invocation `46adba6ffb1a82be8564b6440a93e30af8d80b048d949e9174262cf4eca18d35`; supplied second bounded controls `1af7e97b6ee33e33fa217a3282c083adc660cea15282cbd2f452128c762ef98d`.

Unexecuted: unchanged application/full tests; SQL, migrations, restore, query plans or payment crash/concurrency/retention tests; images/builds/scans; real wallets/network acceptance; mutation probes; the separately coordinated tool gate and current Liqvera qualifying rerun. This metadata-only data review did not need those live or repeated operations. No production access, private dump/configuration/grant read, payment, deployment, candidate edit or Git ref write occurred. Persist all fresh selected reports and complete the qualifying gate before recording passing receipts.
