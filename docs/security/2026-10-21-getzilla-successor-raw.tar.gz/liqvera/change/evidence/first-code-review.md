Independent code review — Liqvera route `ec1239ea42dd`, 2026-10-21.

**PASS within reviewed scope. No blocking code finding. Final full Liqvera gate: NOT_RUN.** This is a fresh review of the complete original Wave 1 comparison, not an inherited verdict or a passing verification receipt.

Candidate: `/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit`. Before and after: HEAD `ca65575dd2283a47b7671b356847ed8fb9f5a125`, tree `53e1e0688f123d35a948bd8946eae7a33c71da88`, clean status including untracked files. Comparison: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f..HEAD`, 86 changed paths. The original base is an ancestor. Observed `origin/main` and its merge-base are `3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd`; this secondary range did not replace the original. Locally available tags v0.0.1–v0.0.5 are ancestors. Product source is `17a70595e98aa183afac115e5b99488830fba712`.

reviewed-tree-modified: no

Private scratch: `/home/pall/projects/liqvera/.getzilla/runtime/completion/liqvera-final-code-review`, mode 0700 under verified owned, non-sticky parents without group/other write permission. `git archive HEAD` reproduced the exact candidate tree; its private Git index reports the same tree before and after probes. A read-only Git object alternate supplies original history; all mutations, compiler outputs and logs stay in scratch. All 86 changed-file SHA-256 values match before/after. The 48 ignored tool-overlay hashes match the package binding. Evidence: `source-before.json`, `source-after.json`, `full-source.diff`, `preservation.json` in scratch.

Reviewed AGENTS, README, architecture, handoff, route/change package and all four bound analyses, then the actual full source diff: funding implementation/integration/tests/CSS/footer, six image recipes, CI bootstrap, both TLS checkers, dependency pins, new pip regression, dispositions and accompanying evidence. Funding remains advisory: exact integers, pinned network/asset/payer, canonical block recheck, provider/context ownership, expiry/freshness invalidation and non-clear payment guards. The CSS creates separate action rows; the footer adds a static external link. Neither grants payment authority or installs a framework.

Existing gateway code still locks the quote/attempt, requires VERIFIED before the durable SUBMITTING transition and permits only the subsequent single settlement call. Reconciliation confirms existing attempts; unknown/manual-review states cannot restart settlement. Merchant nonce uniqueness, receipt/entitlement bindings and canonical finality remain present. These server/database conclusions are static review, supported by unchanged inputs, not fresh database execution. `apps/mezo-gateway`, `packages`, `services` and `schemas` are unchanged across the original range. All declared runtime roots, locks, Makefile and CI inputs are unchanged from deployed source `1c020995adaa1a80fc8a97888aa838041d8e01d5`; nine historical evidence hashes and four analysis hashes independently match. No tracked Getzilla installation or product runtime dependency was added.

The post-merge development extra retains pip 26.2.2, matching the audited lock/bootstrap, and preserves the incoming Ruff declaration. The new regression catches restoration of the older pip pin. It tests metadata consistency, not an actual dependency installation or the security of arbitrary future lock versions.

Exact policy SHA-256: `e0395a8b681958936fa97f552f517d77cecb49744eb33b902a3ee5c6569ef141`. Both public occurrences match the named Testnet MUSD contract in `packages/mezo-protocol/src/index.ts`, verified SHA-256 `28a5c0a9143a803bbd836ab59b3aad31cd225bb6459eb97778a256aada88489b`. They are 20-byte contract identifiers used in synthetic tests, with no signing or grant authority. Target hashes, actual scanner positions/match hashes, and the common explanation hash `d2a11a5029a4fe3b8a05201ba3ed9cc58e55ee32dc79a4e95d442bc5885b15c1` match; details are retained in `exact-bindings.json`.

| Exact disposition target | Observed binding |
| --- | --- |
| `apps/mezo-web/test/mezo-finance.test.mjs` | Line 10, column 7; file hash `61c64095503eaca71d387d610c118d25f3ea2c8f7a8dd1c11f045d5fde34e3e2` |
| `docs/competition/2026-10-21-funding/dom-smoke.mjs` | Line 9, column 73; file hash `4a99ffe47e5620a97fb1ef567b43918ea4d79b89d33208c4ff1b961a69d55325` |
| `docs/security/2026-10-21-wave1-deployment.md` | Only EOF blank line 51; file hash `2fc820a62bd6c8d453256d856f923ee2bdf812875c24fab684265883022335ba` |

The audit helpers were imported from exact external Getzilla `4cf2abf21753e61383e3d89be593e0fb815afc7f`, tree `947e9f362d4f0bc862e8bf12455c8e4b1862e850`, rechecked after review. Against the full changed-file inventory, `_secret_scan` reports **2 observed / 2 disposed / 0 unresolved**. `_git_diff_check` executes worktree, index and both original/secondary ranges: **1 observed / 1 disposed / 0 unresolved**, retaining the original Git exit 2 and complete EOF diagnostic. Raw severity remains error; effective severity alone becomes informational. Six independent negative cases fail closed: stale target hash, stale occurrence hash, stale evidence hash, an additional unlisted occurrence with refreshed file binding, a rebound Unicode-whitespace member context, and unrelated historical-file whitespace. The extra occurrence produces 3 observed / 2 disposed / 1 unresolved. These are bounded helper probes, not the full gate or a general JavaScript-parser claim.

Reproduction commands below use `SCRATCH` for the private path above, `SNAPSHOT=$SCRATCH/snapshot`, and `LIQ_PY=/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit/.venv/bin/python`. Test subprocesses use CPUs 16–17, maximum two; `TMPDIR=$SCRATCH/tmp`, `PYTHONDONTWRITEBYTECODE=1`, `GETZILLA_SERIAL=1`. Exact expanded argv, environment and outputs are saved by the named drivers.

```bash
python3 "$SCRATCH/run-controls.py"
python3 "$SCRATCH/prepare-scratch.py"
taskset -c 16-17 "$LIQ_PY" -B "$SCRATCH/policy-probes.py"
python3 "$SCRATCH/run-mutations.py"
python3 "$SCRATCH/runtime-trust.py"
taskset -c 16-17 python3 "$SCRATCH/preservation.py"
# From SNAPSHOT:
taskset -c 16-17 "$LIQ_PY" -B scripts/check-python-artifacts.py --forbid-path 'cmd/**' 'internal/**' 'go.mod' 'go.sum' --forbid-binary engine
```

Fresh results: `pytest -p no:cacheprovider tests/test_tls_trust_guard.py -q` passes **5**; the three finance Node files pass **55**. The initial mixed Node invocation also had **2 module-load failures** because the archive lacked the built local protocol package; that command is retained as failed. Building the exact scratch protocol using the existing TypeScript compiler and linking it inside scratch resolves that cause; the two browser-flow/orchestration files then pass **15**. No application source repair was made. Independent tests at 29,999 ms, 30,000 ms and a backward clock all pass, including click-time invalidation and no background RPC. The artifact command exits 0, “Liqvera artifacts contain no Go inputs.”

With an explicitly corrected CA file, empty private CA directory and disabled pip configuration, Python system/certifi/pip/additional-system checks each report 120 roots and zero incident roots. Node parent/child checks report the same; removing inherited OpenSSL mode fails as expected. These are local offline trust checks with Node 24.22.0/OpenSSL 3.5.8, not fresh production-image acceptance. Complete results are in `controls.json`, `scratch-setup.json`, `policy-probes.json`, `mutation-results.json`, `runtime-trust.json` and their logs.

| Mutant, applied only to scratch | Exact targeted test command after `taskset -c 16-17` | Outcome |
| --- | --- | --- |
| M1: restore old dev pip pin | `$LIQ_PY -B -m pytest -p no:cacheprovider -q tests/test_tls_trust_guard.py::test_development_install_preserves_the_audited_pip_bootstrap` | **Killed**; 1 assertion failure |
| M2: omit lazy CA-directory inspection | `$LIQ_PY -B -m pytest -p no:cacheprovider -q tests/test_tls_trust_guard.py` | **Killed**; directory and directory-list cases fail, 3 pass |
| M3: remove funding non-clear payment guard | `node --test --test-concurrency=1 --test-reporter=spec apps/mezo-web/test/mezo-finance.test.mjs` | **Killed**; 2 failures, 30 pass |
| M4: omit canonical block-hash comparison | `node --test --test-concurrency=1 --test-reporter=spec apps/mezo-web/test/musd-observation.test.mjs` | **Killed**; changed-block case fails, 13 pass |
| M5: remove funding freshness/clock boundary | `node --test --test-concurrency=1 --test-reporter=spec $SCRATCH/independent-freshness.mjs` | **Killed**; expiry and backward-clock cases fail, 2 pass |

All five executed code mutants were killed and restored; none survived or was inconclusive. The dependency setup failure above remains visible. Nonblocking coverage observation: committed panel tests still omit the exact age/backward-clock cases; this review's independent tests cover them and kill M5.

Unexecuted here: full Python/Liqvera gate, complete native Node suites/builds, CI execution, fresh image/advisory scans, disposable PostgreSQL, full browser/layout rendering, physical wallet pairing, on-chain provenance, borrowing/payment/quote creation, backups/restores, deployment and publication. Historical image, database and browser acceptance may be cited only with the original `1c020995` identities and the independently verified unchanged-input proof. No secrets, private state or live operations were accessed. Earlier negative audits remain unchanged. No final passing receipt or zero-gap completion is asserted.
