Independent data review: PASS. No blocking data finding in the reviewed range. The current Liqvera final gate is NOT_RUN; this report creates no verification receipt or deployment authority.

- Route: `ec1239ea42dd`; package: `engineering/changes/20261021-task-ec1239`.
- Candidate: `/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit`.
- Full comparison base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`.
- Secondary merged-main identity: `3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd`.
- Product: `17a70595e98aa183afac115e5b99488830fba712`, tree `b4a0a202b2002245113fd48db3f9fc73f67ebc49`.
- Source HEAD before and after: `ca65575dd2283a47b7671b356847ed8fb9f5a125`.
- Source tree before and after: `53e1e0688f123d35a948bd8946eae7a33c71da88`.
- Source status before and after: clean, including untracked-file inventory.
- Before/after tracked inventory: 497 blobs and their executable modes; digest `65040157d4bf8f898f26a44ac6010c2240f9327a1f5d761d63f6998e1a43c39a`.
- Final source check: `2026-10-21T14:29:19.095490+00:00`.
- External tool: `4cf2abf21753e61383e3d89be593e0fb815afc7f`, tree `947e9f362d4f0bc862e8bf12455c8e4b1862e850`; its separate gate is not claimed here.
- Private scratch: `/home/pall/projects/liqvera/.getzilla/runtime/completion/liqvera-final-data-review`; scratch and its trusted non-sticky parent are mode `0700`. All 497 committed files and executable modes were reproduced under `snapshot` and checked again after tests.
- reviewed-tree-modified: no

Read repository instructions, README, architecture, handoff, route, change package, data analysis, preservation binding, and the pinned controller/reviewer/workflow skills. Inspected status, history, worktrees, and the actual diff. The original base, merged main, product commit and published `v0.0.5` are ancestors; tags `v0.0.1` through `v0.0.5` are merged. No cleanup or candidate edit occurred.

The full original comparison contains 86 changed paths: 59 product/history paths and 27 active change-package paths. Product-to-candidate differences are confined to those 27 package files. The postmerge executable correction restores the development extra to `pip==26.2.2` and tests equality with the audited lock; the incoming Ruff version remains. The other new product content is the exact audit policy and documentation. Independently verified all nine declared runtime input roots, including apps, packages, services, schemas, deploy, both Python locks, Makefile and verification CI, are identical to deployed source `1c020995adaa1a80fc8a97888aa838041d8e01d5`. Across the original base, gateway code/migrations, packages, services, schemas, public preview assets and all three Compose files are unchanged. There is no new database interface, migration, index, backfill, retention rule or production action required by this completion change.

The following payment and data conclusions are source inspection, not fresh SQL execution:

| Invariant reviewed | Evidence and conclusion |
| --- | --- |
| Scoped idempotency and immutable identities | `apps/mezo-gateway/migrations/001_ledger.sql`, `002_fix_immutable_ledger_identity.sql`, and `src/adapters/postgres.ts`: scoped request key uniqueness, immutable quote/artifact/authorization identity, receipt/entitlement composite foreign keys and digest bindings remain intact. |
| Submission boundary and double-write protection | `src/adapters/postgres.ts:147`, `src/application/gateway.ts:82`: quote/attempt locks, expiry and authority reservation precede committed SUBMITTING; the sole settlement call occurs afterward. Pending/uncertain/manual states block retries. `008_merchant_nonce.sql` retains merchant network/payer/nonce uniqueness without a state filter. |
| Atomic confirmation and recovery | `src/adapters/postgres.ts:220` writes the chain event, receipt, entitlement and confirmed/paid states in one transaction. `src/workers/reconciliation.ts` confirms existing attempts without settlement; stale-unsubmitted recovery only rejects RECEIVED/VERIFIED attempts. |
| Unknown states and tenant/network separation | `src/workers/retention.ts:3` excludes non-rejected attempts and entitlements from expired-artifact cleanup and preserves ledger/deduplication rows. `007_network_identity.sql` and startup assertions retain the immutable ledger network and paired asset; request and entitlement lookups remain scoped. |
| Sealed evidence and delivery | Delivery checks confirmed state, retention, current finality and artifact integrity. The historical report JSON and evidence ZIP retain their recorded SHA-256 values, `0ebf36b89bda183b99767cd7fedc3c956405ef4a3f195d9d73b911d2c146ccf2` and `3255a42c210c6fe6ad0020c34113988da3f1659c566a73b7729606ad65d083b0`. |
| Engine provenance | `packages/evidence-report/src/liqvera_evidence_report/service.py:87` supplies LIQVERA_ENGINE_COMMIT to new requests; existing report IDs use `read_published` at line 189. `evidence_bundle.py:162` reconstructs using the bundle's embedded historical commit and compares exact bytes. Audit product `17a70595` does not relabel deployed engine `1c020995`, renew authority, or rewrite old bundles. |
| Funding observations | `apps/mezo-web/src/mezo-finance.mjs` and its panel preserve integer-string amounts, account/network/quote checks, a canonical block check, freshness and explicit non-payment observations. Non-clear payment guards remain blocked; RPC methods remain read-only. |

All eight SQL files match the migration-policy hashes, the original base, and the TLS deployment ledger record. No schema expansion or backfill applies. Existing migrations 004/005 intentionally reject populated legacy receipts instead of fabricating provenance; the historical empty-receipt upgrade test does not establish compatibility with populated legacy schemas. No fresh query plans, lock-duration measurements or volume/distribution validation were run because the query/schema behavior is unchanged.

Fresh bounded controls executed on CPUs 22–23, with at most two CPUs allocated:

| Command or inspection | Observed result |
| --- | --- |
| `taskset -c 22,23 python3 check.py`, cwd the private scratch above | Exit 0. Reproduced the committed snapshot and checked 497 blob identities/modes, ancestry, 86-path range, 27-path package-only delta, nine unchanged runtime roots, eight migration hashes, nine unchanged historical evidence files, three exact policy entries and two preview assets. Results: `checks.json`; checker SHA-256 `af9b0580501d67942a09e9a31fa18690a2bf142c3e2399164c64b4cb78e79f5b`. |
| `git diff --check f1d3bffc46fa1459908fdff865fcfbfc831b7f7f ca65575dd2283a47b7671b356847ed8fb9f5a125` | Expected raw exit 2, with exactly `docs/security/2026-10-21-wave1-deployment.md:51: new blank line at EOF.` and empty stderr. This raw failure is preserved, not reported as a Git pass. |
| Offline finance and observation command below | Exit 0; 46 tests passed, zero failed/skipped/cancelled. Covers exact monetary values, blocked unknown outcomes, chain/account changes, block changes, invalid metadata and bounded timeouts with synthetic providers. |
| Offline pip metadata command below | Exit 0; one test passed. Three unknown asyncio configuration warnings came from deliberately disabling plugin autoload; this synchronous metadata test does not use asyncio. |
| Final Git/blob checks and snapshot comparison | Exit 0; source identity, status and all 497 source/snapshot blobs and executable modes unchanged. Three actual tracked Compose files have no original-range diff. `source-before.json`, `source-after.json` and `offline-controls.json` retain the observations. |

Both test commands ran from the private scratch's `snapshot` directory:

```sh
env -i PATH=/usr/local/bin:/usr/bin:/bin HOME=/home/pall/projects/liqvera/.getzilla/runtime/completion/liqvera-final-data-review LANG=C.UTF-8 taskset -c 22,23 node --test --test-concurrency=1 apps/mezo-web/test/mezo-finance.test.mjs apps/mezo-web/test/musd-observation.test.mjs
env -i PATH=/usr/local/bin:/usr/bin:/bin HOME=/home/pall/projects/liqvera/.getzilla/runtime/completion/liqvera-final-data-review LANG=C.UTF-8 PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 taskset -c 22,23 /home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit/.venv/bin/python -m pytest -q -p no:cacheprovider tests/test_tls_trust_guard.py::test_development_install_preserves_the_audited_pip_bootstrap
```

The optional policy contains exactly two public Testnet MUSD occurrences and one immutable-Markdown EOF disposition. Checked each whole-file and evidence-document hash, each public match's exact line/column and match hash, and the canonical protocol file hash `28a5c0a9143a803bbd836ab59b3aad31cd225bb6459eb97778a256aada88489b`. Both matches contain the canonical public contract and create no signing authority. The third entry binds only the historical file, SHA-256 `2fc820a62bd6c8d453256d856f923ee2bdf812875c24fab684265883022335ba`, exact line 51 and exact diagnostic. Its original final blank line remains intact. Invalid/stale/unsupported-policy rejection and successor scanner behavior are the security/tool review and final gate's responsibility; this report does not claim those executions.

Historical evidence remains explicitly historical. The nine files named by `product-preservation.json` match their hashes and merged-main bytes. This includes Wave 1, layout, original negative audit and TLS archives. The TLS archive retains SHA-256 `625cd5f517b19b80073530f9ffdba2bfab71f0461050d68d0051be57d0dc8b89`; its recorded 354 verified payloads were not individually reverified here.

The TLS record was recorded at `2026-10-21T12:49:15.145720+00:00` for source `1c020995adaa1a80fc8a97888aa838041d8e01d5`. It reports 71 gateway tests including 13 disposable PostgreSQL cases with zero skips, 955 Python tests plus 85 subtests, 104 web tests, exact-image offline report reproduction, and isolated backup restoration. These were not rerun on this candidate. Its matching preservation/restore summaries contain three CONFIRMED and one MANUAL_REVIEW attempt, four receipts, four entitlements and the eight migration hashes. Those aggregates do not prove every row or today's live state. Retained live PostgreSQL image `sha256:ac94c2b07e35f5f12172a07ba198a7bcd221a90d149122bc9900771d467733ec` remains distinct from historical disposable-test image `sha256:98e5cab850b96ff1acfaca92834c8590274e62ba9f64b6d882d27ec7f6e090d8`. Normal service startup/workers can write legitimate state; historical no-new-payment/no-migration statements are not claims that no SQL executed.

The original Getzilla gate is still negative: tool `2bb417431f1e4b9494e4af71ebf27adb1d04d898`, reviewed source `bf569ce96039deeec69e025a3c3cdc9653584b0d` / tree `c4205fabda3d9d34d08058990fca33b0b059f81d`, final gate source `b030ab142194bd5c50d2edb38238535567d98bda` / tree `d70205ee88e46e1d98280c989a6be758e5f7f591`, raw exit 1, zero-gap completion false and no passing final receipt. Current classifications do not retroactively change it.

Unexecuted: current full qualifying gate; live or disposable SQL; migration execution; restore execution; payment crash/concurrency fault injection; current retention/reconciliation behavior against mixed live states; image builds/scans; real wallet/network acceptance; and mutation probes. The data review required no schema mutation probe; code/test reviewers own their selected probes. Source inspections and hash checks establish preservation, not fresh runtime/database acceptance. No production connection, private dump/configuration/grant read, schema/payment/deployment action, push, or candidate write occurred. No new data blocker was found; persist all selected reports before the final gate.
