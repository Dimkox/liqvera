# Independent Liqvera test review

PASS with one non-blocking test-coverage follow-up. No current product or policy blocker was demonstrated. Final Liqvera qualifying gate: NOT_RUN.

Route ec1239ea42dd; package 20261021-task-ec1239. Candidate: /home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit. Review scope retains the full original base f1d3bffc46fa1459908fdff865fcfbfc831b7f7f, including funding, payment guards, layout, TLS recipes and optional dispositions; it is not narrowed to current main 3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd. Both are ancestors; tags v0.0.1 through v0.0.5 are ancestors. Worktrees were inventoried without cleanup.

Before and after:

- HEAD: ca65575dd2283a47b7671b356847ed8fb9f5a125
- Git tree: 53e1e0688f123d35a948bd8946eae7a33c71da88
- Actual tracked-byte/mode manifest SHA-256: d6321333014da7c2839a3faa6ae6e88a938128fb377c3a7734b58f68a362fadf
- Status: clean, including untracked files.
- reviewed-tree-modified: no

Private scratch: /home/pall/projects/liqvera/.getzilla/runtime/completion/liqvera-final-test-review, mode 0700 under trusted non-sticky parents. All 497 tracked blobs, 9,663,307 bytes and executable modes were verified before/after against candidate and restored snapshot. The snapshot has private Git refs/index and reads the original immutable Git object store, preserving the exact HEAD and original comparison. Generated protocol output and dependency link remain only in scratch. Tests used CPUs 18-19, at most two concurrent Node tests and private TMPDIR. before.json, source-manifest.json and after.json retain verification.

## Fresh checks

The source, tests, repository instructions, architecture/handoff, change analyses, policy and control evidence were inspected. Independent Git comparison confirms zero runtime-input delta from deployed source 1c020995adaa1a80fc8a97888aa838041d8e01d5 across every root listed in product-preservation.json. All nine retained historical file hashes match. The compressed pip RED log matches both its stored and decompressed hashes and contains the expected failing metadata assertion.

Exact command abbreviations below:

```text
S=/home/pall/projects/liqvera/.getzilla/runtime/completion/liqvera-final-test-review
P=/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit/.venv/bin/python
G=/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python
E=taskset -c 18-19 env TMPDIR=$S/tmp PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
```

The abbreviations describe argv, not literal shell variable expansion for E. Complete executable argv and outputs are retained in the named JSON/log files.

- In S/snapshot: E P -B -m pytest -p no:cacheprovider tests/test_tls_trust_guard.py -q. Five passed in 0.63s; three asyncio configuration warnings reflect disabled plugin autoload and do not omit these synchronous tests. Interpreter Python 3.12.3, certifi 2026.10.19. This tests the development-extra pin and clean/file/directory/directory-list trust cases; it performs no dependency installation.
- In S/snapshot/apps/mezo-web: taskset -c 18-19 env TMPDIR=S/tmp node --test --test-concurrency=2 test/mezo-finance.test.mjs test/mezo-finance-panel.test.mjs test/musd-observation.test.mjs test/browser-flow.test.mjs test/browser-orchestration.test.mjs test/x402-transport.test.mjs. All 74 passed, zero skipped, in 544.581ms. They cover safe initial disabling, fresh unpaid shortfall/acknowledgement, quote/account/network/unknown-payment guards, read-only block-bound observations, recovery and transport limits. Initial execution had 59 passes and two module-load failures because private protocol build output was absent. After taskset -c 18-19 node /home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit/apps/mezo-web/node_modules/typescript/bin/tsc -p packages/mezo-protocol/tsconfig.json in the private snapshot and a private local-package link, the same selection passed. Both logs are retained; no source repair was needed.
- E G -B S/policy_probe.py used exact external tool 4cf2abf21753e61383e3d89be593e0fb815afc7f, tree 947e9f362d4f0bc862e8bf12455c8e4b1862e850, unchanged before/after. Two targeted raw generic-secret findings retain severity error and become precisely disposed, zero unresolved. Full original-base Git diff checks retain exits [0,0,2], one raw EOF error and its sole exact disposition. Policy SHA-256: e0395a8b681958936fa97f552f517d77cecb49744eb33b902a3ee5c6569ef141. This bounded direct classifier probe is not a full verifier or receipt.
- E node S/freshness-probe.mjs passes: acknowledgement/link remain available at 29,999ms and are disabled/removed at 30,000ms. Only synthetic wallet read methods are called.
- taskset -c 18-19 P -B S/snapshot/deploy/security/check-tls-trust.py --cafile S/tmp/pip-ca.pem --pip passes with clean S/tmp/clean-pip-capath and rejects the public compromised-root fixture in S/tmp/poisoned-pip-capath. Environment: PIP_CONFIG_FILE=/dev/null, SSL_CERT_FILE=S/tmp/pip-ca.pem, SSL_CERT_DIR set to the named private directory, PYTHONDONTWRITEBYTECODE=1, TMPDIR=S/tmp and inherited PATH only. Clean output verifies 120 roots each for explicit bundle, pip 26.2.2 and additional system trust. Poisoned output exits 1 specifically for pip additional system trust. No handshake or download occurs.

baseline-results.json, web-baseline.json, policy-results.json, pip-effective-results.json and logs preserve actual outputs.

## Mutation probes

Source-mutation driver: taskset -c 18-19 python3 S/mutation_runner.py. Every edit was private and restored. Exact edits, argv and results are in mutation-results.json; policy-input perturbations are in policy_probe.py and policy-results.json.

| Probe | Change and executable check | Outcome |
|---|---|---|
| M1 | Revert only development extra to pip 26.2.1; E P -B -m pytest -p no:cacheprovider -q tests/test_tls_trust_guard.py::test_development_install_preserves_the_audited_pip_bootstrap | Killed: one assertion failure, exit 1 |
| M2 | Disable lazy CA-directory inspection; same pytest command targeting tests/test_tls_trust_guard.py | Killed: directory and directory-list assertions fail; two failed, three passed |
| M3 | Remove fundingEligibility's non-clear payment guard; E node --test --test-concurrency=2 test/mezo-finance.test.mjs in web directory | Killed: two assertions fail, 30 pass |
| M4 | Alter bound review evidence, scan an empty selected list through policy_probe.py | Killed by pinned checker: invalid configuration, one unresolved error |
| M5 | Add a synthetic credential to an admitted file and refresh its whole-file policy hash, leaving occurrence bindings unchanged | Killed by pinned checker: three raw findings, only two disposed, one unresolved; synthetic value absent from output |
| M6 | Replace the 30-second observation-age limit with Infinity; E node --test --test-concurrency=2 test/mezo-finance-panel.test.mjs | Survived all nine native panel tests. Killed by E node S/freshness-probe.mjs at exactly 30,000ms |
| M7 | Remove the additional-system-trust check under --pip; rerun the poisoned-capath CLI above | Killed by reviewer negative oracle: mutated CLI incorrectly exits 0, whereas original exits 1 |

No probe was inconclusive. Input perturbations M4/M5 test classifier rejection, not modifications to the external tool. M7 is detected by the separate offline oracle; this report does not claim native pytest coverage for that mutation.

## Non-blocking follow-up and limits

T1: Add a repository regression around 29,999/30,000ms in apps/mezo-web/test/mezo-finance-panel.test.mjs. Existing tests say fresh read but never advance its age; M6 therefore survives them. The current implementation passes the independent clock oracle, and quote/unknown-payment guards remain separately tested. This is a test gap, not a demonstrated current payment or borrowing defect.

Fresh implementation controls recorded in the package (five Python, 104 web and 63-document checks) remain separate from this review's executions. The TLS record's 955 Python tests plus 85 subtests, 71 gateway tests including 13 disposable-PostgreSQL tests, both browser builds, image checks and published layout/QR observations are historical, bound to their recorded source/images. Their byte-identical runtime inputs support reuse; they are not fresh tests of ca65575. The previous negative Getzilla audits and abandoned broad run remain unchanged.

No full suite, qualifying gate, new image build/scan, gateway/PostgreSQL run, installed dependency resolution, physical wallet or fresh Chrome layout/QR check was performed here. Layout CSS was read; visual acceptance remains historical. The complete language/parser space and adversarial filesystem races were not exhaustively exercised. The pip pin test proves consistency with the audited lock, not a new vulnerability query or real installation. No live quote, loan, payment, grant, database write, deployment or publication occurred. Final acceptance still requires saved reports, a frozen candidate, the full original-scope Liqvera gate and fresh receipts.
