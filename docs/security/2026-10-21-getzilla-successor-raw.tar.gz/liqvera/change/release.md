# Delivery

Deliver the source correction, optional policy and successor audit record through a new Liqvera pull request; PR #14 is already merged. Pin the exact reviewed Getzilla successor and include the complete raw result, invocation, reports, receipts, inventory and audit bundle. Never call the unmodified PR #115 gate successful.

The existing six application images and PostgreSQL container on claw remain unchanged in this phase. Prior deployment acceptance and rollback are historical evidence with exact identities, not a new rollout.
