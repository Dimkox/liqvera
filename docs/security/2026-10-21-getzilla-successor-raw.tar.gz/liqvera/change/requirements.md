# Requirements

Use the reviewed successor Getzilla tool, full PR mode with full scope, the entire tests/ Python target, live online OSV and unchanged comparison inventory. Record all raw and effective findings. Strictly reject stale or malformed dispositions. Retain all previous archives byte for byte.

Fresh bounded metadata/TLS, artifact, documentation and nested browser checks precede the five reviews. Existing exact-image scans, disposable PostgreSQL acceptance, build and published browser evidence are reused only with their original source/image/hash identities where current app inputs are identical. They are not new production acceptance. No credentials or private runtime files enter evidence.
