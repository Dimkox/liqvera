# Rollback

This audit performs no production mutation. Revert the optional policy and successor source commit through normal Git review if needed; keep the corrected pip pin and all old evidence. Without policy the strict detector reports its original raw failures. A policy mismatch must fail closed.

Production recovery remains the previously validated retained-container procedure in the TLS deployment record. Never overwrite live PostgreSQL with an older dump or discard unknown payment states. No production rollback is exercised by this task.
