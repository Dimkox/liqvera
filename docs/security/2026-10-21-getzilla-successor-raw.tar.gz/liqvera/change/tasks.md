# Tasks and resource plan

1. Root owns Liqvera source and audit metadata; no reviewer edits the candidate.
2. Four route-selected analyses run read-only against the committed product identity.
3. Record bounded controls and exact tool/config provenance, commit state reviewing, and dispatch five independent reviews.
4. Persist complete reports only, freeze, run full gate, register reviews and inspect zero gaps.
5. Publish successor evidence and the source branch through a pull request.

Startup measured 26 available logical CPUs after the two-CPU owner reserve. Concurrent Getzilla implementation uses up to eight CPUs. Liqvera bounded controls use at most four CPUs. Review probes use separate private scratch under the canonical runtime root, with coordinated CPU totals. Heavy Python artifact tests are serialized to prevent shared build-directory races.
