# Verification plan

Run bounded controls before reviews; these are observations and create no qualifying receipt. Review one committed candidate with code, test, security, data and release roles. Save the complete returned reports without edits, commit only those allowed files, freeze, then invoke the final full PR gate once.

The final Python target is the entire tests/ tree, expected 956 tests plus 85 subtests after the new pin regression. Use four assigned CPUs with serialized pytest because artifact tests share package build directories. Run online OSV with corrected CA trust and preserve lock scope. Fresh browser tests and unchanged historical gateway/real-PostgreSQL/build/image evidence are identified separately. Run no live payment or quote. Final success requires an actual zero exit and five valid review receipts with zero status gaps.
