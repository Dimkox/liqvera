from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'snapshot'))
from tests.test_verification_dispositions import DispositionTests, ASSIGNMENT
from getzilla.verification import _secret_scan, _git_diff_check, GitRangeSelection
from getzilla import verification_dispositions as policy

results = []
ascii_only = '--ascii-only' in sys.argv
cases = [('plain', ''), ('ascii-credential', 'auth_'),
                      ('zwnj-credential', 'auth\u200c'), ('zwj-credential', 'auth\u200d'),
                      ('combining-credential', 'auth\u0301'),
                      ('unicode-escape-credential', 'auth\\u{5f}')]
for label, prefix in cases[:2] if ascii_only else cases:
    fixture = DispositionTests()
    fixture.setUp()
    try:
        entry = fixture.entry(text=prefix + ASSIGNMENT + '\n', column=len(prefix) + 1)
        fixture.policy([entry])
        before = fixture.git('status', '--porcelain=v1').stdout
        first = _secret_scan(fixture.root, ['protocol.ts'])
        second = _secret_scan(fixture.root, ['protocol.ts'])
        after = fixture.git('status', '--porcelain=v1').stdout
        row = {'name': label, 'expected': 'pass' if not prefix else 'fail', 'actual': first.status,
               'summary': first.summary, 'repeat_equal': first.to_dict() == second.to_dict(),
               'git_status_unchanged': before == after}
        results.append(row)
    finally:
        fixture.doCleanups()

fixture = DispositionTests()
fixture.setUp()
try:
    fixture.policy([fixture.entry(path='historic.md', text='Evidence.\n\n', line=2, whitespace=True)])
    before = fixture.git('status', '--porcelain=v1').stdout
    first = _git_diff_check(fixture.root, 'fast', GitRangeSelection())
    second = _git_diff_check(fixture.root, 'fast', GitRangeSelection())
    results.append({'name': 'repeat-whitespace', 'expected': 'pass', 'actual': first.status,
                    'summary': first.summary, 'repeat_equal': first.to_dict() == second.to_dict(),
                    'git_status_unchanged': before == fixture.git('status', '--porcelain=v1').stdout})
finally:
    fixture.doCleanups()

(ROOT / ('ascii-results.json' if ascii_only else 'independent-results.json')).write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
if ascii_only:
    assert all(row['expected'] == row['actual'] for row in results), 'Credential-name suffix was treated as a standalone token.'
