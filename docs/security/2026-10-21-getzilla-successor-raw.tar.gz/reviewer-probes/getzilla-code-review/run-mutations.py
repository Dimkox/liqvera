from pathlib import Path
import json
import os
import subprocess

ROOT = Path(__file__).resolve().parent
SNAP = ROOT / 'snapshot'
env = {'PATH': '/usr/bin:/bin', 'TMPDIR': str(ROOT / 'tmp'),
       'PYTHONDONTWRITEBYTECODE': '1', 'GETZILLA_SERIAL': '1'}
prefix = ['taskset', '-c', '0-5', 'python3', '-B']
module = 'tests.test_verification_dispositions.DispositionTests.'
results = []

def run(name, args):
    command = prefix + args
    result = subprocess.run(command, cwd=SNAP, env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, timeout=40)
    (ROOT / (name + '.log')).write_text(result.stdout)
    row = {'name': name, 'command': command, 'cwd': str(SNAP), 'environment': env,
           'exit_code': result.returncode,
           'summary': [line for line in result.stdout.splitlines() if line.startswith(('Ran ', 'OK', 'FAILED', 'FAIL:', 'ERROR:'))]}
    results.append(row)
    print(json.dumps({key: row[key] for key in ['name', 'exit_code', 'summary']}), flush=True)
    return result.returncode

assert run('baseline-ascii-oracle', [str(ROOT / 'independent-probes.py'), '--ascii-only']) == 0
assert run('baseline-package', ['-m', 'unittest', '-v', 'tests.test_manifest_package.ManifestTests.test_disposition_helper_ships_without_target_review_policy']) == 0

helper = '.getzilla/getzilla/verification_dispositions.py'
mutants = [
    ('M1-duplicate-json-key', helper, '        if key in result:', '        if False:',
     ['test_malformed_duplicate_key_version_and_size_fail_without_findings']),
    ('M2-only-first-secret-match', '.getzilla/getzilla/verification.py',
     '            for match in pattern.finditer(text):', '            for match in list(pattern.finditer(text))[:1]:',
     ['test_one_disposition_never_suppresses_second_match_on_same_line', 'test_two_occurrences_require_two_location_bindings']),
    ('M3-ignore-git-layer', helper, "            if layer == 'worktree':", '            if True:',
     ['test_current_worktree_hash_cannot_dispose_a_different_head_blob', 'test_staged_and_worktree_eof_are_bound_to_their_own_bytes']),
    ('M4-ignore-source-stability', helper, '    def assert_current(self) -> None:\n', '    def assert_current(self) -> None:\n        return\n',
     ['test_evidence_mutation_during_scan_fails_closed']),
    ('M5-omit-name-boundary', helper,
     "    return bool(_PUBLIC_TOKEN.fullmatch(match.group()) and (\n        match.start() == 0 or not re.match(r'[\\w$.-]', text[match.start() - 1])\n    ))",
     '    return bool(_PUBLIC_TOKEN.fullmatch(match.group()))', None),
]
for name, relative, old, new, tests in mutants:
    path = SNAP / relative
    original = path.read_text()
    assert original.count(old) == 1, (name, original.count(old))
    try:
        path.write_text(original.replace(old, new))
        selected = [module + name for name in tests] if tests else ['tests.test_verification_dispositions']
        code = run(name, ['-m', 'unittest', '-v', *selected])
        results[-1].update(classification='killed' if code else 'survived',
                           mutation={'path': relative, 'old': old, 'new': new})
        if name == 'M5-omit-name-boundary':
            code = run(name + '-independent', [str(ROOT / 'independent-probes.py'), '--ascii-only'])
            results[-1]['classification'] = 'killed' if code else 'survived'
    finally:
        path.write_text(original)
subprocess.run(['git', 'diff', '--exit-code'], cwd=SNAP, env=env, check=True)
(ROOT / 'mutation-results.json').write_text(json.dumps(results, indent=2) + '\n')
