from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'snapshot'))
from tests.test_verification_dispositions import DispositionTests, ADDRESS
from getzilla import verification_dispositions as policy
from getzilla.verification import _secret_scan

cases = [('plain-object', 'const value = { token: ' + repr(ADDRESS) + ' };', 'pass'),
         ('plain-declaration', 'const token = ' + repr(ADDRESS) + ';', 'pass'),
         ('unicode-comment-positive', '/* review \u00a0 */ const token = ' + repr(ADDRESS) + ';', 'pass'),
         ('unicode-string-positive', 'const label = "\u03bb"; const token = ' + repr(ADDRESS) + ';', 'pass')]
for name, continuation in [('zwnj', '\u200c'), ('zwj', '\u200d'), ('combining', '\u0301'), ('escape', r'\u{5f}')]:
    cases.append((name + '-credential', 'const auth' + continuation + 'token = ' + repr(ADDRESS) + ';', 'fail'))
for name, whitespace in [('nbsp', '\u00a0'), ('bom', '\ufeff'), ('line-separator', '\u2028')]:
    cases.append((name + '-member', 'const client = {}; client.' + whitespace + ' token = ' + repr(ADDRESS) + ';', 'fail'))

results = []
for name, source, expected in cases:
    fixture = DispositionTests()
    fixture.setUp()
    try:
        text = source + '\n'
        match = next(policy.SECRET_PATTERNS['generic-secret'].finditer(text))
        line, column = policy.location(text, match.start())
        entry = fixture.entry(text=text, line=line, column=column)
        entry['match_sha256'] = hashlib.sha256(match.group().encode()).hexdigest()
        fixture.policy([entry])
        before = fixture.git('status', '--porcelain=v1').stdout
        first = _secret_scan(fixture.root, ['protocol.ts'])
        second = _secret_scan(fixture.root, ['protocol.ts'])
        # Parse source only: do not execute its assignments or access any service.
        syntax = subprocess.run(['node', '-e', 'new Function(process.argv[1]);', source], capture_output=True, text=True)
        results.append({'name': name, 'expected': expected, 'actual': first.status,
                        'summary': first.summary, 'valid_js_syntax': syntax.returncode == 0,
                        'repeat_equal': first.to_dict() == second.to_dict(),
                        'status_unchanged': before == fixture.git('status', '--porcelain=v1').stdout})
    finally:
        fixture.doCleanups()
(ROOT / 'context-results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
