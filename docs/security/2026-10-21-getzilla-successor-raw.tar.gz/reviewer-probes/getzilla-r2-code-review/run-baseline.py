from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parent
command = ['taskset', '-c', '0-5', 'python3', '-B', '-m', 'unittest', '-v', 'tests.test_verification_dispositions']
env = {'PATH': '/usr/bin:/bin', 'TMPDIR': str(ROOT / 'tmp'), 'PYTHONDONTWRITEBYTECODE': '1', 'GETZILLA_SERIAL': '1'}
result = subprocess.run(command, cwd=ROOT / 'snapshot', env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=40)
(ROOT / 'baseline.log').write_text(result.stdout)
row = {'command': command, 'cwd': str(ROOT / 'snapshot'), 'environment': env, 'exit_code': result.returncode, 'summary': result.stdout.splitlines()[-4:]}
(ROOT / 'baseline-results.json').write_text(json.dumps(row, indent=2) + '\n')
print(json.dumps(row, indent=2))
