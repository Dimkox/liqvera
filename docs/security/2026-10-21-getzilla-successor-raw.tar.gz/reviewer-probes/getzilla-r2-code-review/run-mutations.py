from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parent
SNAP = ROOT / 'snapshot'
env = {'PATH': '/usr/bin:/bin', 'TMPDIR': str(ROOT / 'tmp'),
       'PYTHONDONTWRITEBYTECODE': '1', 'GETZILLA_SERIAL': '1'}
command = ['taskset', '-c', '0-5', 'python3', '-B', '-m', 'unittest', '-v',
           'tests.test_verification_dispositions.DispositionTests.test_address_shape_does_not_admit_credential_names_or_opaque_values',
           'tests.test_verification_dispositions.DispositionTests.test_real_scanner_suffix_never_disposes_unicode_or_escaped_credentials']
path = SNAP / '.getzilla/getzilla/verification_dispositions.py'
original = path.read_text()
results = []
for name, old, new in [
    ('M1-remove-context-guard', ' and _standalone_context(text, match.start())', ''),
    ('M2-remove-member-context-rejection', "    return previous not in {'.', ':', '?', '>'}", '    return True'),
]:
    assert original.count(old) == 1
    try:
        path.write_text(original.replace(old, new))
        result = subprocess.run(command, cwd=SNAP, env=env, text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=30)
        (ROOT / (name + '.log')).write_text(result.stdout)
        row = {'name': name, 'command': command, 'cwd': str(SNAP), 'environment': env,
               'replacement': {'old': old, 'new': new}, 'exit_code': result.returncode,
               'classification': 'killed' if result.returncode else 'survived',
               'summary': [line for line in result.stdout.splitlines() if line.startswith(('Ran ', 'FAILED', 'OK'))]}
        results.append(row)
        print(json.dumps(row), flush=True)
    finally:
        path.write_text(original)
subprocess.run(['git', 'diff', '--exit-code'], cwd=SNAP, check=True)
(ROOT / 'mutation-results.json').write_text(json.dumps(results, indent=2) + '\n')
