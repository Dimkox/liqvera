from __future__ import annotations
import json, sys
from pathlib import Path
scratch=Path(__file__).resolve().parent
sys.path.insert(0,str(scratch/'source'/'tests'))
from test_verification_dispositions import DispositionTests, ADDRESS, digest, _secret_scan
from getzilla.verification_dispositions import SECRET_PATTERNS, location
cases=[
    ('standalone', 'token', 'pass'),
    ('ascii_credential', 'auth_token', 'fail'),
    ('attached_property', 'client.token', 'fail'),
    ('zwnj_credential', 'auth\u200ctoken', 'fail'),
    ('zwj_credential', 'auth\u200dtoken', 'fail'),
    ('combining_credential', 'auth\u0301token', 'fail'),
    ('spaced_property', 'client. token', 'fail'),
    ('newline_property', 'client.\n token', 'fail'),
    ('comment_property', 'client./* member */token', 'fail'),
    ('spaced_comment_property', 'client. /* member */ token', 'fail'),
    ('optional_chain_property', 'client?. token', 'fail'),
    ('escaped_credential', r'auth\u{005F}token', 'fail'),
]
results=[]
for label,prefix,expected in cases:
    fixture=DispositionTests()
    fixture.setUp()
    try:
        text=prefix+' = '+repr(ADDRESS)+'\n'
        match=SECRET_PATTERNS['generic-secret'].search(text)
        assert match
        line,column=location(text,match.start())
        entry=fixture.entry(text=text,line=line,column=column)
        entry['match_sha256']=digest(match.group().encode())
        fixture.policy([entry])
        result=_secret_scan(fixture.root,['protocol.ts'])
        findings=[{'code':x['code'],'severity':x.get('severity'),'effective_severity':x.get('effective_severity'),'line':x.get('line'),'column':x.get('column')} for x in result.details if x['code']!='disposition-summary']
        results.append({'case':label,'prefix_escaped':prefix.encode('unicode_escape').decode(),'expected':expected,'actual':result.status,'findings':findings})
    finally:
        fixture.doCleanups()
output={'source_head':'98ff57375f95cc93e5f3cc785a8105f23743d0a3','source_tree':'52ffc8f3b4e8acec6c0f618cf062d388e84b6782','cases':results,'unexpected_passes':sum(x['expected']=='fail' and x['actual']=='pass' for x in results)}
(scratch/'boundary-probe.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
