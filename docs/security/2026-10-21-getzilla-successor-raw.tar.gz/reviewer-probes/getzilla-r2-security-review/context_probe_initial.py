from __future__ import annotations
import json, sys
from pathlib import Path
scratch=Path(__file__).resolve().parent
sys.path.insert(0,str(scratch/'source'/'tests'))
from test_verification_dispositions import DispositionTests, ADDRESS, digest, _secret_scan, _git_diff_check, GitRangeSelection
from getzilla.verification_dispositions import SECRET_PATTERNS, location
cases=[
    ('declaration', 'const ', ';\n', 'pass'),
    ('compact_comma_declaration', 'const other=1, ', ';\n', 'pass'),
    ('compact_object_field', 'const data={other:1, ', '};\n', 'pass'),
    ('completed_string_punctuation', 'const note = "client. // ; {"; const ', ';\n', 'pass'),
    ('completed_escaped_string', 'const note = "say \\"quoted\\""; const ', ';\n', 'pass'),
    ('completed_comment_punctuation', '/* . // ` \\" ; { */ const ', ';\n', 'pass'),
    ('completed_line_comment', '// . ` \\" ; {\r\nconst ', ';\n', 'pass'),
    ('member_comment_punctuation', 'client. /* \\" ` ; { */ ', ';\n', 'fail'),
    ('member_multiple_comments', 'client. /* one */\n// two ; {\n ', ';\n', 'fail'),
    ('member_escaped_newline', 'client.\\\n ', ';\n', 'fail'),
    ('inside_ordinary_string', 'const note = "example ', '";\n', 'fail'),
    ('inside_line_comment', '// example ', '\n', 'fail'),
    ('inside_block_comment', '/* example ', ' */\n', 'fail'),
    ('completed_regex', 'const pattern = /foo/; const ', ';\n', 'fail'),
    ('division_before_match', 'const ratio = 2 / 1; const ', ';\n', 'fail'),
    ('completed_template', 'const note = `example`; const ', ';\n', 'fail'),
    ('template_interpolation', 'const note = `${( ', ')}`;\n', 'fail'),
    ('earlier_code_escape', r'const auth\u{005F}name=1; const ', ';\n', 'fail'),
    ('non_ascii_separator', 'const \u00a0', ';\n', 'fail'),
    ('namespace_access', 'client:: /* note */ ', ';\n', 'fail'),
    ('pointer_access', 'client-> /* note */ ', ';\n', 'fail'),
]
results=[]
for label,prefix,suffix,expected in cases:
    fixture=DispositionTests()
    fixture.setUp()
    try:
        assignment='token = '+repr(ADDRESS)
        text=prefix+assignment+suffix
        match=SECRET_PATTERNS['generic-secret'].search(text)
        assert match
        line,column=location(text,match.start())
        entry=fixture.entry(text=text,line=line,column=column)
        entry['match_sha256']=digest(match.group().encode())
        fixture.policy([entry])
        scan=_secret_scan(fixture.root,['protocol.ts'])
        diff=_git_diff_check(fixture.root,'fast',GitRangeSelection())
        raw=next(item for item in scan.details if item.get('code')=='generic-secret')
        results.append({'case':label,'expected':expected,'scan':scan.status,'whole_policy_check':diff.status,'raw_severity':raw.get('severity'),'effective_severity':raw.get('effective_severity'),'disposition_applied':'disposition' in raw})
    finally:
        fixture.doCleanups()
output={'source_head':'98ff57375f95cc93e5f3cc785a8105f23743d0a3','source_tree':'52ffc8f3b4e8acec6c0f618cf062d388e84b6782','cases':results,'mismatches':sum(item['expected']!=item['scan'] or item['expected']!=item['whole_policy_check'] for item in results)}
(scratch/'context-probe.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
assert output['mismatches']==0
