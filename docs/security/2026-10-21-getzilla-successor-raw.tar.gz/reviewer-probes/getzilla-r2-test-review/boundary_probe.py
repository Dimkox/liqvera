import hashlib
import json
import pathlib
import subprocess
import sys

SCRATCH = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(SCRATCH / 'snapshot'))
from tests.test_verification_dispositions import ADDRESS, DispositionTests
from getzilla.verification import _secret_scan
from getzilla.verification_dispositions import SECRET_PATTERNS, location

assignment = 'token = ' + repr(ADDRESS)
cases = [
    ('standalone', '', 'pass'),
    ('declaration', 'const ', 'pass'),
    ('after_comment', '/* reviewed */ const ', 'pass'),
    ('ascii_credential', 'auth_', 'fail'),
    ('ascii_member', 'client. ', 'fail'),
    ('zwnj_credential', 'auth\u200c', 'fail'),
    ('zwj_credential', 'auth\u200d', 'fail'),
    ('combining_credential', 'auth\u0301', 'fail'),
    ('escaped_credential', r'auth\u{61}', 'fail'),
    ('member_nbsp_then_ascii', 'client.\u00a0 ', 'fail'),
    ('member_ideographic_then_ascii', 'client.\u3000 ', 'fail'),
    ('member_unicode_line_separator', 'client.\u2028 ', 'fail'),
    ('member_bom_then_ascii', 'client.\ufeff ', 'fail'),
    ('member_nbsp_then_comment', 'client.\u00a0/* gap */ ', 'fail'),
]
if '--ascii-control-space-only' in sys.argv:
    cases = [
        ('member_form_feed', 'client.\f ', 'fail'),
        ('member_vertical_tab', 'client.\v ', 'fail'),
        ('member_tab', 'client.\t ', 'fail'),
        ('member_newline', 'client.\n ', 'fail'),
    ]
mismatches = 0
for label, prefix, expected in cases:
    fixture = DispositionTests(methodName='runTest')
    try:
        fixture.setUp()
        text = prefix + assignment + ';\n'
        match = next(SECRET_PATTERNS['generic-secret'].finditer(text))
        line, column = location(text, match.start())
        entry = fixture.entry(text=text, line=line, column=column)
        entry['match_sha256'] = hashlib.sha256(match.group().encode()).hexdigest()
        fixture.policy([entry])
        result = _secret_scan(fixture.root, ['protocol.ts'])
        summary = fixture.summary(result)
        source = SCRATCH / 'tmp' / (label + '.js')
        source.write_text(text)
        syntax = subprocess.run(['node', '--check', str(source)], capture_output=True, text=True)
        print(json.dumps({'case': label, 'prefix': prefix, 'expected': expected,
                          'actual': result.status, 'disposed': summary['disposed'],
                          'unresolved': summary['unresolved'], 'node_syntax_exit': syntax.returncode}), flush=True)
        assert syntax.returncode == 0, label
        mismatches += result.status != expected
    finally:
        fixture.doCleanups()
print(json.dumps({'cases': len(cases), 'mismatches': mismatches}), flush=True)
raise SystemExit(bool(mismatches))
