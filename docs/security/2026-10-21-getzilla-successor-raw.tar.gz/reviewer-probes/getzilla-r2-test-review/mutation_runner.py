import hashlib
import json
import pathlib
import subprocess

SCRATCH = pathlib.Path(__file__).resolve().parent
ROOT = SCRATCH / 'snapshot'
HELPER = '.getzilla/getzilla/verification_dispositions.py'
VERIFY = '.getzilla/getzilla/verification.py'
CASE = 'tests.test_verification_dispositions.DispositionTests.'
mutations = [
    ('M1_drop_context', HELPER, ' and _standalone_context(text, match.start())', '', [
        CASE + 'test_address_shape_does_not_admit_credential_names_or_opaque_values',
        CASE + 'test_real_scanner_suffix_never_disposes_unicode_or_escaped_credentials']),
    ('M2_drop_member_gate', HELPER, "return previous not in {'.', ':', '?', '>'}",
     'return True', [CASE + 'test_real_scanner_suffix_never_disposes_unicode_or_escaped_credentials']),
    ('M3_whitespace_classes', HELPER, r"whitespace = ' \t\r\n\f\v'",
     r"whitespace = ' \t\r\n'", ['tests.test_verification_dispositions']),
    ('M4_first_match_only', VERIFY, 'for match in pattern.finditer(text):',
     'for match in list(pattern.finditer(text))[:1]:', [
         CASE + 'test_absent_policy_keeps_every_match_blocking',
         CASE + 'test_one_disposition_never_suppresses_second_match_on_same_line']),
    ('M5_git_stderr_covered', VERIFY,
     'proc.returncode == 2 and not proc.stderr and parsed and bool(observations)',
     'proc.returncode == 2 and parsed and bool(observations)', [
         CASE + 'test_unknown_git_output_errors_and_selection_findings_cannot_be_disposed']),
    ('M6_wrong_git_layer', HELPER, "if layer == 'worktree':", 'if True:', [
        CASE + 'test_staged_and_worktree_eof_are_bound_to_their_own_bytes',
        CASE + 'test_current_worktree_hash_cannot_dispose_a_different_head_blob']),
]
results = []
for name, relative, old, new, cases in mutations:
    target = ROOT / relative
    original = target.read_bytes()
    text = original.decode()
    assert text.count(old) == 1, (name, text.count(old))
    command = ['taskset', '-c', '6-11', 'env', f'TMPDIR={SCRATCH / "tmp"}',
               'PYTHONDONTWRITEBYTECODE=1', 'GETZILLA_SERIAL=1',
               'python3', '-B', '-m', 'unittest', *cases]
    try:
        target.write_text(text.replace(old, new))
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=90)
    finally:
        target.write_bytes(original)
    assert target.read_bytes() == original
    output = result.stdout + result.stderr
    log = SCRATCH / 'logs' / (name + '.log')
    log.write_text(output)
    killed = result.returncode == 1 and 'FAIL:' in output and 'FAILED (failures=' in output
    outcome = 'killed' if killed else ('survived' if result.returncode == 0 else 'inconclusive')
    record = {'id': name, 'path': relative, 'old': old, 'new': new,
              'command': command, 'returncode': result.returncode, 'outcome': outcome,
              'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    results.append(record)
    print(json.dumps(record), flush=True)
(SCRATCH / 'mutation-results.json').write_text(json.dumps(results, indent=2) + '\n')
