from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PYTHON = '/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python'
env = {'PATH': '/usr/bin:/bin', 'TMPDIR': str(ROOT / 'tmp'),
       'PYTHONDONTWRITEBYTECODE': '1', 'GETZILLA_SERIAL': '1'}
name = sys.argv[1]
if name == 'focused':
    args = ['-m', 'unittest', '-v', 'tests.test_verification_dispositions']
elif name == 'package':
    args = ['-m', 'unittest', '-v', 'tests.test_manifest_package.ManifestTests.test_disposition_helper_ships_without_target_review_policy']
else:
    args = [str(ROOT / 'context-probes.py')]
command = ['taskset', '-c', '0-5', PYTHON, '-B', *args]
with (ROOT / (name + '.log')).open('w') as out:
    try:
        result = subprocess.run(command, cwd=ROOT / 'snapshot', env=env, text=True,
                                stdout=out, stderr=subprocess.STDOUT, timeout=120)
        returncode = result.returncode
    except subprocess.TimeoutExpired:
        returncode = 124
output = (ROOT / (name + '.log')).read_text()
row = {'command': command, 'cwd': str(ROOT / 'snapshot'), 'environment': env,
       'exit_code': returncode, 'summary': output.splitlines()[-4:]}
(ROOT / (name + '-result.json')).write_text(json.dumps(row, indent=2) + '\n')
print(json.dumps(row, indent=2))
assert returncode == 0
