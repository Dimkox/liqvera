from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parent
SNAP = ROOT / 'snapshot'
PYTHON = '/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python'
env = {'PATH': '/usr/bin:/bin', 'TMPDIR': str(ROOT / 'tmp'),
       'PYTHONDONTWRITEBYTECODE': '1', 'GETZILLA_SERIAL': '1'}
path = SNAP / '.getzilla/getzilla/verification_dispositions.py'
original = path.read_text()
results = []
for name, old, new, selected in [
    ('M1-remove-complete-prefix-ascii-guard', '    if not text[:end].isascii():\n        return False\n', '',
     'test_non_ascii_comment_and_string_prefixes_are_conservatively_refused'),
    ('M2-remove-supported-code-alphabet', "or not (char.isalnum() or char in '_$()[]{}.,:;=+-*!&|%?^~<>')):", 'or False):',
     'test_unsupported_ascii_constructs_cannot_manufacture_standalone_context'),
]:
    assert original.count(old) == 1
    command = ['taskset', '-c', '0-5', PYTHON, '-B', '-m', 'unittest', '-v',
               'tests.test_verification_dispositions.DispositionTests.' + selected]
    try:
        path.write_text(original.replace(old, new))
        with (ROOT / (name + '.log')).open('w') as output:
            result = subprocess.run(command, cwd=SNAP, env=env, text=True,
                                    stdout=output, stderr=subprocess.STDOUT, timeout=45)
        log = (ROOT / (name + '.log')).read_text()
        row = {'name': name, 'command': command, 'cwd': str(SNAP), 'environment': env,
               'replacement': {'old': old, 'new': new}, 'exit_code': result.returncode,
               'classification': 'killed' if result.returncode else 'survived',
               'summary': [line for line in log.splitlines() if line.startswith(('Ran ', 'FAILED', 'OK'))]}
        results.append(row)
        print(json.dumps(row), flush=True)
    finally:
        path.write_text(original)
subprocess.run(['git', 'diff', '--exit-code'], cwd=SNAP, check=True)
(ROOT / 'mutation-results.json').write_text(json.dumps(results, indent=2) + '\n')
