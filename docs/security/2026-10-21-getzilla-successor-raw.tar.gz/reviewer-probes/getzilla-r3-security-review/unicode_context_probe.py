from __future__ import annotations
import json, subprocess, sys
from pathlib import Path
scratch=Path(__file__).resolve().parent
sys.path.insert(0,str(scratch/'source'/'tests'))
from test_verification_dispositions import DispositionTests, ADDRESS, digest, _secret_scan
from getzilla.verification_dispositions import SECRET_PATTERNS, location
cases=[('standalone','const ', 'pass'),('ascii_member','const client={}; client. ', 'fail')]
for name,space in [('nbsp','\u00a0'),('bom','\ufeff'),('line_separator','\u2028'),('ideographic','\u3000')]:
    cases.append((name+'_member','const client={}; client.'+space+' ', 'fail'))
cases.append(('nbsp_comment_member','const client={}; client.\u00a0/* gap */ ', 'fail'))
for name,separator in [('line_separator','\u2028'),('paragraph_separator','\u2029')]:
    cases.append((name+'_ends_line_comment','const client={}; // reviewed'+separator+'client.\n ', 'fail'))
results=[]
for label,prefix,expected in cases:
    fixture=DispositionTests();fixture.setUp()
    try:
        text=prefix+'token = '+repr(ADDRESS)+';\n'
        match=SECRET_PATTERNS['generic-secret'].search(text)
        assert match
        line,column=location(text,match.start())
        entry=fixture.entry(text=text,line=line,column=column)
        entry['match_sha256']=digest(match.group().encode())
        fixture.policy([entry])
        result=_secret_scan(fixture.root,['protocol.ts'])
        raw=next(item for item in result.details if item.get('code')=='generic-secret')
        syntax=subprocess.run(['node','--check','-'],input=text,text=True,capture_output=True,check=False)
        results.append({'case':label,'prefix_escaped':prefix.encode('unicode_escape').decode(),'expected':expected,'actual':result.status,'raw_severity':raw.get('severity'),'effective_severity':raw.get('effective_severity'),'disposition_applied':'disposition' in raw,'node_syntax_exit':syntax.returncode})
    finally:
        fixture.doCleanups()
output={'source_head':'4c4cd124b2e382d3c6d8b19e2efe2c8fb45219ae','source_tree':'3dd0c14d38b13e618a736735d5eefb830295cf32','cases':results,'unexpected_passes':sum(x['expected']=='fail' and x['actual']=='pass' for x in results)}
(scratch/'unicode-context-probe.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
