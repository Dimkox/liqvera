import hashlib
import json
import pathlib
import subprocess
import sys

SCRATCH = pathlib.Path(__file__).resolve().parent
ROOT = SCRATCH / 'snapshot'
HELPER = '.getzilla/getzilla/verification_dispositions.py'
VERIFY = '.getzilla/getzilla/verification.py'
CASE = 'tests.test_verification_dispositions.DispositionTests.'
mutations = [
    ('M1_drop_context', HELPER, ' and _standalone_context(text, match.start())', '', [
        'test_address_shape_does_not_admit_credential_names_or_opaque_values',
        'test_real_scanner_suffix_never_disposes_unicode_or_escaped_credentials']),
    ('M2_drop_prefix_ascii', HELPER, 'if not text[:end].isascii():', 'if False:', [
        'test_non_ascii_comment_and_string_prefixes_are_conservatively_refused']),
    ('M3_whitespace_classes', HELPER, r"whitespace = ' \t\r\n\f\v'",
     r"whitespace = ' \t\r\n'", [
         'test_ascii_whitespace_preserves_declarations_and_member_rejection']),
    ('M4_drop_html_guard', HELPER, "text.startswith(('<!--', '-->'), index)", 'False', [
        'test_unsupported_ascii_constructs_cannot_manufacture_standalone_context']),
    ('M5_drop_member_gate', HELPER, "return previous not in {'.', ':', '?', '>'}",
     'return True', ['test_ascii_whitespace_preserves_declarations_and_member_rejection']),
    ('M6_wrong_git_layer', HELPER, "if layer == 'worktree':", 'if True:', [
        'test_staged_and_worktree_eof_are_bound_to_their_own_bytes',
        'test_current_worktree_hash_cannot_dispose_a_different_head_blob']),
    ('M7_git_stderr_covered', VERIFY,
     'proc.returncode == 2 and not proc.stderr and parsed and bool(observations)',
     'proc.returncode == 2 and parsed and bool(observations)', [
         'test_unknown_git_output_errors_and_selection_findings_cannot_be_disposed']),
]
results = []
for name, relative, old, new, cases in mutations:
    target = ROOT / relative
    original = target.read_bytes()
    text = original.decode()
    assert text.count(old) == 1, (name, text.count(old))
    command = ['taskset', '-c', '6-11', 'env', f'TMPDIR={SCRATCH / "tmp"}',
               'PYTHONDONTWRITEBYTECODE=1', 'GETZILLA_SERIAL=1',
               sys.executable, '-B', '-m', 'unittest', *[CASE + case for case in cases]]
    try:
        target.write_text(text.replace(old, new))
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=120)
    finally:
        target.write_bytes(original)
    assert target.read_bytes() == original
    output = result.stdout + result.stderr
    log = SCRATCH / 'logs' / (name + '.log')
    log.write_text(output)
    killed = result.returncode == 1 and 'FAIL:' in output and 'FAILED (failures=' in output
    outcome = 'killed' if killed else ('survived' if result.returncode == 0 else 'inconclusive')
    record = {'id': name, 'path': relative, 'old': old, 'new': new,
              'command': command, 'returncode': result.returncode, 'outcome': outcome,
              'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    results.append(record)
    print(json.dumps(record), flush=True)
    (SCRATCH / 'mutation-results.json').write_text(json.dumps(results, indent=2) + '\n')
