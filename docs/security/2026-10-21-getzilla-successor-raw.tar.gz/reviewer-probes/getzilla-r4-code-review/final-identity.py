from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

S = Path(__file__).resolve().parent
C = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final')
R = S / 'snapshot'
before = json.loads((S / 'source-before.json').read_text())
def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()
after = {'at': datetime.now(timezone.utc).isoformat(),
         'head': git(C, 'rev-parse', 'HEAD'), 'tree': git(C, 'rev-parse', 'HEAD^{tree}'),
         'status': git(C, 'status', '--porcelain=v1', '--untracked-files=all'),
         'source_sha256': {p: hashlib.sha256((C / p).read_bytes()).hexdigest()
                           for p in before['source_sha256']},
         'scratch_index_tree': git(R, 'write-tree'),
         'scratch_worktree_diff': git(R, 'diff', '--name-only'),
         'scratch_untracked': git(R, 'ls-files', '--others', '--exclude-standard')}
assert after['head'] == before['head']
assert after['tree'] == before['tree'] == after['scratch_index_tree']
assert after['source_sha256'] == before['source_sha256']
assert not after['status'] and not after['scratch_worktree_diff'] and not after['scratch_untracked']
after['reviewed-tree-modified'] = 'no'
(S / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
print(json.dumps({k: v for k, v in after.items() if k != 'source_sha256'}, indent=2))
print('Changed-path byte hashes unchanged:', len(after['source_sha256']))
