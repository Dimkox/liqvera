import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

S = Path(__file__).resolve().parent
R = S / 'snapshot'
PY = '/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python'
sys.path[:0] = [str(R), str(R / '.getzilla')]
from tests._support import project_copy

E = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'TMPDIR': '/home/pall/.g4-code-tmp',
     'PYTHONDONTWRITEBYTECODE': '1', 'GETZILLA_SERIAL': '1',
     'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1'}
foreign = R / '.getzilla/getzilla'
def hashes():
    return {str(p.relative_to(foreign)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in foreign.rglob('*.py')}
before = hashes()
records = []
for missing in ('init', 'package'):
    with project_copy() as root:
        package = root / '.getzilla/getzilla'
        if missing == 'init':
            (package / '__init__.py').unlink()
        else:
            shutil.rmtree(package)
        env = dict(E, PYTHONPATH=os.pathsep.join((str(R / '.getzilla'), str(root / '.getzilla'))))
        command = ['taskset', '-c', '0-3', PY, '-B', '-v', str(root / '.grok/hooks/pre_tool_use.py')]
        payload = {'cwd': str(root), 'tool_name': 'Bash', 'tool_input': {'command': 'rm -rf build'}}
        result = subprocess.run(command, input=json.dumps(payload), cwd=root, env=env,
                                capture_output=True, text=True, timeout=30)
        (S / f'missing-{missing}.stderr').write_text(result.stderr)
        data = json.loads(result.stdout)
        event_path = root / '.getzilla/runtime/hook-events.jsonl'
        events = [json.loads(line) for line in event_path.read_text().splitlines()] if event_path.exists() else []
        imported = [line for line in result.stderr.splitlines()
                    if str(foreign) in line and '.py' in line]
        record = {'missing': missing, 'command': command, 'cwd': str(root), 'environment': env,
                  'synthetic_payload_not_executed': payload, 'exit': result.returncode,
                  'response': data, 'degraded_events': events, 'foreign_import_trace': imported,
                  'expected_decision': 'deny', 'actual_decision': data.get('decision') or data.get('hookSpecificOutput', {}).get('permissionDecision')}
        records.append(record)
        assert result.returncode == 0 and imported
        assert record['actual_decision'] == 'allow' and not events
after = hashes()
assert before == after
(S / 'package-absence-results.json').write_text(json.dumps({'records': records,
    'foreign_before': before, 'foreign_after': after}, indent=2) + '\n')
print(json.dumps({'observed_blocker': [{'missing': r['missing'], 'decision': r['actual_decision'],
    'degraded_events': len(r['degraded_events']), 'foreign_import_trace_count': len(r['foreign_import_trace'])} for r in records],
    'foreign_stack_unchanged': before == after}, indent=2))
