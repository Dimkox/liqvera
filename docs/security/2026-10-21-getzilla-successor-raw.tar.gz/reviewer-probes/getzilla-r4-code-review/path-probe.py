import importlib.util, json, pathlib, sys
S=pathlib.Path(__file__).resolve().parent; R=S/'snapshot'; foreign=str(S/'foreign-stack'); own=str(R/'.getzilla')
sys.path[:0]=[foreign,own,foreign,own]
others=[p for p in sys.path if p!=own]
spec=importlib.util.spec_from_file_location('reviewed_hook_library',R/'.grok/hooks/_lib.py')
module=importlib.util.module_from_spec(spec); sys.modules[spec.name]=module; spec.loader.exec_module(module)
assert sys.path[0]==own and sys.path.count(own)==1
assert sys.path[1:]==others, 'Unrelated search paths must survive in their original order'
assert pathlib.Path(module.fsx.__file__).resolve().is_relative_to(pathlib.Path(own))
import foreign_only_marker
assert foreign_only_marker.VALUE=='foreign path retained'
print(json.dumps({'own_first':True,'own_count':sys.path.count(own),'foreign_entries_retained':sys.path.count(foreign),'foreign_module_resolves':True,'loaded_fsx':module.fsx.__file__}))
