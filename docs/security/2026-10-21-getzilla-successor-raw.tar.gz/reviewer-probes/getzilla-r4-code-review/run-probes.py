import hashlib,json,pathlib,subprocess,time
S=pathlib.Path(__file__).resolve().parent; R=S/'snapshot'; T=pathlib.Path('/home/pall/.g4-code-tmp')
PY='/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python'
E={'PATH':'/usr/local/bin:/usr/bin:/bin','TMPDIR':str(T),'PYTHONDONTWRITEBYTECODE':'1','GETZILLA_SERIAL':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1'}
F=S/'foreign-stack'; (F/'getzilla').mkdir(parents=True)
(F/'getzilla/__init__.py').write_text("raise AssertionError('Foreign Getzilla must not load for the own hook')\n")
(F/'foreign_only_marker.py').write_text("VALUE='foreign path retained'\n")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
foreign_before={str(p.relative_to(F)):sha(p) for p in F.rglob('*') if p.is_file()}
records=[]
def run(name,args):
 command=['taskset','-c','0-3',PY,'-B',*args]; start=time.monotonic()
 with (S/(name+'.log')).open('w') as out: proc=subprocess.run(command,cwd=R,env=E,stdout=out,stderr=subprocess.STDOUT,timeout=90)
 rec={'name':name,'command':command,'cwd':str(R),'environment':E,'exit':proc.returncode,'seconds':round(time.monotonic()-start,3),'log':str(S/(name+'.log'))}; records.append(rec); print(json.dumps(rec),flush=True); return rec
hook='tests.test_hook_degraded.HookDegradedTests.'
arch='tests.test_architecture_fitness.ArchitectureFitnessTests.'
disp='tests.test_verification_dispositions.DispositionTests.'
controls=['-m','unittest','-v',hook+'test_own_stack_precedes_foreign_pythonpath_when_local_imports_break',hook+'test_verify_fails_high_risk_pr_with_degraded_hooks',hook+'test_healthy_hook_records_nothing',arch+'test_queue_capacity_covers_measured_repository_closure',arch+'test_queue_capacity_exact_boundaries_remain_fail_closed',disp+'test_exact_public_occurrence_retains_raw_severity_and_sanitized_identity',disp+'test_one_disposition_never_suppresses_second_match_on_same_line',disp+'test_committed_markdown_eof_retains_real_exit_output_and_all_ranges']
try:
 assert run('baseline-path',[str(S/'path-probe.py')])['exit']==0
 assert run('baseline-controls',controls)['exit']==0
 mutations=[('M1-own-priority-reverted','.grok/hooks/_lib.py',"sys.path[:] = [str(STACK), *(path for path in sys.path if path != str(STACK))]","if str(STACK) not in sys.path:\n    sys.path.insert(0, str(STACK))"),('M2-degraded-protected-shell-open','.grok/hooks/pre_tool_use.py','if _DEGRADED_PROTECTED_SHELL.search(command):','if False:')]
 for name,path,old,new in mutations:
  p=R/path; original=p.read_bytes(); text=original.decode(); assert text.count(old)==1
  try:
   p.write_text(text.replace(old,new,1))
   rec=run(name,['-m','unittest','-v',hook+'test_own_stack_precedes_foreign_pythonpath_when_local_imports_break']); rec.update(mutation={'path':path,'before':old,'after':new},outcome='killed' if rec['exit'] else 'survived')
   if name.startswith('M1'):
    extra=run(name+'-path',[str(S/'path-probe.py')]); extra['outcome']='killed' if extra['exit'] else 'survived'
  finally:p.write_bytes(original)
 assert run('restored-hook',['-m','unittest','-v',hook+'test_own_stack_precedes_foreign_pythonpath_when_local_imports_break'])['exit']==0
 assert run('restored-path',[str(S/'path-probe.py')])['exit']==0
finally:
 foreign_after={str(p.relative_to(F)):sha(p) for p in F.rglob('*') if p.is_file()}
 (S/'probe-results.json').write_text(json.dumps({'records':records,'foreign_before':foreign_before,'foreign_after':foreign_after},indent=2)+'\n')
 assert foreign_before==foreign_after
 assert not subprocess.check_output(['git','-C',str(R),'diff','--name-only'])
