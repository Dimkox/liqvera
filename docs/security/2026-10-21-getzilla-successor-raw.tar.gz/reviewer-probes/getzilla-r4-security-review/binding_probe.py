from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
scratch=Path(__file__).resolve().parent
sys.path.insert(0,str(scratch/'source'/'tests'))
from test_verification_dispositions import DispositionTests, ADDRESS, ASSIGNMENT, CONFIG, EVIDENCE, digest, _secret_scan
cases=['strict_default','exact_binding','stale_target_outside_selection','stale_evidence_outside_selection','stale_match_outside_selection','unknown_field_outside_selection','untracked_policy','additional_occurrence','other_secret_rules','whitespace_raw_status']
rows=[]
for case in cases:
    f=DispositionTests();f.setUp()
    try:
        if case=='whitespace_raw_status':
            entry=f.entry(path='history.md',text='record\n\n',whitespace=True,line=2)
            f.policy([entry]);f.commit()
            result=f.range_check()
            commands=[x for x in result.details if x.get('code')=='diff-check-command']
            observations=[x for x in result.details if x.get('observation')]
            assert result.status=='pass'
            assert [x['exit_code'] for x in commands]==[0,0,2]
            assert len(observations)==1 and observations[0]['severity']=='error' and observations[0]['effective_severity']=='info'
            assert 'new blank line at EOF.' in commands[-1]['stdout'] and not commands[-1]['stderr']
            rows.append({'case':case,'status':result.status,'observed':len(observations),'raw_exit_codes':[x['exit_code'] for x in commands],'raw_error_retained':True})
            continue
        text=ASSIGNMENT+'\n'
        if case=='additional_occurrence':text+=ASSIGNMENT+'\n'
        if case=='other_secret_rules':text+='password = '+repr('synthetic-placeholder-only')+'\n'+'-----BEGIN '+'PRIVATE KEY-----\n'+'AKIA'+'Z'*16+'\n'
        entry=f.entry(text=text)
        if case=='stale_match_outside_selection':entry['match_sha256']='0'*64
        if case=='unknown_field_outside_selection':entry['scope']='all'
        if case!='strict_default':f.policy([entry])
        if case=='stale_target_outside_selection':f.write('protocol.ts',(text+'// changed\n').encode())
        if case=='stale_evidence_outside_selection':f.write(EVIDENCE,b'Changed evidence.\n')
        if case=='untracked_policy':f.git('rm','--cached','--',CONFIG)
        files=[] if case.endswith('_outside_selection') else ['protocol.ts']
        result=_secret_scan(f.root,files)
        summary=f.summary(result)
        assert result.status==('pass' if case=='exact_binding' else 'fail')
        assert ADDRESS not in json.dumps(result.to_dict())
        observations=[x for x in result.details if x.get('observation')]
        if case=='exact_binding':
            raw=observations[0]
            assert raw['severity']=='error' and raw['effective_severity']=='info'
            assert raw['file_sha256']==digest(text.encode())
            assert raw['disposition']['config_sha256']==digest((f.root/CONFIG).read_bytes())
            assert raw['disposition']['evidence']['sha256']==digest((f.root/EVIDENCE).read_bytes())
        if case.endswith('_outside_selection') or case=='untracked_policy':
            assert any(x.get('code')=='disposition-config-invalid' for x in result.details)
        if case=='additional_occurrence':assert (summary['observed'],summary['disposed'],summary['unresolved'])==(2,1,1)
        if case=='other_secret_rules':
            assert (summary['observed'],summary['disposed'],summary['unresolved'])==(4,1,3)
            for code in ['private-key','aws-access-key']:
                assert next(x for x in observations if x['code']==code)['effective_severity']=='error'
        rows.append({'case':case,'status':result.status,'observed':summary['observed'],'disposed':summary['disposed'],'unresolved':summary['unresolved'],'raw_error_count':sum(x['severity']=='error' for x in observations),'source_value_absent':True})
    finally:f.doCleanups()
output={'source_head':'b1ff3de3eb952521cacaa1119c88d2d6990c0545','source_tree':'88a830f5a18631cdfef4cf35b4866f466b06264c','cases':rows,'all_assertions_passed':True}
(scratch/'binding-probe.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
