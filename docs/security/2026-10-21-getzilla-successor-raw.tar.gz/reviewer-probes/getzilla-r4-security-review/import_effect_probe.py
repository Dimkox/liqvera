from pathlib import Path
import json
import subprocess
import sys
import unittest

source = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(source), str(source / '.getzilla')]
from tests.test_architecture_fitness import FIT, GitArchitectureRepo
from tests.test_architecture_model import _rules, _system

rows = []
for statement in ('import adapters.side_effect\n', 'from adapters.side_effect import value\n'):
    fixture = unittest.TestCase()
    try:
        repo = GitArchitectureRepo(fixture)
        system, rules = _system(), _rules()
        system['nodes'][0]['type'] = 'worker'
        system['nodes'][0]['repository_paths'] = ['adapters', 'src']
        rules['background_job_policies'] = [{
            'id':'FIT-JOBS','node_types':['worker'],'max_retries':3,
            'require_idempotency':True,'require_correlation_id':True,
            'terminal_actions':['dead_letter'],'severity':'error'}]
        repo.model(system,rules)
        repo.write_text('adapters/__init__.py','')
        repo.write_text('adapters/side_effect.py',
                        'from rq import Queue\nactive = Queue()\nactive.enqueue("job")\nvalue = 1\n')
        repo.write_text('adapters/facade.py',statement + 'def selected():\n    return 1\n')
        repo.write_text('src/consumer.py','')
        base = repo.commit('base')
        repo.write_text('src/consumer.py','from adapters.facade import selected\nselected()\n')
        head = repo.commit('changed operation')
        diff = FIT.diff_architecture(repo.root,base_sha=base,head_sha=head)
        report = FIT.evaluate_fitness(repo.root,FIT.load_architecture(repo.root),diff,
                                      diff.changed_paths,pre_risk='yellow')
        result = next(item for item in report.results if item.category=='background_job')
        rows.append({'case':statement.strip(),'expected':'unsupported','actual':result.status,
                     'new_queue':'new_queue' in report.triggers,
                     'claim_pass':result.status=='unsupported' and 'new_queue' in report.triggers})
    finally:
        fixture.doCleanups()
print(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),
                  'cases':rows},indent=2))
