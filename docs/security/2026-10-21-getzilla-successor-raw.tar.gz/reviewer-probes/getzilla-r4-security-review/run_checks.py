from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import os
import subprocess
import time

SCRATCH = Path(__file__).resolve().parent
SOURCE = SCRATCH / 'source'
PYTHON = '/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python'
ENV = {**os.environ, 'TMPDIR': '/home/pall/.gz-r4-sec', 'PYTHONDONTWRITEBYTECODE': '1',
       'PYTHONPATH': str(SOURCE / '.getzilla'), 'UV_PYTHON': PYTHON,
       'GIT_CONFIG_GLOBAL': str(SCRATCH / 'no-gitconfig'), 'GIT_CONFIG_NOSYSTEM': '1'}
checks = [
    ('focused-security-tests', SOURCE, ['-m','unittest',
        'tests.test_verification_dispositions','tests.test_hook_degraded','-v']),
    ('capacity-tests', SOURCE, ['-m','unittest',
        'tests.test_architecture_fitness.ArchitectureFitnessTests.test_queue_capacity_covers_measured_repository_closure',
        'tests.test_architecture_fitness.ArchitectureFitnessTests.test_queue_capacity_exact_boundaries_remain_fail_closed','-v']),
    ('unicode-context', SCRATCH, ['unicode_context_probe.py']),
    ('binding', SCRATCH, ['binding_probe.py']),
    ('boundary', SCRATCH, ['boundary_probe.py']),
]

def execute(item):
    name, cwd, args = item
    argv = ['taskset','-c','8-11',PYTHON,'-B',*args]
    start = time.monotonic()
    try:
        result = subprocess.run(argv, cwd=cwd, env=ENV, text=True, capture_output=True, timeout=180)
        record = {'name':name, 'argv':argv, 'cwd':str(cwd), 'exit':result.returncode,
                  'seconds':time.monotonic()-start}
        (SCRATCH / f'{name}.stdout').write_text(result.stdout)
        (SCRATCH / f'{name}.stderr').write_text(result.stderr)
    except subprocess.TimeoutExpired as exc:
        record = {'name':name,'argv':argv,'cwd':str(cwd),'timeout':True,'seconds':time.monotonic()-start}
        (SCRATCH / f'{name}.stdout').write_bytes(exc.stdout or b'')
        (SCRATCH / f'{name}.stderr').write_bytes(exc.stderr or b'')
    print(json.dumps(record), flush=True)
    return record

with ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(execute, checks))
(SCRATCH/'commands.json').write_text(json.dumps(results,indent=2)+'\n')
