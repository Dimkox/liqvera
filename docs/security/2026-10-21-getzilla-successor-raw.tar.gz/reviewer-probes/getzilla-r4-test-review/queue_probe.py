#!/usr/bin/env python3
"""Independent resolver edge probes; no queue jobs are executed."""
import json
import sys
from pathlib import Path

ROOT = Path('/home/pall/.cache/gzr4tr/src')
sys.path.insert(0, str(ROOT / '.getzilla'))
from getzilla import architecture_fitness as fit
from getzilla.architecture import ArchitectureError

assert (fit.MAX_QUEUE_ADAPTER_MODULES, fit.MAX_QUEUE_ADAPTER_DEPTH) == (64, 16)
DONE = fit._QueueAdapterResolution('not_queue', 'completed-probe')
rows = []


def check(name, *, module='adapters.new', seen=(), resolving=(), completed=False,
          known=True, expected_state=None, expected_error=None, expected_seen=None):
    visited = set(seen)
    active = set(resolving)
    cache = fit._QueueResolutionCache((module,) if known else (), (), {module: DONE} if completed else {})
    row = {'name': name, 'visited_before': len(visited), 'resolving_before': len(active)}
    try:
        result = fit._local_queue_resolution(ROOT, None, module, 'head', cache, active, visited, ())
        row.update(state=result.state, reason=result.reason, visited_after=len(visited))
        assert expected_error is None and result.state == expected_state, row
    except ArchitectureError as error:
        row.update(error=str(error), code=error.code, visited_after=len(visited))
        assert error.code == 'limit' and expected_error in str(error), row
    if expected_seen is not None:
        assert len(visited) == expected_seen, row
    rows.append(row)


check('64th new completed module admitted', seen=[f'adapters.m{i}' for i in range(63)],
      completed=True, expected_state='not_queue', expected_seen=64)
check('65th completed cache hit still charged', seen=[f'adapters.m{i}' for i in range(64)],
      completed=True, expected_error='module limit', expected_seen=64)
check('already visited cached module at limit reused', module='adapters.m0',
      seen=[f'adapters.m{i}' for i in range(64)], completed=True,
      expected_state='not_queue', expected_seen=64)
check('16th resolver level admitted', resolving=[f'adapters.m{i}' for i in range(15)],
      expected_state='not_queue', expected_seen=1)
check('17th resolver level rejected', resolving=[f'adapters.m{i}' for i in range(16)],
      expected_error='depth limit', expected_seen=1)
check('cycle at depth limit is recognized before overflow', module='adapters.m0',
      seen=[f'adapters.m{i}' for i in range(16)], resolving=[f'adapters.m{i}' for i in range(16)],
      expected_state='unsupported', expected_seen=16)
check('missing module consumes no module budget', known=False,
      seen=[f'adapters.m{i}' for i in range(64)], expected_state='not_queue', expected_seen=64)
check('invalid module consumes no module budget', module='bad-name',
      seen=[f'adapters.m{i}' for i in range(64)], expected_state='not_queue', expected_seen=64)

Path(__file__).with_name('independent-queue-cases.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps({'cases': len(rows), 'mismatches': 0, 'results': rows}, indent=2))
