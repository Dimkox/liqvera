#!/usr/bin/env python3
"""Bounded native controls and exact source mutants in the verified private snapshot."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

EVIDENCE = Path(__file__).parent
SOURCE = Path('/home/pall/.cache/gzr4tr/src')
TMP = Path('/home/pall/.cache/gzr4tr/t')
PYTHON = '/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python'
sys.path[:0] = [str(SOURCE), str(SOURCE / '.getzilla')]
from getzilla import python_test_runner

QUEUE = 'tests/test_architecture_fitness.py::ArchitectureFitnessTests::'
HOOK = 'tests/test_hook_degraded.py::HookDegradedTests::'
QUEUE_CASES = [
    QUEUE + 'test_queue_capacity_covers_measured_repository_closure',
    QUEUE + 'test_queue_capacity_exact_boundaries_remain_fail_closed',
    QUEUE + 'test_queue_adapter_cycle_at_depth_limit_does_not_enter_a_new_module',
    QUEUE + 'test_queue_adapter_resolution_bounds_fail_closed_only_for_possible_operations',
    QUEUE + 'test_local_queue_adapter_dependency_chains_do_not_silently_truncate',
    QUEUE + 'test_completed_queue_cache_is_charged_per_importer_before_reuse',
]
HOOK_CASES = [
    HOOK + 'test_own_stack_precedes_foreign_pythonpath_when_local_imports_break',
    HOOK + 'test_policy_import_failure_allows_and_records',
    HOOK + 'test_unimportable_lib_allows_and_records_with_stdlib_only',
    'tests/test_degraded_fail_closed.py::DegradedFailClosedTests::test_helper_library_that_does_not_import',
    'tests/test_degraded_fail_closed.py::DegradedFailClosedTests::test_policy_that_does_not_import',
    'tests/test_enforcement_report.py::EnforcementReportTests::test_self_test_proves_the_policy_runs',
]
INVENTORY = 'factory/tests/test_offline_release_builder.py::OfflineReleaseBuilderTests::test_committed_inventory_is_exactly_derived_from_uv_lock'


def save(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, indent=2) + '\n')


def execute(label, targets, *, native=True):
    env = python_test_runner._environment(SOURCE, EVIDENCE / '.coverage-unused')
    env['TMPDIR'] = str(TMP)
    if native:
        command = ['taskset', '-c', '4-7', *python_test_runner._pytest_command(4, 'worksteal'), *targets]
    else:
        command = ['taskset', '-c', '4-7', PYTHON, '-B', *targets]
    meta = {'cwd': str(SOURCE), 'command': command,
            'env': {k: env[k] for k in ('TMPDIR', 'PYTHONPATH', 'PYTHONDONTWRITEBYTECODE',
                                      'PYTEST_DISABLE_PLUGIN_AUTOLOAD', '_GETZILLA_TEST_CHILD')},
            'native_environment_builder': 'getzilla.python_test_runner._environment'}
    save(label + '-command.json', meta)
    started = time.monotonic()
    p = subprocess.run(command, cwd=SOURCE, env=env, capture_output=True, timeout=180)
    for stream in ('stdout', 'stderr'):
        (EVIDENCE / f'{label}.{stream}').write_bytes(getattr(p, stream))
    text = p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')
    result = {'label': label, 'returncode': p.returncode, 'seconds': round(time.monotonic() - started, 3),
              'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
              'stderr_sha256': hashlib.sha256(p.stderr).hexdigest(),
              'summary_lines': [line for line in text.splitlines()
                                if line.startswith(('FAILED ', 'SUBFAILED(', 'ERROR ', 'Ran '))
                                or ' passed' in line or ' failed' in line]}
    save(label + '-result.json', result)
    print(json.dumps(result), flush=True)
    return result


def baseline():
    result = execute('baseline-core', QUEUE_CASES + HOOK_CASES)
    assert result['returncode'] == 0
    result = execute('baseline-inventory', [INVENTORY])
    assert result['returncode'] == 0


def mutants():
    specs = [
        ('M1-module-guard', '.getzilla/getzilla/architecture_fitness.py',
         'if len(visited) >= MAX_QUEUE_ADAPTER_MODULES:', 'if False:',
         [QUEUE + 'test_queue_capacity_exact_boundaries_remain_fail_closed']),
        ('M2-depth-guard', '.getzilla/getzilla/architecture_fitness.py',
         'if len(resolving) >= MAX_QUEUE_ADAPTER_DEPTH:', 'if False:',
         [QUEUE + 'test_queue_capacity_exact_boundaries_remain_fail_closed',
          QUEUE + 'test_queue_adapter_cycle_at_depth_limit_does_not_enter_a_new_module']),
        ('M3-module-off-by-one', '.getzilla/getzilla/architecture_fitness.py',
         'if len(visited) >= MAX_QUEUE_ADAPTER_MODULES:', 'if len(visited) > MAX_QUEUE_ADAPTER_MODULES:',
         [QUEUE + 'test_queue_capacity_exact_boundaries_remain_fail_closed']),
        ('M4-hook-priority', '.grok/hooks/_lib.py',
         'sys.path[:] = [str(STACK), *(path for path in sys.path if path != str(STACK))]',
         'if str(STACK) not in sys.path:\n    sys.path.insert(0, str(STACK))',
         [HOOK + 'test_own_stack_precedes_foreign_pythonpath_when_local_imports_break']),
    ]
    outcomes = []
    for label, relative, old, new, tests in specs:
        target = SOURCE / relative
        original = target.read_bytes()
        text = original.decode()
        assert text.count(old) == 1
        changed = text.replace(old, new).encode()
        save(label + '-mutation.json', {'file': relative, 'old': old, 'new': new,
                                      'before_sha256': hashlib.sha256(original).hexdigest(),
                                      'mutant_sha256': hashlib.sha256(changed).hexdigest()})
        try:
            target.write_bytes(changed)
            outcome = execute(label, tests)
            outcomes.append(outcome)
        finally:
            target.write_bytes(original)
        assert target.read_bytes() == original
        save('mutation-results.json', outcomes)
    inventory = SOURCE / 'factory/runtime/runtime-wheels-linux-x86_64-cpython312.json'
    original = inventory.read_bytes()
    for label in ('M5-stale-certifi', 'M6-stale-lock-binding'):
        data = json.loads(original)
        if label == 'M5-stale-certifi':
            wheel = next(w for w in data['wheels'] if w['name'] == 'certifi')
            wheel.update(filename='certifi-2026.7.22-py3-none-any.whl', version='2026.7.22',
                         sha256='62f22742b58a1a33014a2b6b706588a8d7e2a88ae7bd1a6ebe8c992928483775')
        else:
            data['lock_sha256'] = '546b59e943616b6e114cd34fdf0a2d24d0ffde05598e11af447530c69d320900'
        changed = (json.dumps(data, indent=2) + '\n').encode()
        save(label + '-mutation.json', {'file': str(inventory.relative_to(SOURCE)),
                                      'before_sha256': hashlib.sha256(original).hexdigest(),
                                      'mutant_sha256': hashlib.sha256(changed).hexdigest(),
                                      'mutation': 'restore old certifi row only' if label == 'M5-stale-certifi' else 'restore old lock digest only'})
        try:
            inventory.write_bytes(changed)
            outcomes.append(execute(label, [INVENTORY]))
        finally:
            inventory.write_bytes(original)
        assert inventory.read_bytes() == original
        save('mutation-results.json', outcomes)


if __name__ == '__main__':
    if sys.argv[1] == 'baseline':
        baseline()
    elif sys.argv[1] == 'mutants':
        mutants()
    elif sys.argv[1] == 'independent':
        result = execute('independent-queue', [str(EVIDENCE / 'queue_probe.py')], native=False)
        assert result['returncode'] == 0
    else:
        raise SystemExit('unknown action')
