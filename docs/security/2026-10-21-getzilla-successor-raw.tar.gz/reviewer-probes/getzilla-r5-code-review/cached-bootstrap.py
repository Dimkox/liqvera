import runpy, sys
if sys.argv[1] == "cached-own":
    sys.path.insert(0, sys.argv[2])
import getzilla
print("CACHED_ORIGIN=" + str(getzilla.__file__), file=sys.stderr)
sys.path.insert(0, sys.argv[3])
runpy.run_path(sys.argv[4], run_name="__main__")
