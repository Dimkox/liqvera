import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

S = Path(__file__).resolve().parent
R = S / 'snapshot'
PY = '/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python'
sys.path[:0] = [str(R), str(R / '.getzilla')]
from tests._support import project_copy

E = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'TMPDIR': '/home/pall/.g4-code-tmp',
     'PYTHONDONTWRITEBYTECODE': '1', 'GETZILLA_SERIAL': '1',
     'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1'}
F = R / '.getzilla/getzilla'
def hashes():
    return {str(p.relative_to(F)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in F.rglob('*.py')}
before = hashes()
bootstrap = S / 'cached-bootstrap.py'
bootstrap.write_text('import runpy, sys\n'
    'if sys.argv[1] == "cached-own":\n'
    '    sys.path.insert(0, sys.argv[2])\n'
    'import getzilla\n'
    'print("CACHED_ORIGIN=" + str(getzilla.__file__), file=sys.stderr)\n'
    'sys.path.insert(0, sys.argv[3])\n'
    'runpy.run_path(sys.argv[4], run_name="__main__")\n')
records = []
for scenario in ('healthy', 'missing-init', 'missing-package', 'cached-foreign', 'cached-own'):
    with project_copy() as root:
        package = root / '.getzilla/getzilla'
        if scenario == 'missing-init':
            (package / '__init__.py').unlink()
        elif scenario == 'missing-package':
            shutil.rmtree(package)
        own_stack = root / '.getzilla'
        env = dict(E, PYTHONPATH=os.pathsep.join((str(R / '.getzilla'), str(own_stack))))
        script = root / '.grok/hooks/pre_tool_use.py'
        args = ([str(bootstrap), scenario, str(own_stack), str(script.parent), str(script)]
                if scenario.startswith('cached-') else [str(script)])
        command = ['taskset', '-c', '0-3', PY, '-B', '-v', *args]
        degraded = scenario in ('missing-init', 'missing-package', 'cached-foreign')
        cases = [('Read', {'file_path': 'AGENTS.md'}, 'allow')]
        if degraded:
            cases.append(('Bash', {'command': 'rm -rf build'}, 'deny'))
        for index, (tool, inputs, expected) in enumerate(cases, 1):
            payload = {'cwd': str(root), 'tool_name': tool, 'tool_input': inputs}
            result = subprocess.run(command, input=json.dumps(payload), cwd=root, env=env,
                                    capture_output=True, text=True, timeout=30)
            (S / f'{scenario}-{tool}.stderr').write_text(result.stderr)
            data = json.loads(result.stdout)
            event_path = root / '.getzilla/runtime/hook-events.jsonl'
            events = [json.loads(line) for line in event_path.read_text().splitlines()] if event_path.exists() else []
            foreign_trace = [line for line in result.stderr.splitlines() if str(F) in line and '.py' in line]
            cached_origin = [line for line in result.stderr.splitlines() if line.startswith('CACHED_ORIGIN=')]
            record = {'scenario': scenario, 'command': command, 'cwd': str(root), 'environment': env,
                      'synthetic_payload_not_executed': payload, 'exit': result.returncode,
                      'response': data, 'expected': expected, 'degraded_events': events,
                      'foreign_import_trace': foreign_trace, 'cached_origin': cached_origin}
            records.append(record)
            actual = data.get('decision') or data.get('hookSpecificOutput', {}).get('permissionDecision')
            assert result.returncode == 0 and actual == expected, record
            assert len(events) == (index if degraded else 0), record
            if scenario != 'cached-foreign':
                assert not foreign_trace, record
            else:
                assert cached_origin == ['CACHED_ORIGIN=' + str(F / '__init__.py')], record
                assert foreign_trace and all('__init__.py' in line for line in foreign_trace), record
            if scenario == 'cached-own':
                assert cached_origin == ['CACHED_ORIGIN=' + str(package / '__init__.py')], record
            if degraded:
                assert all(e['kind'] == 'HOOK_DEGRADED' and e['hook'] == 'pre_tool_use'
                           and 'Getzilla package' in e['error'] for e in events), record
after = hashes()
assert before == after
(S / 'closure-results.json').write_text(json.dumps({'records': records, 'foreign_before': before,
    'foreign_after': after}, indent=2) + '\n')
print(json.dumps({'classifications_passed': len(records), 'scenarios': 5,
                  'foreign_stack_unchanged': before == after}, indent=2))
