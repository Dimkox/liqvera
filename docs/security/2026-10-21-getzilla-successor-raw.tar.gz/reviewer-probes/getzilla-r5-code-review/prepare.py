from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile

S = Path(__file__).resolve().parent
C = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final')
R = S / 'snapshot'
T = Path('/home/pall/.g4-code-tmp')
HEAD = '3968ae4445836eda9cf377035b1d1f64fe9659b0'
TREE = '5e0c8153899219b238a3ff63f064665eb28f41ca'
BASE = 'e158ddc7263a55f5308944c5a426eb1e9f1a4327'
PRIOR = 'b1ff3de3eb952521cacaa1119c88d2d6990c0545'
E = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'TMPDIR': str(T),
     'PYTHONDONTWRITEBYTECODE': '1', 'GETZILLA_SERIAL': '1',
     'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1'}
def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], env=E, text=True).strip()
for p in (S, T):
    assert p.resolve() == p and stat.S_IMODE(p.stat().st_mode) == 0o700
    for parent in (p, *p.parents):
        mode = parent.stat().st_mode
        assert not mode & (stat.S_IWGRP | stat.S_IWOTH | stat.S_ISVTX), str(parent)
        assert parent.stat().st_uid in (0, os.getuid())
assert subprocess.run(['git', '-C', str(T), 'rev-parse', '--show-toplevel'], env=E,
                      capture_output=True).returncode != 0
assert git(C, 'rev-parse', 'HEAD') == HEAD
assert git(C, 'rev-parse', 'HEAD^{tree}') == TREE
assert not git(C, 'status', '--porcelain=v1', '--untracked-files=all')
paths = git(C, 'diff', '--name-only', BASE, HEAD).splitlines()
delta = git(C, 'diff', '--name-only', PRIOR, HEAD).splitlines()
before = {'at': datetime.now(timezone.utc).isoformat(), 'head': HEAD, 'tree': TREE,
          'base': BASE, 'prior': PRIOR, 'status': '', 'scratch': str(S), 'tmpdir': str(T),
          'source_sha256': {p: hashlib.sha256((C / p).read_bytes()).hexdigest() for p in paths},
          'r4_delta': delta, 'secondary_main': git(C, 'merge-base', 'HEAD', 'f9f02dd53ba9f6e69d51ae5322df0c96e3d41b02')}
(S / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
for name, base in [('r5.diff', PRIOR), ('original-range.diff', BASE)]:
    with (S / name).open('w') as out:
        subprocess.run(['git', '-C', str(C), 'diff', base, HEAD], env=E, stdout=out, check=True)
with (S / 'candidate.tar').open('wb') as out:
    subprocess.run(['git', '-C', str(C), 'archive', HEAD], env=E, stdout=out, check=True)
R.mkdir()
with tarfile.open(S / 'candidate.tar') as archive:
    archive.extractall(R, filter='data')
subprocess.run(['git', '-C', str(R), 'init', '-q'], env=E, check=True)
subprocess.run(['git', '-C', str(R), 'add', '-f', '.'], env=E, check=True)
assert git(R, 'write-tree') == TREE
(S / 'snapshot-tree.txt').write_text(TREE + '\n')
print(json.dumps({'head': HEAD, 'tree': TREE, 'original_range_paths': len(paths),
                  'r4_delta_paths': len(delta), 'scratch_tree_matches': True,
                  'tmpdir_safe_non_git': True}, indent=2))
