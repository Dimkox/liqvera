import json
from pathlib import Path
import subprocess
import time

S = Path(__file__).resolve().parent
R = S / 'snapshot'
PY = '/home/pall/projects/liqvera/.getzilla/runtime/completion/getzilla-gate-venv/bin/python'
E = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'TMPDIR': '/home/pall/.g4-code-tmp',
     'PYTHONDONTWRITEBYTECODE': '1', 'GETZILLA_SERIAL': '1',
     'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1'}
H = 'tests.test_hook_degraded.HookDegradedTests.'
records = []
def run(name, args):
    command = ['taskset', '-c', '0-3', PY, '-B', *args]
    start = time.monotonic()
    with (S / (name + '.log')).open('w') as out:
        result = subprocess.run(command, cwd=R, env=E, stdout=out, stderr=subprocess.STDOUT, timeout=60)
    record = {'name': name, 'command': command, 'cwd': str(R), 'environment': E,
              'exit': result.returncode, 'seconds': round(time.monotonic() - start, 3)}
    records.append(record)
    print(json.dumps(record), flush=True)
    return record
controls = ['-m', 'unittest', '-v',
    H + 'test_missing_own_package_never_falls_back_to_foreign_pythonpath',
    H + 'test_cached_foreign_package_cannot_supply_hook_policy',
    H + 'test_own_stack_precedes_foreign_pythonpath_when_local_imports_break',
    H + 'test_healthy_hook_records_nothing',
    H + 'test_verify_fails_high_risk_pr_with_degraded_hooks']
p = R / '.grok/hooks/_lib.py'
original = p.read_bytes()
mutations = [
    ('M1-remove-initializer-precondition',
     "if not PACKAGE_INIT.is_file() or PACKAGE_INIT.resolve() != PACKAGE_INIT:\n    raise ImportError('Hook requires its own regular Getzilla package initializer')\n", '',
     H + 'test_missing_own_package_never_falls_back_to_foreign_pythonpath'),
    ('M2-remove-imported-package-ownership',
     "if (Path(getattr(getzilla, '__file__', '')).resolve() != PACKAGE_INIT\n        or tuple(Path(path).resolve() for path in getattr(getzilla, '__path__', ())) != (PACKAGE,)):\n    raise ImportError('Hook imported a Getzilla package outside its installation')\n", '',
     H + 'test_cached_foreign_package_cannot_supply_hook_policy'),
]
try:
    assert run('baseline-controls', controls)['exit'] == 0
    assert run('independent-closure', [str(S / 'closure-probe.py')])['exit'] == 0
    for name, old, new, test in mutations:
        text = original.decode()
        assert text.count(old) == 1
        try:
            p.write_text(text.replace(old, new, 1))
            record = run(name, ['-m', 'unittest', '-v', test])
            record.update(mutation={'path': '.grok/hooks/_lib.py', 'before': old, 'after': new},
                          outcome='killed' if record['exit'] else 'survived')
            assert record['exit'] != 0
        finally:
            p.write_bytes(original)
    assert run('restored-controls', controls)['exit'] == 0
finally:
    p.write_bytes(original)
    (S / 'probe-results.json').write_text(json.dumps({'records': records}, indent=2) + '\n')
    assert not subprocess.check_output(['git', '-C', str(R), 'diff', '--name-only'])
