from pathlib import Path
import json
import os
import subprocess
import sys

SCRATCH = Path(__file__).resolve().parent
SOURCE = SCRATCH / 'source'
sys.path[:0] = [str(SOURCE), str(SOURCE / '.getzilla')]
from tests._support import project_copy

results = []
for damage in ('none', 'broken-policy', 'missing-policy', 'broken-fsx', 'missing-fsx',
               'missing-init', 'missing-package', 'cached-foreign', 'cached-local', 'symlink-init'):
    with project_copy() as root:
        package = root / '.getzilla/getzilla'
        if damage.startswith('broken-'):
            module = damage.removeprefix('broken-')
            (package / f'{module}.py').write_text(f'raise ImportError("local {module} fixture damage")\n')
        elif damage.startswith('missing-'):
            module = damage.removeprefix('missing-')
            if module == 'init':
                (package / '__init__.py').unlink()
            elif module == 'package':
                package.rename(root / '.getzilla/parked-fixture-package')
            else:
                (package / f'{module}.py').unlink()
        elif damage == 'symlink-init':
            (package / '__init__.py').unlink()
            (package / '__init__.py').symlink_to(SOURCE / '.getzilla/getzilla/__init__.py')
        env = {'PATH': os.defpath, 'TMPDIR': '/home/pall/.gz-r5-sec',
               'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': os.pathsep.join(
                   (str(SOURCE / '.getzilla'), str(root / '.getzilla')))}
        for kind, tool, inputs in (
            ('read', 'Read', {'file_path': 'AGENTS.md'}),
            ('protected', 'Bash', {'command': 'rm -rf build'}),
        ):
            script = root / '.grok/hooks/pre_tool_use.py'
            if damage.startswith('cached-'):
                bootstrap = 'import sys,runpy; '
                if damage == 'cached-local':
                    bootstrap += 'sys.path.insert(0,sys.argv[3]); '
                bootstrap += ('import getzilla; sys.path.insert(0,sys.argv[1]); '
                              'runpy.run_path(sys.argv[2],run_name="__main__")')
                argv = [sys.executable, '-B', '-v', '-c', bootstrap,
                        str(script.parent), str(script), str(root / '.getzilla')]
            else:
                argv = [sys.executable, '-B', '-v', str(script)]
            run = subprocess.run(argv, cwd=root, env=env, text=True, capture_output=True,
                                 input=json.dumps({'cwd': str(root), 'tool_name': tool,
                                                   'tool_input': inputs}), timeout=20)
            data = json.loads(run.stdout)
            decision = data.get('decision') or data.get('hookSpecificOutput', {}).get('permissionDecision')
            event_path = root / '.getzilla/runtime/hook-events.jsonl'
            events = [json.loads(line) for line in event_path.read_text().splitlines()] if event_path.exists() else []
            imported = [line for line in run.stderr.splitlines()
                        if 'code object from' in line and '/getzilla/' in line]
            foreign = [line for line in imported if str(SOURCE / '.getzilla/getzilla') in line]
            degraded = damage not in ('none', 'cached-local')
            expected = 'deny' if degraded and kind == 'protected' else 'allow'
            expect_events = (1 if kind == 'read' else 2) if degraded else 0
            assert run.returncode == 0 and decision == expected and len(events) == expect_events, (damage,kind,data,events)
            if damage == 'cached-foreign':
                assert len(foreign) == 1 and '__init__.py' in foreign[0], foreign
            else:
                assert not foreign, foreign
            result = {'case':damage,'action':kind,'exit':run.returncode,'expected':expected,
                      'decision':decision,'degraded_events':len(events),'imports':imported,
                      'foreign_imports':foreign,'argv':argv,'stdout':data,'assertions_passed':True}
            results.append(result)
            (SCRATCH / f'hook-{damage}-{kind}.stderr').write_text(run.stderr)

(SCRATCH / 'hook-probe-results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps([{k:row[k] for k in ('case','action','exit','decision','degraded_events','assertions_passed')}
                  for row in results], indent=2))
