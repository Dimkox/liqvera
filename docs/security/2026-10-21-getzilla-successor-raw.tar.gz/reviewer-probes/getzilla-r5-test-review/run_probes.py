#!/usr/bin/env python3
"""Focused real-hook baseline and guard-removal mutants in private exact source."""
from __future__ import annotations
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

EVIDENCE = Path(__file__).resolve().parent
SOURCE = EVIDENCE / 'src'
TMP = Path('/home/pall/.cache/gzr5t')
sys.path[:0] = [str(SOURCE), str(SOURCE / '.getzilla')]
from getzilla import python_test_runner

HOOK = 'tests/test_hook_degraded.py::HookDegradedTests::'
NEW = [HOOK + 'test_missing_own_package_never_falls_back_to_foreign_pythonpath',
       HOOK + 'test_cached_foreign_package_cannot_supply_hook_policy']
CASES = NEW + [
    HOOK + 'test_own_stack_precedes_foreign_pythonpath_when_local_imports_break',
    HOOK + 'test_policy_import_failure_allows_and_records',
    HOOK + 'test_unimportable_lib_allows_and_records_with_stdlib_only',
    HOOK + 'test_healthy_hook_records_nothing',
    'tests/test_degraded_fail_closed.py::DegradedFailClosedTests::test_helper_library_that_does_not_import',
    'tests/test_degraded_fail_closed.py::DegradedFailClosedTests::test_policy_that_does_not_import',
    'tests/test_enforcement_report.py::EnforcementReportTests::test_self_test_proves_the_policy_runs',
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, indent=2) + '\n')

def execute(label, targets):
    env = python_test_runner._environment(SOURCE, EVIDENCE / '.coverage-unused')
    env['TMPDIR'] = str(TMP)
    command = ['taskset', '-c', '4-7', *python_test_runner._pytest_command(4, 'worksteal'), *targets]
    save(label + '-command.json', {
        'cwd': str(SOURCE), 'argv': command,
        'env': {key: env[key] for key in ('TMPDIR', 'PYTHONPATH', 'PYTHONDONTWRITEBYTECODE',
                                        'PYTEST_DISABLE_PLUGIN_AUTOLOAD', '_GETZILLA_TEST_CHILD')},
        'native_environment_builder': 'getzilla.python_test_runner._environment',
        'native_command_builder': 'getzilla.python_test_runner._pytest_command',
        'coverage': 'omitted for explicit bounded selection', 'reviewer_timeout_seconds': 180})
    started = time.monotonic()
    process = subprocess.run(command, cwd=SOURCE, env=env, capture_output=True, timeout=180)
    for stream in ('stdout', 'stderr'):
        (EVIDENCE / f'{label}.{stream}').write_bytes(getattr(process, stream))
    output = (process.stdout + process.stderr).decode('utf-8', 'replace')
    result = {'label': label, 'returncode': process.returncode,
              'seconds': round(time.monotonic() - started, 3),
              'stdout_sha256': sha(process.stdout), 'stderr_sha256': sha(process.stderr),
              'summary_lines': [line for line in output.splitlines()
                                if line.startswith(('FAILED ', 'SUBFAILED(', 'ERROR '))
                                or ' passed' in line or ' failed' in line]}
    save(label + '-result.json', result)
    print(json.dumps(result), flush=True)
    return result

def baseline():
    result = execute('baseline-hooks', CASES)
    assert result['returncode'] == 0, result

def mutants():
    assert json.loads((EVIDENCE / 'baseline-hooks-result.json').read_text())['returncode'] == 0
    target = SOURCE / '.grok/hooks/_lib.py'
    original = target.read_bytes()
    specs = [
        ('M1-remove-initializer-precondition',
         "if not PACKAGE_INIT.is_file() or PACKAGE_INIT.resolve() != PACKAGE_INIT:\n"
         "    raise ImportError('Hook requires its own regular Getzilla package initializer')",
         '# REVIEWER MUTANT: initializer precondition removed', [NEW[0]]),
        ('M2-remove-imported-package-ownership',
         "if (Path(getattr(getzilla, '__file__', '')).resolve() != PACKAGE_INIT\n"
         "        or tuple(Path(path).resolve() for path in getattr(getzilla, '__path__', ())) != (PACKAGE,)):\n"
         "    raise ImportError('Hook imported a Getzilla package outside its installation')",
         '# REVIEWER MUTANT: imported package ownership check removed', [NEW[1]]),
    ]
    outcomes = []
    for label, old, new, selected in specs:
        text = original.decode()
        assert text.count(old) == 1
        changed = text.replace(old, new).encode()
        save(label + '-mutation.json', {'file': '.grok/hooks/_lib.py', 'old': old, 'new': new,
                                       'original_sha256': sha(original), 'mutant_sha256': sha(changed)})
        (EVIDENCE / f'{label}.diff').write_text(''.join(difflib.unified_diff(
            text.splitlines(keepends=True), changed.decode().splitlines(keepends=True),
            fromfile='original/.grok/hooks/_lib.py', tofile='mutant/.grok/hooks/_lib.py')))
        try:
            target.write_bytes(changed)
            outcomes.append(execute(label, selected))
        finally:
            target.write_bytes(original)
        assert target.read_bytes() == original
        save('mutation-results.json', outcomes)
    result = execute('restored-new-regressions', NEW)
    assert result['returncode'] == 0

if __name__ == '__main__':
    {'baseline': baseline, 'mutants': mutants}[sys.argv[1]]()
