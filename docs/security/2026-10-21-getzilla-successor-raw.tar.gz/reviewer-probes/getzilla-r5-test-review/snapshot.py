#!/usr/bin/env python3
"""Read-only candidate binding and exact reviewer-owned snapshot management."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys

EVIDENCE = Path(__file__).resolve().parent
CANDIDATE = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final')
SOURCE = EVIDENCE / 'src'
TMP = Path('/home/pall/.cache/gzr5t')
HEAD = '3968ae4445836eda9cf377035b1d1f64fe9659b0'
TREE = '5e0c8153899219b238a3ff63f064665eb28f41ca'
R4 = 'b1ff3de3eb952521cacaa1119c88d2d6990c0545'
BASE = 'e158ddc7263a55f5308944c5a426eb1e9f1a4327'
SECONDARY = 'f9f02dd53ba9f6e69d51ae5322df0c96e3d41b02'

def save(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, indent=2) + '\n')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(CANDIDATE), *args],
                                   env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})

def manifest(root):
    records = []
    for item in git('ls-files', '--stage', '-z').split(b'\0'):
        if not item:
            continue
        fields, raw = item.split(b'\t', 1)
        mode, blob, stage = fields.decode().split()
        relative = Path(os.fsdecode(raw))
        assert stage == '0' and not relative.is_absolute() and '..' not in relative.parts
        path = root / relative
        st = path.lstat()
        if mode == '120000':
            assert stat.S_ISLNK(st.st_mode)
            data = os.fsencode(os.readlink(path))
        else:
            assert mode in ('100644', '100755') and stat.S_ISREG(st.st_mode)
            data = path.read_bytes()
        records.append({'path': str(relative), 'git_mode': mode, 'blob': blob,
                        'mode': oct(stat.S_IMODE(st.st_mode)), 'bytes': len(data), 'sha256': sha(data)})
    return sorted(records, key=lambda x: x['path'])

def binding(records):
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'status': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
            'manifest_sha256': sha(json.dumps(records, sort_keys=True, separators=(',', ':')).encode()),
            'tracked_entries': len(records), 'checkout_bytes': sum(x['bytes'] for x in records)}

def safe(path):
    rows = []
    for part in reversed((path, *path.parents)):
        st = part.lstat()
        assert stat.S_ISDIR(st.st_mode) and not part.is_symlink(), part
        assert st.st_uid in (0, os.getuid()) and not stat.S_IMODE(st.st_mode) & 0o1022, part
        rows.append({'path': str(part), 'uid': st.st_uid, 'mode': oct(stat.S_IMODE(st.st_mode))})
    return rows

def setup():
    assert not SOURCE.exists()
    TMP.mkdir(mode=0o700, exist_ok=False)
    SOURCE.mkdir(mode=0o700)
    checks = {'scratch': safe(EVIDENCE), 'source': safe(SOURCE), 'tmp': safe(TMP)}
    assert stat.S_IMODE(EVIDENCE.stat().st_mode) == 0o700
    assert stat.S_IMODE(TMP.stat().st_mode) == 0o700
    probe = subprocess.run(['git', 'rev-parse', '--show-toplevel'], cwd=TMP,
                           capture_output=True, text=True)
    assert probe.returncode == 128
    checks['tmp_git_probe'] = {'argv': ['git', 'rev-parse', '--show-toplevel'],
                               'returncode': probe.returncode, 'stdout': probe.stdout, 'stderr': probe.stderr}
    save('scratch-safety.json', checks)
    records = manifest(CANDIDATE)
    before = binding(records)
    assert before['head'] == HEAD and before['tree'] == TREE and before['status'] == ''
    save('source-manifest.json', records)
    save('before.json', before)
    for record in records:
        relative = record['path']
        source, target = CANDIDATE / relative, SOURCE / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if source.is_symlink():
            target.symlink_to(os.readlink(source))
        else:
            shutil.copy2(source, target)
    assert manifest(SOURCE) == records
    save('snapshot-verification.json', {'exact': True, **before})
    (EVIDENCE / 'r4-r5.diff').write_bytes(git('diff', R4, HEAD))
    (EVIDENCE / 'r4-r5-inventory.txt').write_bytes(git('diff', '--name-status', R4, HEAD))
    (EVIDENCE / 'recent-history.txt').write_bytes(git('log', '-8', '--oneline'))
    (EVIDENCE / 'worktrees.txt').write_bytes(git('worktree', 'list', '--porcelain'))
    ancestors = {}
    for base in (BASE, SECONDARY, R4, 'v2.2.0', 'v2.2.1', 'v2.3.0'):
        result = subprocess.run(['git', '-C', str(CANDIDATE), 'merge-base', '--is-ancestor', base, HEAD])
        ancestors[base] = result.returncode
        assert result.returncode == 0
    save('ancestry.json', ancestors)
    historical = EVIDENCE.parent / 'getzilla-r4-test-review.md'
    retained = CANDIDATE / 'engineering/changes/20261021-task-d83415/evidence/fourth-test-review.md'
    assert historical.read_bytes() == retained.read_bytes()
    controls = EVIDENCE.parent / 'getzilla-r5-committed-controls.json'
    save('historical-and-control-bindings.json', {
        'r4_external_report': str(historical), 'r4_retained_report': str(retained),
        'r4_report_sha256': sha(historical.read_bytes()), 'byte_identical': True,
        'coordinator_controls': str(controls), 'controls_sha256': sha(controls.read_bytes()),
        'controls_not_reviewer_execution': True})
    print(json.dumps(before))

def finalize():
    records = json.loads((EVIDENCE / 'source-manifest.json').read_text())
    before = json.loads((EVIDENCE / 'before.json').read_text())
    current = manifest(CANDIDATE)
    assert current == records
    after = binding(current)
    assert before == after
    assert manifest(SOURCE) == records
    expected = {r['path'] for r in records}
    actual = {str(p.relative_to(SOURCE)) for p in SOURCE.rglob('*') if p.is_file() or p.is_symlink()}
    assert actual == expected, {'extras': sorted(actual - expected), 'missing': sorted(expected - actual)}
    save('after.json', after)
    save('restoration.json', {'candidate_bytes_and_modes_unchanged': True,
                             'snapshot_bytes_and_modes_restored': True,
                             'snapshot_extra_files': [], 'reviewed-tree-modified': 'no'})
    print(json.dumps(after))

if __name__ == '__main__':
    {'setup': setup, 'finalize': finalize}[sys.argv[1]]()
