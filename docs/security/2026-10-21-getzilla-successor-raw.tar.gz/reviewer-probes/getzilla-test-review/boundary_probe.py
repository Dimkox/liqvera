import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent / 'snapshot'
sys.path.insert(0, str(ROOT))
from tests.test_verification_dispositions import ASSIGNMENT, DispositionTests
from getzilla.verification import _secret_scan

cases = [
    ('standalone', '', 'pass'),
    ('space', ' ', 'pass'),
    ('object_open', '{', 'pass'),
    ('credential_underscore', 'auth_', 'fail'),
    ('property_dot', 'obj.', 'fail'),
]
if '--ascii-only' not in sys.argv:
    cases += [
        ('unicode_zwnj', 'auth\u200c', 'fail'),
        ('unicode_zwj', 'auth\u200d', 'fail'),
        ('unicode_combining_mark', 'auth\u0301', 'fail'),
        ('escaped_identifier', r'auth\u{61}', 'fail'),
    ]
failed = 0
for label, prefix, expected in cases:
    fixture = DispositionTests(methodName='runTest')
    try:
        fixture.setUp()
        entry = fixture.entry(text=prefix + ASSIGNMENT + '\n', column=len(prefix) + 1)
        fixture.policy([entry])
        result = _secret_scan(fixture.root, ['protocol.ts'])
        summary = fixture.summary(result)
        print(json.dumps({'case': label, 'prefix': prefix, 'expected': expected,
                          'actual': result.status, 'disposed': summary['disposed'],
                          'unresolved': summary['unresolved']}), flush=True)
        failed += result.status != expected
    finally:
        fixture.doCleanups()
print(json.dumps({'cases': len(cases), 'mismatches': failed}), flush=True)
raise SystemExit(bool(failed))
