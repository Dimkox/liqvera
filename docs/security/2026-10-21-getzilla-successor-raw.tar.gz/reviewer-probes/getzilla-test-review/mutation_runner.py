import hashlib
import json
import os
import pathlib
import subprocess
import time

SCRATCH = pathlib.Path(__file__).resolve().parent
ROOT = SCRATCH / 'snapshot'
HELPER = '.getzilla/getzilla/verification_dispositions.py'
VERIFY = '.getzilla/getzilla/verification.py'
CASE = 'tests.test_verification_dispositions.DispositionTests.'
mutations = [
    ('M1_duplicate_json_keys', HELPER, 'if key in result:', 'if False:', [
        'test_malformed_duplicate_key_version_and_size_fail_without_findings']),
    ('M2_credential_prefix', HELPER,
     "match.start() == 0 or not re.match(r'[\\w$.-]', text[match.start() - 1])",
     'True', ['test_address_shape_does_not_admit_credential_names_or_opaque_values']),
    ('M3_first_match_only', VERIFY, 'for match in pattern.finditer(text):',
     'for match in list(pattern.finditer(text))[:1]:', [
         'test_absent_policy_keeps_every_match_blocking',
         'test_one_disposition_never_suppresses_second_match_on_same_line']),
    ('M4_stale_evidence_hash', HELPER,
     "if sha256(self._read(evidence_path, nonexecutable=True)) != evidence['sha256']:",
     "if False and sha256(self._read(evidence_path, nonexecutable=True)) != evidence['sha256']:", [
         'test_closed_schema_rejects_invalid_and_duplicate_entries_outside_selection']),
    ('M5_git_stderr_covered', VERIFY,
     'proc.returncode == 2 and not proc.stderr and parsed and bool(observations)',
     'proc.returncode == 2 and parsed and bool(observations)', [
         'test_unknown_git_output_errors_and_selection_findings_cannot_be_disposed']),
    ('M6_wrong_git_layer', HELPER, "if layer == 'worktree':", 'if True:', [
        'test_staged_and_worktree_eof_are_bound_to_their_own_bytes',
        'test_current_worktree_hash_cannot_dispose_a_different_head_blob']),
    ('M7_drop_revalidation', HELPER,
     'def assert_current(self) -> None:\n',
     'def assert_current(self) -> None:\n        return\n', [
         'test_evidence_mutation_during_scan_fails_closed']),
]
results = []
for name, relative, old, new, cases in mutations:
    target = ROOT / relative
    original = target.read_bytes()
    text = original.decode()
    assert text.count(old) == 1, (name, text.count(old))
    command = ['taskset', '-c', '6-11', 'env', f'TMPDIR={SCRATCH / "tmp"}',
               'PYTHONDONTWRITEBYTECODE=1', 'GETZILLA_SERIAL=1',
               'python3', '-B', '-m', 'unittest', *[CASE + case for case in cases]]
    start = time.monotonic()
    try:
        target.write_text(text.replace(old, new))
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=90)
    finally:
        target.write_bytes(original)
    assert target.read_bytes() == original
    output = result.stdout + result.stderr
    log = SCRATCH / 'logs' / (name + '.log')
    log.write_text(output)
    killed = result.returncode == 1 and 'FAIL:' in output and 'FAILED (failures=' in output
    outcome = 'killed' if killed else ('survived' if result.returncode == 0 else 'inconclusive')
    record = {'id': name, 'path': relative, 'old': old, 'new': new,
              'command': command, 'returncode': result.returncode, 'outcome': outcome,
              'elapsed_seconds': round(time.monotonic() - start, 3),
              'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    results.append(record)
    print(json.dumps(record), flush=True)
(SCRATCH / 'mutation-results.json').write_text(json.dumps(results, indent=2) + '\n')
