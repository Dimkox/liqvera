import assert from 'node:assert/strict';
import test from 'node:test';
import { mountMezoFinance } from './snapshot/apps/mezo-web/src/mezo-finance-panel.ts';

test('the existing checkout has a mountable finance panel', () => {
  assert.equal(typeof mountMezoFinance, 'function');
});

class Element {
  children = []; attrs = {}; listeners = {}; textContent = ''; checked = false;
  disabled = false; value = ''; hidden = false; parent = null;
  constructor(tag) { this.tagName = tag; }
  append(...children) { for (const child of children) { this.children.push(child); if (typeof child === 'object') child.parent = this; } }
  after(child) { this.parent.append(child); }
  setAttribute(key, value) { this.attrs[key] = value; }
  hasAttribute(key) { return key === 'href' ? typeof this.href === 'string' : Object.hasOwn(this.attrs,key); }
  removeAttribute(key) { delete this.attrs[key]; if (key === 'href') delete this.href; }
  addEventListener(name, fn) { (this.listeners[name] ??= []).push(fn); }
  remove() { this.parent.children = this.parent.children.filter(x => x !== this); }
  async emit(name) { const event = { prevented: false, preventDefault() { this.prevented = true; } }; for (const fn of this.listeners[name] ?? []) await fn(event); return event; }
  find(id) { return this.id === id ? this : this.children.filter(x => typeof x === 'object').map(x => x.find(id)).find(Boolean); }
}
const account = '0x1111111111111111111111111111111111111111';
const other = '0x2222222222222222222222222222222222222222';
const network = {name:'testnet',chainId:31611,asset:'0x118917a40FAF1CD7a13dB0Ef56C86De7973Ac503',decimals:18};
function setup(read) {
  const root = new Element('div'), host = new Element('div'); root.append(host);
  const calls = [];
  const provider = { async request({method}) { calls.push(method); if (method === 'eth_chainId') return '0x7b7b'; if (method === 'eth_accounts') return [account]; if (method === 'eth_getBlockByNumber') return {number:'0x123',hash:'0x'+'a'.repeat(64)}; return read ? read() : '0x' + '0'.repeat(64); } };
  const context = { provider, account, paymentGuard:'clear', busy:false, onMezo:true,
    quote:{quote_id:'q1',state:'READY',terms:{network:'eip155:31611',chain_id:31611,asset:network.asset,decimals:18,amount_atomic:'10000000000000000',expected_payer:account,pay_to:other,expires_at:new Date(Date.now()+60000).toISOString()}} };
  globalThis.document = {createElement: tag => new Element(tag)};
  const panel = mountMezoFinance({host,network,getContext:()=>context});
  return { root, context, calls, panel, find:id=>root.find(id) };
}

for (const [age, allowed] of [[29999, true], [30000, false], [-1, false]]) {
  test(`independent funding freshness boundary ${age}ms`, async t => {
    let clock = 100000;
    t.mock.method(Date, 'now', () => clock);
    const s=setup();
    try {
      await s.find('mezo-balance-check').emit('click');
      s.find('mezo-borrow-ack').checked=true;
      await s.find('mezo-borrow-ack').emit('change');
      assert.equal(typeof s.find('mezo-borrow-link').href,'string');
      assert.equal(typeof s.find('mezo-observation-download').href,'string');
      const calls=s.calls.length;
      clock+=age;
      const action=await s.find('mezo-borrow-link').emit('click');
      assert.equal(action.prevented,!allowed);
      assert.equal(s.find('mezo-borrow-ack').disabled,!allowed);
      const download=await s.find('mezo-observation-download').emit('click');
      assert.equal(download.prevented,!allowed);
      assert.equal(s.calls.length,calls);
    } finally {s.panel.dispose();}
  });
}
