import hashlib, json, os, pathlib, re, subprocess, sys
S=pathlib.Path(__file__).resolve().parent; R=S/'snapshot'
TOOL=pathlib.Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions')
sys.path.insert(0,str(TOOL/'.getzilla'))
from getzilla.verification import _secret_scan, _git_diff_check, GitRangeBase, GitRangeSelection
from getzilla.verification_dispositions import Dispositions, SECRET_PATTERNS, location
sha=lambda data: hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git','-C',str(TOOL),'rev-parse','HEAD'],text=True).strip()=='4cf2abf21753e61383e3d89be593e0fb815afc7f'
base='f1d3bffc46fa1459908fdff865fcfbfc831b7f7f'; main='3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd'
paths=subprocess.check_output(['git','-C',str(R),'diff','--name-only',base+'..HEAD'],text=True).splitlines()
policy_path=R/'engineering/verification-dispositions.json'; original_policy=policy_path.read_bytes(); document=json.loads(original_policy)
selection=GitRangeSelection(bases=[GitRangeBase('route','review full Wave 1',base,base),GitRangeBase('pr-target','current main secondary',main,main)])
results=[]
def record(name,result,expected):
    raw=result.to_dict(); (S/(name+'.json')).write_text(json.dumps(raw,indent=2)+'\n')
    summary=next(x for x in raw['details'] if x['code']=='disposition-summary')
    assert raw['status']==expected,(name,raw)
    if expected=='pass':
        for x in raw['details']:
            if x.get('observation'): assert (x['severity'],x['effective_severity'])==('error','info')
    item={'name':name,'status':raw['status'],'summary':raw['summary'],'counts':summary}; results.append(item); print(json.dumps(item),flush=True)
try:
    binding=[]
    protocol=(R/'packages/mezo-protocol/src/index.ts').read_text()
    public=re.search(r'MUSD_TESTNET = \{.*?address: "(0x[0-9A-Fa-f]{40})"',protocol,re.S).group(1)
    for entry in document['dispositions']:
        raw=(R/entry['path']).read_bytes(); evidence=(R/entry['evidence']['path']).read_bytes()
        assert sha(raw)==entry['sha256'] and sha(evidence)==entry['evidence']['sha256']
        if entry['check']=='secret-scan':
            matches=[m for m in SECRET_PATTERNS['generic-secret'].finditer(raw.decode()) if location(raw.decode(),m.start())==(entry['line'],entry['column'])]
            assert len(matches)==1 and sha(matches[0].group().encode())==entry['match_sha256']
            assert public in matches[0].group()
        binding.append({'id':entry['id'],'target_sha256':sha(raw),'evidence_sha256':sha(evidence),'line':entry['line'],'column':entry.get('column')})
    assert sha(protocol.encode())=='28a5c0a9143a803bbd836ab59b3aad31cd225bb6459eb97778a256aada88489b'
    (S/'exact-bindings.json').write_text(json.dumps({'config_sha256':sha(original_policy),'entries':binding,'canonical_protocol_sha256':sha(protocol.encode())},indent=2)+'\n')
    record('policy-baseline-secret',_secret_scan(R,paths),'pass')
    record('policy-baseline-git',_git_diff_check(R,'pr',selection),'pass')
    for field in ['sha256','match_sha256','evidence']:
        changed=json.loads(original_policy)
        if field=='evidence': changed['dispositions'][0]['evidence']['sha256']='0'*64
        else: changed['dispositions'][0][field]='0'*64
        policy_path.write_text(json.dumps(changed)+'\n')
        record('policy-invalid-'+field,_secret_scan(R,paths),'fail')
    policy_path.write_bytes(original_policy)
    target=R/document['dispositions'][0]['path']; original_target=target.read_bytes()
    try:
        target.write_bytes(original_target+b'\n// Synthetic scanner negative control.\n'+('password'+' = '+repr('review-only-synthetic-value')+';\n').encode())
        changed=json.loads(original_policy); changed['dispositions'][0]['sha256']=sha(target.read_bytes())
        policy_path.write_text(json.dumps(changed)+'\n')
        result=_secret_scan(R,paths); record('policy-unlisted-occurrence',result,'fail')
        summary=next(x for x in result.details if x['code']=='disposition-summary'); assert summary['disposed']==2 and summary['observed']==3 and summary['unresolved']==1
        target.write_bytes(original_target)
        original_text=original_target.decode()
        # Bind the real scanner occurrence after inserting valid member syntax
        # and the formerly dangerous Unicode-whitespace/ASCII-space suffix.
        changed_text=original_text.replace('const token =', 'const owner = {}; owner.\u00a0 token =',1)
        assert changed_text!=original_text; target.write_text(changed_text)
        changed=json.loads(original_policy); entry=changed['dispositions'][0]
        match=next(SECRET_PATTERNS['generic-secret'].finditer(changed_text))
        entry.update(sha256=sha(target.read_bytes()),line=location(changed_text,match.start())[0],column=location(changed_text,match.start())[1],match_sha256=sha(match.group().encode()))
        policy_path.write_text(json.dumps(changed)+'\n')
        record('policy-member-context',_secret_scan(R,paths),'fail')
    finally: target.write_bytes(original_target); policy_path.write_bytes(original_policy)
    target=R/document['dispositions'][2]['path']; original_target=target.read_bytes()
    try:
        target.write_bytes(original_target.replace(b'\n',b' \n',1))
        record('policy-unrelated-whitespace',_git_diff_check(R,'pr',selection),'fail')
    finally: target.write_bytes(original_target)
finally:
    policy_path.write_bytes(original_policy)
    (S/'policy-probes.json').write_text(json.dumps(results,indent=2)+'\n')
assert not subprocess.check_output(['git','-C',str(R),'diff','--name-only'])
print('Policy probes restored exact tracked snapshot.')
