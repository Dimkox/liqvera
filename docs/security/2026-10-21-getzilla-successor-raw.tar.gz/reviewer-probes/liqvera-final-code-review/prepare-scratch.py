import json, pathlib, subprocess, os
S=pathlib.Path(__file__).resolve().parent; R=S/'snapshot'; C=pathlib.Path('/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit')
objects=subprocess.check_output(['git','-C',str(C),'rev-parse','--git-path','objects'],text=True).strip()
objects=(C/objects).resolve()
(R/'.git/objects/info/alternates').write_text(str(objects)+'\n')
head='ca65575dd2283a47b7671b356847ed8fb9f5a125'
subprocess.run(['git','-C',str(R),'update-ref','refs/heads/reviewed',head],check=True)
subprocess.run(['git','-C',str(R),'symbolic-ref','HEAD','refs/heads/reviewed'],check=True)
assert not subprocess.check_output(['git','-C',str(R),'status','--porcelain=v1','--untracked-files=all'])
modules=R/'apps/mezo-web/node_modules/@liqvera'; modules.mkdir(parents=True)
(modules/'mezo-protocol').symlink_to(R/'packages/mezo-protocol',target_is_directory=True)
compiler='/home/pall/projects/liqvera/.worktrees/wave1-deploy/apps/mezo-web/node_modules/typescript/bin/tsc'
env={'PATH':'/usr/local/bin:/usr/bin:/bin','TMPDIR':str(S/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','GETZILLA_SERIAL':'1'}
commands=[['taskset','-c','16-17','node',compiler,'-p','packages/mezo-protocol/tsconfig.json'],['taskset','-c','16-17','node','--test','--test-concurrency=1','--test-reporter=spec','apps/mezo-web/test/browser-orchestration.test.mjs','apps/mezo-web/test/browser-flow.test.mjs']]
results=[]
for name,args in zip(['protocol-build','web-recovery'],commands):
    with (S/(name+'.log')).open('w') as output:
        proc=subprocess.run(args,cwd=R,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=60)
    results.append({'name':name,'command':args,'exit':proc.returncode}); print(json.dumps(results[-1]),flush=True)
    if proc.returncode: break
(S/'scratch-setup.json').write_text(json.dumps({'objects_read_from':str(objects),'head':head,'commands':results,'env':env},indent=2)+'\n')
