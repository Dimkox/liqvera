import hashlib,json,pathlib,subprocess
S=pathlib.Path(__file__).resolve().parent; R=pathlib.Path('/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit'); P=R/'engineering/changes/20261021-task-ec1239/evidence'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
record=json.loads((P/'product-preservation.json').read_text()); roots=record['unchanged_runtime_input_roots']; deployed=record['production_evidence_source']; base=record['comparison_base']
assert not git('diff','--name-only',deployed+'..HEAD','--',*roots)
assert not git('diff','--name-only',base+'..HEAD','--','apps/mezo-gateway','packages','services','schemas')
history={}
for path,digest in record['historical_evidence_sha256'].items():
    raw=(R/path).read_bytes(); assert sha(raw)==digest
    assert git('show',record['current_main']+':'+path)==raw
    history[path]=digest
binding=json.loads((P/'analysis-bindings.json').read_text())
for name,digest in binding['reports'].items():assert sha((P/name).read_bytes())==digest
binding_tool=json.loads((P/'tool-binding.json').read_text())
for name,digest in binding_tool['overlay'].items():assert sha((R/name).read_bytes())==digest
names=git('ls-files').decode().splitlines()
for root in ['apps/mezo-web/','apps/mezo-gateway/','packages/contracts/','packages/public-capture/','packages/readonly-analyzer/','packages/evidence-report/','services/evidence-capture/','services/evidence-report/']:
    assert any(n.startswith(root) for n in names),root
assert not git('ls-files','.getzilla','scripts/getzilla*')
result={'runtime_comparison':deployed+'..HEAD','runtime_roots':roots,'runtime_delta':[],'original_base_preserved_roots':['apps/mezo-gateway','packages','services','schemas'],'historical_evidence':history,'analysis_bindings':binding,'overlay_files_checked':len(binding_tool['overlay']),'tracked_framework_files':0,'policy_digest':sha((R/'engineering/verification-dispositions.json').read_bytes())}
(S/'preservation.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
