import json, os, pathlib, subprocess, time
S=pathlib.Path(__file__).resolve().parent
R=S/'snapshot'
PY='/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit/.venv/bin/python'
env={'PATH':'/usr/local/bin:/usr/bin:/bin','TMPDIR':str(S/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','GETZILLA_SERIAL':'1'}
targets=[('tls', [PY,'-B','-m','pytest','-p','no:cacheprovider','tests/test_tls_trust_guard.py','-q']),('web-critical',['node','--test','--test-concurrency=1','--test-reporter=spec','apps/mezo-web/test/mezo-finance.test.mjs','apps/mezo-web/test/mezo-finance-panel.test.mjs','apps/mezo-web/test/musd-observation.test.mjs','apps/mezo-web/test/browser-orchestration.test.mjs','apps/mezo-web/test/browser-flow.test.mjs'])]
results=[]
for name,args in targets:
    command=['taskset','-c','16-17',*args]; start=time.monotonic()
    with (S/(name+'.log')).open('w') as output:
        proc=subprocess.run(command,cwd=R,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=90)
    result={'name':name,'command':command,'cwd':str(R),'env':env,'exit':proc.returncode,'seconds':round(time.monotonic()-start,3),'log':str(S/(name+'.log'))}
    results.append(result); print(json.dumps(result),flush=True)
(S/'controls.json').write_text(json.dumps(results,indent=2)+'\n')
