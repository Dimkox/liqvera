import json, pathlib, re, subprocess, time
S=pathlib.Path(__file__).resolve().parent; R=S/'snapshot'
PY='/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit/.venv/bin/python'
env={'PATH':'/usr/local/bin:/usr/bin:/bin','TMPDIR':str(S/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','GETZILLA_SERIAL':'1'}
def run(name,args):
    command=['taskset','-c','16-17',*args]; started=time.monotonic()
    with (S/(name+'.log')).open('w') as out:
        proc=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=60)
    text=(S/(name+'.log')).read_text()
    return {'name':name,'command':command,'exit':proc.returncode,'seconds':round(time.monotonic()-started,3),'tail':text.splitlines()[-12:]}
node=['node','--test','--test-concurrency=1','--test-reporter=spec']
pytest=[PY,'-B','-m','pytest','-p','no:cacheprovider','-q']
results=[]
baseline=run('freshness-baseline',node+[str(S/'independent-freshness.mjs')]); results.append(baseline)
assert baseline['exit']==0,baseline
mutations=[
 ('M1-dev-pip-downgrade','pyproject.toml','pip==26.2.2','pip==26.2.1',pytest+['tests/test_tls_trust_guard.py::test_development_install_preserves_the_audited_pip_bootstrap']),
 ('M2-lazy-ca-directory-omitted','deploy/security/check-tls-trust.py','if cafile is None:','if False:',pytest+['tests/test_tls_trust_guard.py']),
 ('M3-unknown-payment-guard-removed','apps/mezo-web/src/mezo-finance.mjs',"if (context.paymentGuard !== 'clear')",'if (false)',node+['apps/mezo-web/test/mezo-finance.test.mjs']),
 ('M4-canonical-block-hash-omitted','apps/mezo-web/src/mezo-finance.mjs',' || canonical.hash.toLowerCase() !== block.hash.toLowerCase()','',node+['apps/mezo-web/test/musd-observation.test.mjs']),
 ('M5-freshness-boundary-removed','apps/mezo-web/src/mezo-finance-panel.ts','lastBalance !== null && Date.now() - lastBalance.at >= 0 && Date.now() - lastBalance.at < 30000','lastBalance !== null',node+[str(S/'independent-freshness.mjs')]),
]
for name,path,old,new,args in mutations:
    file=R/path; original=file.read_bytes(); text=original.decode(); assert text.count(old)==1,(name,text.count(old))
    try:
        file.write_text(text.replace(old,new,1))
        result=run(name,args); result.update(path=path,mutation={'before':old,'after':new})
        result['outcome']='killed' if result['exit'] else 'survived'
        results.append(result); print(json.dumps(result),flush=True)
    finally:file.write_bytes(original)
(S/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
assert not subprocess.check_output(['git','-C',str(R),'diff','--name-only'])
