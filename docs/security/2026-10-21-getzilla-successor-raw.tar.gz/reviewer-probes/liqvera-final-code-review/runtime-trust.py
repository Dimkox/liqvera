import json,pathlib,subprocess
S=pathlib.Path(__file__).resolve().parent; R=S/'snapshot'
PY='/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit/.venv/bin/python'
E={'PATH':'/usr/local/bin:/usr/bin:/bin','TMPDIR':str(S/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','PIP_CONFIG_FILE':'/dev/null'}
bundle=subprocess.check_output([PY,'-B','-c','import certifi; print(certifi.where())'],env=E,text=True).strip()
empty=S/'clean-ca-dir'; empty.mkdir()
E.update(SSL_CERT_FILE=bundle,SSL_CERT_DIR=str(empty),NODE_OPTIONS='--use-openssl-ca')
commands=[('effective-python',[PY,'-B','deploy/security/check-tls-trust.py','--certifi','--pip'],E,0),('effective-node',['node','deploy/security/check-node-tls-trust.cjs'],E,0),('node-missing-inherited-mode',['node','deploy/security/check-node-tls-trust.cjs'],{k:v for k,v in E.items() if k!='NODE_OPTIONS'},1)]
results=[]
for name,args,env,expected in commands:
    args=['taskset','-c','16-17',*args]
    with (S/(name+'.log')).open('w') as out:
        proc=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=20)
    assert (proc.returncode==0)==(expected==0),(name,proc.returncode)
    item={'name':name,'command':args,'environment':env,'exit':proc.returncode,'log':str(S/(name+'.log'))}; results.append(item); print(json.dumps(item),flush=True)
(S/'runtime-trust.json').write_text(json.dumps(results,indent=2)+'\n')
