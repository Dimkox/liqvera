import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile

SOURCE = Path('/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit')
ROOT = Path(__file__).resolve().parent
HEAD = 'ca65575dd2283a47b7671b356847ed8fb9f5a125'
TREE = '53e1e0688f123d35a948bd8946eae7a33c71da88'
BASE = 'f1d3bffc46fa1459908fdff865fcfbfc831b7f7f'
MAIN = '3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd'
DEPLOYED = '1c020995adaa1a80fc8a97888aa838041d8e01d5'
PACKAGE = 'engineering/changes/20261021-task-ec1239/'

def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def changed(base, *paths):
    return git('diff', '--name-only', base, HEAD, '--', *paths).decode().splitlines()

def current_identity():
    assert git('rev-parse', 'HEAD', 'HEAD^{tree}').decode().splitlines() == [HEAD, TREE]
    assert git('status', '--porcelain=v1', '--untracked-files=all') == b''
    entries = []
    for raw in git('ls-tree', '-rz', HEAD).split(b'\0'):
        if not raw:
            continue
        meta, name = raw.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        assert kind == 'blob' and mode in {'100644', '100755'}, (name, mode)
        path = SOURCE / name.decode()
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert actual == blob, name
        assert bool(path.stat().st_mode & 0o111) == (mode == '100755'), name
        entries.append((name.decode(), mode, blob, sha(data)))
    return {'head': HEAD, 'tree': TREE, 'git_status': '', 'tracked_blobs': len(entries),
            'tracked_inventory_sha256': sha(json.dumps(entries, separators=(',', ':')).encode())}

initial = current_identity()
(ROOT / 'source-before.json').write_text(json.dumps(initial, indent=2) + '\n')
assert ROOT.parent.resolve() == ROOT.parent and ROOT.resolve() == ROOT
for path in (ROOT.parent, ROOT):
    assert stat.S_IMODE(path.stat().st_mode) == 0o700

snapshot = ROOT / 'snapshot'
snapshot.mkdir(mode=0o700)
archive_bytes = git('archive', '--format=tar', HEAD)
with tarfile.open(fileobj=io.BytesIO(archive_bytes)) as archive:
    for member in archive:
        relative = PurePosixPath(member.name)
        assert not relative.is_absolute() and '..' not in relative.parts
        target = snapshot / member.name
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            assert member.isfile(), member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.extractfile(member).read())
            target.chmod(member.mode)
for raw in git('ls-tree', '-rz', HEAD).split(b'\0'):
    if not raw:
        continue
    meta, name = raw.split(b'\t', 1)
    mode, _, blob = meta.decode().split()
    target = snapshot / name.decode()
    data = target.read_bytes()
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == blob
    assert bool(target.stat().st_mode & 0o111) == (mode == '100755')

preservation = json.loads((snapshot / PACKAGE / 'evidence/product-preservation.json').read_text())
assert preservation['comparison_base'] == BASE
assert preservation['current_main'] == MAIN
assert preservation['production_evidence_source'] == DEPLOYED
for ref in (BASE, MAIN, 'v0.0.5', preservation['product_commit']):
    subprocess.run(['git', '-C', str(SOURCE), 'merge-base', '--is-ancestor', ref, HEAD], check=True)
assert git('rev-parse', preservation['product_commit'] + '^{tree}').decode().strip() == preservation['product_tree']
package_delta = changed(preservation['product_commit'])
assert package_delta and all(p.startswith(PACKAGE) for p in package_delta)
runtime_delta = changed(DEPLOYED, *preservation['unchanged_runtime_input_roots'])
assert runtime_delta == preservation['runtime_input_delta'] == []
assert changed(BASE, 'apps/mezo-gateway', 'packages', 'services', 'schemas', 'apps/mezo-web/public', 'deploy/mezo-evidence/compose.yml') == []
for name, expected in preservation['historical_evidence_sha256'].items():
    data = (snapshot / name).read_bytes()
    assert sha(data) == expected, name
    assert data == git('show', MAIN + ':' + name), name

tls = json.loads((snapshot / 'docs/security/2026-10-21-tls-deployment.json').read_text())
assert tls['source_commit'] == DEPLOYED
assert tls['verification']['gateway_tests_passed'] == 71
assert tls['verification']['gateway_postgres_tests_passed'] == 13
assert tls['verification']['gateway_skipped'] == 0
assert tls['backup_restore']['source_commit'] == DEPLOYED
assert tls['backup_restore']['restored_ledger_matches'] is True
assert tls['backup_restore']['ledger'] == tls['preservation']['ledger']
assert tls['getzilla']['raw_exit_code'] == 1
assert tls['getzilla']['zero_gap_complete'] is False
assert tls['getzilla']['passing_final_receipt_created'] is False
assert tls['backup_restore']['postgres_image'] != tls['preservation']['services']['postgres']['image']
policy = (snapshot / 'apps/mezo-gateway/src/migration-policy.ts').read_text()
approved = dict(re.findall(r"name:'([^']+\.sql)',sha256:'([0-9a-f]{64})'", policy))
recorded = dict(line.split('|') for line in tls['preservation']['ledger'] if '.sql|' in line)
files = sorted((snapshot / 'apps/mezo-gateway/migrations').glob('*.sql'))
assert len(approved) == len(recorded) == len(files) == 8
for path in files:
    assert sha(path.read_bytes()) == approved[path.name] == recorded[path.name], path.name
    relative = path.relative_to(snapshot).as_posix()
    assert path.read_bytes() == git('show', BASE + ':' + relative)

policy_path = snapshot / 'engineering/verification-dispositions.json'
dispositions = json.loads(policy_path.read_text())['dispositions']
assert len(dispositions) == 3
assert [item['kind'] for item in dispositions] == ['public-token-address', 'public-token-address', 'immutable-markdown-whitespace']
for item in dispositions:
    data = (snapshot / item['path']).read_bytes()
    assert sha(data) == item['sha256']
    assert sha((snapshot / item['evidence']['path']).read_bytes()) == item['evidence']['sha256']
    if item['kind'] == 'public-token-address':
        line = data.decode().splitlines()[item['line'] - 1]
        suffix = line[item['column'] - 1:]
        matching = [suffix[:i] for i in range(1, len(suffix) + 1) if sha(suffix[:i].encode()) == item['match_sha256']]
        assert len(matching) == 1
        assert '0x118917a40FAF1CD7a13dB0Ef56C86De7973Ac503' in matching[0]
    else:
        assert item['check'] == 'git-diff-check' and item['rule'] == 'new-blank-line-at-eof'
        assert item['line'] == 51 and data.endswith(b'\n\n') and len(data.splitlines()) == 51
canonical = snapshot / 'packages/mezo-protocol/src/index.ts'
assert sha(canonical.read_bytes()) == '28a5c0a9143a803bbd836ab59b3aad31cd225bb6459eb97778a256aada88489b'
raw_diff = subprocess.run(['git', '-C', str(SOURCE), 'diff', '--check', BASE, HEAD], text=True, capture_output=True)
expected_diagnostic = 'docs/security/2026-10-21-wave1-deployment.md:51: new blank line at EOF.\n'
assert raw_diff.returncode == 2 and raw_diff.stdout == expected_diagnostic and raw_diff.stderr == '', raw_diff
(ROOT / 'raw-diff-check.log').write_text(raw_diff.stdout)

for path, public in tls['preservation']['corrected_ca_public_checks'].items():
    if path.startswith('/demo/latest-live/'):
        actual = snapshot / 'apps/mezo-web/public' / path.removeprefix('/')
        assert actual.stat().st_size == public['bytes'] and sha(actual.read_bytes()) == public['sha256']

final = current_identity()
assert initial == final
(ROOT / 'source-after-static.json').write_text(json.dumps(final, indent=2) + '\n')
result = {'source': final, 'original_range_changed_paths': len(changed(BASE)),
          'metadata_only_package_paths': len(package_delta), 'unchanged_runtime_roots': len(preservation['unchanged_runtime_input_roots']),
          'unchanged_historical_evidence_files': len(preservation['historical_evidence_sha256']), 'unchanged_migrations': len(files),
          'dispositions_bound': len(dispositions), 'raw_diff_check_exit': raw_diff.returncode,
          'raw_diff_diagnostic': raw_diff.stdout.strip(), 'public_preview_assets_preserved': 2,
          'historical_source': tls['source_commit'], 'historical_recorded_at': tls['recorded_at'],
          'historical_gateway_tests': 71, 'historical_postgres_tests': 13, 'historical_skips': 0,
          'historical_gate_exit': tls['getzilla']['raw_exit_code'], 'live_calls': 0}
(ROOT / 'checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
