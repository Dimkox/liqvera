from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
scratch=Path(__file__).resolve().parent
root=scratch/'source'
tool=Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions')
sys.path.insert(0,str(tool/'.getzilla'))
from getzilla.verification import _secret_scan,_git_diff_check,GitRangeBase,GitRangeSelection
from getzilla import verification_dispositions as vd
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
base='f1d3bffc46fa1459908fdff865fcfbfc831b7f7f';main='3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd'
assert git('rev-parse','HEAD').decode().strip()=='ca65575dd2283a47b7671b356847ed8fb9f5a125'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=tool,text=True).strip()=='4cf2abf21753e61383e3d89be593e0fb815afc7f'
files=git('diff','--name-only',base,'HEAD').decode().splitlines()
policy_path=root/vd.CONFIG_PATH
policy_bytes=policy_path.read_bytes();policy=json.loads(policy_bytes)
paths={e['path'] for e in policy['dispositions']}|{e['evidence']['path'] for e in policy['dispositions']}|{vd.CONFIG_PATH}
original={p:(root/p).read_bytes() for p in paths}
identities=[]
for e in policy['dispositions']:
    raw=(root/e['path']).read_bytes();ev=(root/e['evidence']['path']).read_bytes()
    assert vd.sha256(raw)==e['sha256'] and vd.sha256(ev)==e['evidence']['sha256']
    record={'id':e['id'],'path':e['path'],'sha256':vd.sha256(raw),'line':e['line'],'mode':git('ls-files','--stage','--',e['path']).decode().split()[0],'evidence_sha256':vd.sha256(ev)}
    if e['check']=='secret-scan':
        matches=[m for m in vd.SECRET_PATTERNS['generic-secret'].finditer(raw.decode()) if vd.location(raw.decode(),m.start())==(e['line'],e['column'])]
        assert len(matches)==1 and vd.sha256(matches[0].group().encode())==e['match_sha256']
        assert '0x118917a40FAF1CD7a13dB0Ef56C86De7973Ac503' in matches[0].group()
        record.update(column=e['column'],match_sha256=e['match_sha256'])
    else:
        assert vd.eof_blank_line(raw)==e['line']
        old=git('show',main+':'+e['path']);assert old==raw
        record['unchanged_from_main']=True
    identities.append(record)
selection=GitRangeSelection(bases=[GitRangeBase('route','independent-security',base,base),GitRangeBase('main','independent-security',main,main)])
secret=_secret_scan(root,files);whitespace=_git_diff_check(root,'pr',selection)
assert secret.status=='pass' and whitespace.status=='pass'
raw_secret=[x for x in secret.details if x.get('observation')];raw_space=[x for x in whitespace.details if x.get('observation')]
assert len(raw_secret)==2 and all(x['severity']=='error' and x['effective_severity']=='info' for x in raw_secret)
assert len(raw_space)==1 and raw_space[0]['path']==policy['dispositions'][2]['path'] and raw_space[0]['line']==51 and raw_space[0]['severity']=='error' and raw_space[0]['effective_severity']=='info'
assert [x['exit_code'] for x in whitespace.details if x.get('code')=='diff-check-command']==[0,0,2,0]
(scratch/'native-secret-scan.json').write_text(json.dumps(secret.to_dict(),indent=2)+'\n')
(scratch/'native-diff-check.json').write_text(json.dumps(whitespace.to_dict(),indent=2)+'\n')
mutations=[]
def restore():
    for p,data in original.items():(root/p).write_bytes(data)
for case in ['missing_policy','unknown_rule','stale_target','stale_evidence','stale_match','new_credential']:
    restore();current=json.loads(policy_bytes)
    if case=='missing_policy':policy_path.unlink()
    elif case=='unknown_rule':current['dispositions'][0]['rule']='unknown-rule'
    elif case=='stale_target':
        target=root/current['dispositions'][0]['path'];target.write_bytes(target.read_bytes()+b'// changed\n')
    elif case=='stale_evidence':
        target=root/current['dispositions'][0]['evidence']['path'];target.write_bytes(target.read_bytes()+b'Changed review.\n')
    elif case=='stale_match':current['dispositions'][0]['match_sha256']='0'*64
    elif case=='new_credential':
        target=root/current['dispositions'][0]['path'];target.write_bytes(target.read_bytes()+b"\npassword = 'synthetic-review-only-value';\n")
        current['dispositions'][0]['sha256']=vd.sha256(target.read_bytes())
    if case!='missing_policy':policy_path.write_text(json.dumps(current,indent=2)+'\n')
    result=_secret_scan(root,files if case in ['missing_policy','new_credential'] else [])
    assert result.status=='fail',case
    summary=next(x for x in result.details if x.get('code')=='disposition-summary')
    if case=='new_credential':assert (summary['observed'],summary['disposed'],summary['unresolved'])==(3,2,1)
    if case=='missing_policy':assert summary['disposed']==0 and summary['observed']==2
    mutations.append({'case':case,'status':result.status,'observed':summary['observed'],'disposed':summary['disposed'],'unresolved':summary['unresolved']})
restore();assert not git('status','--porcelain=v1').strip()
(scratch/'disposition-results.json').write_text(json.dumps({'source_head':'ca65575dd2283a47b7671b356847ed8fb9f5a125','tool_head':'4cf2abf21753e61383e3d89be593e0fb815afc7f','changed_paths':len(files),'original_base':base,'secondary_base':main,'policy_sha256':vd.sha256(policy_bytes),'identities':identities,'raw_secret_count':len(raw_secret),'raw_whitespace_count':len(raw_space),'raw_git_exit_codes':[0,0,2,0],'negative_cases':mutations},indent=2)+'\n')
print(json.dumps({'changed_paths':len(files),'secret_status':secret.status,'diff_status':whitespace.status,'raw_secret_count':2,'raw_whitespace_count':1,'negative_cases':mutations}))
