from pathlib import Path
import json,os,subprocess
scratch=Path(__file__).resolve().parent
root=scratch/'source'
python='/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit/.venv/bin/python'
empty=scratch/'empty-ca';empty.mkdir(mode=0o700)
env={'PATH':os.environ['PATH'],'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(scratch/'tmp'),'PIP_CONFIG_FILE':os.devnull}
metadata=json.loads(subprocess.check_output([python,'-B','-c','import json,certifi,pip; print(json.dumps({"certifi":certifi.__version__,"pip":pip.__version__,"cafile":certifi.where()}))'],env=env,text=True))
assert metadata['certifi']=='2026.10.19' and metadata['pip']=='26.2.2'
env.update(SSL_CERT_FILE=metadata['cafile'],SSL_CERT_DIR=str(empty),NODE_OPTIONS='--use-openssl-ca')
rows=[]
for argv in [[python,'-B',str(root/'deploy/security/check-tls-trust.py'),'--certifi','--pip'],['node',str(root/'deploy/security/check-node-tls-trust.cjs')]]:
    result=subprocess.run(argv,env=env,text=True,capture_output=True,timeout=20)
    assert result.returncode==0,result.stderr
    rows.append({'argv':argv,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
output={'scope':'isolated offline trust regression; no production or network check','metadata':metadata,'empty_ca_dir':str(empty),'pip_config_disabled':True,'results':rows}
(scratch/'effective-trust-results.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
