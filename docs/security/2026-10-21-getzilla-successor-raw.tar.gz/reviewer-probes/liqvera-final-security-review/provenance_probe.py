from pathlib import Path
import hashlib,json,subprocess
scratch=Path(__file__).resolve().parent
candidate=Path('/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit')
root=scratch/'source';tool=Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions')
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(raw):return hashlib.sha256(raw).hexdigest()
package=root/'engineering/changes/20261021-task-ec1239/evidence'
binding=json.loads((package/'tool-binding.json').read_text())
assert git(tool,'rev-parse','HEAD').decode().strip()==binding['tool_commit']
assert git(tool,'rev-parse','HEAD^{tree}').decode().strip()==binding['tool_tree']
overlay=[]
for relative,expected in binding['overlay'].items():
    actual=sha((candidate/relative).read_bytes())
    assert actual==expected,relative
    assert not git(candidate,'ls-files','--',relative).strip(),relative
    overlay.append({'path':relative,'sha256':actual,'tracked':False})
reports={}
for name,expected in binding['tool_review_reports'].items():
    path=tool/f'engineering/changes/20261021-task-d83415/evidence/{name}-review.md'
    actual=sha(path.read_bytes());assert actual==expected,name
    reports[name]=actual
review_delta=git(tool,'diff','--name-only','4c4cd124b2e382d3c6d8b19e2efe2c8fb45219ae',binding['tool_commit']).decode().splitlines()
assert len(review_delta)==4 and all(p.startswith('engineering/changes/20261021-task-d83415/evidence/') and p.endswith('-review.md') for p in review_delta)
preservation=json.loads((package/'product-preservation.json').read_text())
runtime_delta=git(root,'diff','--name-only',preservation['production_evidence_source'],'HEAD','--',*preservation['unchanged_runtime_input_roots']).decode().splitlines()
assert runtime_delta==[]
history=[]
for relative,expected in preservation['historical_evidence_sha256'].items():
    raw=(root/relative).read_bytes()
    assert sha(raw)==expected
    assert raw==git(root,'show',preservation['current_main']+':'+relative)
    history.append({'path':relative,'sha256':expected,'unchanged_from_main':True})
assert not git(root,'ls-files','.getzilla').strip()
protocol=sha((root/'packages/mezo-protocol/src/index.ts').read_bytes())
assert protocol=='28a5c0a9143a803bbd836ab59b3aad31cd225bb6459eb97778a256aada88489b'
result={'tool_commit':binding['tool_commit'],'tool_tree':binding['tool_tree'],'tool_reports':reports,'tool_review_only_delta':review_delta,'overlay':overlay,'policy_sha256':sha((root/'engineering/verification-dispositions.json').read_bytes()),'runtime_input_delta':runtime_delta,'historical_evidence':history,'protocol_sha256':protocol,'upstream_public_identity':'https://mezo.org/docs/developers/getting-started/musd-payments-x402/','upstream_checked':'2026-10-21','public_contract':'0x118917a40FAF1CD7a13dB0Ef56C86De7973Ac503','chain_id':31611,'tracked_getzilla_files':0}
(scratch/'provenance-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'overlay_files_matched':len(overlay),'tool_reports_matched':len(reports),'tool_review_only_delta':review_delta,'historical_files_matched':len(history),'runtime_delta':runtime_delta,'tracked_getzilla_files':0}))
