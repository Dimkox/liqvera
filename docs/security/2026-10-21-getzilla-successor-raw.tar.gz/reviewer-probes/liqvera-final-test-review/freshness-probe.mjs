import assert from 'node:assert/strict';
import { mountMezoFinance } from './snapshot/apps/mezo-web/src/mezo-finance-panel.ts';

class Element {
  children = []; attrs = {}; listeners = {}; checked = false; disabled = false; parent = null;
  constructor(tag) { this.tagName = tag; }
  append(...children) { for (const child of children) { this.children.push(child); if (typeof child === 'object') child.parent = this; } }
  after(child) { this.parent.append(child); }
  setAttribute(key, value) { this.attrs[key] = value; }
  hasAttribute(key) { return key === 'href' ? typeof this.href === 'string' : Object.hasOwn(this.attrs, key); }
  removeAttribute(key) { delete this.attrs[key]; if (key === 'href') delete this.href; }
  addEventListener(name, fn) { (this.listeners[name] ??= []).push(fn); }
  remove() { this.parent.children = this.parent.children.filter(x => x !== this); }
  async emit(name) { for (const fn of this.listeners[name] ?? []) await fn({ preventDefault() {} }); }
  find(id) { return this.id === id ? this : this.children.filter(x => typeof x === 'object').map(x => x.find(id)).find(Boolean); }
}

const actualNow = Date.now;
const base = actualNow();
let now = base;
Date.now = () => now;
const root = new Element('div'), host = new Element('div'); root.append(host);
globalThis.document = { createElement: tag => new Element(tag) };
const account = '0x' + '1'.repeat(40);
const network = { name:'testnet', chainId:31611, asset:'0x118917a40FAF1CD7a13dB0Ef56C86De7973Ac503', decimals:18 };
const calls = [];
const provider = { async request({ method }) {
  calls.push(method);
  if (method === 'eth_chainId') return '0x7b7b';
  if (method === 'eth_accounts') return [account];
  if (method === 'eth_getBlockByNumber') return { number:'0x123', hash:'0x'+'a'.repeat(64) };
  if (method === 'eth_call') return '0x'+'0'.repeat(64);
  throw new Error('Unexpected wallet method');
} };
const context = { provider, account, paymentGuard:'clear', busy:false, onMezo:true,
  quote:{ quote_id:'synthetic', state:'READY', terms:{ network:'eip155:31611', chain_id:31611,
    asset:network.asset, decimals:18, amount_atomic:'10000000000000000', expected_payer:account,
    expires_at:new Date(base+60000).toISOString() } } };
const panel = mountMezoFinance({ host, network, getContext: () => context });
try {
  await root.find('mezo-balance-check').emit('click');
  const ack = root.find('mezo-borrow-ack'), link = root.find('mezo-borrow-link');
  assert.equal(ack.disabled, false);
  ack.checked = true; await ack.emit('change');
  assert.equal(link.href, 'https://testnet.mezo.org/feature/borrow');
  now = base + 29999; panel.update();
  assert.equal(ack.disabled, false);
  now = base + 30000; panel.update();
  assert.equal(ack.disabled, true, '30-second-old balance must disable acknowledgement');
  assert.equal(link.href, undefined, '30-second-old balance must remove borrowing link');
  assert.deepEqual(new Set(calls), new Set(['eth_chainId', 'eth_accounts', 'eth_call', 'eth_getBlockByNumber']));
  console.log('PASS: ready at 29,999ms, blocked at 30,000ms; only read RPC methods used.');
} finally {
  panel.dispose(); Date.now = actualNow;
}
