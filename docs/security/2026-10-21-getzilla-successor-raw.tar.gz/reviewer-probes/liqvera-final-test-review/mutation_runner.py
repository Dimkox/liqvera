import json
import pathlib
import subprocess

S = pathlib.Path(__file__).resolve().parent
ROOT = S / 'snapshot'
PYTHON = '/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit/.venv/bin/python'
PREFIX = ['taskset', '-c', '18-19', 'env', f'TMPDIR={S / "tmp"}',
          'PYTHONDONTWRITEBYTECODE=1', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD=1']
PYTEST = PREFIX + [PYTHON, '-B', '-m', 'pytest', '-p', 'no:cacheprovider', '-q']
NODE = PREFIX + ['node', '--test', '--test-concurrency=2']
ORACLE = PREFIX + ['node', str(S / 'freshness-probe.mjs')]
results = []

def run(name, command, cwd):
    p = subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=120)
    output = p.stdout + p.stderr
    (S / 'logs' / (name + '.log')).write_text(output)
    record = {'id':name, 'command':command, 'cwd':str(cwd), 'returncode':p.returncode,
              'outcome':'survived' if p.returncode == 0 else ('killed' if 'AssertionError' in output else 'inconclusive')}
    results.append(record)
    print(json.dumps(record), flush=True)
    return p.returncode

assert run('freshness_baseline', ORACLE, S) == 0
mutations = [
    ('M1_pip_downgrade', 'pyproject.toml', 'pip==26.2.2', 'pip==26.2.1',
     PYTEST + ['tests/test_tls_trust_guard.py::test_development_install_preserves_the_audited_pip_bootstrap'], ROOT),
    ('M2_skip_lazy_ca_directory', 'deploy/security/check-tls-trust.py', 'if cafile is None:', 'if False:',
     PYTEST + ['tests/test_tls_trust_guard.py'], ROOT),
    ('M3_drop_unknown_payment_guard', 'apps/mezo-web/src/mezo-finance.mjs',
     "if (context.paymentGuard !== 'clear')", 'if (false)',
     NODE + ['test/mezo-finance.test.mjs'], ROOT / 'apps/mezo-web'),
    ('M6_remove_balance_age_limit', 'apps/mezo-web/src/mezo-finance-panel.ts',
     'Date.now() - lastBalance.at < 30000', 'Date.now() - lastBalance.at < Infinity',
     NODE + ['test/mezo-finance-panel.test.mjs'], ROOT / 'apps/mezo-web'),
]
for name, relative, old, new, command, cwd in mutations:
    path = ROOT / relative; original = path.read_bytes(); text = original.decode()
    assert text.count(old) == 1, (name, text.count(old))
    try:
        path.write_text(text.replace(old, new))
        run(name, command, cwd)
        if name == 'M6_remove_balance_age_limit':
            assert run(name + '_oracle', ORACLE, S) == 1
    finally:
        path.write_bytes(original)
(S / 'mutation-results.json').write_text(json.dumps(results, indent=2) + '\n')
