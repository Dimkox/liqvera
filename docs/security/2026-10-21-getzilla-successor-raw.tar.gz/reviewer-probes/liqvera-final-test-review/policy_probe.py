import hashlib
import json
import pathlib
import subprocess
import sys

SCRATCH = pathlib.Path(__file__).resolve().parent
ROOT = SCRATCH / 'snapshot'
TOOL = pathlib.Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-dispositions')
BASE = 'f1d3bffc46fa1459908fdff865fcfbfc831b7f7f'
tool_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=TOOL, text=True).strip()
assert tool_head == '4cf2abf21753e61383e3d89be593e0fb815afc7f'
sys.path.insert(0, str(TOOL / '.getzilla'))
from getzilla.verification import GitRangeBase, GitRangeSelection, _git_diff_check, _secret_scan

policy_path = ROOT / 'engineering/verification-dispositions.json'
policy_raw = policy_path.read_bytes()
policy = json.loads(policy_raw)
paths = [e['path'] for e in policy['dispositions'] if e['check'] == 'secret-scan']
assert len(policy['dispositions']) == 3 and len(paths) == 2
results = []

def observe(name, result):
    value = result.to_dict()
    (SCRATCH / 'logs' / (name + '.json')).write_text(json.dumps(value, indent=2) + '\n')
    summary = next(item for item in result.details if item['code'] == 'disposition-summary')
    record = {'name': name, 'status': result.status, 'summary': summary,
              'raw_severities': [item['severity'] for item in result.details if item.get('observation')],
              'command_exits': [item['exit_code'] for item in result.details if item['code'] == 'diff-check-command']}
    results.append(record)
    print(json.dumps(record), flush=True)
    return summary

secret = _secret_scan(ROOT, paths)
summary = observe('secret_baseline', secret)
assert secret.status == 'pass' and summary['observed'] == summary['disposed'] == 2 and summary['unresolved'] == 0
assert all(item['severity'] == 'error' for item in secret.details if item.get('observation'))
selection = GitRangeSelection(bases=[GitRangeBase('route', 'original-full-base', BASE, BASE)])
whitespace = _git_diff_check(ROOT, 'pr', selection)
summary = observe('eof_original_base', whitespace)
assert whitespace.status == 'pass' and summary['disposed'] == 1 and summary['unresolved'] == 0
assert any(BASE + '..HEAD' in ' '.join(item['command']) for item in whitespace.details if item['code'] == 'diff-check-command')
assert any(item.get('exit_code') == 2 for item in whitespace.details)

evidence = ROOT / policy['dispositions'][0]['evidence']['path']
evidence_raw = evidence.read_bytes()
try:
    evidence.write_bytes(evidence_raw + b'Changed local review evidence.\n')
    result = _secret_scan(ROOT, [])
    summary = observe('M4_stale_evidence', result)
    assert result.status == 'fail' and summary['unresolved'] > 0
finally:
    evidence.write_bytes(evidence_raw)

target = ROOT / paths[0]
target_raw = target.read_bytes()
try:
    target.write_bytes(target_raw + b'\nconst password = "reviewer-synthetic-canary";\n')
    changed = json.loads(policy_raw)
    changed['dispositions'][0]['sha256'] = hashlib.sha256(target.read_bytes()).hexdigest()
    policy_path.write_text(json.dumps(changed, indent=2) + '\n')
    result = _secret_scan(ROOT, paths)
    summary = observe('M5_extra_occurrence', result)
    assert result.status == 'fail' and summary['observed'] == 3 and summary['disposed'] == 2 and summary['unresolved'] == 1
    assert 'reviewer-synthetic-canary' not in json.dumps(result.to_dict())
finally:
    target.write_bytes(target_raw)
    policy_path.write_bytes(policy_raw)

assert policy_path.read_bytes() == policy_raw and evidence.read_bytes() == evidence_raw and target.read_bytes() == target_raw
(SCRATCH / 'policy-results.json').write_text(json.dumps({'tool_head': tool_head, 'base': BASE, 'results': results}, indent=2) + '\n')
