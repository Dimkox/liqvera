from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

S = Path(__file__).resolve().parent
C = Path('/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit')
T = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final')
PACKAGE = 'engineering/changes/20261021-task-ec1239/'
TOOL_PACKAGE = 'engineering/changes/20261021-task-d83415/'
HEAD = '1b90f54c7ab26a7689cb892687175ac12cb7e3a4'
TREE = '23d2befc1bcf354fe5ca9c920ed6d54b62fe37dd'
BASE = 'f1d3bffc46fa1459908fdff865fcfbfc831b7f7f'
FIRST = 'ca65575dd2283a47b7671b356847ed8fb9f5a125'
PRODUCT = '17a70595e98aa183afac115e5b99488830fba712'
DEPLOYED = '1c020995adaa1a80fc8a97888aa838041d8e01d5'
TOOL_HEAD = '45be42f74b5a8ee6f079f8ac55206e475936fdc6'
TOOL_TREE = 'bcdd090531e657ee1d3cd20c340205df86fc8900'
TOOL_REVIEWED = '3968ae4445836eda9cf377035b1d1f64fe9659b0'
E = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'GIT_OPTIONAL_LOCKS': '0',
     'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1',
     'PYTHONDONTWRITEBYTECODE': '1'}
commands = []
def git(root, *args, raw=False):
    command = ['git', '-C', str(root), *args]
    result = subprocess.run(command, env=E, capture_output=True, check=True)
    commands.append({'command': command, 'environment': E, 'exit': result.returncode})
    return result.stdout if raw else result.stdout.decode().strip()
def digest(data):
    return hashlib.sha256(data).hexdigest()
for p in (S, *S.parents):
    mode = p.stat().st_mode
    assert not mode & (stat.S_IWGRP | stat.S_IWOTH | stat.S_ISVTX), str(p)
    assert p.stat().st_uid in (0, os.getuid())
assert S.resolve() == S and stat.S_IMODE(S.stat().st_mode) == 0o700
assert git(C, 'rev-parse', 'HEAD') == HEAD
assert git(C, 'rev-parse', 'HEAD^{tree}') == TREE
assert not git(C, 'status', '--porcelain=v1', '--untracked-files=all')
assert git(T, 'rev-parse', 'HEAD') == TOOL_HEAD
assert git(T, 'rev-parse', 'HEAD^{tree}') == TOOL_TREE
assert not git(T, 'status', '--porcelain=v1', '--untracked-files=all')
assert git(C, 'merge-base', HEAD, BASE) == BASE
assert git(C, 'rev-parse', 'refs/remotes/origin/main') == '3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd'
assert git(C, 'merge-base', HEAD, 'refs/remotes/origin/main') == '3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd'
delta = git(C, 'diff', '--name-only', FIRST, HEAD).splitlines()
assert len(delta) == 22 and all(p.startswith(PACKAGE) for p in delta)
assert not git(C, 'diff', '--name-only', PRODUCT, HEAD, '--', '.', ':(exclude)engineering/changes/**')
runtime_roots = ['apps', 'services', 'packages', 'schemas', 'deploy', 'requirements.lock',
                 'requirements-dev.lock', 'Makefile', '.github/workflows/verify.yml']
for path in runtime_roots:
    git(C, 'cat-file', '-e', HEAD + ':' + path)
assert not git(C, 'diff', '--name-only', DEPLOYED, HEAD, '--', *runtime_roots)
assert not git(C, 'ls-files', '.getzilla', '.grok', '.agents')
for name in ('.getzilla/getzilla', '.grok/hooks'):
    assert not (C / name).exists()
binding = json.loads((C / PACKAGE / 'evidence/tool-binding.json').read_text())
old_binding = json.loads((C / PACKAGE / 'evidence/first-tool-binding.json').read_text())
assert binding['tool_commit'] == TOOL_HEAD and binding['tool_tree'] == TOOL_TREE
assert old_binding['tool_commit'] == '4cf2abf21753e61383e3d89be593e0fb815afc7f'
assert git(C, 'show', FIRST + ':' + PACKAGE + 'evidence/tool-binding.json', raw=True) == (C / PACKAGE / 'evidence/first-tool-binding.json').read_bytes()
overlay = binding['overlay']
assert len(overlay) == 48 and set(overlay) == set(old_binding['overlay'])
actual_overlay = {str(p.relative_to(C)) for folder in ('.getzilla/config', '.getzilla/sast', '.getzilla/templates')
                  for p in (C / folder).rglob('*') if p.is_file()}
assert actual_overlay == set(overlay)
overlay_values = {}
for name, expected in overlay.items():
    p = C / name
    assert not p.is_symlink() and p.resolve() == p and stat.S_ISREG(p.stat().st_mode)
    local_hash = digest(p.read_bytes())
    committed_hash = digest(git(T, 'show', TOOL_HEAD + ':' + name, raw=True))
    assert local_hash == expected == committed_hash, name
    overlay_values[name] = local_hash
changed_overlays = [p for p in overlay if overlay[p] != old_binding['overlay'][p]]
assert sorted(changed_overlays) == ['.getzilla/config/managed.json', '.getzilla/config/routing.json']
tool_reports = {}
for role, expected in binding['tool_review_reports'].items():
    path = TOOL_PACKAGE + 'evidence/' + role + '-review.md'
    data = git(T, 'show', TOOL_HEAD + ':' + path, raw=True)
    assert digest(data) == expected
    tool_reports[path] = expected
assert set(git(T, 'diff', '--name-only', TOOL_REVIEWED, TOOL_HEAD).splitlines()) == set(tool_reports)
local_prior = S.parent / 'liqvera-final-code-review.md'
preserved_prior = C / PACKAGE / 'evidence/first-code-review.md'
assert local_prior.read_bytes() == preserved_prior.read_bytes()
policy_path = 'engineering/verification-dispositions.json'
assert digest((C / policy_path).read_bytes()) == binding['policy_sha256']
assert git(C, 'show', FIRST + ':' + policy_path, raw=True) == (C / policy_path).read_bytes()
spec = json.loads((C / PACKAGE / 'change-spec.yaml').read_text())
prior_spec = json.loads(git(C, 'show', FIRST + ':' + PACKAGE + 'change-spec.yaml'))
assert spec['approvals']['required_scopes'] == ['scope_and_design_approval']
prior_spec['approvals']['required_scopes'] = ['scope_and_design_approval']
assert prior_spec == spec
state = json.loads((C / PACKAGE / 'state.json').read_text())
assert state['status'] == 'reviewing'
invocation = json.loads((C / PACKAGE / 'evidence/first-gate-invocation.json').read_text())
assert invocation['returncode'] == 1 and invocation['head'] == '3cadcb7fca99b9d8929a91103735a87cbafeecb0'
paths = git(C, 'diff', '--name-only', BASE, HEAD).splitlines()
record = {'at': datetime.now(timezone.utc).isoformat(), 'head': HEAD, 'tree': TREE, 'base': BASE,
          'first_reviewed': FIRST, 'product': PRODUCT, 'status': '',
          'tool_head': TOOL_HEAD, 'tool_tree': TOOL_TREE, 'tool_status': '',
          'delta_paths': delta, 'source_sha256': {p: digest((C / p).read_bytes()) for p in paths},
          'overlay_sha256': overlay_values, 'changed_overlays': changed_overlays,
          'tool_reports': tool_reports, 'first_code_review_sha256': digest(local_prior.read_bytes()),
          'disposition_policy_sha256': binding['policy_sha256'], 'runtime_roots_equal_deployed': runtime_roots,
          'product_equal_outside_engineering_changes': True, 'mutation': 'skipped (non-critical metadata delta)',
          'commands': commands}
mode = sys.argv[1]
assert mode in ('before', 'after')
if mode == 'after':
    before = json.loads((S / 'source-before.json').read_text())
    for key in ('head', 'tree', 'status', 'tool_head', 'tool_tree', 'tool_status',
                'source_sha256', 'overlay_sha256', 'first_code_review_sha256', 'tool_reports'):
        assert record[key] == before[key], key
    record['reviewed-tree-modified'] = 'no'
(S / ('source-' + mode + '.json')).write_text(json.dumps(record, indent=2) + '\n')
if mode == 'before':
    (S / 'actual-delta.diff').write_bytes(git(C, 'diff', FIRST, HEAD, raw=True))
print(json.dumps({'mode': mode, 'head': HEAD, 'tree': TREE, 'changed_paths_from_original': len(paths),
                  'delta_paths_from_first_review': len(delta), 'overlay_hashes_match': len(overlay_values),
                  'tool_report_hashes_match': len(tool_reports), 'product_unchanged': True,
                  'runtime_inputs_unchanged_from_deployed': True, 'first_gate_preserved_as_failed': True,
                  'first_code_review_sha256': record['first_code_review_sha256'], 'at': record['at']}, indent=2))
