import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

assert os.environ.get('GIT_OPTIONAL_LOCKS') == '0'
ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit')
TOOL = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final')
PACKAGE = 'engineering/changes/20261021-task-ec1239/'
HEAD = '1b90f54c7ab26a7689cb892687175ac12cb7e3a4'
TREE = '23d2befc1bcf354fe5ca9c920ed6d54b62fe37dd'
FIRST_REVIEW = 'ca65575dd2283a47b7671b356847ed8fb9f5a125'
FIRST_GATE = '3cadcb7fca99b9d8929a91103735a87cbafeecb0'
TOOL_HEAD = '45be42f74b5a8ee6f079f8ac55206e475936fdc6'
TOOL_REVIEW = '3968ae4445836eda9cf377035b1d1f64fe9659b0'

def git(*args, cwd=SOURCE):
    return subprocess.check_output(['git', '-C', str(cwd), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads((SOURCE / path).read_text())

assert git('rev-parse', 'HEAD', 'HEAD^{tree}').decode().splitlines() == [HEAD, TREE]
assert git('status', '--porcelain=v1', '--untracked-files=all') == b''
delta = git('diff', '--name-only', FIRST_REVIEW, HEAD).decode().splitlines()
assert len(delta) == 22 and all(path.startswith(PACKAGE) for path in delta)
preservation = read_json(PACKAGE + 'evidence/product-preservation.json')
product_delta = git('diff', '--name-only', preservation['product_commit'], HEAD).decode().splitlines()
assert all(path.startswith(PACKAGE) for path in product_delta)
for role in ('code', 'test', 'security', 'release', 'data'):
    original = git('show', FIRST_GATE + ':' + PACKAGE + 'evidence/' + role + '-review.md')
    assert (SOURCE / PACKAGE / ('evidence/first-' + role + '-review.md')).read_bytes() == original
    assert (SOURCE / PACKAGE / ('evidence/' + role + '-review.md')).read_bytes() == original
first_data = (SOURCE / PACKAGE / 'evidence/first-data-review.md').read_bytes()
assert sha(first_data) == 'b75ecc165629891d3b1fa003716de6f3343665015967834b2257d0908f8ec72e'
assert first_data == (ROOT.parent / 'liqvera-final-data-review.md').read_bytes()
for name in ('tool-binding.json', 'committed-tool-controls.json'):
    original = git('show', FIRST_REVIEW + ':' + PACKAGE + 'evidence/' + name)
    assert (SOURCE / PACKAGE / ('evidence/first-' + name)).read_bytes() == original
first_files = ('first-gate-getzilla-pr.json', 'first-gate-getzilla-pr.stderr', 'first-gate-invocation.json')
first_hashes = {}
for name in first_files:
    path = PACKAGE + 'evidence/' + name
    data = (SOURCE / path).read_bytes()
    assert data == git('show', '2475407c22701538487f932e492fd25c4ef93ca4:' + path)
    first_hashes[name] = sha(data)
first = read_json(PACKAGE + 'evidence/first-gate-getzilla-pr.json')
invocation = read_json(PACKAGE + 'evidence/first-gate-invocation.json')
assert first['status'] == 'fail' and first['evidence_status'] == 'not_recorded'
assert first['receipt_refusal'] == 'change specification cannot provide the current binding'
checks = {item['name']: item for item in first['checks']}
assert [name for name, item in checks.items() if item['status'] == 'fail'] == ['change-spec']
assert checks['pytest']['status'] == 'pass'
assert '956 passed, 85 subtests passed in 382.17s' in checks['pytest']['stdout']
assert 'red-risk requires approvals.required_scopes' in checks['change-spec']['details'][0]['message']
assert invocation['head'] == invocation['head_after'] == FIRST_GATE
assert invocation['tree'] == invocation['tree_after'] == 'b023e497f6d7b4b5cad4f2778e06b95b7efc42cf'
assert invocation['reviewed_head'] == FIRST_REVIEW
assert invocation['tool_commit'] == invocation['tool_head_after'] == '4cf2abf21753e61383e3d89be593e0fb815afc7f'
assert invocation['returncode'] == 1 and invocation['git_status_after'] == ''

spec_path = PACKAGE + 'change-spec.yaml'
old_spec = json.loads(git('show', FIRST_REVIEW + ':' + spec_path))
spec = read_json(spec_path)
assert spec['risk']['tier'] == 'red'
assert spec['approvals']['required_scopes'] == ['scope_and_design_approval']
spec['approvals']['required_scopes'] = []
assert spec == old_spec
gates_path = PACKAGE + 'human-gates.json'
old_gates = json.loads(git('show', FIRST_REVIEW + ':' + gates_path))
gates = read_json(gates_path)
decision_key = next(key for key, value in gates.items() if isinstance(value, list))
old_decisions = old_gates[decision_key]
assert gates[decision_key][:len(old_decisions)] == old_decisions
new_decisions = gates[decision_key][len(old_decisions):]
assert len(new_decisions) == 2
assert {item['action'] for item in new_decisions} == {None, 'migration-plan'}
assert all(item['scope_digest'] == 'b384a67ef56a78b97740755503d549c0c60b096ebec856ab61c304a245d99df8' for item in new_decisions)
assert any('authorize no live write' in item['reason'] for item in new_decisions)

binding = read_json(PACKAGE + 'evidence/tool-binding.json')
assert binding['tool_commit'] == TOOL_HEAD
assert git('rev-parse', 'HEAD', 'HEAD^{tree}', cwd=TOOL).decode().splitlines() == [TOOL_HEAD, binding['tool_tree']]
tool_reports = []
for role, expected in binding['tool_review_reports'].items():
    path = 'engineering/changes/20261021-task-d83415/evidence/' + role + '-review.md'
    report = (TOOL / path).read_bytes()
    assert sha(report) == expected
    assert TOOL_REVIEW.encode() in report
    tool_reports.append(path)
assert sorted(git('diff', '--name-only', TOOL_REVIEW, TOOL_HEAD, cwd=TOOL).decode().splitlines()) == sorted(tool_reports)
assert len(binding['overlay']) == 48
for path, expected in binding['overlay'].items():
    assert path.startswith(('.getzilla/config/', '.getzilla/sast/', '.getzilla/templates/'))
    assert sha((SOURCE / path).read_bytes()) == expected, path
assert sha((SOURCE / 'engineering/verification-dispositions.json').read_bytes()) == binding['policy_sha256']

controls_path = ROOT.parent / 'liqvera-second-committed-controls.json'
controls = json.loads(controls_path.read_text())
assert controls['head'] == controls['head_after'] == HEAD and controls['tree'] == TREE
assert controls['status_after'] == '' and controls['tool_commit'] == TOOL_HEAD
assert controls['original_base'] == preservation['comparison_base'] and controls['secondary_main'] == preservation['current_main']
assert controls['kind'] == 'bounded native observation, not a final gate or receipt'
assert controls['secret_scope'] == 'all tracked Liqvera files'
observed = {item['name']: item for item in controls['checks']}
for name in ('secret-scan', 'git-diff-check', 'change-spec'):
    assert observed[name]['status'] == 'pass'
assert observed['secret-scan']['summary'] == '2 potential secrets; 2 disposed; 0 unresolved'
assert '1 findings disposed; 0 unresolved' in observed['git-diff-check']['summary']
raw_secrets = [item for item in observed['secret-scan']['details'] if item.get('code') == 'generic-secret']
assert len(raw_secrets) == 2
assert all(item['severity'] == 'error' and item['effective_severity'] == 'info' for item in raw_secrets)
assert controls['spec']['specs'][0]['valid'] is True and controls['spec']['specs'][0]['errors'] == []

# Reuse only the original checker's pure definitions for the final identity check.
parsed = ast.parse((ROOT / 'check.py').read_text())
selected = []
names = {'SOURCE', 'ROOT', 'HEAD', 'TREE', 'BASE', 'MAIN', 'DEPLOYED', 'PACKAGE'}
for node in parsed.body:
    if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef)):
        selected.append(node)
    elif isinstance(node, ast.Assign) and all(isinstance(target, ast.Name) and target.id in names for target in node.targets):
        selected.append(node)
namespace = {'__file__': str(ROOT / 'check.py')}
exec(compile(ast.Module(body=selected, type_ignores=[]), str(ROOT / 'check.py'), 'exec'), namespace)
final = namespace['current_identity']()
assert final == json.loads((ROOT / 'source-before.json').read_text())
(ROOT / 'source-after.json').write_text(json.dumps(final, indent=2) + '\n')
result = {'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source': final,
          'first_review_delta_paths': len(delta), 'product_package_only_delta_paths': len(product_delta),
          'preserved_complete_first_reviews': 5, 'preserved_first_data_review_sha256': sha(first_data),
          'first_gate_files_sha256': first_hashes, 'first_gate_status': first['status'],
          'first_gate_exit': invocation['returncode'], 'first_gate_tests_passed': 956, 'first_gate_subtests_passed': 85,
          'current_scope_metadata_only': True, 'current_tool_commit': TOOL_HEAD,
          'bound_tool_review_reports': len(tool_reports), 'bound_overlay_files': len(binding['overlay']),
          'bounded_controls_sha256': sha(controls_path.read_bytes()), 'live_calls': 0}
(ROOT / 'delta-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
