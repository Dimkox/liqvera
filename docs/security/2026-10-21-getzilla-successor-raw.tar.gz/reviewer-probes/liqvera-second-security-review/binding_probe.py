from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import sys

os.environ['GIT_OPTIONAL_LOCKS'] = '0'
SCRATCH = Path(__file__).resolve().parent
ROOT = SCRATCH / 'source'
CANDIDATE = Path('/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit')
TOOL = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final')
PACKAGE = 'engineering/changes/20261021-task-ec1239/'
OLD_REVIEW = 'ca65575dd2283a47b7671b356847ed8fb9f5a125'
PRODUCT = '17a70595e98aa183afac115e5b99488830fba712'
BASE = 'f1d3bffc46fa1459908fdff865fcfbfc831b7f7f'
MAIN = '3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd'
sys.path.insert(0, str(TOOL / '.getzilla'))
from getzilla.verification import _secret_scan, _git_diff_check, GitRangeBase, GitRangeSelection
from getzilla import verification_dispositions as vd

def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

binding = json.loads((ROOT / PACKAGE / 'evidence/tool-binding.json').read_text())
assert git(TOOL, 'rev-parse', 'HEAD').decode().strip() == binding['tool_commit']
assert git(TOOL, 'rev-parse', 'HEAD^{tree}').decode().strip() == binding['tool_tree']
outside = git(ROOT, 'diff', '--name-only', PRODUCT, 'HEAD', '--', '.', ':!engineering/changes').decode().splitlines()
assert not outside
delta = git(ROOT, 'diff', '--name-only', OLD_REVIEW, 'HEAD').decode().splitlines()
assert all(path.startswith(PACKAGE) for path in delta)
tool_delta = git(TOOL, 'diff', '--name-only', '3968ae4445836eda9cf377035b1d1f64fe9659b0', 'HEAD').decode().splitlines()
assert sorted(tool_delta) == sorted('engineering/changes/20261021-task-d83415/evidence/' + role + '-review.md'
                                 for role in ('code','test','security','release'))
scanner_blobs = {}
for path in ('.getzilla/getzilla/verification.py', '.getzilla/getzilla/verification_dispositions.py'):
    original = git(TOOL, 'rev-parse', '4cf2abf21753e61383e3d89be593e0fb815afc7f:' + path).decode().strip()
    current = git(TOOL, 'rev-parse', 'HEAD:' + path).decode().strip()
    assert original == current
    scanner_blobs[path] = current

overlay = []
for path, expected in binding['overlay'].items():
    assert path.startswith(('.getzilla/config/', '.getzilla/sast/', '.getzilla/templates/'))
    assert '..' not in Path(path).parts
    for relative in (Path(path), *Path(path).parents):
        assert not (CANDIDATE / relative).is_symlink()
    target = CANDIDATE / path
    assert stat.S_ISREG(target.stat().st_mode)
    observed = sha(target.read_bytes())
    assert observed == expected == sha(git(TOOL, 'show', binding['tool_commit'] + ':' + path))
    assert not git(CANDIDATE, 'ls-files', '--', path).strip()
    assert subprocess.run(['git','-C',str(CANDIDATE),'check-ignore','-q','--',path]).returncode == 0
    overlay.append({'path':path, 'sha256':observed, 'tracked':False, 'ignored':True, 'matches_exact_tool':True})
assert len(overlay) == 48
reports = {}
for role, expected in binding['tool_review_reports'].items():
    path = 'engineering/changes/20261021-task-d83415/evidence/' + role + '-review.md'
    observed = sha(git(TOOL, 'show', binding['tool_commit'] + ':' + path))
    assert observed == expected
    reports[role] = observed

first = (ROOT / PACKAGE / 'evidence/first-security-review.md').read_bytes()
assert first == Path('/home/pall/projects/liqvera/.getzilla/runtime/completion/liqvera-final-security-review.md').read_bytes()
for name in ('tool-binding.json', 'committed-tool-controls.json'):
    assert (ROOT / PACKAGE / ('evidence/first-' + name)).read_bytes() == git(ROOT, 'show', OLD_REVIEW + ':' + PACKAGE + 'evidence/' + name)
spec_path = PACKAGE + 'change-spec.yaml'
old_spec = json.loads(git(ROOT, 'show', OLD_REVIEW + ':' + spec_path))
spec = json.loads((ROOT / spec_path).read_text())
assert old_spec.pop('approvals')['required_scopes'] == []
assert spec.pop('approvals')['required_scopes'] == ['scope_and_design_approval']
assert spec == old_spec

policy = vd.Dispositions(ROOT)
assert len(policy.entries) == 3
assert policy.config_sha256 == binding['policy_sha256']
assert git(ROOT, 'show', OLD_REVIEW + ':' + vd.CONFIG_PATH) == (ROOT / vd.CONFIG_PATH).read_bytes()
identities = []
for entry in policy.entries:
    raw = (ROOT / entry['path']).read_bytes()
    evidence = (ROOT / entry['evidence']['path']).read_bytes()
    assert sha(raw) == entry['sha256'] and sha(evidence) == entry['evidence']['sha256']
    assert raw == git(ROOT, 'show', OLD_REVIEW + ':' + entry['path'])
    record = {k:entry[k] for k in ('id','path','line','sha256')}
    record['evidence_sha256'] = sha(evidence)
    record['git_mode'] = git(ROOT, 'ls-files', '--stage', '--', entry['path']).decode().split()[0]
    if entry['check'] == 'secret-scan':
        matches = [m for m in vd.SECRET_PATTERNS['generic-secret'].finditer(raw.decode())
                   if vd.location(raw.decode(),m.start()) == (entry['line'],entry['column'])]
        assert len(matches) == 1 and sha(matches[0].group().encode()) == entry['match_sha256']
        assert vd.public_token(raw.decode(), matches[0])
        assert '0x118917a40FAF1CD7a13dB0Ef56C86De7973Ac503' in matches[0].group()
        record.update(column=entry['column'],match_sha256=entry['match_sha256'])
    else:
        assert vd.eof_blank_line(raw) == 51 and raw == git(ROOT, 'show', MAIN + ':' + entry['path'])
    identities.append(record)
protocol = (ROOT / 'packages/mezo-protocol/src/index.ts').read_bytes()
assert sha(protocol) == '28a5c0a9143a803bbd836ab59b3aad31cd225bb6459eb97778a256aada88489b'

secret = _secret_scan(ROOT, [e['path'] for e in policy.entries if e['check']=='secret-scan'])
selection = GitRangeSelection(bases=[GitRangeBase('route','independent-security',BASE,BASE),
                                     GitRangeBase('main','independent-security',MAIN,MAIN)])
diff = _git_diff_check(ROOT, 'pr', selection)
assert secret.status == diff.status == 'pass'
secrets = [x for x in secret.details if x.get('observation')]
spaces = [x for x in diff.details if x.get('observation')]
assert len(secrets)==2 and len(spaces)==1
assert all(x['severity']=='error' and x['effective_severity']=='info' for x in secrets+spaces)
assert [x['exit_code'] for x in diff.details if x.get('code')=='diff-check-command']==[0,0,2,0]
assert not git(ROOT, 'status', '--porcelain=v1').strip()
(SCRATCH/'native-secret-scan.json').write_text(json.dumps(secret.to_dict(),indent=2)+'\n')
(SCRATCH/'native-diff-check.json').write_text(json.dumps(diff.to_dict(),indent=2)+'\n')
result = {'product_delta_outside_changes':outside,'audit_delta':delta,'tool_report_only_delta':tool_delta,
          'unchanged_scanner_blobs':scanner_blobs,'tool_commit':binding['tool_commit'],'tool_tree':binding['tool_tree'],
          'tool_reports':reports,'overlay':overlay,'policy_sha256':policy.config_sha256,
          'identities':identities,'first_security_review_sha256':sha(first),'required_scope_only_change':True,
          'raw_secret_count':2,'raw_whitespace_count':1,'raw_git_exit_codes':[0,0,2,0],
          'negative_controls':'Not rerun: policy and scanner/integration bytes equal the previously independently probed versions.'}
(SCRATCH/'binding-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'product_unchanged':True,'overlay':len(overlay),'tool_reports':len(reports),
                  'exact_dispositions':len(identities),'raw_secret_count':2,'raw_whitespace_count':1,
                  'raw_git_exit_codes':[0,0,2,0],'all_assertions_passed':True}))
