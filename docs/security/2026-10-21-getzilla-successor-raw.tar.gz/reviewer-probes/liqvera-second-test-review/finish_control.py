#!/usr/bin/env python3
"""Finish the private metadata control using the validator's actual diagnostic."""
import json
import sys
import verify_followup as v

sys.path.insert(0, str(v.T / '.getzilla'))
from getzilla.spec import validate_spec
from getzilla.state import get_active_route

before = json.loads((v.E / 'before.json').read_text())
source_rows = json.loads((v.E / 'source-manifest.json').read_text())
tool_rows = json.loads((v.E / 'tool-manifest.json').read_text())
tracked, tool_tracked = v.entries(v.C), v.entries(v.T)
ignored = json.loads((v.E / 'ignored-input-bindings.json').read_text())
route = get_active_route(v.C)
assert route['route_id'] == 'ec1239ea42dd' and route['base_commit'] == v.BASE
assert v.manifest(v.C, tracked) == source_rows and v.manifest(v.T, tool_tracked) == tool_rows
assert v.manifest(v.S, tracked) == source_rows

path = v.S / v.PACKAGE / 'change-spec.yaml'
original = path.read_bytes()
baseline = validate_spec(v.S, path, gate=True, route=route)
assert baseline == []
mutant = json.loads(original)
assert mutant['risk']['tier'] == 'red'
assert mutant['approvals']['required_scopes'] == ['scope_and_design_approval']
mutant['approvals']['required_scopes'] = []
changed = (json.dumps(mutant, indent=2) + '\n').encode()
errors = None
try:
    path.write_bytes(changed)
    errors = validate_spec(v.S, path, gate=True, route=route)
    v.save('M1-native-diagnostic.json', {'errors': errors})
    assert len(errors) == 1 and 'red-risk requires approvals.required_scopes' in errors[0]
finally:
    path.write_bytes(original)
restored = validate_spec(v.S, path, gate=True, route=route)
assert path.read_bytes() == original and restored == []
v.save('M1-required-scope-control.json', {
    'kind': 'private metadata negative control; no application mutation',
    'path': f'{v.PACKAGE}/change-spec.yaml',
    'original_sha256': v.sha(original), 'mutant_sha256': v.sha(changed),
    'change': "approvals.required_scopes: ['scope_and_design_approval'] -> []; risk remains red",
    'baseline_errors': baseline, 'mutant_errors': errors, 'restored_errors': restored,
    'outcome': 'killed',
    'first_driver_limitation': 'Expected scope name in error; native validator names the required_scopes field. Original failed driver and outputs retained.'})
print('Native metadata control: GREEN -> RED (red-risk requires approvals.required_scopes) -> GREEN.', flush=True)
print(json.dumps(errors), flush=True)
assert v.manifest(v.S, tracked) == source_rows
assert v.manifest(v.C, tracked) == source_rows and v.manifest(v.T, tool_tracked) == tool_rows
for relative, digest in ignored.items():
    assert v.sha((v.C / relative).read_bytes()) == v.sha((v.S / relative).read_bytes()) == digest
expected = {row['path'] for row in source_rows} | set(ignored)
actual = {str(p.relative_to(v.S)) for p in v.S.rglob('*') if p.is_file() or p.is_symlink()}
assert actual == expected
after = {'candidate': v.identity(v.C, source_rows), 'tool': v.identity(v.T, tool_rows)}
assert before == after
v.save('after.json', after)
v.save('restoration.json', {'tracked_snapshot_exact': True, 'candidate_and_tool_unchanged': True,
                          'ignored_inputs_unchanged': True, 'snapshot_extra_files': [],
                          'reviewed-tree-modified': 'no', 'refs_mutated': False,
                          'snapshot_git_metadata': 'none; native Git controls read original candidate with GIT_OPTIONAL_LOCKS=0'})
print('Candidate/tool HEAD, tree, status and all tracked bytes/modes unchanged; metadata restored.', flush=True)
