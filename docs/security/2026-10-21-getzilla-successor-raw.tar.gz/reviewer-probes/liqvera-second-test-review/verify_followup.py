#!/usr/bin/env python3
"""Bounded read-only consumer checks; one private metadata negative control."""
from __future__ import annotations
import dataclasses
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys

os.environ['GIT_OPTIONAL_LOCKS'] = '0'
sys.dont_write_bytecode = True
os.sched_setaffinity(0, [18, 19])
E = Path(__file__).resolve().parent
C = Path('/home/pall/projects/liqvera/.getzilla/runtime/liqvera-final-audit')
T = Path('/home/pall/projects/liqvera/.getzilla/runtime/getzilla-audit-final')
S = E / 'snapshot'
PACKAGE = 'engineering/changes/20261021-task-ec1239'
HEAD = '1b90f54c7ab26a7689cb892687175ac12cb7e3a4'
TREE = '23d2befc1bcf354fe5ca9c920ed6d54b62fe37dd'
TOOL = '45be42f74b5a8ee6f079f8ac55206e475936fdc6'
TOOL_TREE = 'bcdd090531e657ee1d3cd20c340205df86fc8900'
FIRST = 'ca65575dd2283a47b7671b356847ed8fb9f5a125'
PRODUCT = '17a70595e98aa183afac115e5b99488830fba712'
BASE = 'f1d3bffc46fa1459908fdff865fcfbfc831b7f7f'
MAIN = '3cfc69b42a0996ccbe6dbdc9bea6e63001e721bd'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, data):
    (E / name).write_text(json.dumps(data, indent=2) + '\n')

def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args],
                                   env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})

def entries(root):
    rows = []
    for raw in git(root, 'ls-files', '--stage', '-z').split(b'\0'):
        if not raw:
            continue
        fields, name = raw.split(b'\t', 1)
        mode, blob, stage = fields.decode().split()
        rel = Path(os.fsdecode(name))
        assert stage == '0' and not rel.is_absolute() and '..' not in rel.parts
        rows.append({'path': str(rel), 'git_mode': mode, 'blob': blob})
    return sorted(rows, key=lambda r: r['path'])

def manifest(root, tracked):
    result = []
    for entry in tracked:
        path = root / entry['path']
        info = path.lstat()
        if entry['git_mode'] == '120000':
            assert stat.S_ISLNK(info.st_mode)
            data = os.fsencode(os.readlink(path))
        else:
            assert entry['git_mode'] in ('100644', '100755') and stat.S_ISREG(info.st_mode)
            data = path.read_bytes()
        result.append({**entry, 'mode': oct(stat.S_IMODE(info.st_mode)),
                       'bytes': len(data), 'sha256': sha(data)})
    return result

def identity(root, rows):
    return {'head': git(root, 'rev-parse', 'HEAD').decode().strip(),
            'tree': git(root, 'rev-parse', 'HEAD^{tree}').decode().strip(),
            'status': git(root, 'status', '--porcelain=v1', '--untracked-files=all').decode(),
            'tracked_entries': len(rows), 'checkout_bytes': sum(x['bytes'] for x in rows),
            'manifest_sha256': sha(json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())}

def safety(path):
    result = []
    for part in reversed((path, *path.parents)):
        st = part.lstat()
        assert stat.S_ISDIR(st.st_mode) and not part.is_symlink()
        assert st.st_uid in (0, os.getuid()) and not stat.S_IMODE(st.st_mode) & 0o1022
        result.append({'path': str(part), 'uid': st.st_uid, 'mode': oct(stat.S_IMODE(st.st_mode))})
    return result

def copy(relative):
    source, target = C / relative, S / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if source.is_symlink():
        target.symlink_to(os.readlink(source))
    else:
        shutil.copy2(source, target)

def main():
    assert not S.exists()
    S.mkdir(mode=0o700)
    (E / 'tmp').mkdir(mode=0o700)
    os.environ['TMPDIR'] = str(E / 'tmp')
    assert stat.S_IMODE(E.stat().st_mode) == 0o700
    save('scratch-safety.json', safety(E))
    tracked, tool_tracked = entries(C), entries(T)
    source_rows, tool_rows = manifest(C, tracked), manifest(T, tool_tracked)
    before = {'candidate': identity(C, source_rows), 'tool': identity(T, tool_rows)}
    assert (before['candidate']['head'], before['candidate']['tree']) == (HEAD, TREE)
    assert (before['tool']['head'], before['tool']['tree']) == (TOOL, TOOL_TREE)
    assert before['candidate']['status'] == before['tool']['status'] == ''
    save('before.json', before)
    save('source-manifest.json', source_rows)
    save('tool-manifest.json', tool_rows)
    for row in tracked:
        copy(row['path'])
    assert manifest(S, tracked) == source_rows
    binding = json.loads((C / PACKAGE / 'evidence/tool-binding.json').read_text())
    assert (binding['tool_commit'], binding['tool_tree']) == (TOOL, TOOL_TREE)
    overlay = binding['overlay']
    assert len(overlay) == 48
    ignored = dict(overlay)
    for relative in ('.getzilla/runtime/active-route.json', '.getzilla/runtime/active-change.json'):
        ignored[relative] = sha((C / relative).read_bytes())
    for relative, digest in ignored.items():
        assert not (C / relative).is_symlink() and sha((C / relative).read_bytes()) == digest
        copy(relative)
    for relative, digest in overlay.items():
        assert sha((T / relative).read_bytes()) == digest
    save('ignored-input-bindings.json', ignored)
    old_binding = json.loads((C / PACKAGE / 'evidence/first-tool-binding.json').read_text())
    changed_overlay = [rel for rel in overlay if old_binding['overlay'][rel] != overlay[rel]]
    assert sorted(changed_overlay) == ['.getzilla/config/managed.json', '.getzilla/config/routing.json']
    outside = {}
    for commit in (FIRST, PRODUCT):
        delta = git(C, 'diff', '--name-status', commit, HEAD, '--', '.', ':!engineering/changes')
        assert delta == b''
        outside[commit] = delta.decode()
    ancestors = {}
    for commit in (BASE, MAIN, FIRST, PRODUCT, 'v0.0.1', 'v0.0.2', 'v0.0.3', 'v0.0.4', 'v0.0.5'):
        p = subprocess.run(['git', '-C', str(C), 'merge-base', '--is-ancestor', commit, HEAD])
        ancestors[commit] = p.returncode
        assert p.returncode == 0
    (E / 'worktrees.txt').write_bytes(git(C, 'worktree', 'list', '--porcelain'))
    (E / 'followup.diff').write_bytes(git(C, 'diff', FIRST, HEAD))
    (E / 'followup-inventory.txt').write_bytes(git(C, 'diff', '--name-status', FIRST, HEAD))
    (E / 'overlay-delta.diff').write_bytes(git(T, 'diff', old_binding['tool_commit'], TOOL, '--', *changed_overlay))
    review_delta = git(T, 'diff', '--name-only', '3968ae4445836eda9cf377035b1d1f64fe9659b0', TOOL).decode().splitlines()
    expected = [f'engineering/changes/20261021-task-d83415/evidence/{role}-review.md'
                for role in ('code', 'release', 'security', 'test')]
    assert sorted(review_delta) == expected
    historical = {}
    for role in ('code', 'test', 'security', 'data', 'release'):
        external = E.parent / f'liqvera-final-{role}-review.md'
        retained = C / PACKAGE / f'evidence/first-{role}-review.md'
        assert retained.read_bytes() == external.read_bytes()
        historical[role] = {'report': str(external), 'sha256': sha(external.read_bytes()),
                            'bytes': external.stat().st_size, 'retained_byte_identical': True}
    tool_reports = {}
    for role, digest in binding['tool_review_reports'].items():
        report = T / f'engineering/changes/20261021-task-d83415/evidence/{role}-review.md'
        assert sha(report.read_bytes()) == digest
        tool_reports[role] = {'sha256': digest, 'bytes': report.stat().st_size}
    for current, prior in [('first-tool-binding.json', 'tool-binding.json'),
                           ('first-committed-tool-controls.json', 'committed-tool-controls.json')]:
        assert (C / PACKAGE / 'evidence' / current).read_bytes() == git(C, 'show', f'{FIRST}:{PACKAGE}/evidence/{prior}')
    preservation = json.loads((C / PACKAGE / 'evidence/product-preservation.json').read_text())
    assert git(C, 'diff', '--name-status', preservation['production_evidence_source'], HEAD,
               '--', *preservation['unchanged_runtime_input_roots']) == b''
    for relative, digest in preservation['historical_evidence_sha256'].items():
        assert sha((C / relative).read_bytes()) == digest
    red = json.loads((C / PACKAGE / 'evidence/red-log-binding.json').read_text())
    compressed = (C / PACKAGE / 'evidence' / red['stored_file']).read_bytes()
    assert sha(compressed) == red['stored_sha256'] and sha(gzip.decompress(compressed)) == red['raw_sha256']
    first_gate = json.loads((C / PACKAGE / 'evidence/first-gate-getzilla-pr.json').read_text())
    invocation = json.loads((C / PACKAGE / 'evidence/first-gate-invocation.json').read_text())
    assert invocation['returncode'] == 1
    failed = [c['name'] for c in first_gate['checks'] if c['status'] == 'fail']
    assert failed == ['change-spec'] and first_gate['status'] == 'fail'
    pytest = next(c for c in first_gate['checks'] if c['name'] == 'pytest')
    assert pytest['status'] == 'pass' and '956 passed, 85 subtests passed' in pytest['stdout']
    save('bindings.json', {'outside_change_package_delta': outside, 'ancestry': ancestors,
                          'first_reviews': historical, 'tool_review_reports': tool_reports,
                          'tool_report_only_delta': review_delta, 'changed_overlay_paths': changed_overlay,
                          'overlay_matches_tool': 48, 'historical_file_hashes_match': 9,
                          'pip_red_raw_and_compressed_hashes_match': True,
                          'first_gate': {'head': invocation['head'], 'returncode': 1, 'failed_checks': failed,
                                         'retained_json_sha256': sha((C / PACKAGE / 'evidence/first-gate-getzilla-pr.json').read_bytes()),
                                         'pytest_observation': '956 passed, 85 subtests passed; historical failed gate'}})
    print('Bindings PASS: unchanged product/test source; 5 first reports; 4 tool reports; 48 overlay files; 9 historical files; pip RED hashes.', flush=True)
    sys.path.insert(0, str(T / '.getzilla'))
    from getzilla.verification import _secret_scan, _git_diff_check, _git_range_selection, _change_specs
    from getzilla.spec import validate_spec
    from getzilla.state import get_active_route
    route = get_active_route(C)
    assert route['route_id'] == 'ec1239ea42dd' and route['base_commit'] == BASE
    selection = _git_range_selection(C, route, 'pr')
    assert not selection.findings
    assert [(x.kind, x.comparison_base_sha) for x in selection.bases] == [('route', BASE), ('pr-target', MAIN)]
    files = [x['path'] for x in tracked]
    secret = _secret_scan(C, files)
    whitespace = _git_diff_check(C, 'pr', selection)
    spec, spec_payload = _change_specs(C, files, route, 'pr')
    checks = [secret, whitespace, spec]
    save('native-controls.json', {'candidate': HEAD, 'tool': TOOL, 'all_tracked_scope': len(files),
                                  'checks': [dataclasses.asdict(x) for x in checks], 'spec': spec_payload})
    assert all(x.status == 'pass' for x in checks)
    for check, expected_count in ((secret, 2), (whitespace, 1)):
        summary = next(x for x in check.details if x.get('code') == 'disposition-summary')
        assert summary['observed'] == summary['disposed'] == expected_count and summary['unresolved'] == 0
        assert all(x['severity'] == 'error' for x in check.details if x.get('observation'))
    assert [x['exit_code'] for x in whitespace.details if x.get('code') == 'diff-check-command'] == [0, 0, 2, 0]
    for check in checks:
        print(check.name, check.status, check.summary, flush=True)
    path = S / PACKAGE / 'change-spec.yaml'
    original = path.read_bytes()
    assert validate_spec(S, path, gate=True, route=route) == []
    mutant = json.loads(original)
    assert mutant['risk']['tier'] == 'red' and mutant['approvals']['required_scopes'] == ['scope_and_design_approval']
    mutant['approvals']['required_scopes'] = []
    changed = (json.dumps(mutant, indent=2) + '\n').encode()
    errors = None
    try:
        path.write_bytes(changed)
        errors = validate_spec(S, path, gate=True, route=route)
        assert errors and any('scope_and_design_approval' in x for x in errors)
    finally:
        path.write_bytes(original)
    assert path.read_bytes() == original and validate_spec(S, path, gate=True, route=route) == []
    save('M1-required-scope-control.json', {'kind': 'private metadata negative control; no application mutation',
          'path': f'{PACKAGE}/change-spec.yaml', 'original_sha256': sha(original), 'mutant_sha256': sha(changed),
          'change': "approvals.required_scopes: ['scope_and_design_approval'] -> []; risk remains red",
          'baseline_errors': [], 'mutant_errors': errors, 'restored_errors': [], 'outcome': 'killed'})
    print('M1 removed required scope: KILLED by native validation; restored metadata PASS.', flush=True)
    assert manifest(S, tracked) == source_rows
    assert manifest(C, tracked) == source_rows and manifest(T, tool_tracked) == tool_rows
    for relative, digest in ignored.items():
        assert sha((C / relative).read_bytes()) == sha((S / relative).read_bytes()) == digest
    after = {'candidate': identity(C, source_rows), 'tool': identity(T, tool_rows)}
    assert after == before
    save('after.json', after)
    save('restoration.json', {'tracked_snapshot_exact': True, 'candidate_and_tool_unchanged': True,
                             'ignored_inputs_unchanged': True, 'reviewed-tree-modified': 'no',
                             'refs_mutated': False, 'snapshot_git_metadata': 'none; native Git controls read original candidate with GIT_OPTIONAL_LOCKS=0'})
    print('Candidate/tool HEAD, tree, status and actual tracked bytes/modes unchanged; private metadata restored.', flush=True)

if __name__ == '__main__':
    main()
