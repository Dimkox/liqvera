# Liqvera completion scope assessment

Conclusion: the proposed scoped Liqvera completion record is justified. No inspected consumer rule requires the optional external tool's own self-gate to pass before the independently reviewed Liqvera candidate can report its actual passing verification. Finalize the Liqvera audit record and reproducibility artifact; do not undertake another Getzilla repair or claim Getzilla qualification, merge or release. Artifact validation and the normal Liqvera PR delivery requirements remain separate completion steps.

This is a read-only scope assessment, not a new source review or test run. Inputs before and after are unchanged and clean:

- Liqvera HEAD `328dfa8f0523310e80693db606a0e737c24b2ee5`, tree `1270bc6ef9d1a3b1a157481c2d78a4c51758c8c7`; reviewed HEAD `1b90f54c7ab26a7689cb892687175ac12cb7e3a4`. The intervening diff consists only of the five selected review reports.
- Getzilla HEAD `45be42f74b5a8ee6f079f8ac55206e475936fdc6`, tree `bcdd090531e657ee1d3cd20c340205df86fc8900`; independently reviewed source `3968ae4445836eda9cf377035b1d1f64fe9659b0`.

reviewed-tree-modified: no

## Consumer requirements

Liqvera `AGENTS.md` rule 7 states: “No external delivery framework is required to build or verify the product. Optional external tools do not own repository policy or runtime behavior.” Rules 8–10 require actual relevant results, independent review and preservation; they do not establish recursive tool-self-certification.

Read the active `20261021-task-ec1239` brief, requirements, release plan, test plan and complete change specification. They require the exact reviewed successor tool, full original comparison, full-scope PR verification of the entire Python test target, preserved raw findings, five independent review receipts and zero status gaps. AC-003 and OBJ-001 bind those conditions to the Liqvera candidate. They do not require a green Getzilla repository gate or a Getzilla release. FORBID-001 still prohibits concealing failures or presenting historical acceptance as fresh.

The Getzilla delivery controller continues to govern claims about Getzilla's own task: its failed native gate prevents a qualified tool completion or passing receipt. That is a separate outcome. Earlier coordinator scripts expecting both gates to pass express the broader packaging plan; they are not an additional consumer rule. A revised artifact must represent both actual outcomes explicitly, without changing either native result or issuing a false tool receipt.

## Observed evidence

Liqvera `.getzilla/runtime/final-2/invocation.json` records `--mode pr --full-scope --keep-going --json`, original base `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`, exact tool pin, exit 0, 411.757 seconds and unchanged clean source. Native result is PASS; pytest output states 956 tests and 85 subtests passed in 389.66 seconds. Six receipts are PASS on the exact final head: verification plus code, test, security, data and release. All five review-source bindings and report hashes match. Status has empty `evidence_gaps` and `package_incomplete` arrays. Native optional/unconfigured skips remain skips, including coverage; the whole-product supporting evidence retains its earlier explicit fresh/historical boundaries.

Getzilla's matching final-2 invocation records exit 1 after 1225.840 seconds. Native `python-unittest` fails; its retained output records one failed, 2277 passed, 17 skipped and 3961 passing subtests. The unique named failure is `Review2PosixTests.test_secret_scan_is_bounded_and_fails_closed_on_a_huge_argv`; that test file is unchanged from original base `e158ddc7263a55f5308944c5a426eb1e9f1a4327`. Its source asserts denial and an elapsed limit below eight seconds. The coordinator reports successful denial and 8.32/8.49-second timing observations; this assessment did not rerun or independently recover those precise durations from the bounded native excerpt. Do not relabel the failed timing requirement as passed or proven harmless. Coverage also reports FAIL because the underlying run was unsuccessful. Factory checks report 63 tests PASS and 1040 tests PASS with six skips.

Accuracy correction: a Getzilla verification receipt exists at `.getzilla/runtime/receipts/d834158878e0/verification.json`, and its status is FAIL on the exact tool head. Say **no passing verification receipt**, not “no receipt.” Four passing independent source reviews do not supersede that failed gate.

Input SHA-256 bindings:

- Liqvera native result: `2d16d4bcc91dbe9ebff2afa74062c5bf7b3ff0122ef8ea5bb5f2856282ebef08`.
- Liqvera invocation: `5128a837890ce2d32b6ba1acd8919ae337dd393c26d97c4168b387461c428884`.
- Liqvera status: `7ea400d768286fb04a885a9dce0eea67669d07f43d1e570eb3ddafbc65d23c72`.
- Getzilla native result: `946a492e64f5382c41523bb04c76a559364582eef5e2a34cf11684c1d8a8da7b`.
- Getzilla invocation: `cfba9278aa5479ae713397b4b958582b0225a3e0e2b61502e9f2588a933ec156`.
- Getzilla failed verification receipt: `ced123797ea1a1b5765e13712b30cdb042f420aad394e2f1c6300bf913fef7fb`.

## Required wording and artifact boundary

Use separate machine-readable statuses: `liqvera_verification: pass`, `getzilla_self_verification: fail`, and `tool_qualification: unqualified`. Suitable report text:

> Liqvera passed its complete selected native verification on the recorded source, with five independent review receipts and zero recorded evidence gaps. The audit used an exact locally frozen Getzilla source whose independent reviews passed but whose own full self-verification failed one timing test. That tool remains unqualified and is not being merged or released as part of this work. Its exact source and complete retained failure evidence are included for reproduction.

Keep the tool's raw FAIL result, failed receipt, prior failures, current reviews and original limits in the artifact. Include the exact frozen source bundle and document any bundle prerequisites; source inclusion supplies reproducibility, not a qualified Getzilla release. Label the three dispositions as raw observations with reviewed effective outcomes. Preserve all native skips and distinguish historical image/PostgreSQL/deployment evidence from current product verification. Avoid a single unqualified “everything passed,” “Getzilla passed,” or global “zero gaps” claim.

No production deployment or new live acceptance is needed for the audit metadata. This conclusion authorizes no source mutation, native-gate bypass, payment, external write or publication. The coordinator will construct the truthful successor artifact and obtain its separate review before final Liqvera delivery.

Commands were limited to read-only Git identity/status/diff checks, existing JSON/report reads, SHA-256 comparisons and inspection of the named test assertions. No tests, candidate edits, private-state reads, grants, receipts, refs or live operations were performed. Git checks used `GIT_OPTIONAL_LOCKS=0`; bounded inspection used CPUs 24–25.
