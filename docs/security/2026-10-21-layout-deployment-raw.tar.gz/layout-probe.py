import asyncio,json,pathlib,subprocess,urllib.request,base64,sys,mimetypes
from websockets.asyncio.client import connect
out=pathlib.Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True);candidate=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else None;opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
chrome=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--no-sandbox','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-address=127.0.0.1','--remote-debugging-port=19349','--user-data-dir='+str(out/'profile'),'about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
async def main():
 for _ in range(40):
  try:tabs=json.load(opener.open('http://127.0.0.1:19349/json'));break
  except OSError:await asyncio.sleep(.25)
 tab=next(x for x in tabs if x['type']=='page');errors=[];seq=0;fetch_seq=0;relay_statuses=[];relay_errors=[];public_fetches=[]
 async with connect(tab['webSocketDebuggerUrl'],proxy=None) as ws:
  async def cmd(method,params={}):
   nonlocal seq,fetch_seq
   seq+=1;ident=seq;await ws.send(json.dumps({'id':ident,'method':method,'params':params}))
   while True:
    item=json.loads(await ws.recv())
    if item.get('method')=='Fetch.requestPaused':
     event=item['params'];req=event['request']
     def fetch_public():
      assert req['method']=='GET', 'Public verification must remain read-only'
      path=urllib.parse.urlsplit(req['url']).path
      local=(candidate / ('index.html' if path=='/' else path.lstrip('/'))) if candidate else None
      if local and local.is_file() and local.resolve().is_relative_to(candidate.resolve()):
       return 200,[{'name':'Content-Type','value':mimetypes.guess_type(str(local))[0] or 'application/octet-stream'}],local.read_bytes()
      headers={k:v for k,v in req['headers'].items() if k.lower() not in ['host','connection','accept-encoding','content-length']}
      request=urllib.request.Request(req['url'],data=req.get('postData','').encode() if req['method']=='POST' else None,headers=headers,method=req['method'])
      try:response=urllib.request.urlopen(request,timeout=25)
      except urllib.error.HTTPError as e:response=e
      with response:
       return response.status,[{'name':k,'value':v} for k,v in response.headers.items() if k.lower() not in ['connection','transfer-encoding','content-length']],response.read()
     status,headers,body=await asyncio.to_thread(fetch_public)
     public_fetches.append({'path':urllib.parse.urlsplit(req['url']).path,'status':status})
     fetch_seq+=1
     await ws.send(json.dumps({'id':100000+fetch_seq,'method':'Fetch.fulfillRequest','params':{'requestId':event['requestId'],'responseCode':status,'responseHeaders':headers,'body':base64.b64encode(body).decode()}}))
    if item.get('method')=='Network.webSocketHandshakeResponseReceived':relay_statuses.append(item['params']['response']['status'])
    if item.get('method')=='Network.webSocketFrameReceived':
     try:
      frame=json.loads(item['params']['response']['payloadData'])
      if isinstance(frame,dict) and 'error' in frame:relay_errors.append(frame['error'].get('code'))
     except (ValueError,TypeError):pass
    if item.get('method')=='Runtime.exceptionThrown':errors.append(item['params']['exceptionDetails'].get('text'))
    if item.get('id')==ident:
     if 'error' in item:raise RuntimeError(item['error'])
     return item.get('result',{})
  async def evaluate(expr):
   r=await cmd('Runtime.evaluate',{'expression':expr,'returnByValue':True,'awaitPromise':True})
   if 'exceptionDetails' in r:raise RuntimeError(r['exceptionDetails'])
   return r['result'].get('value')
  await cmd('Runtime.enable');await cmd('Page.enable');await cmd('Network.enable')
  await cmd('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
  await cmd('Page.addScriptToEvaluateOnNewDocument',{'source':"window.csp=[];document.addEventListener('securitypolicyviolation',e=>window.csp.push({directive:e.effectiveDirective,blocked:e.blockedURI.split('?')[0]}));window.deep=(selector,root=document)=>[...root.querySelectorAll(selector),...[...root.querySelectorAll('*')].filter(e=>e.shadowRoot).flatMap(e=>window.deep(selector,e.shadowRoot))];"})
  await cmd('Fetch.enable',{'patterns':[{'urlPattern':'https://liqvera.site/*','requestStage':'Request'}]})
  await cmd('Page.navigate',{'url':'https://liqvera.site/'})
  for _ in range(40):
   if await evaluate("!!document.querySelector('#connect-button')"):break
   await asyncio.sleep(.25)
  funding=await evaluate("({present:!!document.querySelector('#mezo-balance-check'),disabled:document.querySelector('#mezo-balance-check')?.disabled,borrowDisabled:!document.querySelector('#mezo-borrow-link')?.hasAttribute('href'),status:document.querySelector('#mezo-balance-status')?.textContent})")
  assert funding['present'] and funding['disabled'] and funding['borrowDisabled']
  await evaluate("document.querySelector('details.status-card').open=true;document.querySelector('#historical-button').click()")
  for _ in range(80):
   if await evaluate("document.querySelector('#result-content').textContent.includes('Sealed historical capture')"):break
   await asyncio.sleep(.2)
  assert await evaluate("document.querySelector('#result-content').textContent.includes('Sealed historical capture')")
  results=[]
  for width in [1440,1280,1024,768,390,320]:
   await cmd('Emulation.setDeviceMetricsOverride',{'width':width,'height':1100,'deviceScaleFactor':1,'mobile':width<600})
   await evaluate("document.fonts.ready")
   await evaluate("document.querySelector('#mezo-borrow-ack').scrollIntoView({block:'center'})")
   await asyncio.sleep(.1)
   result=await evaluate("""(()=>{const ack=document.querySelector('#mezo-borrow-ack'),label=ack.closest('label'),borrow=document.querySelector('#mezo-borrow-link'),terms=[...borrow.parentElement.querySelectorAll('a')].find(e=>e.textContent.startsWith('Read Mezo')),panel=ack.closest('details');const box=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,top:r.top,bottom:r.bottom,left:r.left,right:r.right,width:r.width,height:r.height,display:getComputedStyle(e).display}};const l=box(label),b=box(borrow),t=box(terms);return {width:innerWidth,label:l,borrow:b,terms:t,labelBorrowGap:b.top-l.bottom,borrowTermsGap:t.top-b.bottom,overflow:document.documentElement.scrollWidth>innerWidth,ackDisabled:ack.disabled,status:document.querySelector('#mezo-balance-status').textContent,footerGetzilla:[...document.querySelectorAll('footer a')].some(a=>a.href==='https://github.com/Dimkox/Getzilla'),clip:{x:panel.getBoundingClientRect().x,y:panel.getBoundingClientRect().y+scrollY,width:panel.getBoundingClientRect().width,height:panel.getBoundingClientRect().height,scale:1}}})()""")
   shot=await cmd('Page.captureScreenshot',{'format':'png','captureBeyondViewport':True,'clip':result.pop('clip')});(out/f'panel-{width}.png').write_bytes(base64.b64decode(shot['data']))
   result['pass']=result['labelBorrowGap']>=8 and result['borrowTermsGap']>=8 and not result['overflow'];results.append(result)
  report={'results':results,'all_pass':all(r['pass'] for r in results),'exceptions':errors,'public_fetches':public_fetches,'live_posts':0,'source':'local candidate assets with read-only public API' if candidate else 'published assets'}
  (out/'layout.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
  assert report['all_pass'], 'funding controls overlap or overflow'
try:asyncio.run(asyncio.wait_for(main(),timeout=150))
finally:chrome.terminate();chrome.wait(timeout=10)
