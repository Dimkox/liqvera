import asyncio,json,pathlib,subprocess,urllib.request,base64
from websockets.asyncio.client import connect
out=pathlib.Path('/home/pall/projects/liqvera/.getzilla/runtime/layout');opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
chrome=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--no-sandbox','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-address=127.0.0.1','--remote-debugging-port=19359','--user-data-dir='+str(out/'layout-wallet-browser-profile'),'about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
async def main():
 for _ in range(40):
  try:tabs=json.load(opener.open('http://127.0.0.1:19359/json'));break
  except OSError:await asyncio.sleep(.25)
 tab=next(x for x in tabs if x['type']=='page');errors=[];seq=0;fetch_seq=0;relay_statuses=[];relay_errors=[];public_fetches=[]
 async with connect(tab['webSocketDebuggerUrl'],proxy=None) as ws:
  async def cmd(method,params={}):
   nonlocal seq,fetch_seq
   seq+=1;ident=seq;await ws.send(json.dumps({'id':ident,'method':method,'params':params}))
   while True:
    item=json.loads(await ws.recv())
    if item.get('method')=='Fetch.requestPaused':
     event=item['params'];req=event['request']
     def fetch_public():
      assert req['method']=='GET', 'Public verification must remain read-only'
      headers={k:v for k,v in req['headers'].items() if k.lower() not in ['host','connection','accept-encoding','content-length']}
      request=urllib.request.Request(req['url'],data=req.get('postData','').encode() if req['method']=='POST' else None,headers=headers,method=req['method'])
      try:response=urllib.request.urlopen(request,timeout=25)
      except urllib.error.HTTPError as e:response=e
      with response:
       return response.status,[{'name':k,'value':v} for k,v in response.headers.items() if k.lower() not in ['connection','transfer-encoding','content-length']],response.read()
     status,headers,body=await asyncio.to_thread(fetch_public)
     public_fetches.append({'path':urllib.parse.urlsplit(req['url']).path,'status':status})
     fetch_seq+=1
     await ws.send(json.dumps({'id':100000+fetch_seq,'method':'Fetch.fulfillRequest','params':{'requestId':event['requestId'],'responseCode':status,'responseHeaders':headers,'body':base64.b64encode(body).decode()}}))
    if item.get('method')=='Network.webSocketHandshakeResponseReceived':relay_statuses.append(item['params']['response']['status'])
    if item.get('method')=='Network.webSocketFrameReceived':
     try:
      frame=json.loads(item['params']['response']['payloadData'])
      if isinstance(frame,dict) and 'error' in frame:relay_errors.append(frame['error'].get('code'))
     except (ValueError,TypeError):pass
    if item.get('method')=='Runtime.exceptionThrown':errors.append(item['params']['exceptionDetails'].get('text'))
    if item.get('id')==ident:
     if 'error' in item:raise RuntimeError(item['error'])
     return item.get('result',{})
  async def evaluate(expr):
   r=await cmd('Runtime.evaluate',{'expression':expr,'returnByValue':True,'awaitPromise':True})
   if 'exceptionDetails' in r:raise RuntimeError(r['exceptionDetails'])
   return r['result'].get('value')
  await cmd('Runtime.enable');await cmd('Page.enable');await cmd('Network.enable')
  await cmd('Emulation.setDeviceMetricsOverride',{'width':390,'height':844,'deviceScaleFactor':1,'mobile':True})
  await cmd('Page.addScriptToEvaluateOnNewDocument',{'source':"window.csp=[];document.addEventListener('securitypolicyviolation',e=>window.csp.push({directive:e.effectiveDirective,blocked:e.blockedURI.split('?')[0]}));window.deep=(selector,root=document)=>[...root.querySelectorAll(selector),...[...root.querySelectorAll('*')].filter(e=>e.shadowRoot).flatMap(e=>window.deep(selector,e.shadowRoot))];"})
  await cmd('Fetch.enable',{'patterns':[{'urlPattern':'https://liqvera.site/*','requestStage':'Request'}]})
  await cmd('Page.navigate',{'url':'https://liqvera.site/'})
  for _ in range(40):
   if await evaluate("!!document.querySelector('#connect-button')"):break
   await asyncio.sleep(.25)
  funding=await evaluate("({present:!!document.querySelector('#mezo-balance-check'),disabled:document.querySelector('#mezo-balance-check')?.disabled,borrowDisabled:!document.querySelector('#mezo-borrow-link')?.hasAttribute('href'),status:document.querySelector('#mezo-balance-status')?.textContent})")
  assert funding['present'] and funding['disabled'] and funding['borrowDisabled']
  await evaluate("document.querySelector('details.status-card').open=true;document.querySelector('#historical-button').click()")
  for _ in range(80):
   if await evaluate("document.querySelector('#result-content').textContent.includes('Sealed historical capture')"):break
   await asyncio.sleep(.2)
  assert await evaluate("document.querySelector('#result-content').textContent.includes('Sealed historical capture')")
  await evaluate("document.querySelector('details.status-card').scrollIntoView({block:'center'})")
  shot=await cmd('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False});(out/'published-funding-panel.png').write_bytes(base64.b64decode(shot['data']))
  await evaluate("document.querySelector('#connect-button').click()")
  for _ in range(100):
   if await evaluate("deep('button').some(e=>e.innerText.includes('WalletConnect'))"):break
   await asyncio.sleep(.15)
  result=await evaluate("({notice:document.querySelector('#announcement').innerText,csp:window.csp,modal:!!document.querySelector('w3m-modal'),asset:[...document.scripts].map(e=>e.src),texts:deep('button').map(e=>e.innerText),walletButtons:deep('w3m-wallet-button').map(e=>({name:e.name,tag:e.tagName})),body:deep('w3m-connect-view').map(e=>e.shadowRoot?.textContent.slice(-2000))})")
  result['funding_panel']=funding;result['historical_preview']='PASS'
  assert result['modal'] and 'WalletConnect\nQR CODE' in result['texts']
  await evaluate("deep('button').find(e=>e.innerText.includes('WalletConnect')).click()")
  for _ in range(100):
   if await evaluate("deep('wui-qr-code').some(e=>typeof e.uri==='string'&&e.uri.startsWith('wc:'))"):break
   await asyncio.sleep(.15)
  result['qr']=await evaluate("({qr:deep('wui-qr-code').map(e=>({hasUri:typeof e.uri==='string'&&e.uri.startsWith('wc:'),hasSvg:!!e.shadowRoot?.querySelector('svg')})),csp:window.csp,buttons:deep('button').map(e=>e.innerText)})")
  result['transport']='Published HTTPS responses fetched through environment proxy; third-party SDK connections direct';result['public_fetches']=public_fetches
  result['exceptions']=errors;result['relay_handshake_statuses']=relay_statuses;result['relay_error_codes']=relay_errors
  result['asset']=await evaluate("[...document.scripts].map(e=>e.src)")
  assert any(q['hasUri'] and q['hasSvg'] for q in result['qr']['qr']);assert not errors and not result['qr']['csp'];assert 101 in relay_statuses and not relay_errors;assert any('index-Cnfn94HM.js' in s for s in result['asset']);result['new_quote_requests']=0;result['payment_requests']=0;print(json.dumps(result,indent=2));(out/'public-browser.json').write_text(json.dumps(result,indent=2)+'\n')
  # Pairing URI and QR screenshots are deliberately not recorded.
try:asyncio.run(asyncio.wait_for(main(),timeout=100))
finally:chrome.terminate();chrome.wait(timeout=10)
