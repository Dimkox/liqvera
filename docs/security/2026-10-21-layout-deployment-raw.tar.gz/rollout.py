"""One-host static-web rollout. Never restores or migrates a live database."""
import copy
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time

SOURCE = '57660040b36300de62cd45cb663bd2124167fe45'
ROOT = Path('/home/pall/projects/liqvera/.worktrees/wave1-deploy')
OUT = Path('/home/pall/projects/liqvera/.getzilla/runtime/layout')
RECOVERY = Path('/home/pall/.local/state/liqvera/recovery/2026-10-21-layout-5766004')
MANIFEST = Path('/home/pall/.local/share/liqvera/deploy/compose.json')
WC = MANIFEST.parent / 'walletconnect.env'
NAME = 'liqvera-live-web-live-1'
PREVIOUS = NAME + '-before-layout-5766004'
TAG = 'liqvera-mezo-web:layout-5766004'
OLD_IMAGE = 'sha256:de0e5216443ac6a51c5e0c63e5ee45b416f57ced9590943161f8addcbc7ecbcd'
SERVICES = ['web', 'edge', 'gateway', 'gateway-net', 'postgres', 'report', 'evidence-capture']

class Docker(http.client.HTTPConnection):
    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(50)
        self.sock.connect('/var/run/docker.sock')

def api(method, path, body=None):
    connection = Docker('localhost')
    connection.request(method, path, json.dumps(body) if body is not None else None,
                       {'Content-Type': 'application/json'})
    response = connection.getresponse()
    data = response.read()
    connection.close()
    if response.status >= 300:
        raise RuntimeError(f'Docker {method} {path}: HTTP {response.status}')
    return json.loads(data) if data else None

def inspect(name):
    return api('GET', '/containers/' + name + '/json')

def run(args, **kwargs):
    return subprocess.run(args, check=True, timeout=kwargs.pop('timeout', 60), **kwargs)

def private_write(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()

def write_json(path, value):
    private_write(path, (json.dumps(value, indent=2) + '\n').encode())

def inventory():
    result = {}
    for service in SERVICES:
        value = inspect('liqvera-live-' + service + '-live-1')
        result[service] = {'id': value['Id'], 'image': value['Image'],
                           'health': value['State'].get('Health', {}).get('Status'),
                           'restart_count': value['RestartCount'],
                           'volumes': sorted(m['Name'] for m in value['Mounts'] if m['Type'] == 'volume')}
    return result

def ledger():
    # Only aggregate states and immutable migration digests leave PostgreSQL.
    sql = """BEGIN READ ONLY;
SELECT 'payment_attempts|' || state || '|' || count(*) FROM payment_attempts GROUP BY state ORDER BY state;
SELECT 'receipts|' || count(*) FROM receipts;
SELECT 'entitlements|' || count(*) FROM entitlements;
SELECT name || '|' || sha256 FROM gateway_migrations ORDER BY name;
COMMIT;"""
    return subprocess.check_output(['docker', 'exec', 'liqvera-live-postgres-live-1',
        'psql', '-X', '-q', '-U', 'liqvera', '-d', 'liqvera', '-At', '-v', 'ON_ERROR_STOP=1', '-c', sql],
        text=True, timeout=45).splitlines()

def healthy(name):
    deadline = time.monotonic() + 55
    while time.monotonic() < deadline:
        state = inspect(name)['State']
        if state.get('Health', {}).get('Status') == 'healthy':
            return
        if state['Status'] in ['exited', 'dead', 'restarting']:
            raise RuntimeError('Container failed startup')
        time.sleep(1)
    raise RuntimeError('Container health deadline exceeded')

def fetch(path):
    return subprocess.check_output(['curl', '--fail', '--silent', '--show-error',
        '--max-time', '25', 'https://liqvera.site' + path], timeout=30)

def public_check(asset):
    html = fetch('/')
    assert asset.encode() in html, 'Wrong public browser asset'
    cap = json.loads(fetch('/v1/capabilities'))
    assert cap['network'] == 'eip155:31611' and cap['source_mode'] == 'live-public'
    assert cap['amount_atomic'] == '10000000000000000' and cap['payment_ready']
    assert cap['asset'].lower() == '0x118917a40faf1cd7a13db0ef56c86de7973ac503'
    ready = json.loads(fetch('/readyz'))
    assert ready['ready'] and ready['payment_ready']
    fetch('/healthz')
    previews = {'report.json': '0ebf36b89bda183b99767cd7fedc3c956405ef4a3f195d9d73b911d2c146ccf2',
                'evidence.zip': '3255a42c210c6fe6ad0020c34113988da3f1659c566a73b7729606ad65d083b0'}
    for filename, expected in previews.items():
        assert hashlib.sha256(fetch('/demo/latest-live/' + filename)).hexdigest() == expected
    headers = subprocess.check_output(['curl', '--fail', '--silent', '--show-error', '--head',
        '--max-time', '25', 'https://liqvera.site/'], text=True, timeout=30)
    policy = re.search(r'Content-Security-Policy "([^"]+)"',
                       (ROOT / 'deploy/mezo-evidence/Caddyfile').read_text()).group(1)
    assert any(line.lower().startswith('content-security-policy:') and line.split(':', 1)[1].strip() == policy
               for line in headers.splitlines()), 'Changed CSP'
    return {'asset': asset, 'network': cap['network'], 'payment_ready': cap['payment_ready'],
            'preview_sha256': previews, 'csp_matches_source': True}

def prepare():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
    old = inspect(NAME)
    assert old['Image'] == OLD_IMAGE
    image = api('GET', '/images/' + TAG + '/json')
    assert image['Id'] == (OUT / 'web-image-id.txt').read_text().strip()
    assert image['Config']['Labels']['org.opencontainers.image.revision'] == SOURCE
    RECOVERY.mkdir(mode=0o700, exist_ok=False)
    private_write(RECOVERY / 'compose.before.json', MANIFEST.read_bytes())
    shutil.copyfile(WC, RECOVERY / 'walletconnect.before.env')
    (RECOVERY / 'walletconnect.before.env').chmod(0o600)
    baseline = {'source_commit': SOURCE, 'inventory': inventory(), 'ledger': ledger(),
                'walletconnect_sha256': digest(WC), 'manifest_sha256': digest(MANIFEST),
                'image': image['Id'], 'previous_asset': 'index-Dd1iIief.js'}
    assert all(v['health'] == 'healthy' for v in baseline['inventory'].values())
    baseline['public'] = public_check(baseline['previous_asset'])
    write_json(RECOVERY / 'baseline.json', baseline)
    candidate = json.loads(MANIFEST.read_bytes())
    candidate['services']['web-live']['image'] = TAG
    write_json(RECOVERY / 'compose.candidate.json', candidate)
    run(['docker', 'compose', '-f', str(RECOVERY / 'compose.candidate.json'), 'config', '--quiet'])
    print('Prepared source-bound candidate; existing stack unchanged.', flush=True)

def backup():
    assert not (RECOVERY / 'backup-complete.json').exists()
    assert digest(MANIFEST) == json.loads((RECOVERY / 'baseline.json').read_text())['manifest_sha256']
    gateway = 'liqvera-live-gateway-live-1'
    writers = ['liqvera-live-' + service + '-live-1' for service in ['report', 'evidence-capture']]
    assert inspect(gateway)['State']['Running'] and not inspect(gateway)['State']['Paused']
    assert all(not inspect(name)['State']['Paused'] for name in writers)
    started = time.time()
    try:
        # SIGTERM drains HTTP and workers before pool.end; timeout/nonzero is not a coherent boundary.
        # The unchanged runtime entrypoint starts main.js, not the migration CLI.
        api('POST', '/containers/' + gateway + '/stop?t=30')
        gateway_state = inspect(gateway)['State']
        assert gateway_state['Status'] == 'exited' and gateway_state['ExitCode'] == 0, 'Gateway did not drain cleanly'
        for name in writers:
            api('POST', '/containers/' + name + '/pause')
        with open(RECOVERY / 'liqvera.pgdump', 'xb') as stream:
            os.chmod(stream.name, 0o600)
            run(['docker', 'exec', 'liqvera-live-postgres-live-1', 'pg_dump', '-U', 'liqvera',
                 '-d', 'liqvera', '-Fc'], stdout=stream, timeout=55)
        # Each owner can also read its private in-progress lock files without changing permissions.
        for volume, uid in [('artifacts', '10002'), ('captures', '10001')]:
            with open(RECOVERY / (volume + '.tar.gz'), 'xb') as stream:
                os.chmod(stream.name, 0o600)
                run(['docker', 'run', '--rm', '--network', 'none', '--read-only', '--cap-drop', 'ALL',
                     '--security-opt', 'no-new-privileges:true', '--user', uid + ':10001',
                     '--mount', 'type=volume,src=liqvera-live_' + volume + ',dst=/data/' + volume + ',readonly',
                     '--entrypoint', '/bin/busybox', OLD_IMAGE, 'tar', '-czf', '-', '-C', '/data',
                     volume], stdout=stream, timeout=55)
    finally:
        # Reconcile all intended writers even if a pause succeeded but its reply was lost.
        failures = []
        for name in reversed(writers):
            try:
                if inspect(name)['State']['Paused']:
                    api('POST', '/containers/' + name + '/unpause')
            except BaseException:
                try:
                    if inspect(name)['State']['Paused']:
                        api('POST', '/containers/' + name + '/unpause')
                except BaseException:
                    failures.append(name)
        try:
            if not inspect(gateway)['State']['Running']:
                api('POST', '/containers/' + gateway + '/start')
            healthy(gateway)
        except BaseException:
            # A lost start response is reconciled before declaring failed recovery.
            try:
                if not inspect(gateway)['State']['Running']:
                    api('POST', '/containers/' + gateway + '/start')
                healthy(gateway)
            except BaseException:
                failures.append(gateway)
        if failures:
            raise RuntimeError('Writers require unpause recovery: ' + ', '.join(failures))
    checksums = {n: digest(RECOVERY / n) for n in ['liqvera.pgdump', 'artifacts.tar.gz', 'captures.tar.gz']}
    for volume in ['artifacts', 'captures']:
        run(['gzip', '-t', str(RECOVERY / (volume + '.tar.gz'))])
    with open(RECOVERY / 'liqvera.pgdump', 'rb') as stream:
        run(['docker', 'exec', '-i', 'liqvera-live-postgres-live-1', 'pg_restore', '--list'],
            stdin=stream, stdout=subprocess.DEVNULL)
    write_json(RECOVERY / 'backup-complete.json', {'sha256': checksums, 'duration_seconds': time.time() - started})
    print('Coherent database and sealed-volume backups validated; writers resumed.', flush=True)

def restore_manifest():
    fd, filename = tempfile.mkstemp(prefix='compose.wave1-restore-', suffix='.json', dir=MANIFEST.parent)
    temporary = Path(filename)
    with os.fdopen(fd, 'wb') as stream:
        stream.write((RECOVERY / 'compose.before.json').read_bytes())
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, MANIFEST)

def recover_old(baseline, retain_candidate):
    """Attempt every independent recovery action and verify the actual final state."""
    old_id = baseline['inventory']['web']['id']
    errors = []
    current = None
    candidate_clear = False
    def optional_inspect(name):
        try:
            return inspect(name)
        except RuntimeError as error:
            if str(error).endswith('HTTP 404'):
                return None
            raise
    for attempt in range(3):
        try:
            current = optional_inspect(NAME)
            candidate_clear = current is None or current['Id'] == old_id
            break
        except BaseException:
            errors.append('inspect canonical web')
    if current and current['Id'] != old_id:
        if current['Image'] != baseline['image']:
            errors.append('unexpected canonical image; preserved')
        elif retain_candidate:
            for path in ['/containers/' + current['Id'] + '/stop?t=20',
                         '/containers/' + current['Id'] + '/rename?name=' + NAME + '-wave1-rolled-back-9ca9ced']:
                try:
                    api('POST', path)
                except BaseException:
                    errors.append('retain candidate: ' + path)
        else:
            try:
                api('DELETE', '/containers/' + current['Id'] + '?force=1')
            except BaseException:
                errors.append('remove failed candidate')
        # A successful rename does not prove a failed/lost stop request took effect.
        # Reconcile by immutable ID; never start a second web with the same routing aliases.
        if current['Image'] == baseline['image']:
            for attempt in range(3):
                try:
                    candidate = optional_inspect(current['Id'])
                    if candidate and candidate['State']['Running']:
                        api('POST', '/containers/' + current['Id'] + '/stop?t=20')
                        candidate = optional_inspect(current['Id'])
                    candidate_clear = candidate is None or not candidate['State']['Running']
                    if candidate_clear:
                        break
                except BaseException:
                    errors.append('verify candidate stopped')
    # A failure above must not prevent attempted restoration of the old runtime and manifest.
    for action, operation in [
        ('rename previous web', lambda: api('POST', '/containers/' + old_id + '/rename?name=' + NAME)
         if inspect(old_id)['Name'] != '/' + NAME else None),
        ('start previous web', lambda: api('POST', '/containers/' + old_id + '/start')
         if candidate_clear and not inspect(old_id)['State']['Running'] else None),
        ('restore manifest', restore_manifest),
    ]:
        try:
            operation()
        except BaseException:
            errors.append(action)
    try:
        assert candidate_clear, 'Candidate might still serve the production alias'
        assert inspect(NAME)['Id'] == old_id
        healthy(old_id)
        assert digest(MANIFEST) == baseline['manifest_sha256']
        public_check(baseline['previous_asset'])
    except BaseException:
        raise RuntimeError('Rollback could not be verified; recovery actions: ' + ', '.join(errors))
    print('Previous web and manifest restored and verified; persistent data untouched.', flush=True)

def rollback():
    baseline = json.loads((RECOVERY / 'baseline.json').read_text())
    old_id = baseline['inventory']['web']['id']
    current = inspect(NAME)
    assert current['Image'] == baseline['image'], 'Unexpected current image; manual review required'
    assert inspect(PREVIOUS)['Id'] == old_id
    recover_old(baseline, retain_candidate=True)

def deploy():
    baseline = json.loads((RECOVERY / 'baseline.json').read_text())
    assert (RECOVERY / 'backup-complete.json').is_file()
    security = json.loads((OUT / 'security-summary.json').read_text())
    assert security['source_commit'] == SOURCE and security['image_id'] == baseline['image']
    assert security['untriaged_findings'] == 0
    assert digest(WC) == baseline['walletconnect_sha256']
    assert digest(MANIFEST) == baseline['manifest_sha256']
    assert api('GET', '/images/' + TAG + '/json')['Id'] == baseline['image']
    before = inventory()
    assert all(before[s]['id'] == baseline['inventory'][s]['id'] for s in SERVICES)
    old = inspect(NAME)
    cfg = copy.deepcopy(old['Config'])
    cfg['HostConfig'] = copy.deepcopy(old['HostConfig'])
    cfg['Image'] = baseline['image']
    for key in ['Hostname', 'Domainname', 'ExposedPorts']:
        cfg.pop(key, None)
    cfg.setdefault('Labels', {})['org.opencontainers.image.revision'] = SOURCE
    cfg['Labels']['com.docker.compose.image'] = baseline['image']
    cfg['NetworkingConfig'] = {'EndpointsConfig': {network: {'Aliases': data.get('Aliases') or []}
        for network, data in old['NetworkSettings']['Networks'].items()}}
    html = (OUT / 'published-dist/index.html').read_text()
    asset = re.search(r'/assets/(index-[^" ]+\.js)', html).group(1)
    try:
        api('POST', '/containers/' + old['Id'] + '/stop?t=20')
        api('POST', '/containers/' + old['Id'] + '/rename?name=' + PREVIOUS)
        new = api('POST', '/containers/create?name=' + NAME, cfg)['Id']
        api('POST', '/containers/' + new + '/start')
        healthy(new)
        public = public_check(asset)
        after = inventory()
        assert all(after[s]['id'] == before[s]['id'] and after[s]['image'] == before[s]['image']
                   and after[s]['volumes'] == before[s]['volumes'] for s in SERVICES if s != 'web')
        assert all(v['health'] == 'healthy' for v in after.values())
        assert digest(WC) == baseline['walletconnect_sha256']
        temp = MANIFEST.with_name('compose.wave1-ready.json')
        private_write(temp, (RECOVERY / 'compose.candidate.json').read_bytes())
        os.replace(temp, MANIFEST)
        result = {'source_commit': SOURCE, 'web_image': baseline['image'], 'previous_web_image': OLD_IMAGE,
                  'inventory': after, 'ledger_before': baseline['ledger'], 'ledger_after': ledger(),
                  'public': public, 'rollback_container': PREVIOUS, 'recovery_directory': str(RECOVERY),
                  'walletconnect_preserved': True, 'other_services_replaced': False, 'payment_submitted': False}
        write_json(OUT / 'deployment.json', result)
        print(json.dumps({'web_image': baseline['image'], 'asset': asset, 'health': 'healthy',
                          'rollback_container': PREVIOUS}), flush=True)
    except BaseException:
        recover_old(baseline, retain_candidate=False)
        raise

if __name__ == '__main__':
    os.umask(0o077)
    {'prepare': prepare, 'backup': backup, 'deploy': deploy, 'rollback': rollback}[sys.argv[1]]()
