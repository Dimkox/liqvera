# Architecture

Application interfaces, payment guards, SQL and evidence schemas are unchanged. TLS inputs change; effective root checks include directory loading and child inheritance. Operational gateway/carrier replacement and report provenance require separate reviewed recovery evidence. Keep the live PostgreSQL container and all volumes.
