# Data architecture analysis — TLS successor, 2026-10-21

No data migration, backfill, schema/index change or payment-state reset is required by this TLS remediation. The committed delta does not change data/payment invariants. Keep the existing live PostgreSQL container, database volumes, unknown/manual-review outcomes, consumed authority and sealed evidence. Set the report service's new source identity only for future generated bundles; never relabel historical artifacts.

## Source and scope

- Canonical repository: `/home/pall/projects/liqvera`.
- Examined worktree: `/home/pall/projects/liqvera/.worktrees/wave1-deploy`.
- Candidate: `1c020995adaa1a80fc8a97888aa838041d8e01d5`.
- Committed tree: `d2e3a6b86421d3b4f90523cf2dc36fb60a062b20`.
- Exact comparison base: `d56a0e917c36cf22fc68026054c1d1dd8e239462` (candidate parent).
- Both `main` and `origin/main`, and published tag `v0.0.5`, are ancestors. Worktrees were inventoried; none was cleaned or changed.
- Getzilla tool previously pinned in this task: `2bb417431f1e4b9494e4af71ebf27adb1d04d898`. This is the data_architect analysis for the coordinator's successor high-risk route, not a review receipt.
- `reviewed-tree-modified: no`.

Read repository AGENTS, README, architecture and current handoff; inspected status, history, changed-file inventory, relevant diff and unchanged report-provenance code. The source delta has 18 files, 282 insertions and 24 deletions: six Dockerfiles, TLS guards/public certificate fixture, Python dependency pins, CI, a TLS regression test, handoff and security evidence. There are no changes under `apps/`, `packages/`, `services/`, `schemas/`, `migrations/`, or `deploy/mezo-evidence/compose.yaml`. This establishes source-level preservation, not successful runtime remediation or live acceptance.

## Preserved data and payment invariants

All following source references are relative to the examined worktree at the exact candidate above.

| Invariant | Sources |
| --- | --- |
| Scoped idempotency and immutable report/artifact/quote identity; receipts and entitlements remain bound through digests and composite foreign keys. | `apps/mezo-gateway/migrations/001_ledger.sql:6`, `:18`, `:29`, `:67`; `apps/mezo-gateway/migrations/002_fix_immutable_ledger_identity.sql:3` |
| Authorization identities remain unique, each quote has at most one non-rejected attempt, and merchant nonce reservations survive unknown/rejected outcomes across quotes. | `apps/mezo-gateway/migrations/001_ledger.sql:45`; `apps/mezo-gateway/migrations/008_merchant_nonce.sql:1` |
| Durable authority reservation and SUBMITTING precede the sole settlement call; restart/reconciliation never authorize resubmission. | `apps/mezo-gateway/src/adapters/postgres.ts:147`; `apps/mezo-gateway/src/application/gateway.ts:100`; `apps/mezo-gateway/src/workers/reconciliation.ts:4` |
| Receipt, chain event, entitlement and confirmed state commit atomically; delivery requires current finality, confirmed state, retention and artifact integrity. | `apps/mezo-gateway/src/adapters/postgres.ts:220`; `apps/mezo-gateway/src/application/gateway.ts:125`; `apps/mezo-gateway/migrations/005_receipt_confirmation_count.sql:8` |
| Ledger network identity remains immutable and Testnet/Mainnet chain, network and token stay paired. | `apps/mezo-gateway/migrations/007_network_identity.sql:1`; `apps/mezo-gateway/src/adapters/postgres.ts:31` |
| Unknown/manual-review records, authorization deduplication and consumed grants remain preserved. Retention excludes non-rejected attempts and existing entitlements. | `apps/mezo-gateway/src/workers/retention.ts:3`; `apps/mezo-gateway/migrations/003_live_grant_consumption.sql:10`; `apps/mezo-gateway/migrations/006_signed_live_grant_authority.sql:33`; `docs/migration.md:7` |
| Browser funding remains read-only, blocked on unknown payment outcomes, and separate from payment authority. Integer-string amounts and canonical-block/account/network/quote/freshness checks are unchanged. | `apps/mezo-web/src/mezo-finance.mjs`; `apps/mezo-web/src/mezo-finance-panel.ts` |

Fresh local hashing confirms migrations 001–008 still match the previously reviewed pinned identities:

| Migration | SHA-256 |
| --- | --- |
| 001_ledger.sql | `bc127e55c876961112f33ca2abdfac01827769d6156ddba2f42856d070c75b3b` |
| 002_fix_immutable_ledger_identity.sql | `981f48215e64fdd0fb72be5a6df78238cf8050de722adb454b4e28b1940ccbcb` |
| 003_live_grant_consumption.sql | `bbedff6137a648166b77233c56a466e46247480b404b8829b64f29123109bcf0` |
| 004_receipt_confirmation_provenance.sql | `96bba00d344d81670a4c0f8741186004910e959f374ecd77ce78268d52fd465a` |
| 005_receipt_confirmation_count.sql | `e99e5cffab60c08dfb1cd73d13caf2915f31aec542c26c87b016d0e125a23b11` |
| 006_signed_live_grant_authority.sql | `92e346b3fa49699b20d9edca9814d17bde4fb96046e71071c68b0c47326ef18a` |
| 007_network_identity.sql | `377120dd211d6a455f55f264dd188fdf40652be4da512c8d91652c1562f3afa6` |
| 008_merchant_nonce.sql | `562504aa3b54efc7e8e5b5b3eed3a4918c85ec305da775bd33279899dab2e2fe` |

## Report provenance and historical evidence

For the new report image, operational `LIQVERA_ENGINE_COMMIT` should identify `1c020995adaa1a80fc8a97888aa838041d8e01d5`. `packages/evidence-report/src/liqvera_evidence_report/service.py:87` loads it at startup and line 180 supplies it to new report requests. `report.py:74` embeds it in the algorithm document and line 164 embeds it in report reproducibility metadata. This is a provenance change for future artifacts, not a data rewrite or payment authorization.

Existing report IDs use `read_published` (`service.py:189`). Offline reconstruction takes the engine commit from the bundle's own report (`evidence_bundle.py:162`) and compares regenerated report, algorithm, dependency and bundle bytes (lines 167–171). Historical commit identity, report/bundle hashes, receipt bindings and published bytes must therefore remain unchanged. The TLS delta does not change the calculation code or packaged `runtime-dependencies.txt`; certifi/pip pins belong in the complete build/image dependency evidence, not an invented rewrite of that fixed calculation manifest. Historical readback remains a separate runtime verification obligation; it was not executed in this analysis.

Do not conflate `LIQVERA_ENGINE_COMMIT` with grant-bound `LIQVERA_SUBJECT_COMMIT`, `LIQVERA_SUBJECT_TREE` or `LIQVERA_PLAN_SHA256`. Updating report provenance does not renew or relabel grants. Preserve merchant/grant mode and historical consumed-authority rows; source-bound authority must remain fail-closed when it does not match changed source.

## Database and operational boundary

`deploy/mezo-evidence/Dockerfile.postgres` changes CA package installation only, retaining the PostgreSQL base digest. `docs/security/2026-10-21-tls-remediation.md` and current `handoff.md` explicitly retain the existing live PostgreSQL container: no database restart or migration is needed for this scope. This analysis did not inspect the live container or claim a fresh live-state observation.

The external task-owned `tls-fix/rollout.py` was inspected only as text. It sets new report engine provenance at lines 298/318 and asserts unchanged PostgreSQL inventory/identity at lines 406 and 438–440. These are planned controls, not executed proof. Its old draft `release-binding.json` still identifies d56 and `draft: true`; do not use that draft as exact-candidate release evidence.

Normal gateway startup is not entirely write-free: ledger network assertion uses INSERT ON CONFLICT and ordinary workers reconcile existing state. Preserve those existing semantics and investigate any observed state transitions rather than resetting rows to force unchanged counts. MANUAL_REVIEW must not become a fresh settlement attempt. Rollback restores the selected application containers/configuration; never restore an older dump over newer authorization records or restore a database independently of sealed artifacts. Do not run broad Compose migration orchestration merely to deploy TLS image changes.

## Verification obligations and limits

The source handoff records 71 gateway passes, including 13 real disposable-PostgreSQL cases with candidate images; that is coordinator-provided existing evidence, not a run performed or independently replayed here. A full qualifying successor audit must bind its own actual results to its frozen source/images. A skipped PostgreSQL case is not a pass.

If additional database checks are required, retain the prior safe boundary: a new isolated cluster under canonical `.getzilla/runtime`, fresh `liqvera_f4_test_<suffix>`, explicit `TEST_DATABASE_DISPOSABLE=1`, allowlisted environment, no application credentials or live volume/dump mounts, and no payment/public-service egress. The suite intentionally creates `_upgrade`/`_network` databases and temporarily drops the merchant nonce index and migration receipt (`apps/mezo-gateway/test/postgres.test.ts:105`, `:390`, `:441`); a prefixed database on an existing live cluster is insufficient isolation. No real or simulated request may target a live service. Preserve one-CPU scheduling while retaining deliberate concurrency probes.

No new SQL coverage is demanded by this unchanged-schema delta. Existing suite limits still apply: its legacy upgrade case starts with zero receipts; migrations 004/005 reject populated old receipt state rather than fabricate confirmation provenance. Any broader claim of populated migration compatibility, crash durability or restored historical evidence requires separate disposable, synthetic-only evidence. TLS trust checks and vulnerability remediation conclusions belong to the security/code reviews.

Observed bounded checks: exact HEAD/tree and ancestry, clean status, history/worktree inventory, full changed-path inventory, TLS dependency/CI diff, negative data-path diff, report provenance call sites and migration SHA-256 values. The initial shorthand `d56` was not resolvable, so all successful comparisons used its exact parent identity above. No SQL, tests, builds, network requests, live operations, private-material reads or application edits were performed. The sole write is this requested analysis outside the candidate. No data-architecture blocker was found in the committed source delta; this is analysis for review freeze, not a PASS review receipt or deployment authorization.
