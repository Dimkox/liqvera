Read-only repository analysis refreshed 2026-10-21 for successor route `b54297afc340`.

**Current identity and scope**

- Product source: `1c020995adaa1a80fc8a97888aa838041d8e01d5`; tree: `d2e3a6b86421d3b4f90523cf2dc36fb60a062b20`; inspected worktree: `/home/pall/projects/liqvera/.worktrees/wave1-deploy`.
- TLS comparison predecessor: `d56a0e917c36cf22fc68026054c1d1dd8e239462`; tree: `948173c6f44606283d7c5c301fff8fb9fc16b452`.
- PR comparison base and merge-base with `origin/main`: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`. Published tags `v0.0.1` through `v0.0.5` remain ancestors. Git status was clean; recent history and worktrees were inspected without cleanup.
- External Getzilla remains merged PR #115, commit `2bb417431f1e4b9494e4af71ebf27adb1d04d898`, tree `81076df2cd7db8713f7178ead66ebaa2728f861e`.
- Saved successor route at `/home/pall/projects/liqvera/.getzilla/runtime/pr115-tls-liqvera/engineering/changes/20261021-task-b54297/route.json` confirms four selected analyses, five independent reviews, `write_agent=null`, and profiles `base`, `frontend`, `data`.
- This refresh ran source reads and Git inspection only. No tests, builds, live calls, application edits, database operations or changes to either frozen audit clone were performed. This report is an analysis, not a PASS review or verification receipt.

`C:` references below identify files at the current product SHA. The historical appendix retains its own original source identities and is not fresh verification of the successor.

**Dated delta — 2026-10-21**

The `d56a0e9..1c020995` delta contains 18 files, 282 insertions and 24 deletions: CI workflow, all six Dockerfiles, two TLS probes, a public CA-certificate fixture, a four-case regression test, Python development metadata and two locks, remediation/initial-audit documentation and archive, and handoff. `git diff --quiet d56a0e917c36cf22fc68026054c1d1dd8e239462 1c020995adaa1a80fc8a97888aa838041d8e01d5 -- apps packages schemas migrations acceptance` returned exit 0. Application/payment source, protocol/schema definitions, migrations, acceptance plan and historical proof bytes are unchanged by this TLS delta.

The committed changes address the four recorded TLS findings by pinning certifi `2026.10.19` in both Python closures, pip `26.2.2` with an offline checksum-bound bootstrap, both Alpine CA packages `20261020-r0` in build/runtime stages, inherited `NODE_OPTIONS=--use-openssl-ca` for Node, and digest-pinned Go `1.27.3` for unchanged Caddy `2.11.7`. CI selects a corrected CA file and an empty CA directory before dependency downloads. This description is source inspection; it does not independently establish current image or live-remediation acceptance. Sources: `C:requirements.lock`, `C:requirements-dev.lock`, `C:pyproject.toml:14`, `C:deploy/mezo-evidence/Dockerfile.edge:7`, `C:.github/workflows/verify.yml:43`, `C:docs/security/2026-10-21-tls-remediation.md`.

**Current validation commands and added obligations**

The original full-product matrix in the appendix remains applicable: `make verify PYTHON=.venv/bin/python`; documentation checks; both application builds and tests; both browser network builds; all 13 real disposable-PostgreSQL cases; four-wheel/source identity and installed CLI checks; offline acceptance; explicit Compose profiles; image builds and exact-image security scans. Makefile, both application manifests, protocol manifest and `docs/validation.md` are unchanged from `87b66c0`. The initial Python preparation sequence in the historical appendix is superseded by the corrected bootstrap at `C:.github/workflows/verify.yml:43`.

| Current/additional check | Exact command or checked-in configuration | Scope |
|---|---|---|
| Safe dependency preparation | Follow `C:.github/workflows/verify.yml:43`: create `.venv`, fetch pip wheel, verify SHA-256 `fd7f4dfa8190e014013b9f08f3e973f4e4c26ffd179a204895533a7254813a70`, install with `--no-index --no-deps`, set `SSL_CERT_FILE` to its vendored certifi bundle and `SSL_CERT_DIR` to a new empty directory, run the pip probe before installing `requirements-dev.lock` | The checksum-bound wheel is the bootstrap boundary; setup-node and later downloads follow corrected trust setup. |
| New TLS guard regression | `.venv/bin/python -B -m pytest tests/test_tls_trust_guard.py -q` | Four parameter cases: clean store, injected public root in CA file, hashed CA directory and directory list. Included by native `make verify`. |
| Python/pip trust | `.venv/bin/python deploy/security/check-tls-trust.py --pip` in the corrected trust environment | Checks pip vendored and additive system trust, nonempty roots and enabled verification. `--certifi` also checks runtime certifi; `--cafile` accepts an explicit public bundle. |
| Capture/report runtime TLS | `docker run --rm --network none --read-only --cap-drop ALL -v "$PWD/deploy/security/check-tls-trust.py:/check.py:ro" --entrypoint python liqvera-python:ci /check.py --certifi --without-pip` | CI runs this after each capture/report image build; verifies certifi/system trust and absence of pip/ensurepip. |
| Node build trust | `node deploy/security/check-node-tls-trust.cjs` under configured `NODE_OPTIONS=--use-openssl-ca` and corrected CA paths | Probes effective system/extra roots, TLS verification and a spawned child's inherited mode; rejects unsupported CA-directory lists. |
| Gateway runtime TLS | `docker build -f deploy/mezo-evidence/Dockerfile.gateway -t liqvera-gateway:ci .`; `docker run --rm --network none --read-only --cap-drop ALL -v "$PWD/deploy/security/check-node-tls-trust.cjs:/check.cjs:ro" --entrypoint node liqvera-gateway:ci /check.cjs` | New CI image check, separate from normal gateway tests. |
| Dependency and image security | Existing two pip-audit and two npm-audit commands remain; supplement with fresh direct OSV/PyPI checks of both `.lock` closures, exact-image Trivy/Grype, runtime trust probes and Caddy binary govulncheck | A dependency version change does not alone prove every effective trust store or existing deployed image is corrected. |

Sources for the new commands: `C:.github/workflows/verify.yml:31`, `:43`, `:67`, `:73`; `C:deploy/security/check-tls-trust.py:20`, `:52`; `C:deploy/security/check-node-tls-trust.cjs:14`; `C:tests/test_tls_trust_guard.py:20`. The public certificate fixture contains no private key and is introduced only into temporary offline test processes.

**External detection findings at the successor**

All seven underlying detection/coverage limitations in the historical appendix remain applicable. The current route still reports `kind=python`, `languages=[python]`, detected JavaScript/Python/TypeScript, and `package_scripts=[]`. Getzilla is unchanged; the TLS patch adds no root Node manifest and does not alter pytest testpaths, nested Docker locations or lockfile names.

The Python discovery gap now also includes `tests/test_tls_trust_guard.py`: Getzilla's ordinary `pytest -q` follows `C:pyproject.toml:28`, whose eight explicit test directories omit that root-level file as well as `tests/acceptance` and `tests/operations`. Native `make verify` supplies `tests` explicitly and includes the four new TLS cases. A qualifying run must disclose its actual invocation and any supplemental execution; the generic Getzilla selector alone does not prove this regression ran.

Getzilla's Ruff/Bandit paths also omit `deploy/security`, including the new trust probes. Its root-only Trivy trigger still misses the six modified `deploy/mezo-evidence/Dockerfile.*` recipes. Its OSV parser still omits both Python `.lock` filenames, despite the certifi fix inside them. The nested Node build/test omission and builtin-stack metadata limitation remain unchanged. Required native CI and supplemental evidence must be preserved rather than treating a generic external result as complete product verification.

**History and evidence boundary**

`C:docs/security/2026-10-21-getzilla-initial.md` preserves the prior negative audit at product `57660040b36300de62cd45cb663bd2124167fe45`; it records the external gate, independent findings and supplemental results. `C:docs/security/2026-10-21-tls-remediation.md` and handoff record bounded candidate builds/probes, 71 gateway tests including disposable PostgreSQL, and advisory checks; this analysis did not rerun or independently attest those results. Complete successor review, final qualifying verification and any deployment remain separately bound evidence. Existing live PostgreSQL, unknown payment state, sealed bundles, historical archives and retained rollback images are not test targets or cleanup candidates.

The complete earlier repository analysis and UI-successor addendum follow verbatim as historical context. Original report: `/home/pall/projects/liqvera/.getzilla/runtime/analysis-repo_explorer.md`; SHA-256 `515e48f9c173dbbff196760a64b89a17be9aa6488a273107d2e7d3619f22a05f`. Its old source identity, test counts, command line numbers and preparation instructions must be read with the current qualifications above.

---

**Historical analysis — original text**

Read-only inventory for route `fc7402fc1070`. No tests, builds, database operations, live calls or application edits were performed.

**Source identities**

- Liqvera: `87b66c0d53cc276eae41b437f616346c33a28e98`, tree `9b5ec7523543bb8591890db1b8ad885e1e16cf1e`, audit clone `/home/pall/projects/liqvera/.getzilla/runtime/pr115-liqvera`.
- Comparison base and clone `origin/main`: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`; merge-base equals that base. Two commits follow it: application `9ca9ced…`, deployment documentation `87b66c0…`.
- Getzilla merged PR #115: `2bb417431f1e4b9494e4af71ebf27adb1d04d898`, tree `81076df2cd7db8713f7178ead66ebaa2728f861e`, tag `v2.3.0`.
- Liqvera tags `v0.0.1` through `v0.0.5` are ancestors; `v0.0.5` resolves to `19284fb07fedd4909672c7e9a641cb066efbb7cc`.
- Canonical checkout remains older `7130bb55014815df26f6d565cc9c189f8d37da76`; worktrees were inventoried, with no cleanup. Audit and tool clones were clean at inspection.

Below, `L:` denotes files at the Liqvera SHA above; `G:` denotes files at the Getzilla SHA above.

**Native validation inventory**

| Surface | Exact command/configuration | Source |
|---|---|---|
| Python environment | `python3 -m venv .venv`; `.venv/bin/pip install -r requirements-dev.lock`; `.venv/bin/pip install --no-deps --no-build-isolation -e .` | `L:.github/workflows/verify.yml:41` |
| Complete Python verification | `make verify PYTHON=.venv/bin/python` runs the artifact scanner and `.venv/bin/python -B -m pytest tests -q`. Explicit `tests` is significant. Python ≥3.12; pytest excludes the `live` marker by default. | `L:Makefile:9`, `L:pyproject.toml:6`, `L:pyproject.toml:24` |
| Documentation | `.venv/bin/python scripts/check-docs.py` | `L:.github/workflows/verify.yml:46` |
| Gateway build | `make liqvera-gateway`: `npm ci --ignore-scripts --prefix apps/mezo-gateway`, protocol compilation with `apps/mezo-gateway/node_modules/.bin/tsc -p packages/mezo-protocol/tsconfig.json`, then `npm run --prefix apps/mezo-gateway build` | `L:Makefile:25` |
| Browser build | `make liqvera-web`: corresponding browser `npm ci --ignore-scripts`, protocol compilation, then browser build. Build executes `tsc --noEmit && vite build`. | `L:Makefile:30`, `L:apps/mezo-web/package.json:6` |
| Both browser networks | Default build uses Testnet; explicit second build: `LIQVERA_NETWORK=mainnet npm run build --prefix apps/mezo-web` | `L:apps/mezo-web/vite.config.ts:5`, `L:docs/competition/wave1-musd-funding.md:35` |
| Gateway tests | `npm test --prefix apps/mezo-gateway`. Expands to build, test TypeScript compilation, test-resource copying, then `node --test test-dist/test/*.test.js test/*.test.mjs`. | `L:apps/mezo-gateway/package.json:12` |
| Browser tests | `npm test --prefix apps/mezo-web`, executing `node --test test/*.test.mjs` | `L:apps/mezo-web/package.json:9` |
| Real PostgreSQL tests | Provision a **new disposable** database; set `TEST_DATABASE_URL` and `TEST_DATABASE_DISPOSABLE=1`; run `npm run test:postgres --prefix apps/mezo-gateway`. Guard requires hostname `127.0.0.1` or `localhost`, database `liqvera_f4_test_<lowercase suffix>`. | `L:docs/validation.md:14`, `L:apps/mezo-gateway/test/postgres.test.ts:21` |
| Four Python distributions | `make liqvera-python PYTHON=.venv/bin/python` builds contracts, public-capture, readonly-analyzer and evidence-report, bound to clean exact HEAD. Output: `dist/liqvera/python`. | `L:Makefile:21`, `L:scripts/build-liqvera-python-distributions.py:49`, `L:tools/conformance/runner.py:13` |
| Installed artifacts and verifier | Included in full Python run: `tests/artifact/`, `tests/installed/`, `tests/evidence_report/`. Canonical installed test builds all four wheels, installs without index, confirms imports outside checkout, creates a fixture report and invokes `liqvera-evidence-verify`. Canonical report tests cover preview hashes and tampering. | `L:tests/installed/test_canonical_f3_installed.py:27`, `L:tests/evidence_report/test_canonical_f3.py:102` |
| Offline acceptance evidence | `make liqvera-acceptance PYTHON=.venv/bin/python ACCEPTANCE_OUTPUT=/absolute/new/result.json`; verify with `make liqvera-acceptance-verify PYTHON=.venv/bin/python ACCEPTANCE_OUTPUT=/absolute/new/result.json ACCEPTANCE_RESULT_SHA256=<independently-obtained-digest>` | `L:Makefile:41`, `L:acceptance/offline-plan.json:3` |
| Dependency closures | `.venv/bin/pip-audit -r requirements.lock`; `.venv/bin/pip-audit -r requirements-dev.lock`; `npm audit --prefix apps/mezo-gateway`; `npm audit --prefix apps/mezo-web` | `L:.github/workflows/verify.yml:55` |

The PostgreSQL file defines 13 tests covering migration checksums, preservation on upgrade, concurrent creation, grant consumption, restart behavior, immutable network identity, merchant nonce reuse and startup guards. Without the two required environment variables, these tests **skip**; ordinary gateway test success therefore does not establish database coverage.

The offline acceptance plan selects A01, A08, A09, A27 and A30. Its partial results do not establish overall acceptance. The wheel builder also downloads pinned wheels for the host and CPython 3.14/musllinux; installation is offline after wheelhouse preparation (`L:tools/conformance/distributions.py:184`).

**Docker and runtime validation**

- `make liqvera-compose` declares `docker compose -f deploy/mezo-evidence/compose.yaml config --quiet`; `make liqvera-images` declares the corresponding `build`. However, **every service has a `fixture` or `live` profile**. For substantive isolated validation, explicitly select `--profile fixture`; do not assume the profile-less Make target builds the complete stack. Sources: `L:Makefile:35`, `L:deploy/mezo-evidence/compose.yaml:201`.
- The Python operations tests render fixture, live and disabled-payment configurations with synthetic public metadata; four tests require Docker Compose. These test configuration only, without starting services. Source: `L:tests/operations/test_f6_static.py:15`.
- Testnet override configuration: from `deploy/mezo-evidence`, `docker compose -p liqvera-testnet --profile live -f compose.yaml -f compose.testnet-demo.yaml config --quiet`. Compose 2.24.4+ is required. Required public metadata names are `LIQVERA_ENGINE_COMMIT`, `LIQVERA_PUBLIC_ORIGIN`, `LIQVERA_SITE_ADDRESS`, `LIQVERA_PAY_TO`. Configuration inspection is distinct from the runbook’s deployment command. Source: `L:docs/runbooks/testnet-demo.md:19`.
- Runtime images are capture, report, PostgreSQL, gateway, web and edge. CI directly builds capture/report using `docker build -f deploy/mezo-evidence/Dockerfile.<component> -t liqvera-python:ci .`, then executes the CPython and BusyBox regression scripts with network disabled, read-only root, dropped capabilities and temporary `/tmp`. Exact commands: `L:.github/workflows/verify.yml:20`.
- Edge CI builds `Dockerfile.edge`, runs `caddy validate`, builds its `builder` target and runs pinned `govulncheck@v1.9.0` against upstream Caddy. Exact commands: `L:.github/workflows/verify.yml:68`.
- Native policy additionally requires fresh Trivy **and** Grype scans bound to each built image ID, including PostgreSQL and edge. These are separate from source/lockfile auditing. Source: `L:docs/validation.md:20`.

No application Go module exists. The edge’s upstream Caddy build is the relevant Go security surface.

**Getzilla detection and verification gaps**

1. **Nested Node applications receive no Node checks.**  
   The saved route reports `kind=python`, `languages=[python]`, `package_scripts=[]`, while disclosing JavaScript/TypeScript files. Manifest promotion recognizes only root manifests (`G:.getzilla/getzilla/repo.py:135`, `:317`). Although the route explicitly selects `frontend`, the Node runner checks only root `package.json` and returns `[]` when absent (`G:.getzilla/getzilla/verification.py:1771`). Its stack detector does discover nested manifests, but Node is classified `verified_by: builtin:node`; `stack_checks` immediately continues without verifying that any Node check ran (`G:.getzilla/getzilla/stacks.py:141`, `G:.getzilla/config/stacks.json:28`). Both application builds/tests and protocol compilation require explicit native commands.

2. **Default Python discovery is narrower than `make verify`.**  
   Getzilla invokes `pytest -q` (`G:.getzilla/getzilla/verification.py:2026`). Liqvera’s configured `testpaths` omit `tests/acceptance` and `tests/operations` (`L:pyproject.toml:28`). This misses local authorization/replay/acceptance-runner tests and the Compose security checks. Native `make verify` supplies `tests`, covering those directories. Getzilla also records coverage as skipped for this pytest path.

3. **Native artifact guard and complete distribution build are separate.**  
   Getzilla does not invoke `make verify`, the standalone artifact scanner, `make liqvera-python`, or the source-bound acceptance targets. Its pytest selection does include installed/artifact tests, so this is **partial coverage**, not total absence.

4. **Python static analysis misses the implementation packages.**  
   Getzilla’s fixed `QUALITY_PY_PATHS` includes scripts/tests and Getzilla-specific locations, but excludes Liqvera’s `packages/` and `tools/`. Consequently its Ruff/Bandit checks do not cover the four application packages through that path list. Source: `G:.getzilla/getzilla/verification.py:1588`.

5. **Nested Docker configuration is not selected by Getzilla’s Trivy trigger.**  
   The trigger recognizes only root `Dockerfile`, `dockerfile`, `Containerfile` or root `docker-compose*.yml/yaml`. Liqvera uses `deploy/mezo-evidence/Dockerfile.*` and `compose.yaml`. Source: `G:.getzilla/getzilla/verification.py:1758`. Getzilla also has no Liqvera-specific image build, runtime regression, real PostgreSQL or offline-bundle acceptance runner.

6. **Dependency scanning covers nested npm locks but not Liqvera’s Python lock filenames.**  
   OSV collection traverses repository paths and recognizes nested `package-lock.json` and `pyproject.toml`. It recognizes requirements text files, **not** `requirements.lock` or `requirements-dev.lock`. The direct Python pins therefore do not prove the exact locked transitive closure. Sources: `G:.getzilla/getzilla/known_vulns.py:257`, `:303`. Without `GETZILLA_OSV_DB` or `GETZILLA_OSV_ONLINE=1`, the vulnerability scan explicitly skips (`:517`).

7. **Generic contract/SQL checks are limited evidence.**  
   JSON contract checking parses JSON; SQL safety searches changed files for a few destructive patterns. These do not establish OpenAPI semantics, migration checksums, concurrent nonce protection or durable ledger behavior. Sources: `G:.getzilla/getzilla/verification.py:1368`, `:1394`.

The existing GitHub workflow also omits disposable PostgreSQL provisioning, the explicit Mainnet browser build, and fresh whole-stack image scans. Those remain supplemental native checks even when CI is green.

The October 21 deployment record reports historical results of 951 Python tests plus 85 subtests, 102 browser tests and 71 gateway tests including PostgreSQL (`L:docs/security/2026-10-21-wave1-deployment.md:7`). They were **not rerun by this analysis**. A Getzilla PR result should be reported separately from the native full-product matrix and from live wallet/payment acceptance.

**Addendum — 2026-10-21: UI successor inspected**

The user requested the funding-control overlap repair, borrowing-prerequisite guidance and Getzilla footer link. I inspected `git diff 87b66c0d53cc276eae41b437f616346c33a28e98 57660040b36300de62cd45cb663bd2124167fe45` in the canonical repository without checking out or editing the product. Successor commit: `57660040b36300de62cd45cb663bd2124167fe45`; tree: `7f70be70d1e53624ded7efcbba1c80eda5048437`. The one-commit delta contains exactly seven files, 56 insertions and three deletions: `apps/mezo-web/src/main.ts`, `mezo-finance-panel.ts`, `mezo-finance.mjs`, `style.css`, `apps/mezo-web/test/mezo-finance-panel.test.mjs`, `mezo-finance.test.mjs`, and `handoff.md`.

The diff adds scoped grid/button/checkbox layout, an accessible explanation of the shortfall prerequisite, initial no-quote guidance, the requested footer link and two regression tests. Unknown-payment recovery guidance remains on the existing branch. No package manifest, lockfile, Python configuration, Make target, Docker definition, gateway code, SQL migration or Getzilla detection rule changes. All seven detection/coverage findings above therefore remain applicable to this successor. The native browser test/build matrix and actual layout checks must be bound to the successor; baseline browser evidence alone does not verify it.

The successor handoff reports 104 passing browser tests, a Testnet build and Chrome geometry checks at six widths, and records an existing certifi exposure found by supplemental scanning of the two Python lockfiles. Those are recorded claims, not fresh executions by this analysis. This addendum performed only source inspection; no tests, live actions or application edits.
