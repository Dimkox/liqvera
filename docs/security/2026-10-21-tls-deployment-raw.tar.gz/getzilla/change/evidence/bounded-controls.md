# Bounded controls

Source 1c020995adaa1a80fc8a97888aa838041d8e01d5: four TLS regressions and four artifact cases pass; all71 gateway cases pass inside exact v2 gateway with new disposable PostgreSQL; six candidate builds, trust probes, CPython/BusyBox regressions and Caddy Go binary scan pass. Source code/security reviews found no remaining blocker after their independently reproduced fixes. New committed images are being scanned separately. Full successor gate has not run.

Canonical raw evidence: /home/pall/projects/liqvera/.getzilla/runtime/tls-fix/. Original negative gate: docs/security/2026-10-21-getzilla-initial.md and its raw archive.

Successor supplements now pass: web104 tests, Testnet/Mainnet builds, bothnpm audits, artifactguard; finalimages alltrustchecks pass. Gateway/edge/web/PostgreSQL final rootfs equal testedv2; capture/report rebuilt and their TLS/CPython/BusyBox checks rerun. Newreportimage reproduces unchanged historical preview. Finalimage scans retain30 narrowlytriaged occurrences withzero new/untriaged findings. Ops69isolatedfaulttests+Dockerpairpass onscript21211975c0679774958b5801e21e19e6e1f888fbad6c0554088bf85119f7dc4f; no live rollout yet.
