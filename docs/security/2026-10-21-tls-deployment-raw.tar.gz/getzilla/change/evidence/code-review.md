# Independent code review — frozen TLS successor

Status: COMPLETE. Reviewer: `/root/code_reviewer`. Date: 2026-10-21.

No remaining application-code blocker was found in the reviewed diff. Fresh bounded checks pass on the unmodified candidate. Five deliberately introduced source regressions were detected by committed or independent probes; one of them still survives the committed finance tests and is recorded below as a coverage gap. The whitespace findings are retained explicitly. This conclusion is a code-review result, not a passing Getzilla gate, security certification, deployment approval or live acceptance. The final qualifying gate has not run.

## Source identity and isolation

| Field | Reviewed value |
| --- | --- |
| Candidate | `/home/pall/projects/liqvera/.getzilla/runtime/pr115-tls-liqvera` |
| Route | `b54297afc340` |
| Actual PR base | `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f` |
| Before and after HEAD | `bf569ce96039deeec69e025a3c3cdc9653584b0d` |
| Before and after candidate Git tree | `c4205fabda3d9d34d08058990fca33b0b059f81d` |
| Product commit before audit metadata | `1c020995adaa1a80fc8a97888aa838041d8e01d5` |
| Product tree | `d2e3a6b86421d3b4f90523cf2dc36fb60a062b20` |
| Getzilla PR 115 tool commit | `2bb417431f1e4b9494e4af71ebf27adb1d04d898` |
| Private scratch | `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-code-tls` |
| Scratch snapshot | `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-code-tls/snapshot` |
| Before fingerprint time | `2026-10-21T12:20:05.953716+00:00` |
| After fingerprint time | `2026-10-21T12:23:41.395761+00:00` |
| Before and after tracked-byte manifest SHA-256 | `afc15dab7b9136c39267ec267012e883c66ac04622e6dc7cf92b56a12644b98a` |
| Before and after porcelain status | Empty, including untracked files |

reviewed-tree-modified: no

The canonical runtime parent was checked to be a real, current-user-owned, non-sticky directory with mode `0700`. A new sibling scratch directory was created with mode `0700`. `git archive --format=tar HEAD` exported the clean candidate into it. In the scratch snapshot only, `git init -q`, `git add -f .` and `git write-tree` reproduced the exact candidate tree above before any mutation. After all probes, `git diff --exit-code` returned zero and `git write-tree` still produced the same tree. A separate SHA-256 manifest over sorted tracked paths and file bytes matched both the original candidate and restored scratch. Every mutation was restored in a `finally` block.

No commands that build, install, test, generate reports or mutate files ran in the reviewed candidate. Git reads and source reads were the only candidate operations. All generated files, copied public fixtures, logs and reviewer tests are outside it. No application fix was made by this reviewer. No credentials, private grants, backups, database rows or secret configuration were read. No network request, live quote, payment, borrowing operation, deployment or publication was performed by this review. Probe commands were limited to CPU affinity `0,1`; Node test concurrency was one.

The repository startup context, AGENTS, README, architecture, handoff, status/history and active change package were inspected. The candidate's merge base with `origin/main` is the supplied actual PR base, and published tags through v0.0.5 are ancestors. The candidate is an isolated clone; no worktree cleanup occurred. The pinned Getzilla skill, code-review role and routed verification/frontend/data/security workflow instructions were applied.

## Findings

### CR-01 — nonblocking committed-test gap at the 30-second freshness boundary

Location: `apps/mezo-web/src/mezo-finance-panel.ts:98` and the three focused finance test files.

Replacing `Date.now() - lastBalance.at < 30000` with `< Infinity` leaves all 55 committed finance tests passing. The independent clock/click probe then fails: an observation exactly 30 seconds old can still expose the borrow link. On the unmodified candidate, that probe passes and stale downloads are revoked. Thus the current implementation enforces the intended limit, but the committed suite does not protect its removal. Keep a committed regression that advances the clock to the boundary and attempts navigation/download without a preceding explicit panel update. No test or application edit was made during this audit.

### CR-02 — retained historical whitespace finding

Location: `docs/security/2026-10-21-wave1-deployment.md:51`.

`git diff --check` against the actual PR base reports a new blank line at EOF in this historical deployment evidence. The owner explicitly retains the evidence bytes. This is a nonsecurity formatting finding; it is not evidence of an application defect.

### CR-03 — trailing whitespace in frozen analysis metadata

Location: `engineering/changes/20261021-task-b54297/evidence/analysis-repo_explorer.md`, lines 101, 104, 107, 110, 113, 116 and 119.

The same diff check reports trailing whitespace on seven list headings in the complete returned analysis report. The coordinator confirmed that those returned bytes must be preserved. These are nonsecurity formatting findings relevant to the pending final gate. They do not imply a problem in the application, TLS behavior or product source. The reviewed snapshot was not changed to suppress them.

No untested mutation survivor is silently counted as a pass. CR-01 records the survivor in the committed test suite even though the independent probe kills it.

## Actual diff assessment

The complete PR diff was inspected against `f1d3bffc`, including the earlier Wave 1 funding UI and layout/footer correction and the TLS changes. The final audit commit adds only `engineering/changes/20261021-task-b54297/` metadata. There are no browser-source changes since product commit `57660040b36300de62cd45cb663bd2124167fe45`. All 14 TLS implementation/test file hashes from the preceding source review match this frozen candidate exactly; the comparison is recorded in `history-binding.json`. Earlier reviews are historical supporting evidence, not substitutes for the fresh candidate checks below.

The finance code validates the known chain/token configuration, quote network and payer, positive canonical atomic amount, quote expiry, busy state and payment guard before permitting the read. Unknown/pending outcomes retain recovery guidance. Wallet operations remain public reads; the funding panel does not sign or submit a payment. The observation binds `eth_call` to an explicit block number, rechecks that block's canonical hash and wallet identity, shares a bounded deadline, and uses integer arithmetic for shortfall and report budget. The export explicitly marks `payment_submitted: false` and describes a wallet-reported observation, not settlement proof.

Panel ownership checks include provider object, account, quote and checkout state; changes invalidate observations and blob URLs. Click handlers reevaluate freshness and expiry. The borrowing link requires a fresh shortfall plus acknowledgment, and returning does not trigger payment. The layout uses separate grid rows with 14-pixel gaps, a wrapping label and scoped button styles. The footer links to `https://github.com/Dimkox/Getzilla` with the existing external-link protections. The existing payment orchestration and gateway/ledger contracts are preserved. Fresh focused finance tests and two finance mutations cover a subset of these claims; current browser geometry and the remaining static claims are explicitly unexecuted below.

For TLS, both lockfiles pin certifi 2026.10.19; the development lock and optional dependencies pin pip 26.2.2. Capture/report bootstrap pip from a SHA-256-bound wheel using local `--no-index --no-deps` installation before pip index access. Runtime installation remains offline and pip/ensurepip removal is preserved. Both Alpine CA packages are pinned to `20261020-r0` in all six BusyBox download stages and the affected build/runtime stages. Patched BusyBox binaries remain copied after APK operations. The Go builder moves to digest-pinned 1.27.3 while the Caddy and module selections are unchanged.

Node build/runtime environments explicitly select `--use-openssl-ca`; the gateway's existing child-spawn environment inheritance preserves that setting. CI bootstraps the checksum-bound pip wheel before any pip network operation, chooses its corrected CA bundle, overrides the additional CA directory with a new empty directory, persists both variables, and runs setup-node afterward. The Node probe precedes npm operations. This addresses both additive modern-pip system trust and Node bundled-store selection. The checksum-bound wheel and pinned checkout remain the bootstrap boundary; this review does not claim that the runner or Docker daemon was independently rebuilt or audited.

The Python checker now enumerates effective hashed CA-directory entries, including colon-separated paths, as well as loaded certificate roots. It checks certifi, pip's vendored bundle, additional system trust and relevant pip bypass options. The Node checker requires inherited OpenSSL mode, counts distinct system/extra roots, checks verification settings, and refuses directory-list overrides its enumeration cannot inspect correctly. Both retain a substantial-root-count sanity check. The public incident fixture is a certificate only and contains no private key. The fresh positive/poison probes and deliberate guard removals below test these particular behavior claims.

The TLS change does not modify payment application logic, SQL migrations, gateway routes, capture/report algorithms or historical proof bytes relative to its TLS source base `d56a0e9`. PostgreSQL source trust is updated, while retaining the live PostgreSQL container is an operational decision recorded in the change package. This code review grants no authority to change that container or its state.

## Fresh checks and exact commands

Unless stated otherwise, the working directory was `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-code-tls/snapshot`. Full literal argument arrays, sanitized environment values and results are in `probe-results.json` and `node-oracle-results.json`; full outputs are adjacent `.log` files. The controlling driver is `run-probes.py` in the scratch root. No fixture or dependency was downloaded during these probes.

Tools: Python 3.12.3; Node v24.22.0 with embedded OpenSSL 3.5.8; host OpenSSL 3.0.13. These are reviewer host tools, not a claim about the final container binaries. Existing corrected pip/certifi fixtures were copied into the new scratch; their file hashes are in `fixture-sha256.json`. The incident public certificate bytes were asserted equal to the frozen candidate fixture.

1. Committed TLS path regressions:

   `taskset -c 0,1 /home/pall/projects/liqvera/.worktrees/wave1-deploy/.venv/bin/python -B -m pytest -c /dev/null -p no:cacheprovider --basetemp=/home/pall/projects/liqvera/.getzilla/runtime/reviewer-code-tls/pytest-tmp tests/test_tls_trust_guard.py -q`

   Result: exit 0, `4 passed in 1.66s`. Clean, poisoned file, poisoned hashed directory and poisoned directory-list paths are covered. `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`, `PYTHONDONTWRITEBYTECODE=1` and the scratch fixture import path were set. The venv interpreter was used read-only; all pytest outputs were in scratch.

2. Committed finance regressions:

   `taskset -c 0,1 node --test --test-concurrency=1 apps/mezo-web/test/mezo-finance.test.mjs apps/mezo-web/test/musd-observation.test.mjs apps/mezo-web/test/mezo-finance-panel.test.mjs`

   Result: exit 0, 55 tests passed, zero failures/skips.

3. Independent finance probes:

   `taskset -c 0,1 node --test --test-concurrency=1 /home/pall/projects/liqvera/.getzilla/runtime/reviewer-code-tls/reviewer-probes.test.mjs`

   Result: exit 0, four tests passed, zero failures/skips. They exercise exact freshness-boundary clicks, elapsed quote expiry, account/quote/busy/payment invalidation and revocation, and disposal of a completed export. Despite its broader test name, the last test does not independently establish asynchronous in-flight disposal behavior.

4. Python effective-store probes:

   `taskset -c 0,1 /usr/bin/python3 /home/pall/projects/liqvera/.getzilla/runtime/reviewer-code-tls/snapshot/deploy/security/check-tls-trust.py --certifi --pip`

   The sanitized environment sets `PATH=/usr/bin:/bin`, `PYTHONPATH=/home/pall/projects/liqvera/.getzilla/runtime/reviewer-code-tls/fixtures/site`, `PYTHONDONTWRITEBYTECODE=1`, `PIP_CONFIG_FILE=/dev/null`, `SSL_CERT_FILE` and `SSL_CERT_DIR` to the scratch fixtures, plus the explicitly recorded Node mode. Clean bundle `fixtures/2026.10.19.pem` and empty directory: exit 0, system, certifi 2026.10.19, pip 26.2.2 and pip additional system trust each report 120 roots and zero incident roots. Poison bundle `fixtures/2026.7.22.pem`, single hashed directory `fixtures/capath`, and `fixtures/empty:fixtures/capath`: each exits 1 with `compromised emSign trust remains`. The JSON stores the full absolute paths, not these relative abbreviations.

5. Node effective-store and child probes:

   `taskset -c 0,1 node /home/pall/projects/liqvera/.getzilla/runtime/reviewer-code-tls/snapshot/deploy/security/check-node-tls-trust.cjs`

   Same clean bundle/empty directory with `NODE_OPTIONS=--use-openssl-ca`: exit 0; both parent and child report 120 effective distinct roots and zero incident roots. Poison file and single directory each exit 1 naming the incident root. The colon-separated directory list exits 1 with `Multiple CA directories require separate inspection`. Omitting `NODE_OPTIONS` exits 1 with `OpenSSL trust mode must reach spawned Node processes`.

6. Independent executable Node rejection oracles:

   `taskset -c 0,1 node --test --test-concurrency=1 /home/pall/projects/liqvera/.getzilla/runtime/reviewer-code-tls/node-guard-regressions.test.cjs`

   Result: exit 0, two tests passed. These require nonzero checker status for absent startup mode and the poisoned directory list; they fail when the respective checker guards are removed.

7. OpenSSL poison-fixture control:

   `taskset -c 0,1 openssl verify /home/pall/projects/liqvera/.getzilla/runtime/reviewer-code-tls/fixtures/compromised-root.pem`

   With the clean `SSL_CERT_FILE` and `SSL_CERT_DIR` set to the absolute scratch `empty:capath` paths, exit 0 and the public root reports `OK`. This demonstrates that the poisoned lazy path is a usable trust anchor in this local OpenSSL environment. It is not an exploit or TLS handshake, and uses no private key or server.

8. Source whitespace:

   `git -C /home/pall/projects/liqvera/.getzilla/runtime/pr115-tls-liqvera diff --check f1d3bffc46fa1459908fdff865fcfbfc831b7f7f HEAD`

   Result: exit 2, with CR-02 and CR-03 exactly as recorded in `diff-check.log`. This result is not suppressed or represented as a passing check.

## Mutation results

Each mutation changed only the private exact snapshot and was reverted before the next mutation. The commands are the same numbered commands above; exact replacement strings and argument arrays are also retained in the JSON and driver.

| Mutant | Change | Observed result | Classification |
| --- | --- | --- | --- |
| M1 | Remove Python `if cafile is None` hashed-directory enumeration block | Command 1 exits 1: directory and directory-list cases fail, two others pass | Killed by committed regressions |
| M2 | Remove Node inherited `NODE_OPTIONS` assertion | Mutated checker falsely exits 0 without the mode; command 6 exits 1 with one failed rejection oracle | Killed by independent probe |
| M3 | Remove Node multiple-CA-directory assertion | Mutated checker falsely exits 0 on poisoned `empty:capath`; command 6 exits 1 with one failed rejection oracle | Killed by independent probe |
| M4 | Replace finance `paymentGuard !== 'clear'` guard with `false` | Command 2 exits 1: 53 pass, pending-guard and unknown-outcome guidance tests fail | Killed by committed regressions |
| M5 | Replace the panel's `< 30000` freshness limit with `< Infinity` | Command 2 exits 0: all 55 pass. Command 3 exits 1: freshness-boundary click test fails, three others pass | Survived committed suite; killed independently; CR-01 |

No executed mutant was inconclusive. This is a bounded sample, not an exhaustive mutation score. The Python negative tests fail for their intended safety assertions; the Node mutants falsely accept poisoned/unsupported configuration rather than crashing due to syntax changes. Baseline probes pass on the same source and fixtures, establishing that the mutant failures are change-sensitive.

## Supporting evidence and explicit limits

The prior full UI review is `/home/pall/projects/liqvera/.getzilla/runtime/code-review.md`; the intervening TLS source review is `tls-fix/code-source-review.md`. Hash comparisons bind their reviewed code to this candidate, while only the fresh commands above are counted as this review's execution. The earlier browser geometry checks and eight other UI/layout mutation results are historical evidence; they were not rerun here.

I inspected `v2-checks.json`, `final-checks.json`, the bounded-control document and the operations review/addendum. They record successful image trust/backport checks and 69 isolated operations-model tests. The final checks explicitly show capture/report root filesystems differ from v2, whereas gateway/edge/web/PostgreSQL match; no blanket image equivalence is claimed. The operations addendum records final image identity consistency and zero untriaged findings while retaining 30 scanner occurrences. Those are results from other reviewers/coordinator evidence, not tests or security triage independently rerun by this code reviewer.

Unexecuted in this review, including statically reviewed claims without a fresh executable probe:

- Full Getzilla PR gate and complete Python/product suite. The coordinator must persist all five reports, freeze and run the qualifying gate separately. Historical whitespace and public-token heuristic findings must remain visible.
- Fresh browser rendering, desktop/mobile geometry, actual AppKit/physical wallet behavior, and complete entrypoint/payment-orchestration execution. The unchanged UI source and prior browser evidence support review context only; focused fake-DOM tests do not establish live browser acceptance.
- Every earlier finance mutation, all possible race/network/reorg inputs, and independently modeled in-flight disposal. Only the stated bounded sample was mutated in this pass.
- Fresh Docker builds, image provenance reconstruction, all image regressions, OSV/PyPI advisory queries, Trivy/Grype interpretation, Caddy binary scanning and real disposable-PostgreSQL gateway tests. Their preserved evidence and dedicated reviews are separate. Host Node's embedded OpenSSL version is not used to infer the container's version.
- A live TLS handshake or end-to-end pip/npm download through each corrected environment. These probes establish trust-store contents, rejected overrides and startup inheritance, not a full network acceptance claim. Pip bypass-option assertions, every alternative certificate encoding/path and malformed trust-store input were statically reviewed but not separately mutated here.
- Private rollout script execution, fresh backup/restore, production container/state inspection, traffic continuity, grants, purchases, loans and paid delivery. No live operational authority is supplied by this review.

Machine-readable binding evidence is `reviewer-code-tls/source-before.json`, `source-after.json`, `history-binding.json`, `probe-results.json`, `node-oracle-results.json`, `fixture-sha256.json` and `tool-versions.json`. The candidate and restored snapshot identities match. This complete report is saved outside the reviewed candidate for coordinator persistence; it does not itself complete the final verification gate.
