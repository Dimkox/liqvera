# Independent data review — final TLS successor

Date: 2026-10-21. Reviewer role: `data_reviewer`. Getzilla route: `b54297afc340`; change: `20261021-task-b54297`.

**PASS for the bounded data review. No blocking or nonblocking data defect identified in the reviewed diff.** The full qualifying gate is pending all five saved reviews. This report does not authorize deployment or claim live-payment acceptance.

## Source binding and review boundary

| Identity | Before review | After review |
| --- | --- | --- |
| HEAD | `bf569ce96039deeec69e025a3c3cdc9653584b0d` | `bf569ce96039deeec69e025a3c3cdc9653584b0d` |
| Tree | `c4205fabda3d9d34d08058990fca33b0b059f81d` | `c4205fabda3d9d34d08058990fca33b0b059f81d` |
| Git status, including nonignored untracked files | empty | empty |

reviewed-tree-modified: no

- Canonical root: `/home/pall/projects/liqvera`.
- Read-only candidate: `/home/pall/projects/liqvera/.getzilla/runtime/pr115-tls-liqvera`.
- Actual complete comparison base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`.
- TLS product: `1c020995adaa1a80fc8a97888aa838041d8e01d5`, tree `d2e3a6b86421d3b4f90523cf2dc36fb60a062b20`.
- TLS product parent: `d56a0e917c36cf22fc68026054c1d1dd8e239462`.
- Pinned external Getzilla: `2bb417431f1e4b9494e4af71ebf27adb1d04d898`.
- Private reviewer scratch: `/home/pall/projects/liqvera/.getzilla/runtime/tls-data-review-bf569ce`; exact tracked snapshot in `source/`. This report and every reviewer-generated artifact are outside the candidate.

Read repository AGENTS, README, architecture, handoff/current changes, the new route/change package, TLS remediation record, the data architect analysis, payment/data source boundaries, and operational provenance/recovery source. The pinned Getzilla delivery/verification/data/frontend/security skills and reviewer role remain the applicable instructions. This is a new review of the successor identity, not reuse of the previous candidate's receipt.

`git status --short`, `git rev-parse HEAD HEAD^{tree}`, `git log -8 --oneline`, `git worktree list --porcelain`, and full `git diff --stat`/`--name-status` against the actual base established scope. `git merge-base --is-ancestor <ref> HEAD` returned 0 for the base, local `origin/main`, and every available tag v0.0.1–v0.0.5. No remote refresh or publication claim is made. No worktree cleanup occurred.

The scratch and immediate runtime parent are owner-only mode `0700`, non-sticky directories. Ancestors were checked for expected ownership, absence of symlinks/world writes/sticky bits. `git archive --format=tar <exact-HEAD>` supplied the clean snapshot. All **483 tracked blobs and executable modes** matched before testing; all **483 candidate and snapshot blobs** matched after testing. HEAD/tree/status remained unchanged. Ignored dependency/runtime outputs are not product-source inputs to this snapshot.

No live SQL, live container inspection, private configuration, dump, `.env`, grant, key, or credential was read. No application files, database state, migrations, payment/quote/loan state, deployments or publications were changed. The sole container run was a reviewer-owned, network-disabled verifier with public evidence and a read-only probe mounted; it was automatically removed and its absence confirmed.

## Actual diff and preserved invariants

The full base-to-candidate inventory contains **72 changed paths**. The TLS product delta from its parent contains **18 paths**; the product-to-review-candidate delta contains **18 paths**, all inside the active engineering change package. Executable diff assertions found:

- No TLS delta under `apps/`, `packages/`, `services/`, `schemas/`, `migrations/`, or `deploy/mezo-evidence/compose.yaml`.
- Across the complete base comparison, no change to gateway, packages, services, schemas, historical migrations or public preview assets. The earlier browser funding extension remains in the complete review range and received fresh focused tests below.
- All eight approved SQL migration files still match `apps/mezo-gateway/src/migration-policy.ts`, original deployment receipts, and layout deployment receipts.

There is **no schema, query, index, backfill, data-format or payment-state migration** in this successor. No new data-volume assumption, query-plan effect, database lock or database downtime is introduced. `Dockerfile.postgres` retains the pinned PostgreSQL base digest and changes CA installation; the source/operational plan intentionally retains the existing live PostgreSQL container. A newly tested PostgreSQL image is not authority to replace the live database service.

The unchanged source retains scoped request idempotency and immutable digest bindings (`001_ledger.sql`, `002_fix_immutable_ledger_identity.sql`); cross-quote merchant nonce uniqueness regardless of uncertain/rejected state (`008_merchant_nonce.sql`); durable SUBMITTING/authority reservation before the sole settlement call (`src/adapters/postgres.ts:147`, `src/application/gateway.ts:100`); confirm-only reconciliation (`src/workers/reconciliation.ts:4`); and transactional chain-event/receipt/entitlement/confirmed-state publication (`src/adapters/postgres.ts:220`). Delivery still requires retained confirmed entitlement, current chain validation and artifact integrity. Immutable ledger network identity remains enforced by migration 007/startup.

Retention excludes non-rejected attempts and existing entitlements (`src/workers/retention.ts:3`); deduplication rows and consumed grants/reservations remain preserved and append-only. The TLS change supplies no reset or retry authorization. Normal gateway startup/workers may perform existing ledger operations, so a future rollout must investigate legitimate state changes instead of resetting rows to force unchanged aggregate counts.

## Fresh executable checks

All following checks completed with exit 0. Supporting scripts/results reside under the reviewer scratch named above. Source assertions and hash checks read the candidate; executable source tests use its validated snapshot. No code mutations were introduced; data-review mutation testing is not required for this role, and no mutant score is asserted.

### Source, migration, archive, test-log and image binding

Command, from the scratch directory:

```text
python3 check-data-evidence.py
```

Observed: **18 TLS paths; 18 metadata-only paths; zero protected data/application path deltas; 8/8 migration hashes; 39/39 original Wave 1 archive members; 19/19 layout archive members; 12 matching historical aggregate/migration rows.** Both complete archive SHA-256 checks passed. Recorded historical states remain three CONFIRMED attempts, one MANUAL_REVIEW attempt, four receipts and four entitlements. Those totals are preserved evidence, not grounds to delete receipts because current CONFIRMED and receipt counts differ.

The same check read the complete current `gateway-v2-tests.log`, matched all **13 PostgreSQL case names** from the reviewed test source to passing entries, and asserted the **71 pass / 0 fail / 0 skip** summary. It also checked the current final release source/binding and the 69-test operational model's script hash and zero recorded PostgreSQL mutations.

I independently queried image metadata with `docker image inspect --format '{{json .RootFS.Layers}}' <final-id> <tested-v2-id>`. The gateway's **14 layers** and PostgreSQL's **15 layers** match pairwise exactly:

| Component | Tested v2 image | Final image |
| --- | --- | --- |
| gateway | `sha256:21bbfd563669be4c3e730b1eb948927d9b371954e5a70e7b3c42f9ee377a3e2c` | `sha256:a341fae9c0c8a1feade5b11493b58dbeb1a4f22cad5e5b79ef4602dd5b7db901` |
| PostgreSQL, build validation only | `sha256:4a4df747faee7979969b996b981e9488a1063bdab1e1f09e55af8c6746161b57` | `sha256:98e5cab850b96ff1acfaca92834c8590274e62ba9f64b6d882d27ec7f6e090d8` |

This is fresh root-filesystem identity checking, not a new PostgreSQL test execution or an assertion that the live database image changed. Capture/report were rebuilt and are not claimed identical to v2.

### Browser funding guards

Command, from `<scratch>/source`:

```text
env -i PATH=/usr/local/bin:/usr/bin:/bin LANG=C.UTF-8 node --test apps/mezo-web/test/mezo-finance.test.mjs apps/mezo-web/test/musd-observation.test.mjs
```

Observed **46 pass, 0 fail, 0 skip**. These fresh tests exercise exact integer amounts, one-wei shortfall, malformed values, account/network/asset mismatch, expired/uncertain-payment blocking, block-number pinning, changed block hash, shared read deadline, identity changes during the read, serialization and Mainnet separation. Providers are simulated; no wallet/RPC/API connection or payment is made. Full output: `finance-tests.log`.

### Historical and future report provenance in the final image

The exact final report image is `sha256:f938d4f3483af7453944ad98de648f9b7a1f6ac4ad3399434069194245d58901`. I ran the new verifier independently against only the unchanged public preview and an in-memory derivative. The exact executed argument array is retained in `image-provenance-result.json`; its shell equivalent is:

```sh
REVIEW_SCRATCH=/home/pall/projects/liqvera/.getzilla/runtime/tls-data-review-bf569ce
docker run --rm --pull=never --name liqvera-data-review-report-bf569ce \
  --network none --read-only --cap-drop ALL --security-opt no-new-privileges:true \
  --user 10002:10001 --pids-limit 64 --memory 256m --cpus 1 \
  --tmpfs /tmp:rw,noexec,nosuid,size=16m \
  --mount "type=bind,source=${REVIEW_SCRATCH}/provenance-probe.py,target=/probe.py,readonly" \
  --mount "type=bind,source=${REVIEW_SCRATCH}/source/apps/mezo-web/public/demo/latest-live,target=/evidence,readonly" \
  --env LIQVERA_ENGINE_COMMIT=1c020995adaa1a80fc8a97888aa838041d8e01d5 \
  --entrypoint python sha256:f938d4f3483af7453944ad98de648f9b7a1f6ac4ad3399434069194245d58901 \
  -B /probe.py
```

Observed: historical report SHA-256 `0ebf36b89bda183b99767cd7fedc3c956405ef4a3f195d9d73b911d2c146ccf2` reproduced; historical bundle SHA-256 `3255a42c210c6fe6ad0020c34113988da3f1659c566a73b7729606ad65d083b0` remained unchanged; original engine commit **`76b63ecaa5782614435850b1cfbda80ac02684eb` was preserved despite the new environment value**. An in-memory reconstruction using the same historical inputs and product commit `1c020995…` embedded the new commit in report and algorithm metadata and its synthetic bundle also reproduced. No artifact was published or written over the historical bundle. This tests provenance mechanics and offline compatibility, not a fresh market capture or live report-service delivery.

Source inspection explains the boundary: `service.py:87` loads `LIQVERA_ENGINE_COMMIT`, line 180 applies it to new requests, and lines 189–195 read existing published artifacts without relabelling them. `evidence_bundle.py:162–171` reconstructs using the bundle's own engine identity and compares report/algorithm/dependency/bundle bytes. The fixed calculation dependency manifest is unchanged; updated certifi/pip image/build dependencies belong in complete build evidence, not in rewritten historical artifacts.

### Operational provenance and PostgreSQL identity guards

Command, from scratch:

```text
python3 operations-data-probe.py
```

The probe parses the exact `tls-fix/rollout.py` and executes only the original `image_for`, `env_update`, `name`, `candidate_config`, and `guard_baseline` function definitions with synthetic dictionaries and mocked read dependencies. It does **not** import/run the operational module or load prepare/backup/deploy/rollback, Docker, SQL or filesystem-writer functions.

Observed: report candidate configuration uses product commit `1c020995…`; old configuration and mounts remain unchanged; grant subject identity is not introduced/relabelled; PostgreSQL is excluded from both stop/start orders; the unchanged retained database identity passes; **changed ID, changed image, and missing PostgreSQL each fail closed**. Live operations: zero. The report manifest's matching `LIQVERA_ENGINE_COMMIT` assignment at rollout line 300 was also inspected statically; candidate runtime assignment is at line 320.

The current release binding is finalized (`draft: false`), names the product commit, and explicitly retains live PostgreSQL. The earlier draft-status paragraphs in analysis/operations evidence are historical; the later finalized-binding addendum is the applicable record. `guard_baseline` pins source/script/binding and the retained PostgreSQL ID/image before mutation. `prepare` rejects mixed source-grant variables rather than treating a report provenance update as renewed payment authority. No audit metadata commit is substituted for product provenance.

## Evidence identities and observations from other executors

| Artifact | SHA-256 |
| --- | --- |
| Exact operational script | `21211975c0679774958b5801e21e19e6e1f888fbad6c0554088bf85119f7dc4f` |
| Final release binding | `e1c966aa44fd760f5baa26d2108f063c043016c7eec76cd6b2a016b1291b7cf3` |
| Gateway v2 complete test log | `7689ef9678289dc01db5c651b92f52d772cb093f86d4bde798c31e113226ea90` |
| Gateway v2 isolation/result record | `308c5f2eb646fc4e0e567093015bc64d2cf7f9bb3d9cf00e1ec3fb2844283075` |
| Reviewer evidence-check script | `dfd18cd00a21c60c715ab080ff9867f955dba5caaaf395ac92120a6461fc9b89` |
| Reviewer operational data probe | `ce9cfdd7c1d23924fb7740d58aef8af4ea1d5351451e7018c131defd97f1006b` |
| Reviewer final-image provenance probe | `909fbf0acf55448901d2131e65cdcbad6f2712782c4f2138b171d3b44a9d7ccd` |

The coordinator's 71-test gateway run records a new disposable tmpfs PostgreSQL cluster on an internal network, test gateway sharing that namespace for loopback guards, no production volume/credential use, and cleanup. The 13 real database cases cover migrations/checksums, empty-receipt legacy upgrade, twenty-client idempotency/grant concurrency, durable grant budgets/restart/rollback, artifact recovery/cleanup, startup guards, network isolation, merchant repeat purchases/cross-quote nonce reuse, and missing nonce-index/receipt refusal. I inspected and bound this evidence; I did not rerun SQL or independently attest its original runtime isolation.

The separately executed 69-case operational model records zero failures/errors and zero modeled PostgreSQL mutations against the exact operational script. Its finalized-binding addendum and isolated Docker-pair result remain separate evidence. Models use synthetic state; they do not establish production recovery success. The new three PostgreSQL identity fault probes above are independent bounded checks, not a rerun of the whole model.

Immediately before finalization I also read the coordinator's new safe `tls-fix/backup-restore.json` record. It binds product `1c020995adaa1a80fc8a97888aa838041d8e01d5` and the final PostgreSQL image above, records `restored_ledger_matches: true`, and retains the same three CONFIRMED/one MANUAL_REVIEW/four receipts/four entitlements plus all eight migration hashes. It describes an internal-network, tmpfs-only restore without production mounts and removal of its owned container/network. This is current separately executed restore evidence that I inspected, not a restore performed by me; no private dump bytes were opened.

Historical backup/restore records remain intact. Rollback source restores selected containers/configuration and never runs migrations or restores an older ledger over later payment rows. Backups must remain coherent with sealed artifacts/captures; unknown/manual-review outcomes, nonce reservations, consumed authority, and historical digest bindings cannot be reset as part of TLS recovery.

## Findings, unexecuted claims and limits

**No data finding requires a source change.** These explicit limitations remain:

1. No live database state, payment, fresh quote, loan, live capture, report API delivery, production backup, rollback, or database restoration was exercised. The data review issues no deployment authority.
2. Source-level transaction/retention/idempotency reasoning is not exhaustive crash/failure proof. No new PostgreSQL fault injection after every receipt/entitlement insert, unknown/manual-review cleanup/restart probe, or synthetic database dump/restore was run by this reviewer.
3. The existing legacy upgrade test starts with **zero receipts**. Populated legacy migrations 004/005 are designed to stop rather than fabricate confirmation provenance; that behavior was inspected, not executed here. No populated-ledger upgrade compatibility claim is made.
4. Private backup contents remain unopened. Historical and current safe restore summaries compare aggregate states and migration hashes, not every database row or every artifact/capture binding. The new successor restore record was inspected as coordinator evidence; no live restore or independent replay by this reviewer is claimed.
5. Report provenance execution covered offline verification and an in-memory synthetic derivative in the final image. Actual service startup, persisted new-publication/read-published branches and production configuration are statically reviewed or covered by other executors, not executed here. The future rollout must set `LIQVERA_ENGINE_COMMIT` to product `1c020995…`, preserve old bundles, and keep it distinct from grant-bound `LIQVERA_SUBJECT_COMMIT/TREE` and `LIQVERA_PLAN_SHA256`.
6. Wallet block checks use the selected provider's reports; they are not independent chain authentication, reserved funds, or payment authority. The export remains labelled accordingly.
7. Production query plans, scale, contention and alert operation were not exercised; there is no schema/query/backfill delta. Security/CVE conclusions and the full Python/artifact/PR gate belong to their recorded checks and selected reviewers. This PASS does not generalize to pending gates.

Final verification recomputed all 483 Git blob identities in both candidate and snapshot and checked exact HEAD/tree/status. `final-identity.json` records the unchanged source and removal of the reviewer container. Persist this complete report with the other selected reports before the final qualifying gate.
