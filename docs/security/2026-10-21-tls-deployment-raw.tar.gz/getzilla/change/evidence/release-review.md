# Independent release review — TLS successor

**Review result: PASS for release continuity, recovery design and evidence integrity within the scope below. No remaining blocking release-preparation finding was identified.** The final Getzilla gate and the other final reviews are separate, pending obligations at this review boundary. This is not a passing full-audit receipt, deployment acceptance, merge approval or new production authority. TLS image replacement has not been claimed as complete.

## Source identity and review boundary

- Route: `b54297afc340`; change: `engineering/changes/20261021-task-b54297`.
- Canonical repository: `/home/pall/projects/liqvera`.
- Read-only candidate: `/home/pall/projects/liqvera/.getzilla/runtime/pr115-tls-liqvera`.
- HEAD before and after: `bf569ce96039deeec69e025a3c3cdc9653584b0d`.
- Tree before and after: `c4205fabda3d9d34d08058990fca33b0b059f81d`.
- Product: `1c020995adaa1a80fc8a97888aa838041d8e01d5`, tree `d2e3a6b86421d3b4f90523cf2dc36fb60a062b20`.
- Full comparison base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`; TLS-specific parent: `d56a0e917c36cf22fc68026054c1d1dd8e239462`.
- Pinned external Getzilla: `2bb417431f1e4b9494e4af71ebf27adb1d04d898`.
- Working tree clean before and after. The merge base with local `origin/main` equals the specified base; local main is 0 commits ahead / 6 behind. All local published tags v0.0.1–v0.0.5 are ancestors. Worktrees were inventoried; none was changed or removed.
- Product-to-audit-HEAD changes exactly 18 paths, all within the active change package.
- Reviewer scratch: `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-release-tls`, mode 0700 beneath a checked non-sticky, non-world-writable runtime parent. Scratch contains only the reviewer evidence checker and its diagnostic record; no candidate application copy or application mutation was needed.
- **reviewed-tree-modified: no**

I read repository instructions, README, architecture, current handoff, the TLS/application change inventory, actual TLS diff, change-package requirements/release/recovery/test plans, analysis reports, current deployment guidance, public operational script and sanitized build/scan/recovery records. Application code, candidate metadata and production resources were not edited. No private configuration, grants, dumps, wallet keys or pairing material was read. Docker access was limited to read-only image ID/descriptor metadata; no live container was queried or changed by this reviewer.

## Successor and historical continuity

The earlier release review's source certifi blocker is addressed in this successor's source/build evidence: both lockfiles now pin 2026.10.19. The broader TLS correction also updates pip to 26.2.2, pins corrected Alpine CA packages, selects inherited OpenSSL trust for Node and rebuilds Caddy with Go 1.27.3. I inspected those changes and their retained results; the independent source security review owns the full security assessment. Corrected source/builds do not make preceding runtime images remediated.

No TLS delta changes application logic, gateway startup/payment behavior, SQL, API/schema contracts, calculation/verifier resources, historical preview bytes or source Compose topology. A fresh scoped Git comparison against product 5766004 returns no paths under apps, packages, services, schemas, migrations or acceptance, or for Compose and the gateway entrypoint. All eight gateway migration hashes and both preview hashes still match the historical deployment evidence.

The initial negative audit remains committed, explicitly historical and unsuppressed. Fresh hash verification passed for all **49 initial-audit payloads**, **39 original Wave 1 payloads**, and **19 layout-deployment payloads**. No existing security evidence file from 5766004 was modified or deleted. The initial external gate's exit 1, generic public-token heuristic matches, historical whitespace failure, omitted lockfile discovery and four original TLS findings remain evidence rather than being rewritten into success.

Current `docs/deployment.md` correctly describes the already deployed layout browser and its guarded rollback. `docs/security/2026-10-21-tls-remediation.md` and handoff describe TLS source/build preparation and explicitly defer rollout. That is an honest predeployment boundary.

**Nonblocking documentation note:** the audit package's `rollback.md` still points to the older Wave 1 record. It describes audit recovery, not a new production operation. Use the current product deployment guide for the layout generation and the exact TLS script/binding for the planned TLS generation. Do not change frozen source merely to hide this note; this report records the distinction.

## Exact release binding and scan accounting

The finalized binding has `draft: false`, `security_untriaged_findings: 0`, `live_postgres_retained: true`, and product source 1c020995. Its security-summary digest matches the actual summary. The independent operations addendum independently checked final Docker image identities and OCI revisions; its script, binding, summary and final-check hashes still match the artifacts I inspected.

| Built image | Exact image-index ID | Raw scanner occurrences |
| --- | --- | ---: |
| Capture | `sha256:3edb015ec3aea7235b621303d1a1821eaa7c52b44f8ceb03b50fe51c4c97d5c1` | 5 |
| Report | `sha256:f938d4f3483af7453944ad98de648f9b7a1f6ac4ad3399434069194245d58901` | 5 |
| Gateway / carrier | `sha256:a341fae9c0c8a1feade5b11493b58dbeb1a4f22cad5e5b79ef4602dd5b7db901` | 4 |
| Edge | `sha256:aa8f036c87fd1f83aec1618205864fac968ac645882c493c74bcb07d5f7a601c` | 4 |
| Web | `sha256:6b26f78a2856e7f2f5a07884249d2b45351a08b3160732ef50a5d04967e07a06` | 9 |
| PostgreSQL, build validation only | `sha256:98e5cab850b96ff1acfaca92834c8590274e62ba9f64b6d882d27ec7f6e090d8` | 3 |

All six final build return codes are zero. Fresh parsing of all 12 raw Trivy/Grype JSON records established an exact multiset match of scanner, advisory ID, package and version against the summary's **30 occurrences**, with no omitted raw occurrence.

Docker and Trivy identify the OCI image index. Grype identifies its image configuration, so those digest strings differ legitimately. I verified each Grype request input against the bound index, decoded its configuration and manifest, verified the configuration digest and manifest descriptor, and matched its rootfs DiffIDs against Trivy. Read-only Docker image inspection confirms all six bound IDs are OCI image indexes. This is evidence consistency, not an independent rebuild.

The 30 dispositions retain 18 BusyBox backport occurrences, four Python backport occurrences, an unrelated Ada-product match, one unused OpenPGP module finding, and six configuration/path-bound nginx/curl occurrences. The summary explicitly avoids claiming patched nginx/curl versions. The retained Node version is not a claim to include every security change in a newer upstream Node release. Go binary evidence reports zero affected symbols/packages and one module-level finding; it is not zero raw findings across every scanner.

Recorded final checks contain ten zero return codes. Capture/report were rebuilt with different rootfs layers and their TLS, CPython and BusyBox checks reran. Gateway, edge, web and PostgreSQL final rootfs layers match the previously exercised v2 candidates. The gateway's 71-test / 13-PostgreSQL-case result belongs to those v2 images and is transferred only through that explicit rootfs-equivalence evidence, not a claim that the 71 cases were rerun against a different image ID.

## Rollout and durable-state preservation

The public script replaces six services: capture, report, web, gateway carrier, gateway and edge. PostgreSQL is excluded from both stop and start orders. Its newly built image is validation evidence only; the existing internal-only live PostgreSQL container remains intentionally retained. No blanket claim that every running image is newly remediated is justified.

The script checks clean exact product source, final binding, current service identities, merchant mode, ordinary gateway startup, carrier linkage, supported trust overrides and candidate image revisions. It preserves existing mounts, security/resource settings, networks and WalletConnect configuration while applying a bounded override set: exact images, gateway/carrier Node trust mode and future report provenance. `LIQVERA_ENGINE_COMMIT` changes only future reports; historical bundles are not relabelled. Signed grant-bound source fields remain separate and are rejected in the inspected merchant configuration.

Ingress stops before the gateway drains. Downstream services remain available for that drain, and the gateway must exit cleanly. The carrier starts before its matching gateway; upstreams start before edge. The gateway explicitly drops incompatible exposed-port configuration when joining its carrier namespace, a defect independently reproduced and fixed during operations review. Normal startup uses `dist/main.js`, not the migration entrypoint.

Recovery pins active and retained script/binding hashes, source identity, PostgreSQL identity, recognized candidate images/labels, and manifest/WalletConnect digests. It retains stopped candidates, refuses later deployments or conflicting retained candidates, verifies every candidate has stopped before restarting previous services, restores the old carrier/gateway pair and manifest, and checks original IDs, health and public endpoints. It never restores a dump or runs migrations. A permanent stop failure is reported without starting duplicate writers.

The unchanged script hash is bound to **69 recorded isolated fault tests**, zero test failures/errors and zero modeled PostgreSQL mutations, plus an actual disposable Docker carrier/gateway create/start rehearsal with no mounts, no published ports and clean cleanup. I independently checked those result files and hashes; I did not rerun the model or the Docker rehearsal. Their mocks and compatibility scope do not establish six-service live acceptance.

New safe backup records now establish a separately executed coherent backup with an **8.044-second** writer interruption and a restore into a new isolated tmpfs PostgreSQL container. The restore's dump digest equals the preservation baseline, and its recorded aggregate ledger and all eight migrations match. The summary records three CONFIRMED attempts, one MANUAL_REVIEW attempt, four receipts and four entitlements. I inspected only sanitized summaries, not private dumps or rows.

The baseline records all seven preceding containers healthy, with the existing database, capture/artifact and Caddy volumes. Startup can perform ordinary network-identity checks and reconciliation; later legitimate state transitions must be reconciled, never reversed to force counts back to a snapshot. Preserve unknown/manual-review outcomes, consumed authority and subsequent payments. Retained rollback images remain recovery material with their original security limitations.

Planned TLS recovery generation: `/home/pall/.local/state/liqvera/recovery/2026-10-21-tls-1c02099/`. Its retained `rollout.py rollback` is the exact-source/hash-bound recovery entrypoint only when rollback is intended within the separately authorized operation. It is not interchangeable with the layout or original Wave 1 command.

## Executed checks and observed evidence

Fresh commands by this reviewer:

1. `git rev-parse HEAD 'HEAD^{tree}'`, `git status --short`, history/worktree inventory, merge-base/count comparison and `git merge-base --is-ancestor <tag> HEAD`: exact identities above; clean; all five tags ancestors.
2. `git diff d56a0e9 1c02099 -- .github/workflows/verify.yml deploy/mezo-evidence deploy/security pyproject.toml requirements.lock requirements-dev.lock tests/test_tls_trust_guard.py`: inspected actual remediation. Product/application preservation comparisons and metadata-only delta were checked separately.
3. `python3 -B /home/pall/projects/liqvera/.getzilla/runtime/reviewer-release-tls/check_release_evidence.py`: exit 0; 49/39/19 archive payloads, eight migrations, two previews, all six image/scan bindings, 30 raw occurrences and recorded 69-case operations results verified. Source identity/status unchanged before and after.
4. `docker image inspect --format '{{.Id}} {{json .Descriptor}}' <bound-image-id>` for each of the six exact IDs: matching image-index identity, OCI index media type; no container environment or private configuration read.
5. `sha256sum requirements.lock requirements-dev.lock`: `b7095c1e6550126e39ccddc231f884dd202b148780befcc324eba9e720b1f6f0` and `fb15760ce2de61de28da89e0b88c97f4890f5c2fc1638074d9dc91897cb5c20d`, matching the independently recorded fresh 65-record / 52-unique-version dependency audit inputs.

An initial scratch-checker run failed with `KeyError: archive` because I incorrectly assumed both historical summaries had the same JSON shape. Inspection showed that the layout record uses top-level archive/payload hash fields. I corrected only the checker, retained `initial-checker-failure.json`, and the complete retry passed. This was a reviewer harness failure, not a product failure or suppressed result.

Recorded, inspected but not reexecuted here: 104 web tests, both network builds, both npm audits, artifact checks, 71 gateway tests with zero skips, final image trust/backport checks, Caddy binary scan, dependency API scans, backup restoration and operational probes. Final Python capture/report logs show 118 system roots, 120 certifi 2026.10.19 roots and zero incident roots; the Node parent/child logs both show 118 effective roots and required TLS verification.

A fresh coordinator verifier run is now explicitly bound in `historical-preview-binding.json` to final report image f938d4…, source 1c020995, the unchanged bundle SHA-256 `3255a42c210c6fe6ad0020c34113988da3f1659c566a73b7729606ad65d083b0`, exact command and timestamp. It ran with network disabled and reports `INTEGRITY_REPRODUCED`, `VALID_FOR_SNAPSHOT_CALCULATION`, no exchange-authenticity assertion and execution authority NONE. I checked that binding; I did not execute the verifier myself.

**Mutation probes:** none created by this release reviewer; killed/survived/inconclusive is not applicable. Recorded operational fault injection is not a claimed application mutation score.

## Bound artifact hashes

Paths below are relative to canonical `.getzilla/runtime/tls-fix/`.

| Artifact | SHA-256 |
| --- | --- |
| `rollout.py` | `21211975c0679774958b5801e21e19e6e1f888fbad6c0554088bf85119f7dc4f` |
| `release-binding.json` | `e1c966aa44fd760f5baa26d2108f063c043016c7eec76cd6b2a016b1291b7cf3` |
| `security-summary.json` | `fc12e8e1d78d3761493fcb85e599271429c835befdb1667a8f5aaa262f1d25c0` |
| `final-checks.json` | `a558d976964946918ef910c072c3970c24cd560f6961ecb44f7996a95c7ef86f` |
| `backup-restore.json` | `70e9f28d0dd93dd9328f769597ff9f60afcb6d7fd0d1924552bf664639ad7031` |
| `preservation-baseline.json` | `23f2256dac7fb7202e8623a33a9eb8b62e117d8c7ff6efa0cdd204051a9c3f5b` |
| `historical-preview-binding.json` | `b78d4deaed3d42140a8517cf61385f94f96394404c5e4059fef7706764ff2546` |

Initial negative-audit archive SHA-256: `697661c1724bd7a532e1beab90b32ec782f84ddd0db6a6cd2de32b2e42ae3bf3`. Original Wave 1 archive: `75cb10a985d99c3428273d6ed443bf6066e82c9c758ebf108add07695b8255d0`. Layout archive: `f443a236c064eab7728b3061af84c645690626fe8bbc84a221c0705c3988606c`.

## Pending and unexecuted boundaries

- The single final Getzilla PR gate must follow saved complete reviews and the report-only freeze. It has not run at this review boundary. The full tests target must include the new root-level TLS cases and the directories omitted by default discovery.
- Native generic secret matches on public token constants and historical whitespace failures remain unsuppressed. Whatever the final gate returns must be reported literally; this scoped review PASS cannot convert gate FAIL or skipped checks into success. Passing receipts require the controller's qualifying conditions.
- The other final independent reports and final full-product verification remain coordinator obligations. This review makes no external PR-check or merge-eligibility claim; no merge was requested.
- Actual six-service replacement, continuity, final effective environment, public health/readiness/CSP, preserved volume/ledger observations and postdeployment rollback availability remain unexecuted by this reviewer. Record them against the actual runtime after the authorized operation; do not label build/test evidence as deployment completion.
- Physical wallet pairing, live funding observation, borrowing and a newly signed report purchase were not performed and are not implied by TLS, browser or verifier checks.
- No live database restoration, migration, grant renewal or payment was executed. Private backup contents were not inspected; the newly restored aggregate record is evidence from the separate isolated operation.
- Continuous alerting/monitoring and simulated TLS exploitation were not exercised. Point-in-time trust-store checks and source applicability assessments have the limits described above.

The reviewed release preparation preserves the product and durable state, provides identity-bound recovery and retains honest scanner/history evidence. Final gate results and later runtime acceptance must remain distinct from this review.

