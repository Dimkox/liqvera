# Independent security review — exact TLS successor candidate

**Verdict: PASS for the exact candidate and the stated runtime configuration.** No blocking security finding remains in the reviewed change or in the 30 raw scanner occurrences examined below. SR-01 through SR-04 are addressed in the committed source and the identified replacement images. This is a security review, not a final Getzilla verification receipt, a vulnerability-free certification, or evidence of production replacement. The full qualifying gate is **NOT_RUN** at report completion and must follow all five persisted independent reports.

## Identity, scope and independence

- Route: `b54297afc340`; change package: `engineering/changes/20261021-task-b54297`; selected role: `security_reviewer`.
- Read-only candidate: `/home/pall/projects/liqvera/.getzilla/runtime/pr115-tls-liqvera`.
- HEAD before/after: `bf569ce96039deeec69e025a3c3cdc9653584b0d`.
- Tree before/after: `c4205fabda3d9d34d08058990fca33b0b059f81d`.
- Product commit: `1c020995adaa1a80fc8a97888aa838041d8e01d5`; product tree: `d2e3a6b86421d3b4f90523cf2dc36fb60a062b20`.
- Comparison base: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`. Local `origin/main` merge-base equals that base; locally published tags v0.0.1–v0.0.5 are ancestors. No fresh remote publication assertion is made.
- Status before/after: clean. Worktree inventory contained the single audit worktree; no cleanup occurred.
- Pinned external Getzilla: `2bb417431f1e4b9494e4af71ebf27adb1d04d898`; it is not a product runtime dependency.
- Private reviewer evidence: `/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/security-final-review`, mode `0700`, outside the candidate. Source fingerprints, scan cross-checks, image bindings, runtime observations and Caddy symbol results are recorded there.

reviewed-tree-modified: no

Repository instructions, startup documents, current change package, selected route, research and pinned delivery/security-review instructions were read. The delta from product commit to reviewed HEAD consists only of the 18 tracked change-package metadata/evidence files. All 14 TLS implementation/test files are byte-identical to the previously independently reviewed source snapshot, map SHA-256 `2bd7dd5ea5abc625738fcb9cabcb7a42665cad776b483b14a127acee4c5637bc`. That source report is `tls-fix/security-source-review.md`, SHA-256 `5448f4fb520d7f775462792d2e8e88412308912a6a4cb01d1b97e37053dcf5ab`. This review independently binds its conclusions to the clean committed candidate and final images; it does not treat the earlier dirty-tree PASS as a final receipt.

The full base-to-HEAD inventory includes the previously reviewed browser funding/layout work and the new TLS remediation. Gateway, capture/report application logic, protocol/schema files, SQL migrations and existing WalletConnect/payment logic have no source changes since the earlier reviewed product `57660040b36300de62cd45cb663bd2124167fe45`. Funding implementation and adjacent guards were reread. The frozen original audit clone was not changed; the original negative security report remains historical evidence.

## Original blockers and source corrections

| Finding | Final disposition and evidence |
| --- | --- |
| SR-01 — Critical certifi advisory | Both locks pin certifi 2026.10.19. Final capture/report images independently expose 120 certifi roots and 118 system roots, with none of the four incident anchors. HTTPX capture uses `trust_env=False` and default certifi verification, so updating certifi repairs the relevant capture trust path rather than only an unrelated OS bundle. |
| SR-02 — High contextual gateway trust risk | Node build/runtime selects `--use-openssl-ca`; corrected Alpine CA packages precede npm and runtime execution. The final gateway parent and inherited child independently report 118 distinct clean roots with verification enabled. The application uses default `fetch`; its entrypoint inherits `NODE_OPTIONS`. The later research correctly distinguishes Alpine's OpenSSL default from Node's compiled-root enumeration: an old embedded root alone is not proof of active trust. Approval here rests on the selected effective store and its measured contents. |
| SR-03 — High Go x509 advisory | Final Caddy reports Go 1.27.3, Caddy 2.11.7 and `CGO_ENABLED=0`; its OS CA bundle matches the corrected bundle. The source uses the reviewed pinned Go image and retains the module pins/offline final build. The affected Go 1.27.2 x509 finding is absent from the final scans. Root exclusion and Go's intermediate-public-key distrust are separate defenses. |
| SR-04 — High conditional build/development trust risk | pip 26.2.2 is pinned and bootstrapped using the SHA-256-bound official wheel before index-based operations. CI sets the corrected vendored CA file plus an empty CA directory, persists both variables, and runs setup-node afterward. This covers pip's additive system trust and subsequent Node/npm trust. Runtime pip and ensurepip remain absent. |

Relevant locations: `requirements.lock:3`, `requirements-dev.lock:6` and `:28`, `pyproject.toml:14`, `.github/workflows/verify.yml:37`–78, all six `deploy/mezo-evidence/Dockerfile.*` recipes, `deploy/security/check-tls-trust.py:20`–80, `deploy/security/check-node-tls-trust.cjs:16`–32, and `gateway-entrypoint.js:24`–27.

Both Alpine CA packages are pinned to `20261020-r0` in every shared BusyBox source stage and the relevant builder/runtime stages. The first APK transaction retains signature verification; it is the package bootstrap itself. The pip bootstrap is a local/index-free operation with a checksum-bound input, not a claim that its RUN step enforces `--network=none`. CI's hosted runner, pinned checkout and checksum-verified initial wheel remain the explicit bootstrap boundary.

During the preceding source review, the owner resolved three concrete gaps: pip's additional system trust, setup-node executing before the corrected policy, and Python's lazy hashed-directory roots missing from `get_ca_certs()`. The public poisoned-store probe initially survived and then failed after the correction. Its directory/file/directory-list regression fixture contains no private key. Four native tests passed against the exact 14-file snapshot now bound to this candidate. Node's unsupported directory-list override fails closed. These observations are preserved in `security-source-probe/`; no mutant was applied to this committed candidate.

## Final image and scanner binding

The final builds identify product source `1c020995adaa1a80fc8a97888aa838041d8e01d5`. This reviewer checked each image's source revision label, read-only image metadata and actual rootfs layers. Grype's `imageID` is an OCI configuration digest, whereas the supplied final image references are repository/index digests. Its user input and repository digest match the final image; independently recomputed manifest/config SHA-256 values and rootfs layer identities also match. This resolves the apparent digest differences without silently treating different artifacts as identical.

| Image | Exact final reference | Trivy / Grype raw occurrences |
| --- | --- | ---: |
| Capture | `sha256:3edb015ec3aea7235b621303d1a1821eaa7c52b44f8ceb03b50fe51c4c97d5c1` | 0 / 5 |
| Report | `sha256:f938d4f3483af7453944ad98de648f9b7a1f6ac4ad3399434069194245d58901` | 0 / 5 |
| Gateway / network carrier | `sha256:a341fae9c0c8a1feade5b11493b58dbeb1a4f22cad5e5b79ef4602dd5b7db901` | 0 / 4 |
| Edge | `sha256:aa8f036c87fd1f83aec1618205864fac968ac645882c493c74bcb07d5f7a601c` | 1 / 3 |
| Web | `sha256:6b26f78a2856e7f2f5a07884249d2b45351a08b3160732ef50a5d04967e07a06` | 0 / 9 |
| PostgreSQL, source/test build only | `sha256:98e5cab850b96ff1acfaca92834c8590274e62ba9f64b6d882d27ec7f6e090d8` | 0 / 3 |

Every raw occurrence in `final-*-trivy.json` and `final-*-grype.json` exactly matches `security-summary.json`; none was discarded in the cross-check. Grype is 0.120.1 with database build `2026-10-21T06:31:02Z`. The final scanner invocation summaries report success for all twelve scans. Scanner process exit zero is not itself interpreted as zero findings.

The final gateway, edge, web and PostgreSQL rootfs layers are independently confirmed equal to the tested v2 candidates. Their startup command, entrypoint, working directory and user also match. Python rootfs layers differ because capture/report were rebuilt; their final TLS, CPython and BusyBox checks were therefore rerun by the owner and inspected here. The reviewer independently reran final capture/report/gateway trust checks and confirmed final BusyBox/CA hashes for all six images.

## Remaining raw findings: dispositions checked

| Finding and raw severity | Occurrences | Disposition, supporting evidence and limit |
| --- | ---: | --- |
| CVE-2025-60876, Medium | 18 | Fixed by the retained BusyBox URL guard backport. All six final images independently hash to `4261945c0287000d3e73548d381a5afa4279eb07ed6e223ee6c5c51ba39f1642`; raw version matches concern busybox, busybox-binsh and ssl_client. Both rebuilt Python images' final logs pass all eight targeted cases, covering the common binary. Source recipe, patch identity, applet preservation and corresponding-source packaging are unchanged. This is not the full BusyBox upstream test suite. |
| CVE-2025-15367 and CVE-2026-12345, Medium | 4 | Fixed through the existing exact CPython POP3 and tempfile/shutil backports. `apply-python.sh` verifies patch hashes, rejects fuzzy application and records installed module hashes. The final capture/report logs each pass both regressions after rebuild. Python's package version remains 3.14.8; no fabricated upstream-fixed version is claimed. |
| CVE-2024-9410, Medium | 1 | Unrelated-product match. The [original advisory](https://www.tenable.com/security/research/tra-2024-41) concerns Ada.cx's Sentry service configuration; the gateway package is the ada-url C++ URL parser. This is not an exception for an applicable gateway SSRF. |
| GO-2026-5932, Unknown | 1 | Containing-module match with affected OpenPGP code absent. The [Go advisory](https://pkg.go.dev/vuln/GO-2026-5932) names OpenPGP packages, not all x/crypto consumers. The final unstripped Caddy binary has 81,636 symbols and zero `golang.org/x/crypto/openpgp` symbols. Its SHA-256 is `39d60f931f510daec5b626beee3f7b610a5e8aa005e7e57caef0eb947c6c4987`. The retained candidate govulncheck log reports zero affected symbols/imported packages and one containing-module match; it is supporting earlier evidence, not a newly executed scanner run by this reviewer. |
| CVE-2026-93479, CVE-2026-15176, CVE-2026-97205, Critical | 3 | Configuration-bound non-applicability: the final effective nginx config has no affected map/regex evaluation, alias/rewrite/request-filename construction or SSI/AIO combination. Constant root and ordinary log paths remain. These are version-affected nginx packages, not package-level fixes. |
| CVE-2026-95101, Medium | 1 | No nginx HTTP/3 listener or proxy path exists in the effective configuration. |
| CVE-2026-97629, High | 1 | No nginx TLS listener, client-certificate verification or TLS session-ticket configuration exists; Caddy terminates TLS. Do not summarize this as literally zero TLS-related scanner rows. |
| CVE-2026-92392, High | 1 | Curl remains version-affected, but the [affected HTTP/2 upload path](https://curl.se/docs/CVE-2026-92392.html) is unused by this static service. Exact-image `ldd /usr/sbin/nginx` has no libcurl; the inspected entrypoint scripts do not invoke curl, and the configured health check uses BusyBox wget for loopback HTTP. |

The [official nginx advisory index](https://nginx.org/en/security_advisories.html) confirms the affected release ranges and corrected releases. Exact final-image `nginx -T` passed with disposable `/tmp` and showed only plain HTTP port 8083, constant static paths and no relevant optional features. The nginx binary, default config and entrypoint hashes match the retained comparison: `f0c8cc1c8a0580c05db93f8fb465ae95cf075a80e5627e6e3e0c6bafc5339bf6`, `f6c25f5af861eea856610b1cdc29ae0c364be90b82261a7855da58152aa722c7`, and `3372fd90162da30d09f62c245e9c6bfd620fb0bb5b48ab54b16e804c2b9e8aae` respectively. Reassess these dispositions if configuration, linkage, entrypoints or network placement changes. Their acceptance does not represent nginx/curl as patched.

There are zero matches for the remediated certifi/CA-incident and Go x509 findings. This narrower statement is supported; a blanket statement of zero TLS findings would obscure the retained, non-applicable nginx session-ticket row.

## Dependency and application boundaries

The fresh supplemental audit inputs match the committed locks: runtime SHA-256 `b7095c1e6550126e39ccddc231f884dd202b148780befcc324eba9e720b1f6f0`, development `fb15760ce2de61de28da89e0b88c97f4890f5c2fc1638074d9dc91897cb5c20d`. OSV inspected 65 exact records / 52 unique versions with zero findings or accepted exceptions; the direct PyPI endpoint cross-check found zero active advisories for all 52. Both old-certifi positive controls still detect the incident. The reviewer checked result/input hashes, counts, controls and current applicability rather than rerunning those network queries. The `.lock` filename omission in the normal Getzilla scanner remains documented; its result alone cannot establish this coverage. Neither pip package matching nor agreement between OSV and PyPI establishes recursive vendored-code coverage.

The original browser security conclusions remain applicable to unchanged application bytes and were rechecked statically:

- Funding RPC calls remain read-only; payer, chain/token pairing, uint256 amounts, READY quote, expiry and clear payment guard are checked in `mezo-finance.mjs:39`–66 and `:114`–155. A funding observation grants no payment authority.
- Provider/context/sequence checks discard stale results. Thirty-second freshness, quote eligibility, acknowledgment and shortfall govern the external borrowing link and JSON download; click handlers recheck them in `mezo-finance-panel.ts:86`–151. Dynamic text uses `textContent`; navigation targets are fixed HTTPS constants with `noopener noreferrer`.
- Unknown and manual-review payment states stay confirm-only. The existing orchestrator persists submission state before the paid request; gateway durable submitting/nonce/finality/entitlement guards and migrations are unchanged.
- AppKit remains connection-only; session events do not initiate payment. Same-origin executable script policy and the existing WalletConnect endpoint allowlist are unchanged.
- Server resource bearer scoping, bounded inputs/origin checks, service-token boundary, sealed artifacts and report verification remain unchanged. No new secret-bearing frontend path was introduced.

The owner-provided final supplement logs show 104 web tests, both network builds and both npm audits passing. The v2 gateway/PostgreSQL pair passed 71 tests with zero skips, including the isolated database cases; actual final rootfs and startup equivalence bind that observation to the final gateway/database images. These are bounded local tests, not live wallet, loan or settlement acceptance. The new report image's `historical-preview-verification.json` reports `INTEGRITY_REPRODUCED`, report hash `0ebf36b89bda183b99767cd7fedc3c956405ef4a3f195d9d73b911d2c146ccf2`, `VALID_FOR_SNAPSHOT_CALCULATION`, no exchange authenticity assertion and no execution authority. Historical asset bytes have no intervening source changes. That reproduction was inspected, not independently rerun here.

## Executed observations and retained evidence

The new independent observations are recorded in `security-final-review/source-before.json`, `raw-scan-crosscheck.json`, `image-bindings.json`, `startup-bindings.json`, `runtime-checks.json`, `caddy-symbols.json` and `source-after.json`. The report itself is outside the candidate. No application-generated artifact was written into the reviewed tree.

Representative exact command forms, with the image identifiers in the table and full argument arrays in `runtime-checks.json`:

```text
git status --porcelain=v1 --untracked-files=all
git rev-parse HEAD HEAD^{tree}
git diff --name-only 57660040b36300de62cd45cb663bd2124167fe45..HEAD -- apps packages services schemas migrations
docker run --rm --network none --read-only --cap-drop ALL --entrypoint sh IMAGE -c 'sha256sum /bin/busybox /etc/ssl/cert.pem'
docker run --rm --network none --read-only --cap-drop ALL -v CHECKER:/check.py:ro --entrypoint python PYTHON_IMAGE /check.py --certifi --without-pip
docker run --rm --network none --read-only --cap-drop ALL -v CHECKER:/check.cjs:ro --entrypoint node GATEWAY_IMAGE /check.cjs
docker run --rm --network none --read-only --cap-drop ALL --entrypoint caddy EDGE_IMAGE build-info
```

All those runtime observations exited zero. The common final OS CA bundle hash is `5961c0a3c65459931c023e0075c09733f09aea4ca439cb85bc4a08bb4f3f568b`; independently extracted hashes match the retained edge/web/PostgreSQL public bundle files. Python checks report 118 system and 120 certifi roots, gateway parent/child 118 distinct roots, and zero incident anchors. Nginx parsing/linkage inspection used the exact final web image, `--network none --read-only --cap-drop ALL --tmpfs /tmp:rw,nosuid,nodev` and a shell running `nginx -T`, hashes, `ldd` and entrypoint-file reads. Caddy was copied from a disposable network-disabled image process using `/usr/bin/caddy` as public binary data; native `nm` succeeded. No live container was inspected or modified.

## Limits and delivery conditions

- Final Getzilla PR qualification and all review receipts remain separate pending work. This report authorizes neither the gate's result nor deployment; it supplies the independent security review for the exact identities above.
- No production replacement, SQL mutation, backup restore, wallet action, quote, payment, grant renewal, exchange mutation or publication occurred in this review. The existing live PostgreSQL container is intentionally retained on internal-only networks. Its newly built image is source/test evidence and must not be reported as deployed.
- The six application/carrier container replacements, recovery script and its fault/Docker-pair tests are separate operations/release evidence. Existing databases, unknown payment states, sealed bundles and rollback material must remain intact. Retained old images remain unremediated recovery material.
- No functional default-fetch TLS handshake or hostile-chain exploit was executed. Store selection, root exclusion, compiled Go version, application default-fetch usage and parent/child inheritance were verified; trust presence/relevance is distinct from exploitability.
- No fresh exhaustive auth/SSRF/CSRF/tenant/DoS probes, physical WalletConnect pairing or live settlement acceptance were attempted. The application-boundary statements above are static review plus explicitly identified local test evidence.
- Version-affected but unused nginx/curl paths remain residual inventory risk, contingent on the reviewed configuration. Other upstream Node/toolchain changes, unknown vulnerabilities and components beyond the stated scanner inventory are not certified absent.
- No private `.env`, credential, wallet-key, password, grant, production-dump or live-container-environment contents were read. Disposable audit containers had no production mounts or credentials. The candidate stayed read-only and clean.
