# Independent test review — TLS successor b54297afc340

**PASS with one non-blocking test-coverage finding.** Fresh bounded TLS, CI, mutation and actual-browser probes on the exact successor found no current implementation failure. The pip additive-trust mutant survives the four committed regression cases and is reported below. This review does not certify the complete product, images, live deployment or payment acceptance. The final qualifying Getzilla gate has not run as of this report.

## Reviewed identity and isolation

- Candidate: `/home/pall/projects/liqvera/.getzilla/runtime/pr115-tls-liqvera`.
- Before/after HEAD: `bf569ce96039deeec69e025a3c3cdc9653584b0d`.
- Before/after tree: `c4205fabda3d9d34d08058990fca33b0b059f81d`.
- Before/after `git status --porcelain=v1 --untracked-files=all`: empty.
- Product: `1c020995adaa1a80fc8a97888aa838041d8e01d5`; product tree `d2e3a6b86421d3b4f90523cf2dc36fb60a062b20`.
- PR base and observed merge-base with `origin/main`: `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`.
- TLS predecessor: `d56a0e917c36cf22fc68026054c1d1dd8e239462`.
- Published tags `v0.0.1`–`v0.0.5` are ancestors. The worktree inventory lists only this audit clone; no cleanup was performed.
- Private scratch: `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-tls-test`, outside the reviewed candidate, mode **0700**, under canonical runtime mode **0700**, non-sticky. All test processes were restricted to CPUs 0 and 1.
- **reviewed-tree-modified: no**

Read AGENTS, README, architecture, specification/current handoff context, Git history/ancestry, the actual TLS diff, new CI and guard/test code, successor change package, all four analysis reports and bounded evidence. The new route has no implementation owner; this reviewer made no application or candidate edits.

Created the snapshot using:

```sh
git archive --format=tar --output=/home/pall/projects/liqvera/.getzilla/runtime/reviewer-tls-test/source.tar bf569ce96039deeec69e025a3c3cdc9653584b0d
git ls-tree -rz bf569ce96039deeec69e025a3c3cdc9653584b0d
```

Verified **483/483** snapshot entries against Git blob IDs and executable/symlink modes. There were no relevant staged, unstaged or untracked source changes to overlay. After every mutation was restored, separately rehashed the candidate and scratch tracked files: **483/483 match in both**, with the same HEAD/tree and clean candidate status. Git blob verification uses SHA-1 over `blob <byte-length>\0<bytes>`, not timestamps or filenames alone.

- Canonical source-manifest SHA-256: `cc1f0a63bd1136f4b70781fffd9f493f846560d737fe364636c8b251c94e4bf5`.
- Source archive SHA-256: `45d0b8c9793ad4651d6f0d8cf6b900986f38088030e120406edc29804dd78207`.
- Identity evidence: scratch `before.json`, `after.json`, `source-manifest.json`.

The prepared virtual environment was used as a read-only dependency/interpreter source, with `-B`, disabled pytest plugin autoload, private temporary directories and cacheprovider disabled. Pip configuration was explicitly `/dev/null`; no inherited credentials, trusted-host settings or CA overrides were loaded. Node dependencies were copied into scratch and the local protocol compiled there. No build/test output was generated in the candidate. The only injected certificate is the checked-in public CA fixture; no private key, grant or secret was read or created.

## Finding: add a regression for the optional pip/explicit-CA path

`tests/test_tls_trust_guard.py` invokes the guard without `--pip` or `--cafile`. Replacing `results.append(inspect_store("pip additional system trust"))` with `pass` at `deploy/security/check-tls-trust.py:77` therefore leaves all four tests passing.

A fresh reviewer poison probe demonstrates the missing assertion's purpose: with a clean explicit CA bundle and clean pip vendored bundle, but the public incident root in an inherited hashed CA directory, the actual candidate's `--cafile <clean.pem> --pip` invocation exits 1 with `pip additional system trust: compromised emSign trust remains`. The mutant exits 0 and falsely reports success. Add that clean-file/poisoned-additional-store combination to the durable regression tests.

This is **non-blocking test debt**, not a current guard defect. The candidate rejects the poison correctly, the normal CI command also checks system trust up front, and the separate CI empty-directory control below passes. The survivor is not hidden behind a mutation percentage or treated as acceptance. Earlier frontend freshness/geometry mutation findings remain historical coverage limitations; they were not rerun or counted as current mutation acceptance.

## Fresh TLS and CI execution

All complete commands, cwd, return codes and output are retained in scratch `tls-results.json`; `tls-probes.py` is the exact reproducible driver. Executed:

```sh
python3 /home/pall/projects/liqvera/.getzilla/runtime/reviewer-tls-test/tls-probes.py
```

The driver sets CPU affinity `{0,1}` and uses:

- Python: `/home/pall/projects/liqvera/.worktrees/wave1-deploy/.venv/bin/python`.
- Working directory: `/home/pall/projects/liqvera/.getzilla/runtime/reviewer-tls-test/snapshot`.
- Allowlisted environment: fixed PATH/locale, `PYTHONDONTWRITEBYTECODE=1`, `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`, `PIP_CONFIG_FILE=/dev/null`, and scratch `TMPDIR`.
- Positive trust environment: a scratch copy of certifi **2026.10.19** with 120 roots, an empty scratch CA directory, and `NODE_OPTIONS=--use-openssl-ca`.

### Positive and adversarial controls

| Exact command, relative to scratch snapshot unless stated | Observed result |
|---|---|
| `<python> -B -m pytest -q -p no:cacheprovider --basetemp <scratch>/pytest-temp tests/test_tls_trust_guard.py` | **4 passed**, 0 failed; clean, poisoned CA file, hashed CA directory and directory-list cases execute. Three asyncio configuration warnings result from deliberately disabled unrelated plugin autoload; retained in logs. |
| `<python> -B deploy/security/check-tls-trust.py --certifi --pip` | Exit 0; system, certifi 2026.10.19, pip 26.2.2 and pip additional system trust each report 120 roots, zero incident roots, required verification. |
| `node deploy/security/check-node-tls-trust.cjs` | Exit 0; both parent and spawned child report 120 effective roots and required verification. Host probe Node is 24.22.0/OpenSSL 3.5.8; this is guard behavior, not proof of the different final runtime binary. |
| `<python> -B deploy/security/check-tls-trust.py --cafile <scratch>/clean.pem --pip`, with scratch poisoned `SSL_CERT_DIR` | Exit 1 specifically at the additive pip system-trust assertion. |
| `node deploy/security/check-node-tls-trust.cjs`, adding `NODE_EXTRA_CA_CERTS=<snapshot>/deploy/security/fixtures/emsign-ecc-root-ca-g3.pem` | Exit 1: compromised root remains in effective Node trust. |
| Same Node command with `NODE_TLS_REJECT_UNAUTHORIZED=0` | Exit 1: TLS verification must remain enabled. |

These are offline trust-store/inheritance controls. They do not perform a network handshake, emulate an exploit or mutate host trust.

### Bounded mutation results

| Mutant | Exact change or configuration fault | Observed output | Classification |
|---|---|---|---|
| M1 | `if cafile is None:` → `if False:` | Repository TLS cases: exit 1, **2 failed / 2 passed**; directory and directory-list poison now escape. | **killed** |
| M2 | `directories.split(os.pathsep)` → `directories.split(os.pathsep)[:1]` | Exit 1, **1 failed / 3 passed**; later directory poison escapes. | **killed** |
| M3 | Remove `inspect_store("pip additional system trust")` | Repository TLS cases exit 0, **4 passed**. Additional poison probe changes from correct rejection (exit 1) to false success (exit 0). | **survived committed cases**; regression exposed by reviewer negative oracle; finding above. |
| M4 | Remove `export SSL_CERT_DIR=...` from the exact CI preparation snippet | Original snippet exits 0 with inherited poisoned directory safely replaced; mutant exits 1: `system: compromised emSign trust remains`. | **killed** by the actual guard before dependency installation. |
| M5 | Remove inherited product-job `NODE_OPTIONS` | Node guard exits 1: `OpenSSL trust mode must reach spawned Node processes`. | **killed** |

M1–M3 were one-at-a-time mutations of the private exact snapshot, restored in `finally`. M4 is the exact `Prepare Python` sequence from `PIP_CA=` through the trust guard, extracted from `.github/workflows/verify.yml` and run with `bash -e`; wheel bootstrap/download and package installs are intentionally outside this offline probe. `RUNNER_TEMP`, `GITHUB_ENV` and both shell scripts are scratch paths. Exact commands:

```sh
bash -e /home/pall/projects/liqvera/.getzilla/runtime/reviewer-tls-test/ci-prepare-clean.sh
bash -e /home/pall/projects/liqvera/.getzilla/runtime/reviewer-tls-test/ci-prepare-no-capath.sh
```

M5 injects the missing setting into the isolated subprocess environment; it does not edit the real workflow or image. No mutation was inconclusive. Native M3 survival remains a finding even though the independent poison probe exposes its faulty behavior.

## Fresh retained-frontend check

A direct comparison returned exit 0/no diff for `apps`, `packages`, `services`, `schemas` and `deploy/mezo-evidence/compose.yaml` between TLS predecessor and candidate. Candidate changes after product `1c020995` are limited to `engineering/changes/20261021-task-b54297/`. Nevertheless, previous browser execution was not reused as current acceptance.

Executed anew from the private snapshot:

```sh
taskset -c 0,1 apps/mezo-web/node_modules/.bin/tsc -p packages/mezo-protocol/tsconfig.json
taskset -c 0,1 node --test --test-concurrency=1 apps/mezo-web/test/mezo-finance.test.mjs apps/mezo-web/test/musd-observation.test.mjs apps/mezo-web/test/mezo-finance-panel.test.mjs
taskset -c 0,1 apps/mezo-web/node_modules/.bin/esbuild apps/mezo-web/src/main.ts --bundle --format=iife --platform=browser --target=es2022 --loader:.css=empty '--define:__LIQVERA_NETWORK__="testnet"' '--define:__LIQVERA_WALLETCONNECT_PROJECT_ID__=""' --outfile=../browser-main.js
```

Protocol compilation and bundle construction exit 0. The funding tests report **55 passed, 0 failed, 0 skipped**. This esbuild bundle is for browser probing, not a production Vite/typecheck build.

From reviewer scratch, executed:

```sh
taskset -c 0,1 timeout 45s node browser-probe.mjs control
```

**Exit 0.** Actual Chrome, new private profile, newly built candidate entrypoint, exact current CSS, loopback assets and wholly synthetic wallet/API responses. Results:

- Initial checkbox is disabled and remains unchecked after an actual DOM click. No borrowing href exists; initial guidance names the unpaid-report prerequisite.
- A synthetic READY quote alone keeps acknowledgement disabled. A fresh zero-balance observation establishes a 0.01 MUSD shortfall and enables acknowledgement; the borrowing href appears only after acknowledgement.
- Sufficient funds disable borrowing and preserve the saved flow.
- Reloading the saved flow with `paymentGuard: uncertain` keeps acknowledgement, balance read, borrowing and download blocked, even with a synthetic READY quote. Recovery is GET-only; no new quote POST, signature or paid-report request occurs.
- Widths **320, 390, 768, 1024, 1280 and 1440 px** all have **14-pixel** label/button and button/terms gaps, no horizontal overflow, and the expected Getzilla footer link.
- Zero runtime exceptions and zero outbound application network requests. Funding uses only account, chain, block and `eth_call` reads; separate synthetic wallet connection may request accounts/switch chain.

Complete current results: scratch `frontend-results.json`, `funding-tests.log`, `browser-control.json`, `browser-control.log`. The existing browser harness was reused as test code, but all source, bundle, profile and executions were fresh for this candidate.

## Existing evidence inspected and claims not executed

Inspected canonical `tls-fix` raw logs and summaries:

- `bounded-tests.log`: **8 passed**, consisting of four TLS regressions and four artifact cases. This is an implementation observation, separate from my fresh four-case TLS run.
- `web-tests.log`: **104 passed, zero skips**; `source-supplements.json` records successful Testnet/Mainnet builds, both npm audits and artifact guard. Those complete suites/builds/audits were not independently rerun here.
- `gateway-v2-tests.log`: **71 passed, zero skipped**, including the recorded 13 disposable-PostgreSQL cases. I did not connect to or recreate that database.
- `final-checks.json`: all ten listed final checks exit 0: six TLS checks plus capture/report CPython and BusyBox regressions. Gateway/edge/web/PostgreSQL final root filesystems match the tested v2 images; capture/report are rebuilt and rechecked. I inspected `final-capture-tls.log` (system 118 roots, certifi 120) and `final-gateway-tls.log` (Node 24.18.1/OpenSSL 3.5.9, 118 roots in both parent/child). These are coordinator image observations, not this reviewer's image executions or full source gate.

**Unexecuted here:** final Getzilla PR gate; full canonical Python suite; full Node matrix/audits; image builds/scans; all-image TLS/backport reruns; Go certificate verifier exploit/denylist execution; remote GitHub Actions execution; checksum wheel download/bootstrap; package resolution; live TLS handshakes; physical wallet/WalletConnect pairing; external borrowing; signed payments; live quotes; paid delivery; grants; deployment, publication and production database access. Static claims about these boundaries are **unexecuted**, not PASS. Expected test counts or older 951-test/previous-review evidence do not qualify this successor.

The full gate and explicit nested-application/lockfile/image supplements remain necessary because the external checker has documented discovery gaps. A trust probe's success does not certify every library vulnerability, current deployed state or security review. No old negative audit evidence was changed or suppressed.

## Evidence binding and delivery

Private scratch `evidence-manifest.json` binds 27 current identity, driver, command-result and log files. Its SHA-256 is `530cd6785276aa953d58b1194d3a725ac6c6aeb9d9992adeca42d5c8e73fdb46`.

This complete report is returned out-of-band at `/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/test-review.md`. The coordinator can persist it after all selected reviews finish, freeze the report-only successor and run the final qualifying gate. This reviewer changed no candidate file, application code, live service or durable state.
