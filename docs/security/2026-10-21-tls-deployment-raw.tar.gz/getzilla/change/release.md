# Delivery limits

Deliver the audit evidence and handoff on the existing Liqvera PR branch. Do not merge, publish a release, renew a grant or deploy more services as an audit side effect. Getzilla source is pinned to the merged PR115, not claimed to be a published release. Its offline Factory wheel-inventory review finding is not executed consumer functionality; retain that limitation. Any failing audit stays FAIL; open human-gate flags are not security approvals.
