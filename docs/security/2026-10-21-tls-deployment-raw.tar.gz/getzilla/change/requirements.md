# Requirements

Run full PR mode with full scope and keep-going diagnostics. Include complete Python tests, web and gateway test/build checks, a disposable PostgreSQL cluster, source and dependency scans, architecture/contract review, and code/test/security/data/release reviews. Fresh online OSV must include requirements.lock and requirements-dev.lock explicitly. Keep all old evidence. No secret reads or new live purchases.
