# Recovery

This audit changes no production resources. Remove only its named disposable Postgres container/network after testing. Preserve its evidence until archived. Existing browser rollback remains the separately reviewed command in docs/security/2026-10-21-wave1-deployment.md. Never restore a production database to undo an audit.
