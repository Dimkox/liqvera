# Tasks

1. Pin tool/product identities and startup capacity.
2. Four selected analysis agents establish scope and omissions.
3. Run bounded controls and commit audit metadata.
4. Five independent reviews; preserve complete reports.
5. Freeze report-containing clone and run full gate and missing product checks.
6. Persist an honest audit result in Liqvera, update handoff and preserve deployed state.
