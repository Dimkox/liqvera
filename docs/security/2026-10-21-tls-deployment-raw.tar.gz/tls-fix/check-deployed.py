"""Read-only checks of runtime identity, preserved configuration and public GETs."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('rollout', OUT / 'rollout.py')
ops = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ops)
before = json.loads((ops.RECOVERY / 'containers.before.json').read_text())
baseline = json.loads((ops.RECOVERY / 'baseline.json').read_text())
result = {'source_commit': ops.SOURCE, 'services': {}, 'payment_submitted': False}
for service in ops.SERVICES:
    old = before[service]
    new = ops.inspect(ops.name(service))
    assert new['State']['Health']['Status'] == 'healthy'
    if service == 'postgres':
        assert new['Id'] == old['Id'] and new['Image'] == old['Image']
    else:
        assert new['Image'] == ops.image_for(service)
        assert not ops.inspect(old['Id'])['State']['Running']
    expected_env = old['Config']['Env']
    if service in ['gateway', 'gateway-net']:
        expected_env = ops.env_update(expected_env, 'NODE_OPTIONS', '--use-openssl-ca')
    if service == 'report':
        expected_env = ops.env_update(expected_env, 'LIQVERA_ENGINE_COMMIT', ops.SOURCE)
    assert sorted(new['Config']['Env']) == sorted(expected_env), service + ': environment drift'
    for field in ['Cmd', 'Entrypoint', 'User', 'WorkingDir', 'Healthcheck']:
        assert new['Config'].get(field) == old['Config'].get(field), service + ': ' + field
    expected_host = old['HostConfig'].copy()
    if service == 'gateway':
        expected_host['NetworkMode'] = 'container:' + ops.inspect(ops.name('gateway-net'))['Id']
    assert new['HostConfig'] == expected_host, service + ': host configuration drift'
    def mounts(value):
        return sorted((m['Type'], m.get('Name'), m['Source'], m['Destination'], m['RW']) for m in value['Mounts'])
    assert mounts(old) == mounts(new), service + ': mount drift'
    result['services'][service] = {'image': new['Image'], 'healthy': True,
                                   'environment_preserved_except_declared_tls_provenance': True,
                                   'host_config_and_mounts_preserved': True,
                                   'restart_count': new['RestartCount']}

result['ledger'] = ops.ledger()
assert result['ledger'] == baseline['ledger'], 'Ledger transition needs review; do not restore or reset it'
result['ledger_and_migration_hashes_preserved'] = True
result['walletconnect_preserved'] = ops.digest(ops.WC) == baseline['walletconnect_sha256']
assert result['walletconnect_preserved']
result['corrected_ca_public_checks'] = {}
for path in ['/', '/healthz', '/readyz', '/v1/capabilities', '/demo/latest-live/report.json', '/demo/latest-live/evidence.zip']:
    body = subprocess.check_output(['curl', '--fail', '--silent', '--show-error', '--max-time', '30',
        '--cacert', str(OUT / 'final-edge-ca.pem'), 'https://liqvera.site' + path], timeout=35)
    result['corrected_ca_public_checks'][path] = {'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body)}
(OUT / 'deployed-preservation.json').write_text(json.dumps(result, indent=2) + '\n')
print('All seven healthy; exact images, configuration, mounts, ledger, WalletConnect and corrected-CA HTTPS checks PASS.')
