# TLS remediation: independent source review

Status: **COMPLETE — no unresolved blocking source finding in the final file versions listed below.** The implementation owner corrected the build-trust, host-pip trust, and checker false-negative findings raised during this review. Fresh independent probes now reject every tested poisoned trust path, and the four added repository regressions pass.

This is the requested AGENTS.md §9 review of an actively edited implementation, **not** the later frozen-candidate Getzilla review or a passing verification receipt. Image rebuilds, exact-image acceptance, vulnerability scans, full-product checks, rollout, and the final qualifying gate remain separate. No production safety or live TLS/payment acceptance is inferred from these offline tests.

## Source identity and review boundary

- Source worktree: `/home/pall/projects/liqvera/.worktrees/wave1-deploy`.
- Comparison base and current HEAD: `d56a0e917c36cf22fc68026054c1d1dd8e239462`.
- HEAD tree: `948173c6f44606283d7c5c301fff8fb9fc16b452`. The reviewed changes are uncommitted; this HEAD tree is **not** their content identity.
- Final tracked-diff SHA-256 from `git diff --binary d56a0e9`: `74e6f261c8687d0414e9bfd0a54790e8981be4ef81de0d54dd4e595fe288b116`.
- Complete reviewed file hashes, including new untracked checkers, test and public certificate: `reviewer-source/source-final.json`, beside this report. Initial observations and final source copies are retained separately under `reviewer-source/`.
- Private reviewer scratch: `/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/reviewer-source`, mode `0700`.
- Reviewer source modifications: **none**. Root remained the sole implementation owner. The source changed in response to findings during review, so an unchanged frozen-tree claim would be incorrect. Final checker probes ran against copied exact bytes; the final source manifest is the binding for this report.
- The initial frozen audit clone was not touched. No secrets, private keys, grants, production database, or production container configuration were read. The incident fixture is a public root certificate, not a private key.

Read Liqvera instructions, README, architecture, current handoff, Git status/history/worktrees, the TLS plan/research/design, the actual tracked diff, all six affected Dockerfiles, the two new checkers, CI workflow, dependency pins, added regression and public fixture. Observed `origin/main` remains `f1d3bffc46fa1459908fdff865fcfbfc831b7f7f`; the supplied base is an ancestor of HEAD, and all locally available published tags `v0.0.1`–`v0.0.5` are ancestors. No refs were refreshed and no worktrees were cleaned.

## Findings and their resolution

1. **Resolved: BusyBox source-download stages retained the old CA setup.** The first inspected diff upgraded application builder/runtime stores but left every shared `busybox-security` stage unchanged. Those stages run Git and abuild downloads; the first candidate build log explicitly reused their cached layers. The saved official APK index showed an unversioned `ca-certificates-bundle` dependency, which did not require upgrading an already installed old bundle. Final source explicitly installs `ca-certificates=20261020-r0 ca-certificates-bundle=20261020-r0` before these downloads in capture, report, gateway, web, edge and PostgreSQL. PostgreSQL's final image stage is also pinned; this source improvement does not authorize replacing the live database container.

2. **Resolved: upgrading pip alone did not constrain its additional OS trust.** Inspection of the checksum-verified pip 26.2.2 wheel showed `pip/_internal/cli/index_command.py` constructing a truststore context and loading certifi; vendored `truststore/_openssl.py` additionally loads system paths. The original CI change upgraded pip but left the host store unconstrained, while its initial green diagnostic inspected an explicit clean bundle. Final CI uses the corrected pip-vendored certifi file as `SSL_CERT_FILE`, creates an empty `SSL_CERT_DIR`, exports both before the first pip network install, and persists them through `GITHUB_ENV`. `setup-node` now follows that step, and the product job explicitly sets `NODE_OPTIONS=--use-openssl-ca`. The Python checker additionally inspects system trust for modern pip and rejects configured `trusted_hosts` or an unreviewed pip certificate override. The new Node check runs before npm operations.

3. **Resolved: the Python checker missed lazily loaded directory roots.** With a corrected CA file and a hashed directory containing the public distrusted G3 root, the preceding checker returned 0 and reported zero compromised roots. OpenSSL verification under that trust configuration accepted the root. Final Python source explicitly enumerates hashed entries in effective CA directories, including colon-separated paths, and checks their public certificate fingerprints. The same single-directory and directory-list probes now return 1 with `compromised emSign trust remains`.

4. **Resolved: Node enumeration missed colon-separated CA directories.** The preceding Node checker warned that it could not open the combined directory string, then returned 0; OpenSSL's default lookup under the same environment accepted the root. Final Node source rejects that unsupported directory-list override before enumeration. It also reports distinct fingerprints instead of counting duplicated system entries. A single poisoned directory is detected normally, and directory lists now fail closed with `Multiple CA directories require separate inspection`.

The final source retains the existing patched CPython, BusyBox and OpenSSL inputs; the runtime Python stages still install wheels offline and remove pip/ensurepip. The pip bootstrap URL is fixed and checksum-bound before its local `--no-index --no-deps` install. Both locks pin certifi 2026.10.19, and pip 26.2.2 agrees between the development lock and pyproject. Node's explicit OpenSSL mode is inherited by the gateway entrypoint's existing child-process environment. The Caddy toolchain changes to the reviewed Go 1.27.3 digest while retaining its Caddy/module versions and network-disabled final compilation. These are source observations, not substitute image or upstream-advisory acceptance.

## Fresh independent checks

All probe outputs and exact argv/environment dictionaries are retained in `reviewer-source/final-trust-probe-results.json`. Probes ran offline, on CPUs 0 and 1, with a sanitized environment, `PIP_CONFIG_FILE=/dev/null`, and no application or production service. The pip/certifi wheels were extracted into reviewer scratch. No package was installed into the source worktree. Trust-input changes occurred only in scratch, using the public G3 root from the earlier certifi wheel.

Common controlled paths:

```text
F=/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/reviewer-source/fixtures
S=/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/reviewer-source/final-scripts
PYTHONPATH=$F/site
PIP_CONFIG_FILE=/dev/null
PYTHONDONTWRITEBYTECODE=1
SSL_CERT_FILE=$F/2026.10.19.pem
SSL_CERT_DIR=$F/empty
NODE_OPTIONS=--use-openssl-ca
```

Each Python scenario executed `/usr/bin/python3 "$S/check-tls-trust.py" --certifi --pip`; each Node scenario executed `node "$S/check-node-tls-trust.cjs"`. Cwd was reviewer scratch. The exact eight results were:

| Input | Python | Node | Meaning |
| --- | --- | --- | --- |
| Corrected bundle, empty directory | Exit 0; system, certifi, pip and pip additional system stores each contain 120 roots | Exit 0; parent and child each report 120 distinct roots | Positive controls passed |
| `SSL_CERT_FILE=$F/2026.7.22.pem` | Exit 1, compromised trust assertion | Exit 1, compromised trust assertion | Poisoned-file mutant killed |
| `SSL_CERT_DIR=$F/capath`, containing `14bc7599.0` | Exit 1, compromised trust assertion | Exit 1, compromised trust assertion | Lazy-directory mutant killed |
| `SSL_CERT_DIR=$F/empty:$F/capath` | Exit 1, compromised trust assertion | Exit 1, unsupported multiple-directory assertion | Directory-list mutant killed/fail-closed |

The underlying negative control was independently established with:

```sh
SSL_CERT_FILE="$F/2026.10.19.pem" SSL_CERT_DIR="$F/empty:$F/capath" \
  openssl verify "$F/compromised-root.pem"
```

It returned 0 with `compromised-root.pem: OK`, confirming the preceding enumeration failures were real checker false-negatives. The public root's DER SHA-256 is `86a1ecba089c4a8d3bbe2734c612ba341d813e043cf9e8a862cd5c57a36bbe6b`. No private key, forged certificate, TLS server or network handshake was used. Initial red/false-pass outputs remain in `trust-probe-results.json`, `multidirectory-probe-results.json` and `multidirectory-default-openssl.json`; they are not overwritten by final results.

The added repository test and fixture were reviewed and copied into the private source subset. Exact test command, with that subset as cwd:

```sh
taskset -c 0,1 /home/pall/projects/liqvera/.worktrees/wave1-deploy/.venv/bin/python \
  -B -m pytest -p no:cacheprovider \
  --basetemp=/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/reviewer-source/pytest-tmp \
  tests/test_tls_trust_guard.py -q
```

With plugin autoload disabled and the isolated corrected certifi on `PYTHONPATH`, this returned **0: 4 passed**, covering clean/file/directory/directory-list cases. Three configuration warnings arose because disabling plugin autoload also omitted pytest-asyncio while the copied pyproject still declares its settings; there were no failed or skipped cases. Full output and exact environment context are retained in `repository-regressions.json` and this report. This is a focused standalone run, not the full native suite.

Additional fresh source checks:

- `git diff --check d56a0e9`: no output, exit 0 for the tracked diff.
- `node --check deploy/security/check-node-tls-trust.cjs`: exit 0; the final script also executed successfully in the positive control.
- Python AST parsing, both certifi pins, pyproject/development pip agreement, and all six BusyBox CA pins passed assertions.
- The downloaded pip wheel SHA-256 matched the Docker/CI pin `fd7f4dfa8190e014013b9f08f3e973f4e4c26ffd179a204895533a7254813a70`.
- `git diff --exit-code d56a0e9 -- apps services packages schemas acceptance deploy/mezo-evidence/compose.yaml deploy/mezo-evidence/compose.testnet-demo.yaml deploy/mezo-evidence/gateway-entrypoint.js deploy/security/apply-python.sh deploy/security/busybox/build.sh` returned 0. These application, protocol, schema, migration-bearing, authority, orchestration and existing patch inputs remain byte-unchanged in this comparison.

One attempted independent Docker option probe ran the first candidate gateway image `sha256:feb064a1b3498d01eef377088873c7a732bafda221fc487a112020ceca35fe20` read-only, without network or capabilities, with `node --use-bundled-ca /check.cjs`. Node exited 9 because that option conflicts with the image's inherited `--use-openssl-ca`; no bypass or failure of the default image configuration was observed. This was a disposable container without production mounts, not a new image build or deployed-service test. An initial OpenSSL `-CApath` argument containing a directory list was rejected by the CLI; the valid default-path environment probe above was used to establish the actual behavior instead.

## Evidence limits and final binding

The first five candidate-build successes and Python/BusyBox/Node green logs were inspected as coordinator evidence. They preceded later source corrections, so this report does not reuse them as evidence for the final rebuilt images. The second image-build cycle and final image identities require their own binding and checks. The independent host Node positive control used Node v24.22.0/OpenSSL 3.5.8; it tests the guard's trust-path logic and does not certify the gateway runtime's OpenSSL version.

Not executed here: a GitHub-hosted CI run; full Python/Node/PostgreSQL/artifact suites; fresh upstream vulnerability research or container scans; complete production image rebuilds; TLS handshakes/default-fetch interoperability; current live database or service inspection; rollout/recovery operations; payments or new live quotes; final frozen-candidate Getzilla review/gate. The fixed-path CI behavior is reviewed source plus equivalent isolated trust probes, not a completed remote workflow.

Final checker SHA-256 values:

- `deploy/security/check-tls-trust.py`: `73fd87eaa288f99976cf05f4e8c1b0272be7f3930b7f0d2516ff179b61b87e6c`.
- `deploy/security/check-node-tls-trust.cjs`: `b293decdb5de940a41f10b0efeea10659670afbd49f8e4af20bbcdca50dc36b1`.
- `.github/workflows/verify.yml`: `9c408bbe1fcf3d61cb0f51a6b30a69ba41e238f68db28f1f1d6e3371a69cb8ee`.

The complete 14-file manifest is `reviewer-source/source-final.json`. Any subsequent executable-source change requires inspection again. Final handoff/evidence preparation and the later committed candidate review remain the coordinator's next steps.
