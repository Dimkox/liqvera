Fresh supplemental Python dependency audit, 2026-10-21.

Both updated lockfiles passed an online OSV query and a direct cross-check of the release-specific PyPI advisory endpoint used by pip-audit. The run examined 65 dependency records: 13 runtime entries and 52 development entries, representing 52 unique PyPI package/version pairs. OSV returned zero findings and zero accepted exceptions; PyPI returned zero active advisories for all 52 versions. Every request completed with HTTP 200. The run started at `2026-10-21T11:59:38.987273+00:00` and finished at `2026-10-21T12:00:36.743798+00:00`.

The source was the working files under `/home/pall/projects/liqvera/.worktrees/wave1-deploy`, with HEAD `d56a0e917c36cf22fc68026054c1d1dd8e239462` and HEAD tree `948173c6f44606283d7c5c301fff8fb9fc16b452`. The TLS changes were uncommitted during this observation, so the file hashes below identify the audited inputs; this is not a claim about that committed tree or the complete changing worktree. Both source lockfiles retained these hashes through the end of the scan.

| Source file | Byte-identical scan copy | Pins | SHA-256 |
| --- | --- | --- | --- |
| `requirements.lock` | `lock-inputs/requirements.txt` | 13 | `b7095c1e6550126e39ccddc231f884dd202b148780befcc324eba9e720b1f6f0` |
| `requirements-dev.lock` | `lock-inputs/requirements-dev.txt` | 52 | `fb15760ce2de61de28da89e0b88c97f4890f5c2fc1638074d9dc91897cb5c20d` |

Both locks include `certifi==2026.10.19`; the development lock includes `pip==26.2.2`. The exact pinned Getzilla implementation was reused from `/home/pall/projects/liqvera/.getzilla/runtime/pr115-tool`, commit `2bb417431f1e4b9494e4af71ebf27adb1d04d898`. Its `.getzilla/getzilla/known_vulns.py` SHA-256 remains `aaa4227228fa4402cfd496f70e8c8418798a855b46163d59b238bd1bbbfa5c7b`.

The original coverage limitation remains explicit: this scanner's requirements filename regex recognizes `.txt`, not `requirements.lock` or `requirements-dev.lock`. It still returns no manifest parser for either original filename. Therefore an ordinary repository-wide Getzilla result alone does not establish coverage of these locks. This supplemental scan used byte-identical `.txt` copies in the private runtime directory; no product or scanner files were changed. Every noncomment lockfile line was an exact pin, and all 65 lines were represented in the collected inventory.

The scan explicitly passed `GETZILLA_OSV_DB=''` and `GETZILLA_OSV_ONLINE='1'` to `getzilla.known_vulns.scan`. This is necessary because a nonempty offline database setting takes precedence over online mode. The earlier default repository scan that used the inherited stale mirror is retained as diagnostic evidence, not fresh proof. The successful supplemental result's `source` is `OSV API`, and its actual POST request and response are saved. [OSV API documentation](https://google.github.io/osv.dev/api/).

The PyPI cross-check made fresh GET requests to `https://pypi.org/pypi/{canonical_name}/{version}/json`, the endpoint used by the pinned pip-audit `2.10.1` PyPI service. All 52 responses contained the `vulnerabilities` field, with no active advisories. This was a direct endpoint verification; the pip-audit CLI was not executed, and no packages were installed or resolved. OSV and PyPI share upstream advisory data, so agreement is useful transport/coverage corroboration rather than independent vulnerability research. [Pinned pip-audit service implementation](https://raw.githubusercontent.com/pypa/pip-audit/v2.10.1/pip_audit/_service/pypi.py), [PyPI JSON API documentation](https://docs.pypi.org/api/json/).

Fresh control queries strengthen the interpretation. Both services still report `GHSA-6q48-6c7w-9gw2` and `PYSEC-2026-4320` for the old `certifi==2026.7.22`; both report none for the new locked certifi version. The two advisory IDs describe the same incident. Both services report no package-level advisory for old `pip==26.2.1`, although the separate primary-source research established its old vendored certifi bundle. Thus a clean pip version query does not inspect pip's vendored dependencies. Keep the checksum-bound pip bootstrap and effective TLS trust regressions; this dependency audit does not replace them. [Old certifi endpoint](https://pypi.org/pypi/certifi/2026.7.22/json), [new certifi endpoint](https://pypi.org/pypi/certifi/2026.10.19/json), [new pip endpoint](https://pypi.org/pypi/pip/26.2.2/json).

The literal command was:

```text
python3 .getzilla/runtime/tls-fix/dependency-audit/run-audit.py
```

It ran from `/home/pall/projects/liqvera`, exited 0, used one CPU, and wrote only under the requested private directory (mode `0700`). `run-audit.py` is retained for reproducibility. `audit-metadata.json` records timestamps, source identities, mappings, explicit environment settings and output hashes. `inventory.json` records every scanned dependency. `lock-scan.json` is the unmodified Getzilla result; `pypi-endpoint-scan.json` is the release-endpoint cross-check. `osv-controls.json` and `pypi-controls.json` contain the controls. `fetches.json` indexes all 57 HTTP exchanges with request URLs, selected public headers, raw response paths and SHA-256 hashes; both OSV POST bodies are also saved. Raw payloads are under `raw/`.

The 57 retained response hashes/lengths and both POST request hashes/lengths were checked after the run. The original pre-fix `reviewer-docs-researcher/lock-scan.json` and `scan-metadata.json` retain their earlier SHA-256 values, so the failing historical evidence was preserved.

Conclusion: no known advisory matches were returned for these exact updated Python lockfiles at the recorded time. This observation is limited to known advisories for the named versions. It does not inspect installed artifacts, vendored components, operating-system packages, Node/Go dependencies, TLS behavior or production state, and it supplements the later final Getzilla gate rather than replacing it. No product edits, dependency installations, deployments or external issues were performed.
