"""Read-only online advisory verification of exact Liqvera lockfile copies."""
from __future__ import annotations

import dataclasses
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone
import urllib.error
import urllib.request

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/pall/projects/liqvera/.worktrees/wave1-deploy')
TOOL = Path('/home/pall/projects/liqvera/.getzilla/runtime/pr115-tool')
INPUTS = ROOT / 'lock-inputs'
os.umask(0o077)
os.environ['GIT_CEILING_DIRECTORIES'] = str(ROOT)
os.environ['GETZILLA_OSV_DB'] = ''
os.environ['GETZILLA_OSV_ONLINE'] = '1'
if hasattr(os, 'sched_setaffinity'):
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
sys.path.insert(0, str(TOOL / '.getzilla'))
from getzilla import known_vulns


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


started = now()
mapping = []
source_before = {'head': git(SOURCE, 'rev-parse', 'HEAD'),
                 'head_tree': git(SOURCE, 'rev-parse', 'HEAD^{tree}'),
                 'status': git(SOURCE, 'status', '--short')}
for original, copied in [('requirements.lock', 'requirements.txt'),
                         ('requirements-dev.lock', 'requirements-dev.txt')]:
    payload = (SOURCE / original).read_bytes()
    (INPUTS / copied).write_bytes(payload)
    mapping.append({'source_path': original, 'scan_path': copied, 'bytes': len(payload),
                    'sha256': digest(payload),
                    'byte_identical_at_copy': (INPUTS / copied).read_bytes() == payload})

scanner_path = Path(known_vulns.__file__)
scanner_sha = digest(scanner_path.read_bytes())
assert scanner_sha == 'aaa4227228fa4402cfd496f70e8c8418798a855b46163d59b238bd1bbbfa5c7b'
assert git(TOOL, 'rev-parse', 'HEAD') == '2bb417431f1e4b9494e4af71ebf27adb1d04d898'
assert known_vulns._manifest_parser('requirements.lock') is None
assert known_vulns._manifest_parser('requirements-dev.lock') is None
dependencies, manifests = known_vulns.collect_dependencies(INPUTS)
assert manifests == ['requirements-dev.txt', 'requirements.txt'], manifests
assert len(dependencies) == 65, len(dependencies)
pairs = sorted({(d.ecosystem, known_vulns.normalize_name(d.ecosystem, d.name), d.version)
                for d in dependencies})
assert len(pairs) == 52, len(pairs)
assert ('PyPI', 'certifi', '2026.10.19') in pairs
assert ('PyPI', 'pip', '26.2.2') in pairs
save_json(ROOT / 'inventory.json', {'dependencies': [dataclasses.asdict(d) for d in dependencies],
                                 'unique_pairs': pairs, 'manifests': manifests, 'mapping': mapping})

fetches = []


def fetch(url, body=None, *, group='osv'):
    number = len(fetches) + 1
    prefix = f'raw/{group}/{number:03d}'
    entry = {'url': url, 'method': 'POST' if body is not None else 'GET', 'started_at': now()}
    if body is not None:
        request_file = prefix + '-request.json'
        (ROOT / request_file).write_bytes(body)
        entry.update(request_file=request_file, request_sha256=digest(body), request_bytes=len(body))
    headers = {'User-Agent': 'Liqvera-read-only-dependency-verification',
               'Accept': 'application/json', 'Cache-Control': 'no-cache'}
    if body is not None:
        headers['Content-Type'] = 'application/json'
    entry['request_headers'] = headers
    request = urllib.request.Request(url, data=body, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            payload = response.read()
            entry.update(http_status=response.status, final_url=response.url,
                         response_headers={h: response.headers[h] for h in
                                           ['Date', 'Age', 'Content-Type', 'ETag', 'Last-Modified',
                                            'Cache-Control', 'X-PyPI-Last-Serial']
                                           if h in response.headers})
    except urllib.error.HTTPError as exc:
        payload = exc.read()
        entry.update(http_status=exc.code, error=str(exc))
    response_file = prefix + '-response.json'
    (ROOT / response_file).write_bytes(payload)
    entry.update(response_file=response_file, response_sha256=digest(payload),
                 response_bytes=len(payload), finished_at=now())
    fetches.append(entry)
    save_json(ROOT / 'fetches.json', fetches)
    if entry['http_status'] != 200:
        raise RuntimeError(f"HTTP {entry['http_status']} from {url}")
    return payload


scan_report = known_vulns.scan(INPUTS, environ={'GETZILLA_OSV_DB': '', 'GETZILLA_OSV_ONLINE': '1'},
                               fetch=fetch)
save_json(ROOT / 'lock-scan.json', scan_report)
print(json.dumps({'osv_status': scan_report['status'], 'source': scan_report['source'],
                  'dependencies': scan_report['dependencies'], 'findings': scan_report['findings']}), flush=True)

control_query = {'queries': [
    {'package': {'name': 'certifi', 'ecosystem': 'PyPI'}, 'version': '2026.7.22'},
    {'package': {'name': 'pip', 'ecosystem': 'PyPI'}, 'version': '26.2.1'}]}
control_answer = json.loads(fetch('https://api.osv.dev/v1/querybatch',
                                  json.dumps(control_query).encode()))
save_json(ROOT / 'osv-controls.json', {'queries': control_query['queries'],
                                    'response': control_answer,
                                    'purpose': 'Old certifi positive control; old pip vendoring limitation diagnostic.'})

pypi_results = []
for index, (ecosystem, name, version) in enumerate(pairs, 1):
    assert ecosystem == 'PyPI'
    url = f'https://pypi.org/pypi/{name}/{version}/json'
    data = json.loads(fetch(url, group='pypi'))
    active = [v for v in (data.get('vulnerabilities') or []) if v.get('withdrawn') is None]
    pypi_results.append({'name': name, 'version': version, 'url': url,
                         'vulnerabilities_field_present': 'vulnerabilities' in data,
                         'active_vulnerabilities': active,
                         'withdrawn_vulnerabilities': [v for v in (data.get('vulnerabilities') or [])
                                                       if v.get('withdrawn') is not None],
                         'raw_response_file': fetches[-1]['response_file'],
                         'raw_response_sha256': fetches[-1]['response_sha256']})
    if index % 10 == 0 or index == len(pairs):
        print(json.dumps({'pypi_checked': index, 'total': len(pairs)}), flush=True)

pypi_controls = []
for name, version in [('certifi', '2026.7.22'), ('pip', '26.2.1')]:
    url = f'https://pypi.org/pypi/{name}/{version}/json'
    data = json.loads(fetch(url, group='pypi'))
    pypi_controls.append({'name': name, 'version': version, 'url': url,
                          'active_vulnerabilities': [v for v in (data.get('vulnerabilities') or [])
                                                    if v.get('withdrawn') is None],
                          'raw_response_file': fetches[-1]['response_file'],
                          'raw_response_sha256': fetches[-1]['response_sha256']})
save_json(ROOT / 'pypi-controls.json', pypi_controls)
service_url = 'https://raw.githubusercontent.com/pypa/pip-audit/v2.10.1/pip_audit/_service/pypi.py'
service_source = fetch(service_url, group='sources')
(ROOT / 'raw/sources/pip-audit-v2.10.1-pypi.py').write_bytes(service_source)
pypi_report = {'endpoint_pattern': 'https://pypi.org/pypi/{canonical_name}/{version}/json',
               'pip_audit_reference': service_url,
               'method': 'Direct fresh requests to the same release-specific API used by pip-audit; pip-audit CLI not executed.',
               'packages_checked': len(pypi_results),
               'active_findings': sum(len(r['active_vulnerabilities']) for r in pypi_results),
               'results': pypi_results}
pypi_report['status'] = 'pass' if pypi_report['active_findings'] == 0 else 'fail'
save_json(ROOT / 'pypi-endpoint-scan.json', pypi_report)

for entry in mapping:
    after = (SOURCE / entry['source_path']).read_bytes()
    entry['source_sha256_after'] = digest(after)
    entry['source_unchanged_through_scan'] = digest(after) == entry['sha256']
metadata = {'started_at': started, 'finished_at': now(), 'source_root': str(SOURCE),
            'source_before': source_before, 'source_head_after': git(SOURCE, 'rev-parse', 'HEAD'),
            'tool_root': str(TOOL), 'tool_head': git(TOOL, 'rev-parse', 'HEAD'),
            'scanner_path': str(scanner_path), 'scanner_source_sha256': scanner_sha,
            'scan_api': 'getzilla.known_vulns.scan', 'scratch': str(ROOT),
            'scratch_mode': oct(ROOT.stat().st_mode & 0o777),
            'explicit_environ': {'GETZILLA_OSV_DB': '', 'GETZILLA_OSV_ONLINE': '1'},
            'git_discovery_ceiling': str(ROOT),
            'mapping': mapping, 'dependency_records': len(dependencies), 'unique_package_version_pairs': len(pairs),
            'scan_status': scan_report['status'], 'pypi_endpoint_status': pypi_report['status'],
            'lock_filename_omission_still_present': True,
            'scan_result_sha256': digest((ROOT / 'lock-scan.json').read_bytes()),
            'pypi_result_sha256': digest((ROOT / 'pypi-endpoint-scan.json').read_bytes()),
            'raw_fetches_manifest_sha256': digest((ROOT / 'fetches.json').read_bytes()),
            'script_sha256': digest(Path(__file__).read_bytes()),
            'product_files_written': [],
            'limitations': ['Advisory matching for pinned PyPI versions only; no dependency installation or runtime inspection.',
                            'OSV and PyPI share upstream advisory sources and are not independent vulnerability research.',
                            'A pip package query does not recursively audit pip-vendored packages.',
                            'This supplemental scan does not replace the final Getzilla gate or TLS trust regressions.',
                            'No pip-audit CLI execution; direct endpoint cross-check only.']}
save_json(ROOT / 'audit-metadata.json', metadata)
print(json.dumps({'finished_at': metadata['finished_at'], 'osv_status': scan_report['status'],
                  'pypi_endpoint_status': pypi_report['status'], 'pypi_active_findings': pypi_report['active_findings'],
                  'source_locks_unchanged': all(m['source_unchanged_through_scan'] for m in mapping),
                  'fetch_count': len(fetches)}), flush=True)
