# Independent TLS rollout operations review

Date: 2026-10-21. Reviewer: `/root/wave1_rollout_review`, independent of the implementation owner.

No remaining operations-code blocker was found in the final reviewed script. The release is not yet eligible for deployment: the inspected release binding remains explicitly draft with 99 untriaged findings. This review is not deployment acceptance or approval of the candidate images' security dispositions.

## Reviewed identities

- Script: `/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/rollout.py`.
- Final reviewed script SHA-256: `21211975c0679774958b5801e21e19e6e1f888fbad6c0554088bf85119f7dc4f`.
- Inspected binding SHA-256: `c968aee651668f7039af734a6add704d81528bfe7408d0d31bcd01adebe5c998`.
- Binding source field: `d56a0e917c36cf22fc68026054c1d1dd8e239462`; `draft: true`; `security_untriaged_findings: 99`. This is the inspected draft metadata, not a claim that the remediation images are built from final committed source.

The review covered six replaced services: evidence capture, report, web, gateway namespace carrier, gateway, and edge. PostgreSQL is intentionally excluded from replacement. Application implementation, full dependency/security triage, final committed-image identity, and later live rollout acceptance are separate work.

## Findings resolved by the owner during review

1. **High — explicit exposed ports prevented gateway creation in a shared namespace.** The original candidate configuration copied `ExposedPorts` from the old gateway. An actual isolated Docker API request returned HTTP 400: `conflicting options: port exposing and the container type network mode`. The owner removes explicit `ExposedPorts` for the gateway at line 323 while rebinding `NetworkMode` to the new carrier. The exact updated configuration now creates and starts successfully in a disposable pair. The earlier failure and successful diagnostic transformation are retained in `ops-review/docker-pair-5add515d0f72.json`.

2. **High — retrying a rollout after rollback could make subsequent recovery reject two candidates.** Retained candidates and a second canonical candidate could have different IDs, causing candidate discovery to abort before recovery. The new pre-mutation guard at line 384 rejects a rollout identity that already has candidates. A model test verifies refusal before any mutation after a complete deployment/rollback cycle.

3. **Important — transient discovery/stopped-state reads could abort recovery before old services restarted.** `optional_inspect` now retries transient failures while preserving 404 handling, and the all-candidates-stopped check uses it. The discovery and stopped-state fault cases both restore the old runtime. Lost stop, create, rename, and start responses are reconciled against Docker state and immutable IDs.

4. **Important — a changed release binding could diverge runtime images from the prepared manifest.** The baseline now pins script and binding digests, and `guard_baseline` checks both active and recovery copies before deployment or rollback (lines 434–440). Changed-script and changed-image-binding cases fail before mutation.

5. **Important — a later PostgreSQL replacement was detected only after changing the other services.** `guard_baseline` now checks the canonical PostgreSQL ID and image before recovery (lines 441–443). The later-PostgreSQL case refuses rollback without altering any service.

6. **Important — a draft binding with its finding count set to zero was not explicitly excluded.** `prepare` and `guard_baseline` now reject draft bindings (lines 264 and 435). The zero-count draft case and nonzero-untriaged case both fail before mutation.

No product files or the rollout implementation were edited by this reviewer. All implementation fixes above were made by the owner.

## Verification performed

The isolated model executes the actual rollout functions loaded from the reviewed script. Docker API state, SQL aggregates, public responses, and runtime files are synthetic. It does not call the production Docker API, PostgreSQL, or public application. All **69 tests pass**, with zero failures/errors and zero modeled PostgreSQL mutations. The model checks:

- Successful six-service replacement and restoration, preserving the PostgreSQL ID and rebinding the gateway to its matching carrier.
- Lost replies after stop, create, rename, and start across every replaced service, including rollback operations.
- Rejected creates and permanent startup failures at every position, restoring the original runtime.
- A failed public acceptance check and a gateway forced exit, both restoring the old runtime.
- Candidate discovery and stopped-state read retries.
- Refusal to start old writers or aliases while any candidate remains active after stop retries fail.
- Reuse after retained rollback; script/binding drift; draft/untriaged bindings; and later PostgreSQL, candidate-image, manifest, or WalletConnect changes.

Evidence: `ops-review/model-results-21211975c067.json`, `ops-review/model-run-expanded.log`, and `ops-review/test_rollout_model.py`. Earlier model outputs are developmental diagnostics, not the final passing result.

A separate actual Docker API rehearsal uses only audit-owned disposable names beginning `liqvera-ops-review-tls-`, one internal network, synthetic configuration, no mounts, and no published ports. It runs the actual `candidate_config` function to create/start a gateway sharing its carrier namespace. The exact reviewed script passes; all created containers and the network were removed with no cleanup errors. Evidence: `ops-review/docker-pair-21211975c067.json` and `ops-review/docker-pair-rehearsal.py`. This is Docker create/start compatibility evidence, not a live application or database acceptance test.

## Preservation and recovery assessment

The final script stops ingress before draining the gateway, excludes PostgreSQL from stop/start orders, retains preceding containers, and recreates services from the saved runtime configuration. Only intended image references, gateway Node trust options, and the report engine source identity are changed. The report engine identity applies to subsequent report generation; the script does not rewrite historical bundles.

Recovery preflights identities and manifest/WalletConnect digests, stops and retains recognized candidates, confirms every discovered candidate is stopped before starting originals, restores the gateway's original carrier first, restores the previous manifest, and checks original IDs/health and public acceptance before claiming success. Recovery does not restore a database dump or run migrations. A permanent stop failure is reported rather than starting duplicate writers.

The inherited backup helper was inspected for clean gateway drain, per-owner artifact/capture archives, and independent writer recovery. No fresh backup, private dump restore, or production backup validation was performed by this reviewer. The final rollout must still establish its own backup and acceptance evidence through the authorized owner workflow.

## Scope limits and behaviors set aside

- Private configuration, grants, secrets, database rows, and backup contents were not inspected. The only live metadata read was a projection of gateway identity and Docker create-related fields; no environment values were accessed or emitted.
- Real six-service traffic continuity, actual report/capture work, live SQL state, and public payment readiness were not simulated as production acceptance. The model uses explicit mocks; the real rehearsal covers only isolated Docker namespace compatibility.
- Final source/image security eligibility is outside this operations review. The inspected draft binding is correctly blocked. A finalized binding requires the owner's separate exact-source build, review, security, and validation evidence before preparation.
- No new quote, payment, borrowing operation, migration, database restoration, or live container mutation was performed by this reviewer.

The conclusion is tied to the exact script hash above. Any subsequent operational-script change requires review of that change; finalized release metadata does not turn these model checks into live acceptance.

## 2026-10-21 addendum — finalized release binding verified

This addendum supersedes the earlier draft-status statements for the current binding. The original review accurately recorded the draft it inspected; the binding was finalized afterward. The operational script is unchanged at SHA-256 `21211975c0679774958b5801e21e19e6e1f888fbad6c0554088bf85119f7dc4f`, so the 69 model tests were not rerun.

The reviewer independently read the current binding, security summary, and final checks, checked Git HEAD/tree and working-tree status, and queried Docker image identity and OCI revision metadata. No live container mutation or private configuration read was performed.

- Source HEAD: `1c020995adaa1a80fc8a97888aa838041d8e01d5`; tree: `d2e3a6b86421d3b4f90523cf2dc36fb60a062b20`; working tree clean.
- Current binding SHA-256: `e1c966aa44fd760f5baa26d2108f063c043016c7eec76cd6b2a016b1291b7cf3`. It records `draft: false`, `security_untriaged_findings: 0`, and `live_postgres_retained: true`.
- Security summary SHA-256: `fc12e8e1d78d3761493fcb85e599271429c835befdb1667a8f5aaa262f1d25c0`, matching the binding's pinned digest. Its source and all six image IDs match the binding; it records zero untriaged findings with explicit dispositions. Raw findings remain: capture 5, report 5, gateway 4, edge 4, web 9, and PostgreSQL 3. This is not a zero-scanner-findings claim.
- Final checks SHA-256: `a558d976964946918ef910c072c3970c24cd560f6961ecb44f7996a95c7ef86f`. All ten recorded check return codes are zero. It explicitly reports that capture/report root filesystems differ from the earlier candidate, while the other four match; no blanket root-filesystem-equivalence claim is made.

Every bound image exists under the exact bound image ID and has `org.opencontainers.image.revision` equal to source HEAD:

| Image | Verified image ID |
| --- | --- |
| capture | `sha256:3edb015ec3aea7235b621303d1a1821eaa7c52b44f8ceb03b50fe51c4c97d5c1` |
| report | `sha256:f938d4f3483af7453944ad98de648f9b7a1f6ac4ad3399434069194245d58901` |
| gateway | `sha256:a341fae9c0c8a1feade5b11493b58dbeb1a4f22cad5e5b79ef4602dd5b7db901` |
| edge | `sha256:aa8f036c87fd1f83aec1618205864fac968ac645882c493c74bcb07d5f7a601c` |
| web | `sha256:6b26f78a2856e7f2f5a07884249d2b45351a08b3160732ef50a5d04967e07a06` |
| PostgreSQL, build verification only | `sha256:98e5cab850b96ff1acfaca92834c8590274e62ba9f64b6d882d27ec7f6e090d8` |

The two gateway services use the same bound gateway image. The verified PostgreSQL image is excluded from the six-service replacement; the existing live PostgreSQL container remains retained by design.

Machine-readable verification is saved in `ops-review/final-binding-verification.json`. No remaining operations or binding-consistency blocker was found for preparation with this finalized binding. This addendum verifies artifact and image identity consistency; it does not rerun the security research, assert that labels alone prove build provenance, or establish later backup/deployment acceptance. The authorized rollout must still satisfy the script's runtime identity, backup, health, configuration, and public acceptance checks.
