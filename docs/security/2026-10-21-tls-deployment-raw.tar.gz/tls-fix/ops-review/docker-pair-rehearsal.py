"""Disposable Docker API compatibility check: no production names, volumes or ports."""
import copy
import hashlib
import http.client
import json
import os
from pathlib import Path
import socket
import time
import types

HERE = Path(__file__).resolve().parent
SCRIPT = HERE.parent / 'rollout.py'
SOURCE = SCRIPT.read_bytes()
module = types.ModuleType('reviewed_rollout')
module.__file__ = str(SCRIPT)
exec(compile(SOURCE, str(SCRIPT), 'exec'), module.__dict__)
PREFIX = 'liqvera-ops-review-tls-' + str(os.getpid())
created = []
network_id = None
result = {'script_sha256': hashlib.sha256(SOURCE).hexdigest(), 'audit_prefix': PREFIX,
          'scope': 'Disposable network and containers; synthetic configuration; no mounts or published ports.'}


class Docker(http.client.HTTPConnection):
    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(20)
        self.sock.connect('/var/run/docker.sock')


def api(method, path, body=None):
    connection = Docker('localhost')
    connection.request(method, path, json.dumps(body) if body is not None else None,
                       {'Content-Type': 'application/json'})
    response = connection.getresponse()
    raw = response.read()
    connection.close()
    payload = json.loads(raw) if raw else None
    if response.status >= 300:
        raise RuntimeError(f'{method} {path}: HTTP {response.status}: {payload}')
    return payload


def inspect(identity):
    return api('GET', '/containers/' + identity + '/json')


def create(suffix, config):
    assert not config.get('HostConfig', {}).get('Binds')
    assert not config.get('HostConfig', {}).get('Mounts')
    assert not config.get('HostConfig', {}).get('PortBindings')
    identity = api('POST', '/containers/create?name=' + PREFIX + '-' + suffix, config)['Id']
    created.append(identity)
    return identity


try:
    network_id = api('POST', '/networks/create', {'Name': PREFIX, 'Internal': True,
                                                'Labels': {'io.liqvera.ops-review': PREFIX}})['Id']
    config = {'Image': module.image_for('gateway-net'), 'Entrypoint': ['/bin/busybox'],
              'Cmd': ['sleep', '300'], 'User': '10003:10001',
              'Env': ['NODE_OPTIONS=--use-openssl-ca'],
              'Labels': {'io.liqvera.ops-review': PREFIX},
              'Healthcheck': {'Test': ['CMD', '/bin/busybox', 'true'], 'Interval': 1000000000,
                              'Timeout': 1000000000, 'Retries': 3},
              'HostConfig': {'NetworkMode': network_id, 'ReadonlyRootfs': True,
                             'CapDrop': ['ALL'], 'SecurityOpt': ['no-new-privileges:true']},
              'NetworkingConfig': {'EndpointsConfig': {network_id: {'Aliases': ['audit-carrier']}}}}
    carrier = create('carrier', config)
    api('POST', '/containers/' + carrier + '/start')
    donor = {'Config': {key: copy.deepcopy(value) for key, value in config.items()
                        if key not in ['HostConfig', 'NetworkingConfig']},
             'HostConfig': copy.deepcopy(config['HostConfig']),
             'NetworkSettings': {'Networks': {}}}
    donor['Config']['ExposedPorts'] = {'8080/tcp': {}}
    donor['Config']['Hostname'] = 'old-carrier-id'
    donor['HostConfig']['NetworkMode'] = 'container:old-carrier-id'
    child_config = module.candidate_config('gateway', donor, carrier)
    try:
        child = create('gateway', child_config)
        api('POST', '/containers/' + child + '/start')
        result['exact_candidate_config'] = 'PASS'
        result['gateway_network_mode'] = inspect(child)['HostConfig']['NetworkMode']
        assert result['gateway_network_mode'] == 'container:' + carrier
    except Exception as error:
        result['exact_candidate_config'] = 'FAIL'
        result['error'] = str(error)
        # Test a diagnostic transformation without modifying the owner script.
        revised = copy.deepcopy(child_config)
        revised.pop('ExposedPorts', None)
        child = create('gateway-without-explicit-expose', revised)
        api('POST', '/containers/' + child + '/start')
        result['without_explicit_exposed_ports'] = 'PASS'
        result['gateway_network_mode'] = inspect(child)['HostConfig']['NetworkMode']
        assert result['gateway_network_mode'] == 'container:' + carrier
finally:
    cleanup = []
    for identity in reversed(created):
        try:
            current = inspect(identity)
            assert current['Name'].startswith('/' + PREFIX + '-')
            api('DELETE', '/containers/' + identity + '?force=true')
        except Exception as error:
            cleanup.append(str(error))
    if network_id:
        try:
            api('DELETE', '/networks/' + network_id)
        except Exception as error:
            cleanup.append(str(error))
    result['cleanup_errors'] = cleanup
    output = HERE / ('docker-pair-' + result['script_sha256'][:12] + '.json')
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
