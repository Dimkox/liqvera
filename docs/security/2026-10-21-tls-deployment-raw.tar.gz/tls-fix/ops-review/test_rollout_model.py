"""Fault injection against actual rollout functions; all runtime/SQL/public IO is fake."""
import contextlib
import copy
import hashlib
import io
import json
from pathlib import Path
import re
import tempfile
import types
import unittest
from urllib.parse import parse_qs, urlsplit

HERE = Path(__file__).resolve().parent
SCRIPT = HERE.parent / 'rollout.py'
SOURCE_BYTES = SCRIPT.read_bytes()
SCRIPT_SHA = hashlib.sha256(SOURCE_BYTES).hexdigest()
RESULTS = []


class Model:
    def __init__(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='fake-runtime-', dir=HERE)
        self.base = Path(self.tmp.name)
        self.m = types.ModuleType('reviewed_rollout')
        self.m.__file__ = str(SCRIPT)
        exec(compile(SOURCE_BYTES, str(SCRIPT), 'exec'), self.m.__dict__)
        m = self.m
        m.OUT = self.base / 'out'; m.OUT.mkdir()
        m.__file__ = str(m.OUT / 'rollout.py')
        m.RECOVERY = self.base / 'recovery'; m.RECOVERY.mkdir()
        m.MANIFEST = self.base / 'compose.json'
        m.WC = self.base / 'synthetic-walletconnect.txt'
        m.WC.write_text('synthetic non-secret fixture\n')
        m.BINDING = copy.deepcopy(m.BINDING)
        m.BINDING['draft'] = False
        m.BINDING['security_untriaged_findings'] = 0
        for service, image in m.BINDING['images'].items():
            image['image'] = 'sha256:' + hashlib.sha256(('new-' + service).encode()).hexdigest()
        self.containers = {}
        self.mutations = []
        self.faults = []
        self.counter = 0
        self.extra_hook = None
        for service in m.SERVICES:
            self.containers['old-' + service] = self.make_container(service, 'old-' + service,
                                                                  m.name(service), 'old-image-' + service)
        self.containers['old-gateway']['HostConfig']['NetworkMode'] = 'container:old-gateway-net'
        m.api = self.api
        m.healthy = self.healthy
        m.public_check = self.public_check
        m.ledger = lambda: ['payment_attempts|CONFIRMED|3', 'payment_attempts|MANUAL_REVIEW|1',
                            'receipts|4', 'entitlements|4', '001.sql|synthetic-migration-hash']
        m.run = lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError('unexpected subprocess run'))
        m.subprocess = types.SimpleNamespace(check_output=self.check_output)
        before = {'services': {s + '-live': {'image': 'old-image-' + s} for s in m.SERVICES}}
        candidate = copy.deepcopy(before)
        for service in m.START_ORDER:
            candidate['services'][service + '-live']['image'] = m.image_for(service)
        m.MANIFEST.write_text(json.dumps(before))
        (m.RECOVERY / 'compose.before.json').write_bytes(m.MANIFEST.read_bytes())
        (m.RECOVERY / 'compose.candidate.json').write_text(json.dumps(candidate))
        (m.RECOVERY / 'backup-complete.json').write_text('{}')
        (m.RECOVERY / 'containers.before.json').write_text(json.dumps(
            {s: self.containers['old-' + s] for s in m.SERVICES}))
        self.baseline = {'source_commit': m.SOURCE, 'inventory': m.inventory(), 'ledger': m.ledger(),
                         'walletconnect_sha256': m.digest(m.WC), 'manifest_sha256': m.digest(m.MANIFEST),
                         'script_sha256': SCRIPT_SHA,
                         'binding_sha256': hashlib.sha256(json.dumps(m.BINDING).encode()).hexdigest()}
        (m.RECOVERY / 'baseline.json').write_text(json.dumps(self.baseline))
        for location in [m.OUT, m.RECOVERY]:
            (location / 'rollout.py').write_bytes(SOURCE_BYTES)
            (location / 'release-binding.json').write_text(json.dumps(m.BINDING))

    def close(self):
        self.tmp.cleanup()

    def make_container(self, service, identity, name, image):
        volumes = {'report': ['audit-artifacts'], 'evidence-capture': ['audit-captures'],
                   'postgres': ['audit-postgres']}.get(service, [])
        return {'Id': identity, 'Name': '/' + name, 'Image': image,
                'RestartCount': 0, 'State': {'Running': True, 'Paused': False, 'Status': 'running',
                                          'ExitCode': 0, 'Health': {'Status': 'healthy'}},
                'Mounts': [{'Type': 'volume', 'Name': v} for v in volumes],
                'Config': {'Env': ['LIQVERA_ENGINE_COMMIT=old-engine'],
                           'Cmd': ['node', '/app/gateway-entrypoint.js'],
                           'Hostname': identity, 'Domainname': '',
                           'ExposedPorts': {'8080/tcp': {}},
                           'Labels': {'audit-service': service}},
                'HostConfig': {'NetworkMode': 'audit-network', 'ReadonlyRootfs': True},
                'NetworkSettings': {'Networks': {'audit-network': {'Aliases': [service]}}}}

    def check_output(self, args, **kwargs):
        if args[:3] == ['git', 'rev-parse', 'HEAD']:
            return self.m.SOURCE + '\n'
        if args[:2] == ['git', 'status']:
            return b''
        raise AssertionError('unexpected subprocess check_output: ' + repr(args))

    def lookup(self, identity):
        for value in self.containers.values():
            if identity in [value['Id'], value['Name'].lstrip('/')]:
                return value
        raise RuntimeError('Docker GET /containers/' + identity + '/json: HTTP 404')

    def fault(self, action, identity, phase='after', count=1):
        self.faults.append([action, identity, phase, count])

    def maybe_fault(self, action, identity, phase):
        if self.extra_hook:
            self.extra_hook(action, identity, phase)
        for item in self.faults:
            if item[:3] == [action, identity, phase] and item[3]:
                item[3] -= 1
                raise ConnectionError('injected ' + phase + ' ' + action + ' reply loss')

    def api(self, method, path, body=None):
        url = urlsplit(path)
        if url.path == '/containers/create':
            name = parse_qs(url.query)['name'][0]
            service = body['Labels']['audit-service']
            key = 'new-' + service
            self.maybe_fault('create', key, 'before')
            if any(v['Name'] == '/' + name for v in self.containers.values()):
                raise RuntimeError('Docker create: HTTP 409')
            self.counter += 1
            identity = key + '-' + str(self.counter)
            value = self.make_container(service, identity, name, body['Image'])
            value['Config'] = copy.deepcopy({k: v for k, v in body.items()
                                           if k not in ['HostConfig', 'NetworkingConfig']})
            value['HostConfig'] = copy.deepcopy(body['HostConfig'])
            value['State'].update(Running=False, Status='created', Health={'Status': 'starting'})
            self.containers[identity] = value
            self.mutations.append(('create', identity))
            self.maybe_fault('create', key, 'after')
            return {'Id': identity}
        match = re.fullmatch('/containers/(.+)/(json|start|stop|rename|unpause)', url.path)
        if not match:
            raise AssertionError('Unexpected Docker request: ' + method + ' ' + path)
        identity, action = match.groups()
        self.maybe_fault(action, identity, 'before')
        value = self.lookup(identity)
        if action == 'json':
            result = copy.deepcopy(value)
        else:
            self.mutations.append((action, value['Id']))
            if action == 'stop':
                value['State'].update(Running=False, Status='exited', ExitCode=0,
                                      Health={'Status': 'unhealthy'})
            elif action == 'start':
                service = value['Config']['Labels']['audit-service']
                assert not any(v['Id'] != value['Id'] and v['State']['Running'] and
                               v['Config']['Labels']['audit-service'] == service for v in self.containers.values()), \
                       'Duplicate active service/alias/writer'
                mode = value['HostConfig']['NetworkMode']
                if mode.startswith('container:'):
                    assert self.lookup(mode.split(':', 1)[1])['State']['Running'], 'carrier not running'
                value['State'].update(Running=True, Status='running', Health={'Status': 'healthy'})
            elif action == 'rename':
                target = '/' + parse_qs(url.query)['name'][0]
                assert not any(v['Id'] != value['Id'] and v['Name'] == target for v in self.containers.values()), \
                       'Container name collision'
                value['Name'] = target
            elif action == 'unpause':
                value['State']['Paused'] = False
            result = None
        self.maybe_fault(action, identity, 'after')
        return result

    def healthy(self, identity):
        value = self.m.inspect(identity)
        assert value['State']['Running'] and value['State']['Health']['Status'] == 'healthy'

    def public_check(self, asset):
        for service in self.m.SERVICES:
            self.healthy(self.m.name(service))
        return {'asset': asset, 'synthetic_public_checks': True}

    def old_restored(self):
        current = self.m.inventory()
        assert all(current[s]['id'] == 'old-' + s and current[s]['health'] == 'healthy'
                   for s in self.m.SERVICES)
        assert self.m.digest(self.m.MANIFEST) == self.baseline['manifest_sha256']
        assert all(not v['State']['Running'] for v in self.containers.values()
                   if not v['Id'].startswith('old-'))

    def summary(self):
        return {'mutations': len(self.mutations),
                'running': [v['Id'] for v in self.containers.values() if v['State']['Running']],
                'postgres_mutations': [a for a in self.mutations if a[1] == 'old-postgres']}


class RolloutTests(unittest.TestCase):
    def setUp(self):
        self.model = Model()
        self.m = self.model.m
        self.log = io.StringIO()
        self.stdout = contextlib.redirect_stdout(self.log)
        self.stdout.__enter__()

    def tearDown(self):
        self.stdout.__exit__(None, None, None)
        RESULTS.append({'test': self.id().split('.')[-1], **self.model.summary(),
                        'stdout': self.log.getvalue()})
        self.model.close()

    def test_happy_deploy_rollback_keeps_postgres_and_namespaces(self):
        self.m.deploy()
        gateway = self.m.inspect(self.m.name('gateway'))
        carrier = self.m.inspect(self.m.name('gateway-net'))
        self.assertEqual(gateway['HostConfig']['NetworkMode'], 'container:' + carrier['Id'])
        self.assertEqual(self.m.inspect(self.m.name('postgres'))['Id'], 'old-postgres')
        self.m.rollback()
        self.model.old_restored()

    def test_rerun_after_rollback_rejected_before_mutation(self):
        self.m.deploy(); self.m.rollback()
        before = len(self.model.mutations)
        with self.assertRaises(AssertionError):
            self.m.deploy()
        self.assertEqual(len(self.model.mutations), before)
        self.model.old_restored()

    def test_recovery_discovery_transient_is_retried(self):
        self.m.deploy()
        self.model.fault('json', self.m.name('evidence-capture'), 'before')
        self.m.rollback()
        self.model.old_restored()

    def test_stopped_candidate_check_transient_is_retried(self):
        self.m.deploy()
        candidate = self.m.inspect(self.m.name('evidence-capture'))['Id']
        fired = []
        def hook(action, identity, phase):
            retained = [v for v in self.model.containers.values() if '-rolled-back-' in v['Name']]
            if action == 'json' and identity == candidate and phase == 'before' and len(retained) == 6 and not fired:
                fired.append(True)
                raise ConnectionError('lost response after every candidate was stopped and retained')
        self.model.extra_hook = hook
        self.m.rollback()
        self.model.old_restored()

    def test_later_postgres_recreation_blocks_rollback_before_mutation(self):
        self.m.deploy()
        old = self.model.containers.pop('old-postgres')
        old['Id'] = 'later-postgres'; self.model.containers['later-postgres'] = old
        before = len(self.model.mutations)
        with self.assertRaises(AssertionError):
            self.m.rollback()
        self.assertEqual(len(self.model.mutations), before, 'Rollback altered six services before detecting changed PostgreSQL')

    def test_draft_binding_blocks_deploy_before_mutation(self):
        self.m.BINDING['draft'] = True
        for location in [self.m.OUT, self.m.RECOVERY]:
            (location / 'release-binding.json').write_text(json.dumps(self.m.BINDING))
        self.model.baseline['binding_sha256'] = self.m.digest(self.m.OUT / 'release-binding.json')
        (self.m.RECOVERY / 'baseline.json').write_text(json.dumps(self.model.baseline))
        with self.assertRaises(AssertionError):
            self.m.deploy()
        self.assertEqual(self.model.mutations, [])

    def test_changed_image_binding_blocks_deploy_before_mutation(self):
        self.m.BINDING['images']['web']['image'] = 'sha256:' + '9' * 64
        (self.m.OUT / 'release-binding.json').write_text(json.dumps(self.m.BINDING))
        with self.assertRaises(AssertionError):
            self.m.deploy()
        self.assertEqual(self.model.mutations, [])

    def test_changed_script_blocks_deploy_before_mutation(self):
        with (self.m.OUT / 'rollout.py').open('ab') as stream:
            stream.write(b'\n# changed after prepare\n')
        with self.assertRaises(AssertionError):
            self.m.deploy()
        self.assertEqual(self.model.mutations, [])

    def test_untriaged_security_blocks_deploy_before_mutation(self):
        self.m.BINDING['security_untriaged_findings'] = 1
        for location in [self.m.OUT, self.m.RECOVERY]:
            (location / 'release-binding.json').write_text(json.dumps(self.m.BINDING))
        self.model.baseline['binding_sha256'] = self.m.digest(self.m.OUT / 'release-binding.json')
        (self.m.RECOVERY / 'baseline.json').write_text(json.dumps(self.model.baseline))
        with self.assertRaises(AssertionError):
            self.m.deploy()
        self.assertEqual(self.model.mutations, [])

    def test_public_acceptance_failure_restores_old(self):
        original = self.m.public_check
        calls = []
        def failing_once(asset):
            calls.append(True)
            if len(calls) == 1:
                raise AssertionError('synthetic public acceptance failure')
            return original(asset)
        self.m.public_check = failing_once
        with self.assertRaises(AssertionError):
            self.m.deploy()
        self.model.old_restored()

    def test_gateway_forced_exit_aborts_and_restores(self):
        def hook(action, identity, phase):
            if action == 'stop' and identity == 'old-gateway' and phase == 'after':
                self.model.containers[identity]['State']['ExitCode'] = 137
        self.model.extra_hook = hook
        with self.assertRaises(AssertionError):
            self.m.deploy()
        self.model.old_restored()

    def test_active_candidate_blocks_all_old_starts_on_failed_stop(self):
        self.m.deploy()
        candidate = self.m.inspect(self.m.name('gateway'))['Id']
        self.model.fault('stop', candidate, 'before', count=3)
        boundary = len(self.model.mutations)
        with self.assertRaises(AssertionError):
            self.m.rollback()
        self.assertTrue(self.model.containers[candidate]['State']['Running'])
        self.assertFalse(any(action == 'start' and identity.startswith('old-')
                             for action, identity in self.model.mutations[boundary:]))

    def test_later_candidate_image_blocks_rollback_before_mutation(self):
        self.m.deploy()
        candidate = self.model.lookup(self.m.name('web'))
        candidate['Image'] = 'later-release-image'
        boundary = len(self.model.mutations)
        with self.assertRaises(AssertionError):
            self.m.rollback()
        self.assertEqual(len(self.model.mutations), boundary)

    def test_later_manifest_blocks_rollback_before_mutation(self):
        self.m.deploy()
        self.m.MANIFEST.write_text('later manifest')
        boundary = len(self.model.mutations)
        with self.assertRaises(AssertionError):
            self.m.rollback()
        self.assertEqual(len(self.model.mutations), boundary)

    def test_later_walletconnect_config_blocks_rollback_before_mutation(self):
        self.m.deploy()
        self.m.WC.write_text('later synthetic config')
        boundary = len(self.model.mutations)
        with self.assertRaises(AssertionError):
            self.m.rollback()
        self.assertEqual(len(self.model.mutations), boundary)


def fault_case(operation, service, phase):
    def test(self):
        if operation.startswith('recover_'):
            self.m.deploy()
            action = operation.removeprefix('recover_')
            identity = 'old-' + service if action == 'start' else self.m.inspect(self.m.name(service))['Id']
            self.model.fault(action, identity, phase)
            self.m.rollback()
            self.model.old_restored()
        else:
            action = operation.removeprefix('deploy_')
            if action in ['stop', 'rename']:
                identity = 'old-' + service
                self.model.fault(action, identity, phase)
            elif action == 'create':
                self.model.fault(action, 'new-' + service, phase)
            else:
                fired = []
                def hook(actual_action, identity, actual_phase):
                    if actual_action == action and identity.startswith('new-' + service + '-') and actual_phase == phase and not fired:
                        fired.append(True)
                        raise ConnectionError('lost candidate start reply')
                self.model.extra_hook = hook
            if action == 'create' and phase == 'before':
                with self.assertRaises(ConnectionError):
                    self.m.deploy()
                self.model.old_restored()
            else:
                self.m.deploy()
                self.m.rollback()
                self.model.old_restored()
        self.assertEqual([v for v in self.model.mutations if v[1] == 'old-postgres'], [])
    return test


def startup_failure_case(service):
    def test(self):
        def hook(action, identity, phase):
            if action == 'start' and identity.startswith('new-' + service + '-') and phase == 'before':
                raise ConnectionError('permanent candidate startup failure')
        self.model.extra_hook = hook
        with self.assertRaises(ConnectionError):
            self.m.deploy()
        self.model.old_restored()
    return test


for service in ['evidence-capture', 'report', 'web', 'gateway-net', 'gateway', 'edge']:
    for operation in ['deploy_stop', 'deploy_rename', 'deploy_create', 'deploy_start',
                      'recover_stop', 'recover_rename', 'recover_start']:
        setattr(RolloutTests, 'test_' + operation + '_' + service.replace('-', '_') + '_lost_reply',
                fault_case(operation, service, 'after'))
    setattr(RolloutTests, 'test_deploy_create_' + service.replace('-', '_') + '_rejected',
            fault_case('deploy_create', service, 'before'))
    setattr(RolloutTests, 'test_failed_candidate_start_' + service.replace('-', '_') + '_rolls_back',
            startup_failure_case(service))


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(RolloutTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {'script_sha256': SCRIPT_SHA, 'tests_run': result.testsRun,
              'failures': [{'test': case.id(), 'traceback': tb} for case, tb in result.failures],
              'errors': [{'test': case.id(), 'traceback': tb} for case, tb in result.errors],
              'results': RESULTS,
              'scope': 'Actual rollout functions with fake Docker/SQL/public responses and synthetic files only.'}
    (HERE / ('model-results-' + SCRIPT_SHA[:12] + '.json')).write_text(json.dumps(report, indent=2) + '\n')
    raise SystemExit(not result.wasSuccessful())
