# TLS trust remediation implementation plan

Goal: resolve SR-01–SR-04 from the independent security review, including the actual deployed images, without changing payment authority or historical evidence.
Architecture: retain existing application interfaces and database schema; upgrade only CA/dependency/toolchain inputs. Check effective trust with offline probes, build immutable candidate images, independently review the diff, then replace selected services with retained rollback containers.
Tech stack: Alpine 3.23/3.24, CPython3.14.8 with existing backports, Node24.18.1 linked to OpenSSL3.5.9, Caddy2.11.7 built with Go1.27.3.
Spec: owner explicitly requested fixing the inherited TLS findings after the full audit; repository AGENTS and docs/specification.md remain authoritative.

- [ ] Reproduce compromised-root trust with committed offline Python and Node checks against existing images.
- [ ] Pin certifi2026.10.19, pip26.2.2, CA packages20261020-r0 and Go1.27.3 official digest. Bootstrap pip from a checksum-bound wheel before network installs. Force OpenSSL CA selection for Node build/runtime where applicable.
- [ ] Run trust checks against exact new images; preserve CPython/BusyBox backports and verify them. Run current Python/Node, PostgreSQL, artifact and Docker checks plus fresh unsuppressed vulnerability scans.
- [ ] Commit coherent source plus handoff after bounded checks. Independently review actual source diff and operational replacement/recovery script; no second application writer.
- [ ] Re-run the selected Getzilla review/freeze/final-gate cycle for changed source, preserving the preceding negative audit as history and documenting all tool scope gaps.
- [ ] Back up coherently; replace gateway and gateway-net as a namespace pair plus capture/report/edge; retain web/DB unless their changed runtime requires replacement. Preserve all secrets/configuration, TLS volumes, wallet settings and old containers. No compose up/migration, no new payment, loan or grant.
- [ ] Set only new report LIQVERA_ENGINE_COMMIT provenance to the reviewed new source. Preserve old sealed bundles and embedded commit identity. Verify health/readiness and existing evidence externally, save rollback and fresh evidence, commit docs and push PR14.

Review focus: accidental bundled Node roots despite updated OS packages; old pip bootstrap trust; gateway shared network namespace; report historical commit binding; rollback interruption or lost Docker API responses.
Ruling: source owner remains /root in the existing isolated branch; all helpers are read-only. Runtime workspace stays under canonical .getzilla/runtime rather than installing another framework. User request already authorizes this security fix; existing deploy authorization covers fixing the affected deployed product. Tests alone grant no authority. No private material is read into reports.
