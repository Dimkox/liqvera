"""TLS image rollout with retained-container recovery; no migration or data restore."""
import copy
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time

ROOT = Path('/home/pall/projects/liqvera/.worktrees/wave1-deploy')
OUT = Path('/home/pall/projects/liqvera/.getzilla/runtime/tls-fix')
BINDING = json.loads((Path(__file__).parent / 'release-binding.json').read_text())
SOURCE = BINDING['source_commit']
RUN_ID = 'tls-' + SOURCE[:7]
RECOVERY = Path('/home/pall/.local/state/liqvera/recovery/2026-10-21-' + RUN_ID)
MANIFEST = Path('/home/pall/.local/share/liqvera/deploy/compose.json')
WC = MANIFEST.parent / 'walletconnect.env'
SERVICES = ['web', 'edge', 'gateway', 'gateway-net', 'postgres', 'report', 'evidence-capture']
START_ORDER = ['evidence-capture', 'report', 'web', 'gateway-net', 'gateway', 'edge']
STOP_ORDER = ['edge', 'gateway', 'report', 'evidence-capture', 'web', 'gateway-net']
OLD_IMAGE = 'sha256:e824dfe58616166fcabbe973b140be27857d7dbb3113fa501296488610527e0f'
ASSET = 'index-Cnfn94HM.js'

class Docker(http.client.HTTPConnection):
    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(50)
        self.sock.connect('/var/run/docker.sock')

def api(method, path, body=None):
    connection = Docker('localhost')
    connection.request(method, path, json.dumps(body) if body is not None else None,
                       {'Content-Type': 'application/json'})
    response = connection.getresponse()
    data = response.read()
    connection.close()
    if response.status >= 300:
        raise RuntimeError(f'Docker {method} {path}: HTTP {response.status}')
    return json.loads(data) if data else None

def inspect(name):
    return api('GET', '/containers/' + name + '/json')

def run(args, **kwargs):
    return subprocess.run(args, check=True, timeout=kwargs.pop('timeout', 60), **kwargs)

def private_write(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()

def write_json(path, value):
    private_write(path, (json.dumps(value, indent=2) + '\n').encode())

def inventory():
    result = {}
    for service in SERVICES:
        value = inspect('liqvera-live-' + service + '-live-1')
        result[service] = {'id': value['Id'], 'image': value['Image'],
                           'health': value['State'].get('Health', {}).get('Status'),
                           'restart_count': value['RestartCount'],
                           'volumes': sorted(m['Name'] for m in value['Mounts'] if m['Type'] == 'volume')}
    return result

def ledger():
    # Only aggregate states and immutable migration digests leave PostgreSQL.
    sql = """BEGIN READ ONLY;
SELECT 'payment_attempts|' || state || '|' || count(*) FROM payment_attempts GROUP BY state ORDER BY state;
SELECT 'receipts|' || count(*) FROM receipts;
SELECT 'entitlements|' || count(*) FROM entitlements;
SELECT name || '|' || sha256 FROM gateway_migrations ORDER BY name;
COMMIT;"""
    return subprocess.check_output(['docker', 'exec', 'liqvera-live-postgres-live-1',
        'psql', '-X', '-q', '-U', 'liqvera', '-d', 'liqvera', '-At', '-v', 'ON_ERROR_STOP=1', '-c', sql],
        text=True, timeout=45).splitlines()

def healthy(name):
    deadline = time.monotonic() + 55
    while time.monotonic() < deadline:
        state = inspect(name)['State']
        if state.get('Health', {}).get('Status') == 'healthy':
            return
        if state['Status'] in ['exited', 'dead', 'restarting']:
            raise RuntimeError('Container failed startup')
        time.sleep(1)
    raise RuntimeError('Container health deadline exceeded')

def fetch(path):
    return subprocess.check_output(['curl', '--fail', '--silent', '--show-error',
        '--max-time', '25', 'https://liqvera.site' + path], timeout=30)

def public_check(asset):
    html = fetch('/')
    assert asset.encode() in html, 'Wrong public browser asset'
    cap = json.loads(fetch('/v1/capabilities'))
    assert cap['network'] == 'eip155:31611' and cap['source_mode'] == 'live-public'
    assert cap['amount_atomic'] == '10000000000000000' and cap['payment_ready']
    assert cap['asset'].lower() == '0x118917a40faf1cd7a13db0ef56c86de7973ac503'
    ready = json.loads(fetch('/readyz'))
    assert ready['ready'] and ready['payment_ready']
    fetch('/healthz')
    previews = {'report.json': '0ebf36b89bda183b99767cd7fedc3c956405ef4a3f195d9d73b911d2c146ccf2',
                'evidence.zip': '3255a42c210c6fe6ad0020c34113988da3f1659c566a73b7729606ad65d083b0'}
    for filename, expected in previews.items():
        assert hashlib.sha256(fetch('/demo/latest-live/' + filename)).hexdigest() == expected
    headers = subprocess.check_output(['curl', '--fail', '--silent', '--show-error', '--head',
        '--max-time', '25', 'https://liqvera.site/'], text=True, timeout=30)
    policy = re.search(r'Content-Security-Policy "([^"]+)"',
                       (ROOT / 'deploy/mezo-evidence/Caddyfile').read_text()).group(1)
    assert any(line.lower().startswith('content-security-policy:') and line.split(':', 1)[1].strip() == policy
               for line in headers.splitlines()), 'Changed CSP'
    return {'asset': asset, 'network': cap['network'], 'payment_ready': cap['payment_ready'],
            'preview_sha256': previews, 'csp_matches_source': True}

def backup():
    assert not (RECOVERY / 'backup-complete.json').exists()
    assert digest(MANIFEST) == json.loads((RECOVERY / 'baseline.json').read_text())['manifest_sha256']
    gateway = 'liqvera-live-gateway-live-1'
    writers = ['liqvera-live-' + service + '-live-1' for service in ['report', 'evidence-capture']]
    assert inspect(gateway)['State']['Running'] and not inspect(gateway)['State']['Paused']
    assert all(not inspect(name)['State']['Paused'] for name in writers)
    started = time.time()
    try:
        # SIGTERM drains HTTP and workers before pool.end; timeout/nonzero is not a coherent boundary.
        # The unchanged runtime entrypoint starts main.js, not the migration CLI.
        api('POST', '/containers/' + gateway + '/stop?t=30')
        gateway_state = inspect(gateway)['State']
        assert gateway_state['Status'] == 'exited' and gateway_state['ExitCode'] == 0, 'Gateway did not drain cleanly'
        for name in writers:
            api('POST', '/containers/' + name + '/pause')
        with open(RECOVERY / 'liqvera.pgdump', 'xb') as stream:
            os.chmod(stream.name, 0o600)
            run(['docker', 'exec', 'liqvera-live-postgres-live-1', 'pg_dump', '-U', 'liqvera',
                 '-d', 'liqvera', '-Fc'], stdout=stream, timeout=55)
        # Each owner can also read its private in-progress lock files without changing permissions.
        for volume, uid in [('artifacts', '10002'), ('captures', '10001')]:
            with open(RECOVERY / (volume + '.tar.gz'), 'xb') as stream:
                os.chmod(stream.name, 0o600)
                run(['docker', 'run', '--rm', '--network', 'none', '--read-only', '--cap-drop', 'ALL',
                     '--security-opt', 'no-new-privileges:true', '--user', uid + ':10001',
                     '--mount', 'type=volume,src=liqvera-live_' + volume + ',dst=/data/' + volume + ',readonly',
                     '--entrypoint', '/bin/busybox', OLD_IMAGE, 'tar', '-czf', '-', '-C', '/data',
                     volume], stdout=stream, timeout=55)
    finally:
        # Reconcile all intended writers even if a pause succeeded but its reply was lost.
        failures = []
        for name in reversed(writers):
            try:
                if inspect(name)['State']['Paused']:
                    api('POST', '/containers/' + name + '/unpause')
            except BaseException:
                try:
                    if inspect(name)['State']['Paused']:
                        api('POST', '/containers/' + name + '/unpause')
                except BaseException:
                    failures.append(name)
        try:
            if not inspect(gateway)['State']['Running']:
                api('POST', '/containers/' + gateway + '/start')
            healthy(gateway)
        except BaseException:
            # A lost start response is reconciled before declaring failed recovery.
            try:
                if not inspect(gateway)['State']['Running']:
                    api('POST', '/containers/' + gateway + '/start')
                healthy(gateway)
            except BaseException:
                failures.append(gateway)
        if failures:
            raise RuntimeError('Writers require unpause recovery: ' + ', '.join(failures))
    checksums = {n: digest(RECOVERY / n) for n in ['liqvera.pgdump', 'artifacts.tar.gz', 'captures.tar.gz']}
    for volume in ['artifacts', 'captures']:
        run(['gzip', '-t', str(RECOVERY / (volume + '.tar.gz'))])
    with open(RECOVERY / 'liqvera.pgdump', 'rb') as stream:
        run(['docker', 'exec', '-i', 'liqvera-live-postgres-live-1', 'pg_restore', '--list'],
            stdin=stream, stdout=subprocess.DEVNULL)
    write_json(RECOVERY / 'backup-complete.json', {'sha256': checksums, 'duration_seconds': time.time() - started})
    print('Coherent database and sealed-volume backups validated; writers resumed.', flush=True)

def name(service):
    return 'liqvera-live-' + service + '-live-1'

def image_for(service):
    return BINDING['images'][{'evidence-capture': 'capture', 'gateway-net': 'gateway'}.get(service, service)]['image']

def env_update(env, key, value):
    if isinstance(env, dict):
        return {**env, key: value}
    return [item for item in env if item.split('=', 1)[0] != key] + [key + '=' + value]

def optional_inspect(identity):
    for attempt in range(3):
        try:
            return inspect(identity)
        except BaseException as error:
            if isinstance(error, RuntimeError) and str(error).endswith('HTTP 404'):
                return None
            if attempt == 2:
                raise

def reconcile_stop(identity, require_drain=False):
    for attempt in range(3):
        try:
            state = inspect(identity)['State']
            if state.get('Paused'):
                api('POST', '/containers/' + identity + '/unpause')
            if state['Running']:
                api('POST', '/containers/' + identity + '/stop?t=30')
            state = inspect(identity)['State']
            assert not state['Running']
            if require_drain:
                assert state['ExitCode'] == 0, 'Gateway did not drain cleanly'
            return
        except BaseException:
            if attempt == 2:
                raise

def reconcile_rename(identity, target):
    for attempt in range(3):
        try:
            if inspect(identity)['Name'] != '/' + target:
                api('POST', '/containers/' + identity + '/rename?name=' + target)
            assert inspect(identity)['Name'] == '/' + target
            return
        except BaseException:
            if attempt == 2:
                raise

def reconcile_start(identity):
    for attempt in range(3):
        try:
            if not inspect(identity)['State']['Running']:
                api('POST', '/containers/' + identity + '/start')
            healthy(identity)
            return
        except BaseException:
            if attempt == 2:
                raise

def replace_manifest(source):
    fd, filename = tempfile.mkstemp(prefix='compose.tls-', suffix='.json', dir=MANIFEST.parent)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(source.read_bytes())
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(filename, MANIFEST)

def prepare():
    assert not BINDING.get('draft', False), 'Draft image binding cannot be prepared'
    assert BINDING['security_untriaged_findings'] == 0
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
    baseline = {'source_commit': SOURCE, 'inventory': inventory(), 'ledger': ledger(),
                'walletconnect_sha256': digest(WC), 'manifest_sha256': digest(MANIFEST),
                'script_sha256': digest(Path(__file__)),
                'binding_sha256': digest(Path(__file__).parent / 'release-binding.json')}
    assert all(v['health'] == 'healthy' for v in baseline['inventory'].values())
    baseline['public'] = public_check(ASSET)
    before = {service: inspect(name(service)) for service in SERVICES}
    gateway = before['gateway']
    env = dict(item.split('=', 1) for item in gateway['Config']['Env'])
    assert env['LIQVERA_PAYMENT_MODE'] == 'merchant'
    assert gateway['Config']['Cmd'] == ['node', '/app/gateway-entrypoint.js']
    assert gateway['HostConfig']['NetworkMode'] == 'container:' + before['gateway-net']['Id']
    for service in START_ORDER:
        env = dict(item.split('=', 1) for item in before[service]['Config']['Env'])
        assert all(not env.get(k) for k in ['LIQVERA_SUBJECT_COMMIT', 'LIQVERA_SUBJECT_TREE', 'LIQVERA_PLAN_SHA256',
                                          'SSL_CERT_FILE', 'SSL_CERT_DIR', 'NODE_EXTRA_CA_CERTS', 'NODE_TLS_REJECT_UNAUTHORIZED'])
        assert env.get('NODE_OPTIONS', '') in ['', '--use-openssl-ca']
        image = api('GET', '/images/' + image_for(service) + '/json')
        assert image['Config']['Labels']['org.opencontainers.image.revision'] == SOURCE
        assert not optional_inspect(name(service) + '-before-' + RUN_ID)
    RECOVERY.mkdir(mode=0o700, exist_ok=False)
    private_write(RECOVERY / 'compose.before.json', MANIFEST.read_bytes())
    private_write(RECOVERY / 'walletconnect.before.env', WC.read_bytes())
    write_json(RECOVERY / 'containers.before.json', before)
    write_json(RECOVERY / 'baseline.json', baseline)
    candidate = json.loads(MANIFEST.read_bytes())
    for service in START_ORDER:
        target = candidate['services'][service + '-live']
        target['image'] = image_for(service)
        if service in ['gateway', 'gateway-net']:
            target['environment'] = env_update(target.get('environment', {}), 'NODE_OPTIONS', '--use-openssl-ca')
        if service == 'report':
            target['environment'] = env_update(target.get('environment', {}), 'LIQVERA_ENGINE_COMMIT', SOURCE)
    write_json(RECOVERY / 'compose.candidate.json', candidate)
    run(['docker', 'compose', '-f', str(RECOVERY / 'compose.candidate.json'), 'config', '--quiet'])
    for filename in ['rollout.py', 'release-binding.json']:
        private_write(RECOVERY / filename, (OUT / filename).read_bytes())
    (RECOVERY / 'rollout.py').chmod(0o700)
    print('Prepared immutable TLS images and private recovery configuration; runtime unchanged.', flush=True)

def candidate_config(service, old, carrier_id=None):
    cfg = copy.deepcopy(old['Config'])
    cfg['HostConfig'] = copy.deepcopy(old['HostConfig'])
    cfg['Image'] = image_for(service)
    for key in ['Hostname', 'Domainname']:
        cfg.pop(key, None)
    cfg.setdefault('Labels', {}).update({'org.opencontainers.image.revision': SOURCE,
                                       'com.docker.compose.image': image_for(service),
                                       'io.liqvera.tls-rollout': RUN_ID})
    if service in ['gateway', 'gateway-net']:
        cfg['Env'] = env_update(cfg['Env'], 'NODE_OPTIONS', '--use-openssl-ca')
    if service == 'report':
        cfg['Env'] = env_update(cfg['Env'], 'LIQVERA_ENGINE_COMMIT', SOURCE)
    if service == 'gateway':
        assert carrier_id
        cfg.pop('ExposedPorts', None)
        cfg['HostConfig']['NetworkMode'] = 'container:' + carrier_id
    else:
        cfg['NetworkingConfig'] = {'EndpointsConfig': {network: {'Aliases': data.get('Aliases') or []}
            for network, data in old['NetworkSettings']['Networks'].items()}}
    return cfg

def candidates(baseline):
    result = {}
    for service in START_ORDER:
        old_id = baseline['inventory'][service]['id']
        # Canonical and retained candidates are both checked, including lost rename replies.
        for candidate_name in [name(service), name(service) + '-rolled-back-' + RUN_ID]:
            current = optional_inspect(candidate_name)
            if current and current['Id'] != old_id:
                assert current['Image'] == image_for(service), 'Unexpected image; no automatic rollback'
                assert current['Config']['Labels'].get('io.liqvera.tls-rollout') == RUN_ID
                assert service not in result or result[service]['Id'] == current['Id']
                result[service] = current
    return result

def recover_old(baseline):
    # Preflight every service before stopping any: never roll back a later deployment.
    guard_baseline(baseline)
    found = candidates(baseline)
    assert digest(MANIFEST) in [baseline['manifest_sha256'], digest(RECOVERY / 'compose.candidate.json')]
    assert digest(WC) == baseline['walletconnect_sha256']
    errors = []
    for service in STOP_ORDER:
        if service in found:
            try:
                reconcile_stop(found[service]['Id'])
                reconcile_rename(found[service]['Id'], name(service) + '-rolled-back-' + RUN_ID)
            except BaseException:
                errors.append('stop/retain ' + service)
    # Do not start duplicate writers or route aliases if any candidate is still running.
    assert all(not optional_inspect(value['Id'])['State']['Running'] for value in found.values()), 'Candidate still active'
    for service in START_ORDER:
        try:
            old_id = baseline['inventory'][service]['id']
            reconcile_rename(old_id, name(service))
            reconcile_start(old_id)
        except BaseException:
            errors.append('restore ' + service)
    try:
        replace_manifest(RECOVERY / 'compose.before.json')
    except BaseException:
        errors.append('restore manifest')
    after = inventory()
    assert all(after[s]['id'] == baseline['inventory'][s]['id'] and after[s]['health'] == 'healthy' for s in SERVICES), errors
    assert digest(MANIFEST) == baseline['manifest_sha256']
    public_check(ASSET)
    print('Previous runtime and manifest restored; databases and evidence were not restored or rewritten.', flush=True)

def deploy():
    baseline = json.loads((RECOVERY / 'baseline.json').read_text())
    guard_baseline(baseline)
    assert (RECOVERY / 'backup-complete.json').is_file()
    assert BINDING['security_untriaged_findings'] == 0
    assert digest(WC) == baseline['walletconnect_sha256']
    assert digest(MANIFEST) == baseline['manifest_sha256']
    assert not candidates(baseline), 'Retained candidate exists; use a new reviewed rollout identity'
    before = inventory()
    assert all(before[s]['id'] == baseline['inventory'][s]['id'] for s in SERVICES)
    old = json.loads((RECOVERY / 'containers.before.json').read_text())
    started = time.monotonic()
    new = {}
    try:
        for service in STOP_ORDER:
            reconcile_stop(old[service]['Id'], require_drain=service == 'gateway')
            reconcile_rename(old[service]['Id'], name(service) + '-before-' + RUN_ID)
        for service in START_ORDER:
            cfg = candidate_config(service, old[service], new.get('gateway-net'))
            try:
                created = api('POST', '/containers/create?name=' + name(service), cfg)
                identity = created['Id']
            except BaseException:
                value = optional_inspect(name(service))
                if not value or value['Config']['Labels'].get('io.liqvera.tls-rollout') != RUN_ID:
                    raise
                assert value['Image'] == image_for(service)
                identity = value['Id']
            new[service] = identity
            reconcile_start(identity)
        after = inventory()
        assert after['postgres'] == before['postgres'], 'PostgreSQL container changed'
        for service in START_ORDER:
            assert after[service]['image'] == image_for(service)
            assert after[service]['volumes'] == before[service]['volumes']
        assert all(v['health'] == 'healthy' for v in after.values())
        assert inspect(new['gateway'])['HostConfig']['NetworkMode'] == 'container:' + new['gateway-net']
        assert digest(WC) == baseline['walletconnect_sha256']
        public = public_check(ASSET)
        replace_manifest(RECOVERY / 'compose.candidate.json')
        result = {'source_commit': SOURCE, 'inventory': after, 'previous_inventory': before,
                  'public': public, 'ledger_before': baseline['ledger'], 'ledger_after': ledger(),
                  'rollback_containers': [name(s) + '-before-' + RUN_ID for s in START_ORDER],
                  'recovery_directory': str(RECOVERY), 'duration_seconds': time.monotonic() - started,
                  'walletconnect_preserved': True, 'postgres_replaced': False,
                  'payment_submitted': False, 'migrations_run': False}
        write_json(OUT / 'deployment.json', result)
        print(json.dumps({'source_commit': SOURCE, 'health': 'all seven healthy',
                          'duration_seconds': result['duration_seconds'], 'recovery_directory': str(RECOVERY)}), flush=True)
    except BaseException:
        recover_old(baseline)
        raise

def rollback():
    baseline = json.loads((RECOVERY / 'baseline.json').read_text())
    recover_old(baseline)

def guard_baseline(baseline):
    assert not BINDING.get('draft', False), 'Draft image binding cannot be deployed'
    assert SOURCE == baseline['source_commit']
    assert digest(Path(__file__)) == baseline['script_sha256'], 'Rollout script changed since prepare'
    assert digest(RECOVERY / 'rollout.py') == baseline['script_sha256']
    assert digest(Path(__file__).parent / 'release-binding.json') == baseline['binding_sha256'], 'Image binding changed since prepare'
    assert digest(RECOVERY / 'release-binding.json') == baseline['binding_sha256']
    pg = optional_inspect(name('postgres'))
    assert pg and pg['Id'] == baseline['inventory']['postgres']['id'], 'PostgreSQL identity changed'
    assert pg['Image'] == baseline['inventory']['postgres']['image']

if __name__ == '__main__':
    os.umask(0o077)
    {'prepare': prepare, 'backup': backup, 'deploy': deploy, 'rollback': rollback}[sys.argv[1]]()

