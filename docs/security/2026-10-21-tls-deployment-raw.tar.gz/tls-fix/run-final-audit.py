import datetime
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/pall/projects/liqvera/.getzilla/runtime/pr115-tls-liqvera')
TOOL = Path('/home/pall/projects/liqvera/.getzilla/runtime/pr115-tool')
OUT = ROOT / '.getzilla/runtime/final'
REVIEWED = 'bf569ce96039deeec69e025a3c3cdc9653584b0d'
CHANGE = 'engineering/changes/20261021-task-b54297/evidence/'
REPORTS = {CHANGE + name + '-review.md' for name in ['code', 'test', 'security', 'data', 'release']}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

assert not git('status', '--porcelain')
assert set(git('diff', '--name-only', REVIEWED, 'HEAD').splitlines()) == REPORTS
assert not git('diff', '1c020995', 'HEAD', '--', '.', ':!engineering')
OUT.mkdir(mode=0o700, exist_ok=False)
cpus = sorted(os.sched_getaffinity(0))[:4]
os.sched_setaffinity(0, cpus)
names = ['HOME', 'LANG', 'LC_ALL', 'PATH', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY',
         'NO_PROXY', 'http_proxy', 'https_proxy', 'all_proxy', 'no_proxy',
         'SSL_CERT_FILE', 'SSL_CERT_DIR', 'REQUESTS_CA_BUNDLE', 'CURL_CA_BUNDLE',
         'NODE_EXTRA_CA_CERTS', 'UV_SYSTEM_CERTS', 'PYTHONHTTPSVERIFY']
env = {name: os.environ[name] for name in names if name in os.environ}
for name in ['REQUESTS_CA_BUNDLE', 'CURL_CA_BUNDLE', 'NODE_EXTRA_CA_CERTS']:
    env.pop(name, None)
env['PATH'] = str(ROOT / '.venv/bin') + os.pathsep + env['PATH']
env.update(SSL_CERT_FILE=str(Path('/home/pall/projects/liqvera/.worktrees/wave1-deploy/.venv/lib/python3.12/site-packages/pip/_vendor/certifi/cacert.pem')), SSL_CERT_DIR='/home/pall/projects/liqvera/.getzilla/runtime/tls-fix/empty-ca', NODE_OPTIONS='--use-openssl-ca', PYTHONHTTPSVERIFY='1')
env.update(GETZILLA_NO_VENV='1', GETZILLA_OSV_DB='', GETZILLA_OSV_ONLINE='1',
           PYTEST_ADDOPTS='tests', PYTHONDONTWRITEBYTECODE='1',
           RUFF_CACHE_DIR=str(OUT / 'ruff-cache'))
cmd = [str(ROOT / '.venv/bin/python'), str(TOOL / 'scripts/getzilla_verify.py'),
       '--mode', 'pr', '--full-scope', '--keep-going', '--json']
versions = json.loads(subprocess.check_output([str(ROOT / '.venv/bin/python'), '-c',
    "import importlib.metadata,json; print(json.dumps({n:importlib.metadata.version(n) for n in ['pytest','ruff','bandit','coverage','certifi','pip']}))"], text=True))
record = {'command': cmd, 'cwd': str(ROOT), 'head': git('rev-parse', 'HEAD'),
          'tree': git('rev-parse', 'HEAD^{tree}'), 'reviewed_head': REVIEWED,
          'base': 'f1d3bffc46fa1459908fdff865fcfbfc831b7f7f',
          'tool_commit': '2bb417431f1e4b9494e4af71ebf27adb1d04d898',
          'environment_names': sorted(env), 'explicit_nonsecret_environment': {
              k: env[k] for k in ['GETZILLA_NO_VENV', 'GETZILLA_OSV_DB',
                                  'GETZILLA_OSV_ONLINE', 'PYTEST_ADDOPTS']},
          'python_scope': 'Entire tests/ target, equivalent to make verify-packages; artifact guard recorded separately.',
          'cpu_affinity': cpus, 'cpu_policy': 'Four CPUs, serialized pytest to avoid shared build-directory races; measured host capacity 26.',
          'versions': versions, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
started = time.monotonic()
with (OUT / 'getzilla-pr.json').open('w') as stdout, (OUT / 'getzilla-pr.stderr').open('w') as stderr:
    run = subprocess.run(cmd, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
record.update(returncode=run.returncode, duration_seconds=time.monotonic() - started,
              head_after=git('rev-parse', 'HEAD'), tree_after=git('rev-parse', 'HEAD^{tree}'),
              git_status_after=git('status', '--porcelain'))
(OUT / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'returncode': run.returncode, 'duration_seconds': record['duration_seconds'],
                  'head': record['head'], 'tree': record['tree']}), flush=True)
