# Independent TLS remediation source review

Date: 2026-10-21 UTC. Reviewer: independent security_reviewer. Scope: the uncommitted TLS remediation in `/home/pall/projects/liqvera/.worktrees/wave1-deploy` against `d56a0e917c36cf22fc68026054c1d1dd8e239462`.

**Verdict: PASS for the reviewed source snapshot, with no remaining blocking source findings.** The owner corrected the CI trust bootstrap and the regression-check gaps identified during review. This is not the final committed-candidate gate, deployment approval, a live acceptance result, or a claim that all dependencies are vulnerability-free. The final rebuilds and exact committed candidate still require their own evidence binding.

## Source identity and independence

- Before/after HEAD: `d56a0e917c36cf22fc68026054c1d1dd8e239462`.
- Before/after committed tree: `948173c6f44606283d7c5c301fff8fb9fc16b452`.
- Reviewed tracked diff SHA-256: `74e6f261c8687d0414e9bfd0a54790e8981be4ef81de0d54dd4e595fe288b116`.
- Final 14-file snapshot map SHA-256: `2bd7dd5ea5abc625738fcb9cabcb7a42665cad776b483b14a127acee4c5637bc`.
- The map includes the ten modified tracked files, both new trust checkers, the public CA fixture and its four-case regression test. Individual hashes and capture times are in `security-source-before.json` and `security-source-after.json`; the actual copies are in `security-source-snapshot/` and the tracked diff is in `security-source-snapshot.diff`.
- reviewed-tree-modified: **no** — the reviewer made no application, test, repository or index changes. The sole implementation owner changed the working tree during this review; those revisions were read and the final snapshot was checked against the source. Consequently the committed tree alone does not identify this uncommitted review.
- The frozen PR115 audit clone was not accessed or modified in this review. The public incident certificate used in the negative probe came from the earlier review's separate public-CA scratch evidence.

Repository instructions, startup documentation, status, history, ancestry and worktree inventory were read. The pinned Getzilla security-review instructions were followed for the independent, bounded review. No worktrees were cleaned up.

## Findings and resolution

### TLSREV-01 — High, conditional: pip's system trust survived the initial certifi-only fix — resolved

Location: `.github/workflows/verify.yml:43`–59; `deploy/security/check-tls-trust.py:64`–77.

The initial CI diff installed pip 26.2.2 and then downloaded the dependency closure without constraining the Ubuntu runner's system CA store. Pip 26.2.2's `pip/_internal/cli/index_command.py:36`–51 constructs a truststore context and loads vendored certifi; its `pip/_vendor/truststore/_openssl.py:25`–46 also loads the system lookup paths. Replacing the vendored bundle alone therefore does not remove an old system root. This is a conditional supply-chain exposure, not evidence that a particular GitHub runner was compromised. [Pip's certificate documentation](https://pip.pypa.io/en/stable/topics/https-certificates/) confirms that system roots are additive by default.

The final workflow downloads the pinned pip wheel, verifies SHA-256 `fd7f4dfa8190e014013b9f08f3e973f4e4c26ffd179a204895533a7254813a70`, installs it without an index or dependencies, sets `SSL_CERT_FILE` to its corrected vendored certifi and `SSL_CERT_DIR` to a newly created empty directory, and persists both through `GITHUB_ENV` before dependency downloads. The pre-download checker now checks the additional system trust in modern pip mode and rejects configured trusted-host bypasses and pip certificate overrides. `dev-effective-trust-green.log` records the owner's matching policy checks. The original `dev-trust-green.log`, which checked only an explicit CA bundle, is not used as proof of effective pip trust.

### TLSREV-02 — Medium, conditional: Node installation preceded the clean CI trust policy — resolved

Location: `.github/workflows/verify.yml:37`–62.

The intermediate revision established the corrected CA policy after `actions/setup-node`, leaving its possible cache-miss download outside the verified trust boundary. The owner moved setup-node after the checksum-bound Python bootstrap and CA export. Job-level `NODE_OPTIONS=--use-openssl-ca` then makes both the action runtime and subsequent Node/npm processes use the corrected OpenSSL paths. The source now checks Node trust before npm builds and tests.

The hosted runner, pinned checkout action and repository checkout remain bootstrap assumptions. This review did not execute GitHub Actions or claim to audit the hosted runner's provenance.

### TLSREV-03 — Medium: the first Python check missed lazy OpenSSL directory anchors — resolved and independently reproduced

Location: `deploy/security/check-tls-trust.py:20`–48; `tests/test_tls_trust_guard.py:20`–45.

The initial checker used only `SSLContext.get_ca_certs()`. With a corrected CA file and the public compromised G3 root in an OpenSSL hashed directory as `14bc7599.0`, it returned success and zero compromised roots. OpenSSL accepted that public root with the directory present and rejected it with an empty directory. This demonstrates the checker blind spot; it does not demonstrate interception or possession of a compromised private key.

The final checker additionally inspects every effective hashed CA directory, including colon-separated paths. Explicit `cafile` contexts remain file-only, matching their construction. The same poisoned-directory probe now fails with `AssertionError: system: compromised emSign trust remains`; clean capture/report checks still pass. Evidence: `security-source-probe/capath-regression.json` and `security-source-probe/fixed-checker-results.json`.

The owner also added a public-certificate-only fixture and native clean/file/directory/directory-list tests. All four passed when the reviewer ran them from the copied snapshot. The fixture's DER SHA-256 is `86a1ecba089c4a8d3bbe2734c612ba341d813e043cf9e8a862cd5c57a36bbe6b`; it contains no private key. The Node checker fails closed on multiple CA directories because Node's system enumeration does not split that OpenSSL directory list. Its positive and negative cases were independently checked in `security-source-probe/node-final-results.json`.

## Original SR01–04 and effective trust

| Original issue | Source assessment |
| --- | --- |
| SR01: affected certifi trust | Both locks now pin `certifi==2026.10.19`. Python image builder and runtime stages pin corrected `ca-certificates` and `ca-certificates-bundle` packages. Capture/report checks inspect both system and certifi stores and ensure pip/ensurepip are absent at runtime. |
| SR02: Node effective trust | Gateway and web build stages install corrected system roots before npm and set `NODE_OPTIONS=--use-openssl-ca`. The gateway runtime uses the same explicit mode and corrected CA packages. This selects OpenSSL trust instead of adding the system store to old embedded Node roots. |
| SR03: Go certificate verification | Caddy is rebuilt with digest-pinned Go 1.27.3, retaining `GOTOOLCHAIN=local`, `CGO_ENABLED=0`, Caddy/module pins and the offline final Go build. Builder and final system CA packages are updated too. The retained edge candidate independently reports `go1.27.3`, Caddy `v2.11.7`, `CGO_ENABLED=0`, linux/amd64 in `security-source-probe/edge-build-info.log`. |
| SR04: affected pip vendored trust | The development pins are `pip==26.2.2`. Capture/report wheel stages bootstrap the checksum-bound wheel without network index resolution before building dependencies. CI separately constrains additive system trust before downloading its closure. |

All six Dockerfiles now pin both corrected CA packages to `20261020-r0` in their shared BusyBox build stage before Git/abuild downloads. Runtime stages, including the source-only PostgreSQL hardening, receive the corrected packages. The PostgreSQL executable/version and data handling are not changed by this diff. A live PostgreSQL replacement was not performed or required by this review; its unchanged live status must remain explicit in delivery evidence.

The gateway path was checked beyond version strings. `gateway-entrypoint.js:24`–27 inherits the process environment into the child, and `apps/mezo-gateway/src/adapters/http.ts:5` uses ordinary default `fetch`. No custom dispatcher, CA or verification bypass was found in the reviewed application path. The archived exact Node source shows `--use-openssl-ca` calling `X509_STORE_set_default_paths`; its system certificate enumeration reads the effective OpenSSL file and directory. See `research-sources/node-v24.18.1-crypto_context.cc` and `research-sources/node-v24.18.1-tls.js`.

The final checker reports **118 distinct** runtime gateway anchors for both parent and child, with none of the four incident root fingerprints. Earlier output of 472 represented duplicate certificate entries, not 472 distinct trust anchors. The compiled Node bundle may still contain distrusted certificates; their presence in an unused bundle is not proof that default fetch trusts them under this explicit mode. Operator overrides or application changes to TLS configuration would require renewed verification.

No authentication, payment, unknown-state, WalletConnect, UI guard, SQL migration, database-volume or sealed-artifact behavior is edited in this source diff. This is bounded TLS and build/development trust remediation, not a fresh whole-product security audit.

## Evidence inspected and checks executed

The reviewer inspected `research.md`, primary-source excerpts and the hash-verified pip wheel contents, `incident-fingerprints.json`, `candidate-builds.json`, supplied green logs, the actual source diff and both added regression scripts. The source research distinguishes root DER fingerprints from Go's separate intermediate-public-key distrust logic; those identifiers were not conflated.

Independent commands used disposable containers with `--network none --read-only --cap-drop ALL`, mounting only the public checker/fixture scratch read-only. No running service was used.

| Independently checked retained image | Result |
| --- | --- |
| Capture `sha256:67521e77b33c6c108e18efdfe289f1d3969ccce73dd2ce5bdf353ff5995058c6` | Current Python guard passed: 118 system roots, 120 certifi roots, zero incident roots; pip and ensurepip absent. |
| Report `sha256:7a73e01b5a50c0a6cbeb490ee9f02c4207dfe67ac4280bc5256910ed044cd52c` | Same positive result. |
| Gateway `sha256:feb064a1b3498d01eef377088873c7a732bafda221fc487a112020ceca35fe20` | Final Node guard passed in parent and child: Node 24.18.1, OpenSSL 3.5.9, 118 distinct clean roots. Multiple-directory override failed closed as expected. |
| Edge `sha256:f510312ffa55e0dc4e8de2f8a8332d9b34f3a4b39d5319d69eb4763725dfb8bf` | `caddy build-info` confirmed patched Go version and the retained Caddy version. |

These are the explicitly identified earlier candidate images, not an assertion that the later v2 builds have identical identities. The supplied capture/report Python and BusyBox green logs were read; they reported two Python regressions and eight BusyBox cases passing for each image. They were not rerun merely to duplicate those results.

The native trust-guard test command was run with bytecode and pytest caching disabled against the snapshot: **4 passed in 0.48 seconds**. `git diff --check` passed for the reviewed source. Application payment/wallet suites were not rerun for this infrastructure-only source review.

## Limitations and remaining gate

- This review is bound to the dirty snapshot identified above. It cannot substitute for the requested later exact committed-candidate review or final image/source provenance checks. V2 rebuilds were still in progress during this source review.
- No full GitHub Actions workflow, final deployment smoke, live exchange request, quote, wallet action, payment, grant renewal or public publication was executed.
- No functional default-fetch handshake test was executed here. Node evidence establishes the selected store, root exclusion, default application path and child inheritance. The checker deliberately describes those facts rather than claiming a completed fetch or adversarial TLS handshake.
- No exploitation or compromised private-key material was used. Trust-anchor presence, trust-path relevance and demonstrated exploitation are distinct. The poisoned-store negative tests use public CA material only.
- No secrets, private grants, `.env` contents, wallet keys, password files, production dumps or live container environments were read. No production container, database, volume, deployment or repository source was changed by the reviewer.
- Runtime enumeration reflects the normal tested process configuration. Arbitrary external TLS overrides, trusted host configuration, newly injected roots, or custom application TLS contexts are outside that result.
- No fresh whole-stack clean certification is made. Existing scanner dispositions, unreachable-module findings, unrelated Node/toolchain vulnerabilities and earlier audit limitations remain separately accountable. The final gate must use the final candidate's scanner and runtime evidence rather than promote these bounded source checks into a broader claim.
