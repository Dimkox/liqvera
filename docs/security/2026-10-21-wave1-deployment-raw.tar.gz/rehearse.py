"""Exercise actual Docker create/switch/restore on loopback-only disposable web containers."""
import copy
import json
import subprocess
import time
import ops

name = 'liqvera-wave1-rehearsal-9ca9ced'
previous = name + '-previous'
image = ops.api('GET', '/images/' + ops.TAG + '/json')['Id']
subprocess.run(['docker', 'run', '-d', '--name', name, '--network', 'bridge',
    '-p', '127.0.0.1::8083', '--read-only', '--cap-drop', 'ALL',
    '--security-opt', 'no-new-privileges:true', '--tmpfs', '/tmp:rw,noexec,nosuid,size=8m',
    '--tmpfs', '/var/cache/nginx:rw,nosuid,size=8m', '--tmpfs', '/var/run:rw,nosuid,size=8m',
    '--health-cmd', 'wget -q -O /dev/null http://127.0.0.1:8083/healthz',
    '--health-interval', '1s', '--health-timeout', '3s', ops.OLD_IMAGE], check=True, stdout=subprocess.DEVNULL)
old = ops.inspect(name)
new = None
result = {}
try:
    ops.healthy(old['Id'])
    def entry():
        port = ops.inspect(name)['NetworkSettings']['Ports']['8083/tcp'][0]['HostPort']
        return subprocess.check_output(['curl', '--fail', '--silent', '--max-time', '10',
            'http://127.0.0.1:' + port + '/'], text=True)
    assert 'index-BQP4zj3R.js' in entry()
    cfg = copy.deepcopy(old['Config'])
    cfg['HostConfig'] = copy.deepcopy(old['HostConfig'])
    cfg['Image'] = image
    for key in ['Hostname', 'Domainname', 'ExposedPorts']:
        cfg.pop(key, None)
    cfg['NetworkingConfig'] = {'EndpointsConfig': {network: {'Aliases': data.get('Aliases') or []}
        for network, data in old['NetworkSettings']['Networks'].items()}}
    ops.api('POST', '/containers/' + old['Id'] + '/stop?t=10')
    ops.api('POST', '/containers/' + old['Id'] + '/rename?name=' + previous)
    new = ops.api('POST', '/containers/create?name=' + name, cfg)['Id']
    ops.api('POST', '/containers/' + new + '/start')
    ops.healthy(new)
    assert 'index-Dd1iIief.js' in entry()
    result['candidate_switch'] = 'PASS'
    ops.api('DELETE', '/containers/' + new + '?force=1')
    new = None
    ops.api('POST', '/containers/' + old['Id'] + '/rename?name=' + name)
    ops.api('POST', '/containers/' + old['Id'] + '/start')
    ops.healthy(old['Id'])
    assert 'index-BQP4zj3R.js' in entry()
    result.update(previous_container_restored='PASS', previous_asset_restored='PASS',
                  scope='Disposable loopback web containers; no production mutations',
                  previous_image=ops.OLD_IMAGE, candidate_image=image)
    ops.write_json(ops.OUT / 'rollback-rehearsal.json', result)
    print(json.dumps(result))
finally:
    if new:
        ops.api('DELETE', '/containers/' + new + '?force=1')
    ops.api('DELETE', '/containers/' + old['Id'] + '?force=1')
