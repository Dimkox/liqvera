"""Fault injection for operational recovery only. No Docker or network requests."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import ops

class RecoveryTest(unittest.TestCase):
    def test_transport_inspection_failure_is_retried_before_recovery(self):
        state = {'inspections': 0, 'restored': False}
        baseline = {'inventory': {'web': {'id': 'old'}}, 'image': 'candidate',
                    'manifest_sha256': 'before', 'previous_asset': 'old.js'}
        def inspect(name):
            if name == ops.NAME:
                state['inspections'] += 1
                if state['inspections'] == 1:
                    raise TimeoutError('Lost Docker response')
                return {'Id': 'old'}
            return {'Name': '/' + ops.NAME, 'State': {'Running': True}}
        with patch.object(ops, 'inspect', inspect), patch.object(ops, 'api'), \
             patch.object(ops, 'restore_manifest', lambda: state.update(restored=True)), \
             patch.object(ops, 'digest', lambda path: 'before'), patch.object(ops, 'healthy'), patch.object(ops, 'public_check'):
            ops.recover_old(baseline, True)
        self.assertTrue(state['restored'])

    def test_retained_candidate_cannot_remain_running_on_success(self):
        state = {'candidate_running': True, 'stop_calls': 0, 'old_started': False, 'canonical': 'new'}
        baseline = {'inventory': {'web': {'id': 'old'}}, 'image': 'candidate',
                    'manifest_sha256': 'before', 'previous_asset': 'old.js'}
        def inspect(name):
            if name == ops.NAME:
                return {'Id': state['canonical'], 'Image': 'candidate'}
            if name == 'new':
                return {'State': {'Running': state['candidate_running']}}
            return {'Name': '/' + (ops.NAME if state['canonical'] == 'old' else ops.PREVIOUS),
                    'State': {'Running': state['old_started']}}
        def api(method, path):
            if path.startswith('/containers/new/stop'):
                state['stop_calls'] += 1
                if state['stop_calls'] == 1:
                    raise TimeoutError('Stop failed before applying')
                state['candidate_running'] = False
            elif path.startswith('/containers/old/rename'):
                state['canonical'] = 'old'
            elif path.startswith('/containers/old/start'):
                self.assertFalse(state['candidate_running'])
                state['old_started'] = True
        with patch.object(ops, 'inspect', inspect), patch.object(ops, 'api', api), \
             patch.object(ops, 'restore_manifest'), patch.object(ops, 'digest', lambda path: 'before'), \
             patch.object(ops, 'healthy'), patch.object(ops, 'public_check'):
            ops.recover_old(baseline, True)
        self.assertTrue(state['old_started'])
        self.assertFalse(state['candidate_running'])

    def test_lost_create_delete_responses_reconcile_actual_container_state(self):
        state = {'canonical': 'new', 'old_running': False, 'manifest_restored': False}
        baseline = {'inventory': {'web': {'id': 'old'}}, 'image': 'candidate',
                    'manifest_sha256': 'before', 'previous_asset': 'old.js'}
        def inspect(name):
            if name == 'new':
                raise RuntimeError('Docker GET /containers/new/json: HTTP 404')
            if name == ops.NAME:
                return {'Id': state['canonical'], 'Image': 'candidate'}
            return {'Name': '/' + (ops.NAME if state['canonical'] == 'old' else ops.PREVIOUS),
                    'State': {'Running': state['old_running']}}
        def api(method, path):
            if method == 'DELETE':
                state['canonical'] = None
                raise RuntimeError('Lost deletion response')
            if '/rename?' in path:
                state['canonical'] = 'old'
            if path.endswith('/start'):
                state['old_running'] = True
        with patch.object(ops, 'inspect', inspect), patch.object(ops, 'api', api), \
             patch.object(ops, 'restore_manifest', lambda: state.update(manifest_restored=True)), \
             patch.object(ops, 'digest', lambda path: 'before'), patch.object(ops, 'healthy'), patch.object(ops, 'public_check'):
            ops.recover_old(baseline, False)
        self.assertEqual(state, {'canonical': 'old', 'old_running': True, 'manifest_restored': True})

    def test_removal_failure_does_not_skip_restart_or_manifest_restore(self):
        state = {'started': False, 'restored': False}
        baseline = {'inventory': {'web': {'id': 'old'}}, 'image': 'candidate', 'manifest_sha256': 'before', 'previous_asset': 'old.js'}
        def inspect(name):
            if name == ops.NAME:
                return {'Id': 'new', 'Image': 'candidate'}
            return {'Name': '/' + ops.PREVIOUS, 'State': {'Running': False}}
        def api(method, path):
            if path.endswith('/start'):
                state['started'] = True
            else:
                raise RuntimeError('Injected Docker failure')
        with patch.object(ops, 'inspect', inspect), patch.object(ops, 'api', api), \
             patch.object(ops, 'restore_manifest', lambda: state.update(restored=True)):
            with self.assertRaises(RuntimeError):
                ops.recover_old(baseline, False)
        self.assertTrue(state['started'] and state['restored'])

    def test_lost_pause_response_resumes_all_writers_and_gateway(self):
        names = ['liqvera-live-' + s + '-live-1' for s in ['gateway', 'report', 'evidence-capture']]
        state = {name: {'Running': True, 'Paused': False, 'Status': 'running', 'ExitCode': 0} for name in names}
        def inspect(name):
            return {'State': copy.deepcopy(state[name])}
        def api(method, path):
            name = path.split('/')[2]
            if '/stop?' in path:
                state[name].update(Running=False, Status='exited')
            elif path.endswith('/pause'):
                state[name]['Paused'] = True
                if 'evidence-capture' in name:
                    raise RuntimeError('Lost pause response')
            elif path.endswith('/unpause'):
                state[name]['Paused'] = False
            elif path.endswith('/start'):
                state[name].update(Running=True, Status='running')
        with tempfile.TemporaryDirectory() as directory:
            recovery = Path(directory)
            (recovery / 'baseline.json').write_text(json.dumps({'manifest_sha256': 'before'}))
            with patch.object(ops, 'RECOVERY', recovery), patch.object(ops, 'digest', lambda path: 'before'), \
                 patch.object(ops, 'inspect', inspect), patch.object(ops, 'api', api), patch.object(ops, 'healthy'):
                with self.assertRaises(RuntimeError):
                    ops.backup()
        self.assertTrue(all(value['Running'] and not value['Paused'] for value in state.values()))

if __name__ == '__main__':
    unittest.main()
