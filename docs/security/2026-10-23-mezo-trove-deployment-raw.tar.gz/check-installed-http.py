import hashlib,json,os,socket,subprocess,time,uuid,sys
from pathlib import Path
import httpx
from liqvera_evidence_report.evidence_bundle import verify_bundle_bytes
root=Path('/proof')
out=Path('/proof/native');out.mkdir()
for d in ['captures','artifacts']: (out/d).mkdir()
# Public synthetic authentication fixture for this isolated loopback test only.
fixture='liqvera_public_test_only_internal_fixture_20261023'
(out/'public-test-auth-fixture').write_text(fixture)
(out/'public-test-auth-fixture').chmod(0o600)
with socket.socket() as probe: probe.bind(('127.0.0.1',8081))
with socket.socket() as probe: probe.bind(('127.0.0.1',0)); report_port=probe.getsockname()[1]
source=os.environ['LIQVERA_TEST_ENGINE_COMMIT']
base={'PATH':os.environ['PATH']}
common={**base,'LIQVERA_SOURCE_MODE':'live-public','LIQVERA_CAPTURE_ROOT':str(out/'captures')}
logs=[];processes=[]
started=time.monotonic_ns()
try:
 for module,env in [('liqvera_public_capture.evidence_service',{**common,'LIQVERA_CAPTURE_HOST':'127.0.0.1','LIQVERA_CAPTURE_PORT':'8081'}),('liqvera_evidence_report.service',{**common,'LIQVERA_REPORT_HOST':'127.0.0.1','LIQVERA_REPORT_PORT':str(report_port),'LIQVERA_CAPTURE_URL':'http://127.0.0.1:8081','LIQVERA_ARTIFACT_ROOT':str(out/'artifacts'),'LIQVERA_ENGINE_COMMIT':source,'LIQVERA_INTERNAL_TOKEN_FILE':str(out/'public-test-auth-fixture'),'LIQVERA_MEZO_TROVES_ENABLED':'true','LIQVERA_MEZO_DEX_ENABLED':'true'})]:
  log=(out/(module+'.log')).open('wb');logs.append(log)
  processes.append(subprocess.Popen([sys.executable,'-m',module],env=env,cwd=root,stdout=log,stderr=log))
 with httpx.Client(trust_env=False,timeout=20) as client:
  for port in [8081,report_port]:
   for _ in range(60):
    try:
     if client.get(f'http://127.0.0.1:{port}/healthz').status_code==200:break
    except httpx.ConnectError:pass
    if any(p.poll() is not None for p in processes):raise RuntimeError('isolated service exited')
    time.sleep(.1)
   else:raise RuntimeError('isolated service startup failed')
  request={'report_id':str(uuid.uuid4()),'product_id':'trove_risk','borrower':'0xDA04759E54728B6636Fe48F7c9795c7B609bAaAa'}
  begin=time.monotonic_ns()
  response=client.post(f'http://127.0.0.1:{report_port}/internal/v1/reports',json=request,headers={'Authorization':'Bearer '+fixture})
  end=time.monotonic_ns()
  (out/'response.json').write_bytes(response.content)
  if response.status_code!=200:raise RuntimeError(f'native HTTP build failed: {response.status_code}')
  artifact=response.json();folder=out/'artifacts'/request['report_id'];bundle=(folder/'evidence.zip').read_bytes()
  built=verify_bundle_bytes(bundle,expected_report_sha256=artifact['report_sha256'])
  assert built.report_bytes==(folder/'report.json').read_bytes()
  assert built.document['request']=={'product_id':'trove_risk','borrower':request['borrower']}
  assert built.document['quality']['snapshot_status']=='VALID_FOR_SNAPSHOT_CALCULATION'
  assert hashlib.sha256(bundle).hexdigest()==artifact['bundle_sha256']
  result={'status':'PASS','source_commit':source,'http_status':response.status_code,'request':request,'block_number':built.document['trove_risk']['block_number'],'report_sha256':artifact['report_sha256'],'bundle_sha256':artifact['bundle_sha256'],'started_monotonic_ns':begin,'ended_monotonic_ns':end,'elapsed_ms':(end-begin)//1_000_000,'scope':'Installed candidate image: native isolated capture/report HTTP services and offline bundle replay, no source checkout mounted; no gateway settlement, wallet, payment or deployment.'}
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:
 for p in processes:p.terminate()
 for p in processes:
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 for log in logs:log.close()

while True: time.sleep(30)
