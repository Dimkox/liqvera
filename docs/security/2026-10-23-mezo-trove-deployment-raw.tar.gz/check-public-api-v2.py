"""One public unpaid Trove quote; no wallet, signature, settlement or entitlement."""
import base64,hashlib,json,re,subprocess,time,uuid
from pathlib import Path
import httpx
out=Path(__file__).parent/'public-api-v2';out.mkdir()
borrower='0xDA04759E54728B6636Fe48F7c9795c7B609bAaAa'
merchant='0xd7F52d1Ddb5dC8678191f14E439Fc5DB67541535'
# Generated capabilities stay only in memory and are never logged or published.
cap=base64.urlsafe_b64encode(__import__('os').urandom(32)).decode().rstrip('=')
other=base64.urlsafe_b64encode(__import__('os').urandom(32)).decode().rstrip('=')
key=str(uuid.uuid4());body={'product_id':'trove_risk','borrower':borrower,'expected_payer':borrower}
headers={'Origin':'https://liqvera.site','Authorization':'Bearer '+cap,'Connection':'close'}
started=time.monotonic_ns()
with httpx.Client(base_url='https://liqvera.site',trust_env=False,timeout=8,follow_redirects=False,limits=httpx.Limits(max_keepalive_connections=0)) as client:
 response=client.post('/v1/report-quotes',headers={**headers,'Idempotency-Key':key},json=body)
 initial=response.status_code;assert initial in [201,202],response.text
 status=response.json()
 if initial==202:
  request_id=status['report_request_id'];assert str(uuid.UUID(request_id))==request_id
  (out/'created-request.json').write_text(json.dumps({'report_request_id':request_id,'initial_status':initial})+'\n')
  for _ in range(80):
   time.sleep(.25)
   try:poll=client.get('/v1/report-requests/'+request_id,headers=headers)
   except httpx.TransportError:
    if time.monotonic_ns()-started>40_000_000_000:raise
    continue
   assert poll.status_code in [200,202]
   status=poll.json()
   if status['state']=='READY':break
   assert status['state']=='PREPARING',status
  else:raise RuntimeError('Public quote did not become ready')
  quote=client.get('/v1/report-quotes/'+status['quote_id'],headers=headers);assert quote.status_code==200
  q=quote.json()
 else:q=status
 ended=time.monotonic_ns();report_id=q['report_id'];assert str(uuid.UUID(report_id))==report_id
 assert q['preview']['product_id']=='trove_risk' and q['preview']['borrower']==borrower
 assert q['preview']['trove_status']=='ACTIVE' and q['state']=='READY'
 assert q['terms']['network']=='eip155:31611' and q['terms']['amount_atomic']=='10000000000000000'
 assert q['terms']['pay_to'].lower()==merchant.lower() and q['terms']['expected_payer']==borrower.lower()
 replay=client.post('/v1/report-quotes',headers={**headers,'Idempotency-Key':key},json=body);assert replay.status_code==201
 assert replay.json()['quote_id']==q['quote_id'] and replay.json()['report_id']==report_id
 conflict=client.post('/v1/report-quotes',headers={**headers,'Idempotency-Key':key},json={**body,'borrower':merchant});assert conflict.status_code==409
 invalid=client.post('/v1/report-quotes',headers={**headers,'Idempotency-Key':str(uuid.uuid4())},json={**body,'borrower':borrower.lower()});assert invalid.status_code==400
 hidden=client.get('/v1/report-quotes/'+q['quote_id'],headers={**headers,'Authorization':'Bearer '+other});assert hidden.status_code==404
 paywall=client.get('/v1/reports/'+report_id,headers=headers);assert paywall.status_code==402
 required=json.loads(base64.b64decode(paywall.headers['PAYMENT-REQUIRED'],validate=True));assert required['x402Version']==2
 terms=required['accepts'];assert len(terms)==1 and terms[0]['amount']=='10000000000000000' and terms[0]['network']=='eip155:31611'
 assert terms[0]['payTo'].lower()==merchant.lower()
 assert terms[0]['asset'].lower()=='0x118917a40faf1cd7a13db0ef56c86de7973ac503'
 (out/'quote.json').write_text(json.dumps(q,indent=2)+'\n')
 (out/'payment-required.json').write_text(json.dumps(required,indent=2)+'\n')
 result={'status':'PASS','initial_status':initial,'quote_id':q['quote_id'],'report_id':report_id,'report_sha256':q['report_sha256'],'bundle_sha256':q['bundle_sha256'],
  'started_monotonic_ns':started,'ended_monotonic_ns':ended,'elapsed_to_ready_ms':(ended-started)//1_000_000,
  'idempotent_replay_status':replay.status_code,'changed_body_status':conflict.status_code,'invalid_checksum_status':invalid.status_code,'other_scope_status':hidden.status_code,'unpaid_delivery_status':paywall.status_code,
  'payment_submitted':False,'scope':'Public native Trove preparation through READY and x402 402 only. The public SortedTroves borrower was used as an expected-payer test address; no ownership or wallet authorization is claimed.'}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
