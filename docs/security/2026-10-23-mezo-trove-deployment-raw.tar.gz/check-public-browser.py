import base64,functools,json,subprocess,threading,time,urllib.request,tempfile
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from websockets.sync.client import connect
import httpx
root=Path('/home/pall/projects/liqvera/.getzilla/runtime/mezo-trove-product')
scratch=Path('/home/pall/projects/liqvera/.getzilla/runtime/mezo-trove-rollout/published-browser');scratch.mkdir(mode=0o700,exist_ok=True)
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(root/'apps/mezo-web/dist'),**kw)
 def log_message(self,*args):pass
 def do_GET(self):
  if self.path=='/v1/capabilities':
   try:
    r=httpx.get('https://liqvera.site/v1/capabilities',timeout=5,trust_env=False)
    body=r.content;self.send_response(r.status_code);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
   except Exception:self.send_error(502)
  else:super().do_GET()
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
profile=Path(tempfile.mkdtemp(prefix='profile-',dir=scratch))
log=(scratch/'chrome.log').open('wb')
chrome=subprocess.Popen(['/usr/bin/google-chrome','--headless=new','--disable-gpu','--disable-extensions','--disable-sync','--disable-background-networking','--no-first-run','--no-default-browser-check','--password-store=basic','--remote-debugging-port=0',f'--user-data-dir={profile}','about:blank'],stdout=log,stderr=log)
exceptions=[];results=[]
try:
 deadline=time.monotonic()+45
 while not (profile/'DevToolsActivePort').exists():
  if chrome.poll() is not None:raise RuntimeError('Chrome exited; inspect task-owned log')
  if time.monotonic()>deadline:raise RuntimeError('Chrome startup timed out')
  time.sleep(.1)
 port=(profile/'DevToolsActivePort').read_text().splitlines()[0]
 targets=json.load(urllib.request.build_opener(urllib.request.ProxyHandler({})).open(f'http://127.0.0.1:{port}/json/list'))
 target=next(t for t in targets if t['type']=='page')
 with connect(target['webSocketDebuggerUrl'],open_timeout=5,proxy=None) as ws:
  serial=0
  def command(method,params=None):
   global serial
   serial+=1;request_id=serial;ws.send(json.dumps({'id':request_id,'method':method,'params':params or {}}))
   while True:
    reply=json.loads(ws.recv(timeout=10))
    if reply.get('method')=='Runtime.exceptionThrown':exceptions.append(reply['params']['exceptionDetails'].get('text'))
    if reply.get('id')==request_id:
     if 'error'in reply:raise RuntimeError(reply['error']['message'])
     return reply.get('result',{})
  def evaluate(expression):return command('Runtime.evaluate',{'expression':expression,'returnByValue':True,'awaitPromise':True}).get('result',{}).get('value')
  command('Page.enable');command('Runtime.enable')
  for width in [320,1280]:
   command('Emulation.setDeviceMetricsOverride',{'width':width,'height':1000,'deviceScaleFactor':1,'mobile':width==320})
   command('Page.navigate',{'url':'https://liqvera.site/'})
   deadline=time.monotonic()+45
   while not evaluate('Boolean(document.querySelector("#trove-tab"))'):
    if time.monotonic()>deadline:raise RuntimeError('Preview button missing')
    time.sleep(.1)
   evaluate('document.querySelector("#trove-tab").click(); document.querySelector("#trove-preview-button").click()')
   while not evaluate('document.querySelector(".trove-risk")?.textContent.includes("16323457")'):
    if time.monotonic()>deadline:raise RuntimeError('Mezo preview missing')
    time.sleep(.1)
   state=evaluate('({width:innerWidth,clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,heading:document.querySelector(".trove-risk h3").textContent,links:[...document.querySelectorAll(".trove-risk a")].map(a=>a.href),text:document.querySelector(".trove-risk").textContent})')
   assert state['scrollWidth']<=state['clientWidth'],state
   assert len(state['links'])==4 and all(u.startswith('https://explorer.test.mezo.org/') for u in state['links'])
   assert '16323457'in state['text']
   state.pop('text');results.append(state)
   evaluate('document.querySelector(".trove-risk").scrollIntoView({block:"start"})')
   screenshot=command('Page.captureScreenshot',{'format':'png','captureBeyondViewport':False})
   (scratch/f'preview-{width}.png').write_bytes(base64.b64decode(screenshot['data']))
  assert not exceptions,exceptions
 (scratch/'result.json').write_text(json.dumps({'status':'PASS','scope':'Published HTTPS Trove preview; real sealed native proof and pinned downloads, no wallet or payment','views':results,'runtime_exceptions':exceptions},indent=2)+'\n')
 print(json.dumps({'status':'PASS','views':results,'runtime_exceptions':exceptions}))
finally:
 chrome.terminate()
 try:chrome.wait(timeout=5)
 except subprocess.TimeoutExpired:chrome.kill();chrome.wait()
 log.close();server.shutdown();server.server_close()
