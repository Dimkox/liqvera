import base64,hashlib,json
from pathlib import Path
out=Path(__file__).parent
images=json.loads((out/'image-provenance.json').read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
rows=[];bindings=[]
for service,image in images.items():
 t=json.loads((out/f'{service}-trivy.json').read_text());g=json.loads((out/f'{service}-grype.json').read_text());target=g['source']['target'];cfg_raw=base64.b64decode(target['config']);cfg=json.loads(cfg_raw)
 assert t['Metadata']['ImageID']==image['image']==target['userInput']
 assert 'sha256:'+hashlib.sha256(cfg_raw).hexdigest()==target['imageID']
 assert cfg['rootfs']['diff_ids']==image['rootfs_layers']
 assert target['labels']['org.opencontainers.image.revision']==image['source_commit']
 assert not [v for r in t.get('Results',[]) for v in r.get('Vulnerabilities',[])]
 bindings.append({'service':service,'docker_image':image['image'],'grype_config':target['imageID'],'rootfs_matches':True,'trivy_sha256':digest(out/f'{service}-trivy.json'),'grype_sha256':digest(out/f'{service}-grype.json')})
 for match in g['matches']:
  cve=match['vulnerability']['id'];package=match['artifact']['name']
  if cve=='CVE-2025-60876' and package in ['busybox','busybox-binsh','ssl_client']:
   state='fixed_by_backport';reason='Retained BusyBox upstream URL guard; exact-image binary regressions pass. APK version deliberately retains the vendor identity.';evidence=f'{service}-regressions.log' if service in ['capture','report'] else 'busybox-all-images.log'
  elif service in ['capture','report'] and package=='python' and cve in ['CVE-2025-15367','CVE-2026-12345']:
   state='fixed_by_backport';reason='Retained CPython poplib/tempfile upstream corrections; exact-image before/after behavior regressions pass.';evidence=f'{service}-regressions.log'
  elif service=='gateway' and package=='ada-libs' and cve=='CVE-2024-9410':
   state='not_affected_package_mismatch';reason='Installed ada-url URL parser is unrelated to the Ada.cx AI chatbot Sentry integration named by this advisory.';evidence='gateway-ada-package.log'
  elif service=='web' and package=='curl' and cve=='CVE-2026-92392':
   state='not_affected_configuration';reason='Vulnerable curl remains installed but unused: nginx is not linked to libcurl, its entrypoint/config contains no curl invocation, and health uses BusyBox wget. No HTTP/2 upload path exists in this static runtime. This is a configuration disposition, not a package patch.';evidence='web-curl-reachability.log'
  else:raise RuntimeError(f'Untriaged finding: {service} {cve} {package}')
  rows.append({'service':service,'image':image['image'],'id':cve,'package':package,'version':match['artifact']['version'],'raw_severity':match['vulnerability']['severity'],'status':state,'reason':reason,'evidence':'inherited-runtime/'+evidence,'evidence_sha256':digest(out/'inherited-runtime'/evidence)})
(out/'scan-dispositions.json').write_text(json.dumps({'source_commit':next(iter(images.values()))['source_commit'],'trivy_findings':0,'grype_raw_findings':len(rows),'untriaged_findings':0,'image_bindings':bindings,'dispositions':rows},indent=2)+'\n')
print('Bound scan occurrences:',len(rows),'; untriaged: 0')
