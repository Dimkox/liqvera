import hashlib,json,re,subprocess
from pathlib import Path
out=Path(__file__).parent
images=json.loads((out/'images.json').read_text())
source=images['source_commit']
root=Path('/home/pall/projects/liqvera/.getzilla/runtime/mezo-trove-product')
subprocess.run(['git','merge-base','--is-ancestor',source,'origin/main'],cwd=root,check=True)
html=subprocess.check_output(['docker','run','--rm','--pull=never','--network','none','--read-only','--cap-drop','ALL','--entrypoint','/bin/busybox',images['images']['web']['image'],'cat','/usr/share/nginx/html/index.html'],text=True)
assets=re.findall(r'<script\b[^>]*\bsrc="/assets/([^\"]+)"',html);assert len(assets)==1
scan=json.loads((out/'scan-dispositions.json').read_text());assert scan['untriaged_findings']==0
native=json.loads((out/'installed-http-v2/result.json').read_text())
assert native['source_commit']==source and native['http_status']==200 and native['status']=='PASS'
assert json.loads((out/'native-http-offline-verify.log').read_text())['status']=='INTEGRITY_REPRODUCED'
assert json.loads((out/'web-final-http.json').read_text())['status']=='PASS'
for filename in ['capture-regressions.log','report-regressions.log','gateway-tls.log','preview-image-offline-verify.log','trove-evidence-offline-verify.log']:
 assert (out/filename).is_file()
ci=json.loads(subprocess.check_output(['gh','run','view','40009751538','--repo','Dimkox/liqvera','--json','status,conclusion,headSha'],text=True));assert ci=={'conclusion':'success','headSha':source,'status':'completed'}
main_ci=json.loads(subprocess.check_output(['gh','run','view','40010846187','--repo','Dimkox/liqvera','--json','status,conclusion,headSha'],text=True));assert main_ci['status']=='completed' and main_ci['conclusion']=='success'
(out/'ci.json').write_text(json.dumps({'pull_request':23,'source_commit':source,'pull_request_run':40009751538,'main_run':40010846187,'main_commit':main_ci['headSha'],'status':'PASS'},indent=2)+'\n')
qa={'source_commit':source,'status':'PASS','native_installed_http':native,'native_offline_status':'INTEGRITY_REPRODUCED','web_image_http':json.loads((out/'web-final-http.json').read_text()),'runtime_evidence_reuse':'Exact critical binary/config bytes match; inherited gateway/web runtime facts are explicit. Python security behavior checks ran on new images.','harness_corrections':['Initial host-only check could not bind occupied port and made no request.','First installed test internally verified its report but docker cp cannot export this tmpfs; second test uses bounded tar streaming.','Exported 0640 artifact was unreadable by unrelated host UID/group in a fresh verifier container; a public 0644 byte-identical export verified successfully. Original artifact modes are unchanged.']}
(out/'candidate-validation.json').write_text(json.dumps(qa,indent=2)+'\n')
b=json.loads((out/'release-binding.json').read_text());b.update({'source_commit':source,'images':images['images'],'draft':False,'asset':assets[0],'security_untriaged_findings':0,'ci_success':True,'ci_source_commit':source,'ci_run_id':40009751538,'main_ci_run_id':40010846187,'main_ci_commit':main_ci['headSha'],'main_ci_success':True,'scan_dispositions_sha256':hashlib.sha256((out/'scan-dispositions.json').read_bytes()).hexdigest(),'candidate_validation_sha256':hashlib.sha256((out/'candidate-validation.json').read_bytes()).hexdigest()})
(out/'release-binding.json').write_text(json.dumps(b,indent=2)+'\n')
print(json.dumps({'source_commit':source,'asset':assets[0],'main_ci':'PASS','candidate_validation':'PASS','security_untriaged':0}))
