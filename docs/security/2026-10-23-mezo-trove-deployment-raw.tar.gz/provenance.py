import hashlib,json,shutil,subprocess
from pathlib import Path
out=Path(__file__).parent
old=out.with_name('mezo-dex-rollout-v2')
previous=json.loads((old/'image-provenance.json').read_text())
images=json.loads((out/'images.json').read_text())['images']
web_files=[line.split('  ',1)[1] for line in (old/'web-runtime-critical-files.log').read_text().splitlines()]
checks=[]
for service,data in images.items():
 info=json.loads(subprocess.check_output(['docker','image','inspect',data['image']]))[0]
 assert info['Config']['Labels']['org.opencontainers.image.revision']==data['source_commit']
 data.update(rootfs_layers=info['RootFS']['Layers'],architecture=info['Architecture'],os=info['Os'])
 paths=['/bin/busybox']
 if service=='gateway':paths+=['/usr/lib/libada.so.4','/usr/bin/node']
 if service=='web':paths=web_files+['/usr/lib/libcurl.so.4']
 outputs=[]
 for image in [previous[service]['image'],data['image']]:
  value=subprocess.check_output(['docker','run','--rm','--pull=never','--network','none','--read-only','--cap-drop','ALL','--entrypoint','/bin/busybox',image,'sha256sum',*paths],text=True)
  outputs.append(value)
 assert outputs[0]==outputs[1],f'Changed inherited runtime proof bytes: {service}'
 checks.append({'service':service,'previous_image':previous[service]['image'],'current_image':data['image'],'files':{line.split('  ',1)[1]:line.split('  ',1)[0] for line in outputs[1].splitlines()},'scope':'Exact critical runtime bytes only; application files changed. Earlier runtime facts remain explicitly inherited.'})
(out/'image-provenance.json').write_text(json.dumps(images,indent=2)+'\n')
(out/'runtime-evidence-reuse.json').write_text(json.dumps(checks,indent=2)+'\n')
reuse=out/'inherited-runtime';reuse.mkdir(exist_ok=True)
for filename in ['busybox-all-images.log','gateway-ada-package.log','web-curl-reachability.log']:
 shutil.copyfile(old/'inherited-runtime'/filename,reuse/filename)
for service in ['capture','report']:shutil.copyfile(out/(service+'-regressions.log'),reuse/(service+'-regressions.log'))
print('Critical inherited runtime bytes match for all four images; new Python behavior regressions passed separately')
