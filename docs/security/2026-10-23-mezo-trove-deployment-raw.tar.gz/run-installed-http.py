import json,re,subprocess,time,uuid,tarfile
from pathlib import Path
out=Path(__file__).parent
image='liqvera-mezo-report:trove-d63860d7af70'
source='d63860d7af70b5ad12145b039131ac11f0d4e729'
revision=subprocess.check_output(['docker','image','inspect',image,'--format','{{index .Config.Labels "org.opencontainers.image.revision"}}'],text=True).strip();assert revision==source
name='liqvera-trove-installed-http-'+uuid.uuid4().hex[:12]
identity=None
try:
 identity=subprocess.check_output(['docker','run','--pull=never','-d','--name',name,'--label','liqvera.scope=disposable-installed-http','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--tmpfs','/tmp:rw,nosuid,nodev','--tmpfs','/proof:rw,nosuid,nodev,mode=1777','--mount','type=bind,source='+str(out/'check-installed-http.py')+',target=/qa.py,readonly','-e','LIQVERA_TEST_ENGINE_COMMIT='+source,'--entrypoint','python',image,'/qa.py'],text=True).strip()
 assert re.fullmatch('[0-9a-f]{64}',identity)
 for _ in range(100):
  ready=subprocess.run(['docker','exec',identity,'test','-f','/proof/native/result.json'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  if ready.returncode==0:break
  running=subprocess.check_output(['docker','inspect',identity,'--format','{{.State.Running}}'],text=True).strip()
  if running!='true':raise RuntimeError('Installed candidate test exited before producing a result')
  time.sleep(.25)
 else:raise RuntimeError('Installed candidate HTTP test exceeded its bounded wait')
 dest=out/'installed-http-v2';dest.mkdir()
 with (out/'installed-http-v2.tar').open('wb') as stream:
  subprocess.run(['docker','exec',identity,'/bin/busybox','tar','-C','/proof/native','-cf','-',
   'artifacts','captures','response.json','result.json','liqvera_public_capture.evidence_service.log','liqvera_evidence_report.service.log'],check=True,stdout=stream)
 with tarfile.open(out/'installed-http-v2.tar') as archive:
  members=archive.getmembers();assert len(members)<64 and sum(m.size for m in members)<10*1024*1024
  archive.extractall(dest,filter='data')
 result=json.loads((dest/'result.json').read_text());assert result['status']=='PASS';print(json.dumps(result))
finally:
 if identity is not None and re.fullmatch('[0-9a-f]{64}',identity):
  with (out/'installed-http-container-v2.log').open('wb') as log:subprocess.run(['docker','logs',identity],stdout=log,stderr=subprocess.STDOUT)
  subprocess.run(['docker','rm','-fv',identity],check=True,stdout=subprocess.DEVNULL)
