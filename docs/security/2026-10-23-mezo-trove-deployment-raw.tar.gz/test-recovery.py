"""Isolated Docker state-machine fault injection; never talks to the Docker daemon."""
import copy,importlib.util,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('trove_ops',Path(__file__).with_name('rollout.py'));ops=importlib.util.module_from_spec(spec);spec.loader.exec_module(ops)

class Model:
 def __init__(self,root,exposed=True,fault=None):
  self.root=root;self.items={};self.events=[];self.manifest='candidate';self.fault=fault;self.fault_used=False;self.seq=0
  self.old={}
  for svc in ops.SERVICES:
   ident='old-'+svc;running=svc not in ops.START_ORDER
   self.old[svc]=self.add(ident,svc,'old-'+svc,running,old=True)
   self.old[svc]['Name']='/'+ops.name(svc)+(('-before-'+ops.RUN_ID) if svc in ops.START_ORDER else '')
  self.baseline={'inventory':self.inventory_old(),'manifest_sha256':'before','walletconnect_sha256':'wc'}
  (root/'containers.before.json').write_text(json.dumps(self.old))
  for svc in ops.START_ORDER:
   if not exposed and svc=='gateway':continue
   cfg=self.config(svc)
   value=self.add('new-'+svc,svc,'new-'+svc,True);value['Config']=copy.deepcopy(cfg);value['HostConfig']=copy.deepcopy(cfg['HostConfig']);value['Name']='/'+ops.name(svc)
  if exposed:(root/'new-reader-exposed.json').write_text(json.dumps({'source_commit':ops.SOURCE,'binding_sha256':'binding'}))
 def add(self,ident,svc,image,running,old=False):
  val={'Id':ident,'Name':'/'+ops.name(svc),'Image':image,'Config':{'Env':['BASE=unchanged'],'Labels':{},'Cmd':['program']},'HostConfig':{'RestartPolicy':{'Name':'unless-stopped'},'NetworkMode':'container:old-gateway-net' if svc=='gateway' else 'network'},'NetworkSettings':{'Networks':{'network':{'Aliases':[svc]}}},'Mounts':[{'Type':'volume','Name':'retained-'+svc}],'State':{'Running':running,'Paused':False,'ExitCode':0,'Health':{'Status':'healthy'}},'RestartCount':0}
  self.items[ident]=val;return val
 def config(self,svc):return ops.candidate_config(svc,self.old[svc],self.old['gateway-net']['Id'])
 def inspect(self,ident):
  if ident in self.items:return self.items[ident]
  vals=[v for v in self.items.values() if v['Name']=='/'+ident]
  if not vals:raise RuntimeError('Docker inspect: HTTP 404')
  assert len(vals)==1;return vals[0]
 def inventory_old(self):return {s:{'id':v['Id'],'image':v['Image'],'health':'healthy','restart_count':0,'volumes':['retained-'+s]} for s,v in self.old.items()}
 def digest(self,path):
  if Path(path)==ops.MANIFEST:return self.manifest
  return {'compose.candidate.json':'candidate','compose.compatible.json':'compatible','release-binding.json':'binding'}.get(Path(path).name,'wc')
 def replace(self,path):self.manifest='compatible' if 'compatible' in Path(path).name else 'before'
 def api(self,method,path,body=None):
  assert method=='POST';event=None
  if path.startswith('/containers/create?name='):
   name=path.split('=',1)[1];assert not any(v['Name']=='/'+name for v in self.items.values())
   svc=body['Labels']['io.liqvera.rollout-service'];self.seq+=1;ident='created-'+str(self.seq)
   val=self.add(ident,svc,'new-'+svc,False);val['Name']='/'+name;val['Config']=copy.deepcopy(body);val['HostConfig']=copy.deepcopy(body['HostConfig'])
   event=('create',svc,body['Labels']['io.liqvera.recovery-role']);result={'Id':ident}
  else:
   ident,action=path[len('/containers/'):].split('/',1);val=self.inspect(ident);svc=val['Config'].get('Labels',{}).get('io.liqvera.rollout-service') or ident.removeprefix('old-')
   if action.startswith('stop'):
    val['State']['Running']=False;event=('stop',svc,ident)
   elif action.startswith('rename'):
    target=action.split('=',1)[1];assert not any(v['Name']=='/'+target and v['Id']!=ident for v in self.items.values());val['Name']='/'+target;event=('rename',svc,ident)
   elif action=='start':
    if (self.root/'new-reader-exposed.json').exists() and svc in ['gateway','report','web']:assert not ident.startswith('old-'),'Old reader started after exposure'
    if svc=='gateway':
     if not ident.startswith('old-'):assert (self.root/'new-reader-exposed.json').exists()
     assert not any(v['State']['Running'] and v['Id']!=ident and v['Config'].get('Labels',{}).get('io.liqvera.rollout-service')=='gateway' for v in self.items.values())
    elif svc in ['report','web','evidence-capture']:
     assert not any(v['State']['Running'] and v['Config'].get('Labels',{}).get('io.liqvera.rollout-service')=='gateway' for v in self.items.values()),'Dependency changed before draining gateway'
    val['State']['Running']=True;event=('start',svc,ident)
   else:raise AssertionError(action)
   result=None
  self.events.append(event)
  if self.fault and not self.fault_used and self.fault(event):self.fault_used=True;raise TimeoutError('Injected lost reply after operation')
  return result
 def patches(self):
  return patch.multiple(ops,RECOVERY=self.root,MANIFEST=self.root/'manifest.json',WC=self.root/'walletconnect.env',
   image_for=lambda svc:'new-'+svc,inspect=self.inspect,api=self.api,guard_baseline=lambda b:None,
   digest=self.digest,replace_manifest=self.replace,healthy=lambda ident:None,public_check=lambda *a,**k:None)
 def assert_floor(self,test):
  ids={}
  for svc in ['gateway','report','web']:
   val=self.inspect(ops.name(svc));test.assertEqual(val['Image'],'new-'+svc);test.assertTrue(val['State']['Running']);test.assertFalse(self.old[svc]['State']['Running']);ids[svc]=val['Id']
   if svc in ['gateway','report']:
    test.assertEqual(dict(e.split('=',1) for e in val['Config']['Env'])['LIQVERA_MEZO_TROVES_ENABLED'],'false')
    test.assertEqual(val['Config']['Labels']['io.liqvera.recovery-role'],'compatible')
  test.assertEqual(self.inspect(ops.name('gateway'))['HostConfig']['NetworkMode'],'container:old-gateway-net')
  test.assertEqual(self.inspect(ops.name('evidence-capture'))['Id'],'old-evidence-capture')
  test.assertEqual(self.manifest,'compatible');return ids

class RecoveryTests(unittest.TestCase):
 def test_preexposure_can_restore_original_readers(self):
  with tempfile.TemporaryDirectory() as d:
   # image_for is needed while constructing candidate configs.
   with patch.object(ops,'image_for',lambda svc:'new-'+svc):m=Model(Path(d),False)
   with m.patches():ops.recover_old(m.baseline)
   for svc in ops.SERVICES:self.assertEqual(m.inspect(ops.name(svc))['Id'],'old-'+svc)
 def test_repeated_floor_preserves_new_web_and_stable_reader_ids(self):
  self.run_floor()
 def test_lost_primary_gateway_rename_reply_is_reconciled(self):
  self.run_floor(lambda e:e==('rename','gateway','new-gateway'))
 def test_lost_compatible_gateway_create_reply_is_adopted(self):
  self.run_floor(lambda e:e==('create','gateway','compatible'))
 def test_failed_report_start_then_recovery_does_not_restore_old_readers(self):
  with tempfile.TemporaryDirectory() as d:
   with patch.object(ops,'image_for',lambda svc:'new-'+svc):m=Model(Path(d))
   with m.patches():
    def unhealthy(ident):
     if m.inspect(ident)['Config']['Labels'].get('io.liqvera.rollout-service')=='report':raise TimeoutError('injected unhealthy report')
    with patch.object(ops,'healthy',unhealthy):
     with self.assertRaises(TimeoutError):ops.recover_old(m.baseline)
    ops.recover_old(m.baseline);ids=m.assert_floor(self);ops.recover_old(m.baseline);self.assertEqual(ids,m.assert_floor(self))
 def test_public_failure_after_compatible_manifest_is_retryable(self):
  with tempfile.TemporaryDirectory() as d:
   with patch.object(ops,'image_for',lambda svc:'new-'+svc):m=Model(Path(d))
   with m.patches():
    with patch.object(ops,'public_check',side_effect=TimeoutError('public check failed')):
     with self.assertRaises(TimeoutError):ops.recover_old(m.baseline)
    ids=m.assert_floor(self);ops.recover_old(m.baseline);self.assertEqual(ids,m.assert_floor(self))
 def test_exposure_marker_precedes_lost_new_gateway_start_reply(self):
  with tempfile.TemporaryDirectory() as d:
   with patch.object(ops,'image_for',lambda svc:'new-'+svc):m=Model(Path(d),True,lambda e:e==('start','gateway','new-gateway'))
   (Path(d)/'new-reader-exposed.json').unlink();m.items['new-gateway']['State']['Running']=False
   with m.patches():ops.reconcile_start('new-gateway');ops.recover_old(m.baseline);m.assert_floor(self)
   self.assertTrue(m.fault_used)
 def run_floor(self,fault=None):
  with tempfile.TemporaryDirectory() as d:
   with patch.object(ops,'image_for',lambda svc:'new-'+svc):m=Model(Path(d),True,fault)
   with m.patches():
    ops.recover_old(m.baseline);ids=m.assert_floor(self);ops.recover_old(m.baseline);self.assertEqual(ids,m.assert_floor(self))
   if fault:self.assertTrue(m.fault_used)


class RestartPolicies(unittest.TestCase):
 def test_retained_original_cannot_use_always_restart(self):
  for policy in ['unless-stopped','no']:
   ops.require_manual_stop_policy({'HostConfig':{'RestartPolicy':{'Name':policy}}})
  for policy in ['always','on-failure','']:
   with self.assertRaises(AssertionError):ops.require_manual_stop_policy({'HostConfig':{'RestartPolicy':{'Name':policy}}})

class PublicChecks(unittest.TestCase):
 def test_candidate_checks_both_immutable_pairs_and_product(self):self.check(False)
 def test_compatible_checks_new_browser_and_disabled_creation(self):self.check(True)
 def test_changed_trove_zip_is_rejected(self):
  with self.assertRaises(AssertionError):self.check(False,True)
 def check(self,compatible,corrupt=False):
  import re
  policy=re.search(r'Content-Security-Policy "([^"]+)"',(ops.ROOT/'deploy/mezo-evidence/Caddyfile').read_text()).group(1)
  cap={'network':'eip155:31611','source_mode':'live-public','amount_atomic':'10000000000000000',
   'payment_ready':True,'asset':'0x118917a40FAF1CD7a13dB0Ef56C86De7973Ac503'}
  if not compatible:cap['products']=['market_depth','trove_risk']
  seen=[]
  def fetch(path):
   seen.append(path)
   if path=='/':return b'<script src="/assets/new-asset.js"></script>'
   if path=='/v1/capabilities':return json.dumps(cap).encode()
   if path=='/readyz':return b'{"ready":true,"payment_ready":true}'
   if path=='/healthz':return b'{}'
   raw=(ops.ROOT/'apps/mezo-web/public'/path.lstrip('/')).read_bytes()
   if corrupt and path==ops.BINDING['trove_preview_prefix']+'evidence.zip':return raw+b'x'
   return raw
  with patch.object(ops,'fetch',fetch),patch.object(ops.subprocess,'check_output',return_value='Content-Security-Policy: '+policy):
   ops.public_check('new-asset.js',candidate=True,compatible=compatible)
  self.assertIn(ops.BINDING['trove_preview_prefix']+'evidence.zip',seen)

if __name__=='__main__':unittest.main()
